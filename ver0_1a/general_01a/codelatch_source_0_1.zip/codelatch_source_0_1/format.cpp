//!----------------------------------------------------------------------------
//! file: format.cpp
//!
//! Implements source code formatting.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------


// Styles
// ---------------------------
// A1 = Allman
// A2 = Java
// A3 = Kernighan & Ritchie
// A4 = Stroustrup
// A5 = Whiteshmit
// A6 = Banner
// A7 = GNU
// A8 = Linux
// A9 = Hostmann
// A10 = One True Brace
// A11 = Pico
// A12 = Lisp
//
// Options
// ------------------------------------------------
// s = indent using space characters (s6 = use six spaces) can be 2..20, default is 4.
// t = ** indent using tab characters (t6 = use six spaces) can be 2..20, default is 4.
// T = use only tab indents

// C = ** indent classes
// S = ** indent switch statement contents
// K = indent cases
// L = indent labels
// Y = ** align comment indents with code

// p = insert space around operators
// P = insert space around parenthesis
// H = insert space after if, for, while statements
// U = remove extra space between parenthesis

// k1 = align pointer * with type
// k2 = align pointer * in middle
// k3 = align pointer * with variable

// W0 = align pointer * function type none
// W1 = align pointer * with type in function return
// W2 = align pointer * in middle in function return
// W3 = align pointer * with function name in function return

// ** deemed manditory

#include "format.h"
#include "utility/fileutility.h"
#include <QFile>
#include <QTextStream>
#include <QProcess>
#include <QTimer>
#include "programconfig.h"


Format::Format(QObject *parent) :
    QObject(parent)
{
}

QString Format::run(QString &input, bool &ok, QString pathname, int timeout_ms)
{
    if(input.trimmed().isEmpty())
    {
        ok = true;
        return QString();
    }

    // get a couple unique file names
    QString ext;
    int i = pathname.lastIndexOf('.');
    if(i != -1)
        ext = pathname.right(pathname.length()-i);
    QString srcName = FileUtility::getUniqueTempFilename(ext);
    QString origName = srcName+".orig";

    QFile srcFile(srcName);
    QFile origFile(origName);

    // write text to temp file
    srcFile.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream src(&srcFile);
    src << input;
    src.flush();
    srcFile.flush();
    srcFile.close();

    QProcess *process = new QProcess(this);    
    process->setWorkingDirectory(FileUtility::getDirHome());
    QString cmd = "\"" + FileUtility::getDirTools() + "/astyle\"";
    cmd += " -A1tCSYpHU \"" + srcName + "\"";
    // create an event loop to monitor the process
    QTimer timer;
    connect(&timer, SIGNAL(timeout()), this, SLOT(eventLoopTimeout()));
    connect(process,SIGNAL(finished(int)),this,SLOT(processFinished(int)));

    // launch the process
    process->start(cmd);

    // check for an error 0=failed to start, 1=crashed, 2=timeout,
    // 3=read error, 4=write error, 5=unknown(default if no error)
    QProcess::ProcessError error = process->error();
    if(error != QProcess::UnknownError)
    {
        ok = false;
        qDebug() << "astyle startup error:" << error;
        return QString();
    }

    if(!process->waitForStarted(750))
    {
        // process didn't start
        disconnect(&timer, SIGNAL(timeout()), this, SLOT(eventLoopTimeout()));
        disconnect(process,SIGNAL(finished(int)),this,SLOT(processFinished(int)));
        if(srcFile.exists()) srcFile.remove();
        if(origFile.exists()) origFile.remove();
        ok = false;
        process->deleteLater();
        qDebug() << "ERROR: couldn't run AStyle";
        return QString();
    }
    // run the event loop
    timer.start(timeout_ms);
    int ret = eventLoop.exec(); // 0=timeout 1=process finished
    disconnect(&timer, SIGNAL(timeout()), this, SLOT(eventLoopTimeout()));
    disconnect(process,SIGNAL(finished(int)),this,SLOT(processFinished(int)));
    timer.stop();

    process->deleteLater();

    // if a timeout occurred or the file doesn't exist deal with it.
    if((ret == 0) || !srcFile.exists())
    {
        if(srcFile.exists()) srcFile.remove();
        if(origFile.exists()) origFile.remove();
        ok = false;
        return QString();
    }
    // read output file contents
    QString output;
    srcFile.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream dest(&srcFile);
    output = dest.readAll();
    srcFile.close();

    // delete temporary files
    if(srcFile.exists()) srcFile.remove();
    if(origFile.exists()) origFile.remove();

    ok = true;
    return output;
}

void Format::eventLoopTimeout()
{
    if(eventLoop.isRunning())
        eventLoop.exit(0);
}

void Format::processFinished(int ret)
{
    processReturnCode = ret;
    if(eventLoop.isRunning())
        eventLoop.exit(1);
}
