#ifndef ARCHIVE_H
#define ARCHIVE_H

#include <QObject>
#include <sys/types.h>
#include <utime.h>

class Archive : public QObject
{
    Q_OBJECT
public:
    explicit Archive(QObject *parent = 0);

    bool compress(const QString sourcePath, const QString outputFilePath, bool overwrite = false);
    bool expand(const QString sourceFilePath, QString outputFolderPath, bool overwrite = false);

    bool compress(const QString sourcePath, bool overwrite = false);
    bool expand(const QString sourceFilePath, bool overwrite = false);

signals:

public slots:

private:
    bool append(const QString &rootPath, const QString &inputPath, QDataStream &outputStream);
    bool appendFile(const QString &rootPath, const QString &inputPath, QDataStream &outputStream);
//    bool appendDir(const QString &rootPath, const QString &inputPath, QDataStream &outputStream);
//    bool isEmptyDirectory(const QString path);

    int fileCount;
};

#endif // ARCHIVE_H
