//!----------------------------------------------------------------------------
//! file: programconfig.cpp
//!
//! Loads and saves top level program info.
//! Data is stored in a global QMap variable "prgConfigMap".
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "programconfig.h"
#include <QFile>
#include <QTextStream>
#include <QDataStream>
#include <QApplication>
#include <QtGlobal>
#include <QDir>
#include <QDebug>
#include "utility/fileutility.h"

#define STR_CONFIG_FILE_NAME            "codelatch.config"

QMap<QString, QVariant> ProgramConfig_map;

//!-----------------------------------------------------------------------------
//! \brief Constructor, sets filename.
//!-----------------------------------------------------------------------------
ProgramConfig::ProgramConfig()
{
}

//!-----------------------------------------------------------------------------
//! \brief Load config list from disk
//!-----------------------------------------------------------------------------
bool ProgramConfig::load()
{
    QString homePath = FileUtility::getDirApp();
    QString configFile(homePath + "/" + QString(STR_CONFIG_FILE_NAME));
    QFile file(configFile);
    if (!file.open(QIODevice::ReadOnly))
        return false;

    QDataStream in(&file);
    in.setVersion(QDataStream::Qt_4_3);
    ProgramConfig_map.clear();
    in >> ProgramConfig_map;
    file.close();
    return true;
}

//!-----------------------------------------------------------------------------
//! \brief Save config list to disk
//!-----------------------------------------------------------------------------
bool ProgramConfig::save()
{
    QString homePath = FileUtility::getDirApp();
    QString configFile(homePath + "/" + QString(STR_CONFIG_FILE_NAME));
    QFile file(configFile);
    if (!file.open(QIODevice::WriteOnly))
        return false;

    QDataStream out(&file);
    out.setVersion(QDataStream::Qt_4_3);
    out << ProgramConfig_map;
    file.close();
    return true;
}

//!-----------------------------------------------------------------------------
//! \brief Get a config list item by key name
//!-----------------------------------------------------------------------------
QVariant ProgramConfig::get(QString key)
{
    return ProgramConfig_map.value(key,QVariant());
}

//!-----------------------------------------------------------------------------
//! \brief  Set a config list item by key name. If the item is not in the map
//!         it will be added. If it's already in the map it will be replaced.
//!-----------------------------------------------------------------------------
void ProgramConfig::set(QString key, QVariant value)
{
    ProgramConfig_map.insert(key,value);
}

//!-----------------------------------------------------------------------------
//! \brief Checks if a item is available by key name
//!-----------------------------------------------------------------------------
bool ProgramConfig::contains(QString key)
{
    return ProgramConfig_map.contains(key);
}

//!-----------------------------------------------------------------------------
//! \brief Clears all data
//!-----------------------------------------------------------------------------
void ProgramConfig::clear()
{
    ProgramConfig_map.clear();
}
