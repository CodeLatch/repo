#ifndef TARGET_H
#define TARGET_H

#include <QObject>
#include <QStringList>
#include <QMap>

class Target : public QObject
{
    Q_OBJECT
public:
    explicit Target(QObject *parent = 0); // default constructor
    Target(const Target &other, QObject *parent = 0);
    Target(QString name, QObject *parent = 0);
    Target(QMap<QString,QVariant> &map, QObject *parent = 0);

    bool load(QString name);
    bool save();
    bool saveAs(QString newName);
    bool erase();
    bool rename(QString newName);

    void setLibraryFiles(QStringList list) {libraryFiles = list;}
    void setStandardLibs(QStringList list) {standardLibs = list;}
    void setObjectFiles(QStringList list) {objectFiles = list;}
    void setExternalIncludeFolders(QStringList list) {externalIncludeFolders = list;}
    void setStartupFile(QString str) { startObjFile = str;}
    void setStubsFile(QString str) { stubsObjFile = str;}
    void setLinkerScriptFile(QString str) { linkerScriptFile = str;}
    void setDescription(QString str) {description = str;}
    void setGdbStartupCmds(QStringList list) {gdbStartupCmds.clear();gdbStartupCmds.append(list);}
    void setCompilerToolPrefix(QString str) {compilerToolPrefix = str;}
    void setFlashProgramTool(QString str) {flashProgramTool = str;}
    void setFlashProgramArgs(QString str) {flashProgramArgs = str;}
    void setGdbServerTool(QString str) {gdbServerTool = str;}
    void setGdbServerArgs(QString str) {gdbServerArgs = str;}
    void setMaxHWBreakpoints(int n) {maxHWBreakpoints = n;}
    void setUpdateLPCUserCode(bool b) {updateLPCUserCode = b;}

    void loadFromMap(QMap<QString,QVariant> &map);

    QStringList getExternalIncludeFolders() {return externalIncludeFolders;}
    QStringList getStandardLibs() {return standardLibs;}
    QStringList getLibraryFiles() {return libraryFiles;}
    QStringList getObjectFiles() {return objectFiles;}
    QStringList getGdbStartupCmds() {return gdbStartupCmds;}
    QString getStartupFile() {return startObjFile;}
    QString getStubsFile() {return stubsObjFile;}
    QString getLinkerScriptFile() {return linkerScriptFile;}
    QString getTargetName() {return targetName;}
    QString getPathname() {return pathname;}
    QString getDescription() {return description;}
    QString getCompilerToolPrefix() {return compilerToolPrefix;}
    QString getFlashProgramTool() {return flashProgramTool;}
    QString getFlashProgramArgs() {return flashProgramArgs;}
    QString getGdbServerTool() {return gdbServerTool;}
    QString getGdbServerArgs() {return gdbServerArgs;}
    int getMaxHWBreakpoints() {return maxHWBreakpoints;}
    bool getUpdateLPCUserCode() {return updateLPCUserCode;}

    QMap<QString, QVariant> getMap();


    static QStringList getTargetNames();
    static QString getDescription(QString targetName);

signals:
    
public slots:

private:
    QStringList gdbStartupCmds;
    QStringList libraryFiles;
    QStringList standardLibs;
    QStringList objectFiles;
    QStringList externalIncludeFolders;
    QString startObjFile;
    QString stubsObjFile;
    QString linkerScriptFile;
    QString targetName;
    QString pathname;
    QString description;
    QString compilerToolPrefix;
    QString flashProgramTool;
    QString flashProgramArgs;
    QString gdbServerTool;
    QString gdbServerArgs;
    int maxHWBreakpoints;
    bool updateLPCUserCode;
};


#endif // TARGET_H
