#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtGui>
#include <QTextEdit>
#include <QSplitter>
#include <QFuture>
#include <programconfig.h>
#include "navtree.h"
#include "Views/console.h"
#include <QTabWidget>
#include "sourceeditor.h"
#include <QComboBox>

//----------------------------------------------------------------------------
// STRING DEFINITIONS
//----------------------------------------------------------------------------
#define STR_PROGRAM_VER "CodeLatch Version 0.1"
#define STR_DIRTY_FILE  " *"

// File menu item text
#define STR_FILE_MENU_EXAMPLES              "Examples"
#define STR_FILE_MENU_PROJECTS              "Projects"
#define STR_FILE_MENU_LIBRARIES             "Libraries"

#define STR_FILE_MENU_PROJECT               "Project"
#define STR_FILE_MENU_PROJECT_NEW           "New Project"
#define STR_FILE_MENU_PROJECT_OPEN          "Open"
#define STR_FILE_MENU_PROJECT_SAVE          "Save"
#define STR_FILE_MENU_PROJECT_SAVE_AS       "SaveAs Project"
#define STR_FILE_MENU_PROJECT_CLOSE         "Close Project"
#define STR_FILE_MENU_PROJECT_ARCHIVE       "Archive"

#define STR_FILE_MENU_FILE                  "File"
#define STR_FILE_MENU_FILE_NEW              "New"
#define STR_FILE_MENU_FILE_OPEN             "Open"
#define STR_FILE_MENU_FILE_SAVE             "Save"
#define STR_FILE_MENU_FILE_SAVE_AS          "SaveAs"

#define STR_FILE_MENU_FILE_SAVE_ALL         "Save All"
#define STR_FILE_MENU_PRINT                 "Print..."

// Edit menu item text
#define STR_EDIT_MENU_UNDO                  "Undo"
#define STR_EDIT_MENU_REDO                  "Redo"
#define STR_EDIT_MENU_CUT                   "Cut"
#define STR_EDIT_MENU_COPY                  "Copy"
#define STR_EDIT_MENU_PASTE                 "Paste"
#define STR_EDIT_MENU_FIND_REPLACE          "Find / Replace"
#define STR_EDIT_MENU_GOTO_LINE             "Goto Line"
#define STR_EDIT_MENU_JUMP_TO_CODE          "Jump to code"
#define STR_EDIT_MENU_FORMAT_DOCUMENT       "Format Document"

// Tools menu item text
#define STR_TOOLS_MENU_RESET_VIEW           "Reset View"
#define STR_TOOLS_MENU_OPEN_HOME_FOLDER     "Open Home Folder"
#define STR_TOOLS_MENU_OPEN_REFERENCE       "Open Reference"
#define STR_TOOLS_MENU_CONFIGURE_EDITOR     "Configure Editor"
#define STR_TOOLS_MENU_AUTO_FORMAT          "Auto Format"
#define STR_TOOLS_MENU_AUTO_INDENT          "Auto Indent"
#define STR_TOOLS_MENU_REBUILD_MENU         "Update Project Menus"
#define STR_TOOLS_MENU_CHECK_FOR_UPDATES    "Downloads..."
#define STR_TOOLS_MENU_SET_MAIN_FOLDER      "Select Home Folder"
#define STR_TOOLS_MENU_ABOUT                "About"
#define STR_TOOLS_MENU_INDEX_PROJECT        "Index Project"
//----------------------------------------------------------------------------

class GdbServer;
class Debug;
class DataView;
class InfoView;
class TabManager;
class DeviceMonitor;
class ConsoleProcess;
class TerminalWindow;

class MainWindow : public QMainWindow
{
    Q_OBJECT

    enum MarkerTypes {
        DebugMarker = 8
    };
    struct LocationHistory {
        QString path;
        int col,row;
    };

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    NavTree *getNav() {return nav;}
    TabManager *getTabManager() {return tabManager;}

    QSplitter *getVSplitter() {return vSplit;}

protected:
    void closeEvent(QCloseEvent *event);
    void hideEvent(QHideEvent *);

private:
    QSplitter *vSplit, *hSplit;
    TabManager *tabManager;
    DataView *dataView;
    NavTree *nav;
    InfoView *infoView;
    QProcess *terminal;
    DeviceMonitor *terminalDeviceMonitor;
    DeviceMonitor *debugDeviceMonitor;

    QString activeTargetPath;

    QToolBar *fileToolBar, *formatToolBar, *buildToolBar;
    QToolBar *debugToolBar, *utilityToolBar;
    QMenu *fileMenu, *editMenu, *toolsMenu, *projectsMenu;
    QComboBox *targetSelCombo;

    bool actionInProgress;
    bool debugRunning;

    QFuture<void> indexerFuture;
    QList<LocationHistory> locationHistory;

    int infoViewSize;

public slots:

    // file menu slots
    void newFile();
    void newFolder();
    void openFile();
    void saveAsFile();
    void newProject();
    void openProject();
    void saveAsProject();
    void closeProject(Project *prj = NULL);
    void navContextMenuRename();

    // project build related slots
    void slotBuildComplete(bool retval, Project *prj);
    void slotDebugComplete(Debug *debug);

    // debug was in run mode and stopped.
    void slotDebugAtPrompt();

    void classViewTreeItemClicked(QModelIndex index);
    void projectIndexingComplete(Project *prj);

    void editorIndexFinished(SourceEditor *editor);
    void setStatusMessage(QString msg);

    void dataViewTabSelChanged(int index);

    void indexingComplete();

    void actionTest();
    void actionTestVar();
    void actionDeleteItem();
    void actionEditTarget();

    // edit menu actions
    void actionFind();
    void actionGoto();
    void actionUndo();
    void actionRedo();
    void actionCut();
    void actionCopy();
    void actionPaste();

    // menu/toolbar enable/disable helper functions
    void updateEditMenuState();
    void updateSaveSaveAll();
    void updateToolbarState();

    // view menu actions
    void viewReset();

    // toolbar actions
    void actionBuild();
    void actionClean();
    void actionOpenProjectConfig();
    void actionDownload();
    void actionDebug();
    void actionSelectProbe();
    void actionTerminal();
    void actionFormatDocument();

    // debug toolbar actions
    void actionDebugResume();
    void actionDebugSuspend();
    void actionDebugTerminate();
    void actionDebugStepOver();
    void actionDebugStepInto();
    void actionDebugStepReturn();
    void actionDebugStepMode();

    // navigator slots
//    void navItemDoubleClicked(QTreeWidgetItem* item,int col);
    void updateIndexViews();

    // dynamic menus
    void dynamicMenuItemSelected(QAction *action);
    void updateDynamicProjectMenu();

    void actionToggleLogging();
    void slotRequestFileOpen(QString pathname, int linenumber = 1, int col = 0);

    void downloadComplete();
private slots:
    void startupCheck();
    void changeHomeFolder();
    void setTarget(QString configName);
    void populateTargetSelCombo();
    void openHomeFolder();
    void openReference();
    void openEditorConfig();
    void showDownloadComponentsDlg();
    void runProjectIndexer(Project *prj);
    void projectAdded(Project *prj);
    void about();
    void printFile();
    void updateFileMenuState();
    void slotTerminalClosing();
    void minimizeInfoView();
    void restoreInfoView();
    void indexActiveProject();

    void testReadAll();
    void testReadStd();
    void testReadError();
    void testFinished(int ret, QProcess::ExitStatus status);

    void cleanAllProjects();
    void cleanProjectFolder(QString pathname);
    void archiveProject();

private:
    void createWidgets();
    void makeConnections();
    QString getTabWidgetPathname(QWidget *widget);
    QString getTabWidgetProjectFolder(QWidget *widget);
    void checkForComponents();

    void createActions();
    void createMenu();
    void createToolbar();
    void loadMainWindowConfig();
    void saveMainWindowConfig();
    int askToSaveDocument(QString pathname);
    bool closeTab(int index);
    bool closeAllTabs();
//    void saveFile(int tabIndex, bool runIndexer = false);
    void disableDebugRunTools();

    // utlity functions to enable or disable menu items and toolbar items
    QAction *getMenuAction(QMenu *menu, QString menuName);
    void enableAction(QMenu *menu, QString menuName);
    void disableAction(QMenu *menu, QString menuName);
    void enableAction(QToolBar *toolbar, QString toolName, bool enabled = true);
    void disableAction(QToolBar *toolbar, QString toolName);
    void setDebugInfoText(QString text);
    QString getDebugInfoText();
    void setStepModeIcon(bool mode);

    void changeMenuItemText(QMenu *menu, QString currentText, QString newText);

    void addDynamicMenuItems(QMenu *menu);
    void buildDynamicMenu(QMenu *menu, QString folderName);
    bool isProjectFolder(QString path);
    bool subsContainProjects(QString path);

    void updateDebugUi();
    QStringList runCtags(QStringList fileList);

    Debug *debug;

    static void threadBuildProject(Project *prj);
    static void threadDownloadProject(Project *prj);

    QProcess *debugProcess1;
    ConsoleProcess *debugProcess2;
    TerminalWindow *terminalWindow;
};

#endif // MAINWINDOW_H
