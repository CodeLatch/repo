//!----------------------------------------------------------------------------
//! file: navtree.cpp
//!
//! Implements project navigation tree with drag n drop capability.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "navtree.h"
#include "utility/fileutility.h"
#include "utility/projectnamedialog.h"
#include "programconfig.h"
#include <QDebug>
#include <QInputDialog>
#include <QFileInfo>
#include <QMenu>
#include <QMessageBox>
#include <QShortcut>
#include <QApplication>
#include <QSignalMapper>

//!-----------------------------------------------------------------------------
//! \brief Constructor. Handle some basic initialization.
//!-----------------------------------------------------------------------------
NavTree::NavTree(QWidget *parent) :
    QTreeWidget(parent)
{
    // enable drag n drop
    setAcceptDrops(true);
    setDragDropMode(QAbstractItemView::DragDrop);
    setDropIndicatorShown(true);

    // don't show blue outline when widget has the focus
    setAttribute(Qt::WA_MacShowFocusRect, 0);

    // allow multiple selections by holding down shift key.
    setSelectionMode(QAbstractItemView::ExtendedSelection);

    // setup dnd hover timer (for auto expanding folders feature)
    hoverItem = NULL;
    hoverTimer = new QTimer(this);
    hoverTimer->setSingleShot(true);
    connect(hoverTimer, SIGNAL(timeout()), this, SLOT(hoverTimerExpired()));

    connect (this, SIGNAL(itemDoubleClicked(QTreeWidgetItem*,int)), this, SLOT( navItemDoubleClicked(QTreeWidgetItem*,int)));
    connect (this, SIGNAL(itemClicked(QTreeWidgetItem*,int)), this, SLOT( navItemClicked(QTreeWidgetItem*,int)));
    connect (this, SIGNAL(itemSelectionChanged()), this, SLOT(slotItemSelectionChanged()));
}

//!-----------------------------------------------------------------------------
//! \brief Destructor.
//!-----------------------------------------------------------------------------
NavTree::~NavTree()
{
    // delete project objects
    for(int i=0;i<projectList.size();i++)
    {
        Project *prj = projectList.at(i);
        if(prj != NULL)
        {
            prj->close();
            prj->deleteLater();
            prj = NULL;
        }
    }
}


//!-----------------------------------------------------------------------------
//! \brief   Initialize the tree by creating the header and populating the tree
//!          with the projects listed in the global program config file.
//!-----------------------------------------------------------------------------
void NavTree::initializeTree()
{
    // initialize tree
    QTreeWidgetItem *headerItem = new QTreeWidgetItem;
    headerItem->setText(0,QString("Project"));
    // mem manage note: setHeaderItem makes this class parent of headerItem
    setHeaderItem(headerItem);

    if(ProgramConfig::contains(NAVIGATOR_OPEN_PROJECT_LIST))
    {
        QStringList list = ProgramConfig::get(NAVIGATOR_OPEN_PROJECT_LIST).toStringList();
        // each entry in the list should be a pathname to a project file.
        for(int i=0;i<list.size();i++)
        {
            QString pathname = list.at(i);
            addProject(pathname);
        }

        if(topLevelItemCount() > 0)
        {
            QTreeWidgetItem *item = topLevelItem(0);
            navItemClicked(item,0);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Navigator item was double clicked.
//!              This is the method for opening files via navigator ui.
//!-----------------------------------------------------------------------------
void NavTree::navItemDoubleClicked(QTreeWidgetItem* item,int col)
{
    Q_UNUSED(col); // avoid compiler warning for unused param

    // if this is a .c, .cpp, .h, or .hpp file open it with SourceEditor
    QString pathname = item->data(0,NavTree::FilePath).toString();
    QString projectFolder = item->data(0,NavTree::ProjectFolder).toString();
    Project *prj = getProjectFromFolder(projectFolder);
    if(prj == NULL) return;

    // activate or open file in tabManager
    emit doubleClicked(prj,pathname);
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Navigator item was clicked. The only thing we need to accomplish
//! is send out a signal with the associated item project and pathname.
//!-----------------------------------------------------------------------------
void NavTree::navItemClicked(QTreeWidgetItem* item,int col)
{
    Q_UNUSED(col); // avoid compiler warning for unused param

    // if this is a .c, .cpp, .h, or .hpp file open it with SourceEditor
    QString pathname = item->data(0,NavTree::FilePath).toString();
    QString projectFolder = item->data(0,NavTree::ProjectFolder).toString();
    Project *prj = getProjectFromFolder(projectFolder);
    if(prj == NULL) return;

    // activate or open file in tabManager
    emit singleClicked(prj,pathname);
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Navigator item selection was changed.
//!-----------------------------------------------------------------------------
void NavTree::slotItemSelectionChanged()
{
    QTreeWidgetItem *item = currentItem();
    if(item == NULL)
    {
        emit sigSelectionChanged(NULL,QString());
        return;
    }
    QString pathname = item->data(0,NavTree::FilePath).toString();
    QString projectFolder = item->data(0,NavTree::ProjectFolder).toString();
    Project *prj = getProjectFromFolder(projectFolder);

    emit sigSelectionChanged(prj,pathname);
}


//=============================================================================
//
//                       CONTEXT MENU ROUTINES
//
//=============================================================================

//!-----------------------------------------------------------------------------
//! \brief SLOT: User pressed right mouse button over tree, display
//!              context menu.
//!-----------------------------------------------------------------------------
void NavTree::contextMenuEvent(QContextMenuEvent *event)
{
    contextItem = itemAt(event->pos());
    // if we didn't right click over an item, do nothing.
    if(contextItem == NULL)
        return;

    QMenu menu(this);
    QString projectFolder = contextItem->data(0,NavTree::ProjectFolder).toString();
    QString pathname = contextItem->data(0,NavTree::FilePath).toString();
    QFileInfo info(pathname);
    QString filename = info.fileName();
    QFileInfo fileinfo(pathname);
    Project *prj = getProjectFromFolder(projectFolder);
    QSignalMapper mapper;

    menu.addAction("New File",this,SIGNAL(sigNewFile()));
    menu.addAction("New Folder",this,SIGNAL(sigNewFolder()));
    QAction *openFolderAction = menu.addAction("Open Containing Folder",&mapper,SLOT(map()));
    menu.addSeparator();

    mapper.setMapping(openFolderAction,pathname);
    connect(&mapper, SIGNAL(mapped(QString)),this, SLOT(openContainingFolder(QString)));

    if(pathname == projectFolder)
        menu.addAction("Save Project As",this,SIGNAL(sigProjectSaveAs()));
    else if(fileinfo.isFile())
        menu.addAction("Save File As",this,SIGNAL(sigFileSaveAs()));
    menu.addSeparator();
    if(prj == NULL) return;

    if(pathname == projectFolder)
        menu.addAction("Close Project",this,SLOT(slotCloseProject()));
    menu.addSeparator();

    // allow delete/rename of anything except the project.config file.
    if(filename != prj->getConfigFilename())
    {
        if(pathname == projectFolder)
        {
            menu.addAction("Delete Project",this,SIGNAL(sigDelete()));
            menu.addSeparator();
            menu.addAction("Rename Project",this,SIGNAL(sigRename()));
        }
        else
        {
            menu.addAction("Delete Item",this,SIGNAL(sigDelete()));
            menu.addSeparator();
            menu.addAction("Rename Item",this,SIGNAL(sigRename()));
        }
    }

    menu.exec(event->globalPos());
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void NavTree::openContainingFolder(QString pathname)
{
    QFileInfo info(pathname);
    if(info.exists())
        QDesktopServices::openUrl(QUrl::fromLocalFile(info.absolutePath()));
}

//=============================================================================
//
//                       CUT/COPY/PASTE ROUTINES
//
//=============================================================================

//!-----------------------------------------------------------------------------
//! \brief  Slot called when "cut" keystroke or menu selection activated.
//!-----------------------------------------------------------------------------
void NavTree::actionCut()
{
    QWidget *wPtr = QApplication::focusWidget();
    if(wPtr != this) return;
    pasteSourceList = selectedItems();
    pasteMove = true;
}

//!-----------------------------------------------------------------------------
//! \brief  Slot called when "copy" keystroke or menu selection activated.
//!-----------------------------------------------------------------------------
void NavTree::actionCopy()
{
    QWidget *wPtr = QApplication::focusWidget();
    if(wPtr != this) return;
    pasteSourceList = selectedItems();
    pasteMove = false;
}

//!-----------------------------------------------------------------------------
//! \brief  Slot called when "paste" keystroke or menu selection activated.
//!-----------------------------------------------------------------------------
void NavTree::actionPaste()
{
    QWidget *wPtr = QApplication::focusWidget();
    if(wPtr != this) return;

    if(pasteSourceList.size() == 0) return;

    // get destination, only allow one selection for destination.
    QList<QTreeWidgetItem *> destList = selectedItems();
    if(destList.size() != 1) return;
    QTreeWidgetItem *destItem = destList.at(0);

    // if the destination is not a folder use the items parent, which must be folder, as the paste target.
    if(!isFolder(destItem))
    {
        destItem = destItem->parent();
        if(!isFolder(destItem)) return;
    }
    // get destination path
    QString destPath = destItem->data(0,NavTree::FilePath).toString();
    if(destPath.isEmpty()) return;
    QDir destDir(destPath);
    if(!destDir.exists()) return;

    Project *destProject = getProject(destItem);
    if(destProject == NULL) return;

    QList<Project*> prjList;

    // make a list of source projects and source paths
    QStringList sourceList;
    foreach(QTreeWidgetItem *item,pasteSourceList)
    {
        QString sourcePath = item->data(0,NavTree::FilePath).toString();
        sourceList.append(sourcePath);
        Project *prj = getProject(item);
        if(!prjList.contains(prj) && (prj != NULL))
            prjList.append(prj);
    }

    // don't drop a source folder into a child folder
    if(isSourceParentOfDest(sourceList,destPath))
    {
        QMessageBox::information(this,"Error","Can't paste into child folder.");
        return;
    }

    // copy source files to destination
    foreach(QTreeWidgetItem *item,pasteSourceList)
    {
        QString sourcePath = item->data(0,NavTree::FilePath).toString();
        // if we are pasting an entire project...
        if(isProjectFolder(item))
        {
            if(sourcePath != destPath)
                QMessageBox::information(this,"Error","Can't paste a project into another project.");
            else if(pasteMove)
                QMessageBox::information(this,"Error","Can't cut a project, only copy.");
            else
            {
                // get a new project name
                ProjectNameDialog dlg;
                QFileInfo info(destPath);
                dlg.setInitialDirectory(info.path());
                dlg.setInitialName(info.fileName());
                dlg.setMessage("Enter new project name.");
                dlg.setTitle("Paste Project");
                if(!dlg.exec()) return;
                QString destPath = dlg.getProjectFolder();
                destPath.replace("\\","/");
                if(!destPath.isEmpty())
                {
                    FileUtility::copyDir(sourcePath,destPath);
                    addProject(destPath);
                    emit sigUpdateDynamicProjectMenu();
                }
            }
        }
        else
            copyFile(sourcePath,destPath,pasteMove);
    }

    // update projects and trees
    if(destProject != NULL)
    {
        destProject->update();
        updateProjectTree(destProject);
        destProject->runIndexer();
    }
    // only update source projects if we are cutting
    if(pasteMove)
    {
        foreach(Project *prj,prjList)
        {
            if(prj != NULL)
            {
                prj->update();
                updateProjectTree(prj);
                prj->runIndexer();
            }
        }
    }
    pasteSourceList.clear();
}

//!-----------------------------------------------------------------------------
//! \brief  Helper function to determine if a valid copy selection is selected.
//!-----------------------------------------------------------------------------
bool NavTree::hasCopySelection()
{
    QList<QTreeWidgetItem *> list = selectedItems();
    if(list.size() > 0)
        return true;
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief  Helper function to determine if a valid cut selection is selected.
//!-----------------------------------------------------------------------------
bool NavTree::hasCutSelection()
{
    QList<QTreeWidgetItem *> list = selectedItems();
    if(list.size() > 0)
    {
        // don't allow cut action of project level folders
        foreach(QTreeWidgetItem *item,list)
        {
            if(isProjectFolder(item))
                return false;
        }
        return true;
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief  Helper function to determine if a valid paste source is available.
//!-----------------------------------------------------------------------------
bool NavTree::hasPasteSource()
{
    // only allow a single selection for destination.
    QList<QTreeWidgetItem *> destList = selectedItems();
    if(destList.size() != 1)
        return false;
    // make sure we have something to paste
    if(pasteSourceList.size() > 0)
        return true;
    return false;
}

//=============================================================================
//
//                       DRAG AND DROP ROUTINES
//
//=============================================================================

//!-----------------------------------------------------------------------------
//! \brief SLOT:
//!          Drag and drop hover timer expired. This gets called if we hover
//!          over an expandable tree item for more than a set period of time
//!          while performing a dnd drag.
//!-----------------------------------------------------------------------------
void NavTree::hoverTimerExpired()
{
    if(hoverItem != NULL)
        hoverItem->setExpanded(true);
    hoverTimer->stop();
}

//!-----------------------------------------------------------------------------
//! \brief OVERRIDE:
//!          User entered tree area dragging something. Accept the drag if the
//!          data has urls (file support) or abstract data (tree items).
//!-----------------------------------------------------------------------------
void NavTree::dragEnterEvent(QDragEnterEvent *event)
{
    if(event->mimeData()->hasUrls() ||
            event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
        event->acceptProposedAction();
}

//!-----------------------------------------------------------------------------
//! \brief OVERRIDE:
//!          User is moving over tree with a dragged item. Enforce rules as
//!          to what can be dropped where. Manage auto-expand hover feature.
//!-----------------------------------------------------------------------------
void NavTree::dragMoveEvent(QDragMoveEvent *event)
{
    // default return
    Qt::DropAction action = Qt::IgnoreAction;

    // get destination item
    QTreeWidgetItem *destItem = itemAt(event->pos());

    // hover over expandable item expands item after timeout
    if((destItem == NULL) || (hoverItem == NULL) || (hoverItem != destItem))
    {
        hoverTimer->stop();
        hoverItem = destItem;
        if(hoverItem != NULL)
            if(hoverItem->childCount() > 0)
                if(!hoverItem->isExpanded())
                    hoverTimer->start(750);
    }  // else hoverItem == destItem != NULL so let the hoverTimer run if active

    // do nothing more if destItem is NULL
    if(destItem == NULL)
    {
        event->setDropAction(action);
        event->accept();
        return;
    }

    // if the destination is not a folder use the items parent, which must be folder, as the drop target.
    if(!isFolder(destItem))
    {
        destItem = destItem->parent();
        if(!isFolder(destItem))
        {
            event->setDropAction(action);
            event->accept();
            return;
        }
    }
    // get pathname of destination
    QString destpath = destItem->data(0,NavTree::FilePath).toString();

    // create a list of source pathnames
    QStringList sourcelist;

    // if file-item(s) are the drop source
    if (event->mimeData()->hasUrls())
    {
        foreach (QUrl url, event->mimeData()->urls())
        {
            QFileInfo fileinfo(url.path());
            if(fileinfo.exists() && (fileinfo.path() != "/"))
                sourcelist.append(url.path());
            // as a precautionary measure we will bail out if there's a large
            // number of files in the list, posing the possibility of user error.
            if(sourcelist.size() > 500)
            {
                event->setDropAction(action);
                event->accept();
                return;
            }
        }
    }
    // if tree-item(s) are the drop source
    else if (event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
    {
        //        QWidget *source = event->source();
        QObject *source = event->source();
        NavTree *tree = qobject_cast<NavTree *>(source);
        if(tree != NULL)
        {
            NavTree *tree = (NavTree*)source;
            QList<QTreeWidgetItem *> itemList = tree->selectedItems();
            foreach(QTreeWidgetItem *item,itemList)
                sourcelist.append(item->data(0,NavTree::FilePath).toString());
        }
    }

    // process the source list to see if it meets our criteria
    // don't drop a directory onto itself
    if(!sourcelist.contains(destpath))
    {
        // don't drop a source folder into a child folder
        if(!isSourceParentOfDest(sourcelist,destpath))
        {
            // don't drop a source into the directory it already resides in
            if(!isSourceInDest(sourcelist,destpath))
            {
                action = Qt::CopyAction; // even though we might move we are going to just say copy.
            }
        }
    }
    event->setDropAction(action);
    event->accept();
}

//!-----------------------------------------------------------------------------
//! \brief OVERRIDE:
//!          User dropped item over tree area. Determine if it's a valid
//!          drop point and what to do with the dropped data.
//!-----------------------------------------------------------------------------
void NavTree::dropEvent(QDropEvent *event)
{
    QTreeWidgetItem *destItem = itemAt(event->pos());
    if(destItem == NULL) return;

    // if the destination is not a folder use the items parent (which must be folder) as the drop target.
    if(!isFolder(destItem))
    {
        destItem = destItem->parent();
        if(destItem == NULL) return;
        if(!isFolder(destItem)) return;
    }

    // if dropping file(s) from a file browser...
    if (event->mimeData()->hasUrls())
    {
        QStringList list;
        foreach (QUrl url, event->mimeData()->urls())
        {
            QFileInfo fileinfo(url.path());

            if(fileinfo.exists() && (fileinfo.path() != "/"))
                list.append(url.path());
        }
        if(!list.isEmpty())
        {
            event->acceptProposedAction();
            handleFileDrop(list,destItem);
        }
    }

    // if dropping inter-tree item(s)...
    else if(event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
    {
        //        QWidget *source = (QWidget*) event->source();
        QObject *source = event->source();
        NavTree *tree = qobject_cast<NavTree *>(source);
        if(tree != NULL)
        {
            QList<QTreeWidgetItem *> itemList = tree->selectedItems();
            event->acceptProposedAction();
            handleWidgetDrop(itemList,destItem);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief   Determine if one of the drop sources is a folder in the parental
//!          lineage of the destination (re: avoid recurssion). This is a
//!          support routine for determining acceptable dnd operations.
//!-----------------------------------------------------------------------------
bool NavTree::isSourceParentOfDest(QStringList source, QString destpath)
{
    foreach(QString sourcepath,source)
    {
        // only check sources that are folders
        QFileInfo info(sourcepath);
        if(info.isDir())
        {
            // make directory string end with / to ensure correct validation
            if(!sourcepath.endsWith("/"))
                sourcepath.append("/");
            // check if source is in parent lineage
            if(sourcepath.length() < destpath.length())
                if(destpath.startsWith(sourcepath))
                    return true;
        }
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief   Determine if the destination is the direct parent of any of the sources.
//!          (re: don't drop something onto itself). This is a support routine
//!          for determining acceptable dnd operations.
//!-----------------------------------------------------------------------------
bool NavTree::isSourceInDest(QStringList source, QString destpath)
{
    foreach(QString src,source)
    {
        QFileInfo info(src);
        if(info.path() == destpath)
            return true;
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief   Handle copying a single or multiple files to a disk folder
//!          and creating associated tree items in response to a dnd operation
//!          dragging files from a file-browser and the dropping them on the tree.
//!
//! \param[in]   list - list pathnames of files to copy.
//! \param[in]   dest - pointer to tree destination item.
//!-----------------------------------------------------------------------------
void NavTree::handleFileDrop(QStringList list, QTreeWidgetItem *dest)
{
    // double check...if the dest is not a folder do not proceed
    if(!isFolder(dest))
        return;

    QString destpath = dest->data(0,NavTree::FilePath).toString();
    Project *destProject = getProject(dest);
    if(destProject == NULL)
        return;

    // copy source files to destination directory
    for(int i=0;i<list.size();i++)
    {
        QString sourceFilepath = list.at(i);
        copyFile(sourceFilepath,destpath,false);
    }
    updateProjectTree(destProject);
}

//!-----------------------------------------------------------------------------
//! \brief   Handle moving a single or multiple tree items and associated files
//!          to a new tree parent and disk folder in response to an inter-tree
//!          dnd drop operation.
//!
//! \param[in]   list - pointer to list of tree items to move.
//! \param[in]   dest - pointer to tree destination item.
//!-----------------------------------------------------------------------------
void NavTree::handleWidgetDrop(QList<QTreeWidgetItem *> list, QTreeWidgetItem *dest)
{
    // double check...if the dest is not a folder do not proceed
    if(!isFolder(dest))
        return;

    // don't allow a source to be a project left item
    foreach(QTreeWidgetItem *item,list)
        if(isProjectFolder(item))
            return;

    QStringList sourceProjects;
    QString destpath = dest->data(0,NavTree::FilePath).toString();
    Project *destProject = getProject(dest);
    if(destProject == NULL)
        return;

    // move source files to destination directory
    for(int i=0;i<list.size();i++)
    {
        QTreeWidgetItem *sourceWidget = list.at(i);
        QString sourceFilepath = sourceWidget->data(0,NavTree::FilePath).toString();
        sourceProjects.append(sourceWidget->data(0,NavTree::ProjectFolder).toString());
        copyFile(sourceFilepath,destpath,true);
    }
    updateProjectTree(destProject);
    sourceProjects.removeDuplicates();
    foreach(QString folder,sourceProjects)
        updateProjectTree(getProjectFromFolder(folder));
}

//=============================================================================
//
//                            UTILTY ROUTINES
//
//=============================================================================

//!-----------------------------------------------------------------------------
//! \brief   Populate a QStringList with the paths of the open projects.
//!
//! \parmam[in]  list - pointer to QStringList to populate.
//!-----------------------------------------------------------------------------
void NavTree::getOpenProjectsList(QStringList *list)
{
    list->clear();
    for(int i=0;i<projectList.size();i++)
    {
        Project *prj = projectList.at(i);
        list->append(prj->getProjectFolder());
    }
}

//!-----------------------------------------------------------------------------
//! \brief   Returns the project associated with the current selection.
//!-----------------------------------------------------------------------------
Project *NavTree::getSelectedProject()
{
    QTreeWidgetItem *item = currentItem();
    if(item == NULL)
        return NULL;
    QString projectFolder = item->data(0,NavTree::ProjectFolder).toString();
    Project *project = getProjectFromFolder(projectFolder);
    return project;
}

//!-----------------------------------------------------------------------------
//! \brief   Returns the pathname of the current selection.
//!-----------------------------------------------------------------------------
QString NavTree::getSelectedFilepath()
{
    QTreeWidgetItem *item = currentItem();
    if(item == NULL)
        return QString();
    QString pathname = item->data(0,NavTree::FilePath).toString();
    return pathname;
}

//!-----------------------------------------------------------------------------
//! \brief   Adds a project to the tree. This is the one and only routine that
//! is used to actually open a project. If the project is already opened we
//! return the exisiting pointer.
//!
//! \param[in]   pathname - pathname of the project folder.
//! \return      NULL = failed, otherwise a pointer to the project.
//!-----------------------------------------------------------------------------
Project* NavTree::addProject(QString pathname)
{
    // if this project is already in the tree, return.
    foreach(Project *prj, projectList)
    {
        if(prj->getProjectFolder() == pathname)
            return prj;
    }

    QFileInfo fileInfo(pathname);
    if(!fileInfo.exists())
        return NULL;

    // if this project is in the examples directory copy it to the temp directory.
    // if it already exists in the temp directory add a digit to the end.
    QString examplesDirStr = FileUtility::getDirExamples() + "/";
    if(pathname.startsWith(examplesDirStr))
    {
        // make sure we have a unique filename
        QString name = pathname.right(pathname.length()-pathname.lastIndexOf('/')-1);
        QString destPath = FileUtility::getDirTemp() + "/" + name;
        QFileInfo info(destPath);
        if(info.exists())
        {
            int n = 1;
            QString newPath = destPath + " " + QString::number(n);
            info.setFile(newPath);
            while(info.exists() && (n <= 10))
            {
                n++;
                newPath = destPath + " " + QString::number(n);
                info.setFile(newPath);
            }
            if(n >= 10)
            {
                QMessageBox::critical(this,"Error","You have more than 10 copies in the temp folder, please clean up.");
                return NULL;
            }
            destPath = newPath;
        }
        if(!FileUtility::copyDir(pathname,destPath))
        {
            QMessageBox::critical(this,"Error","Error copying project to temp folder.");
            return NULL;
        }
        if(!info.exists())
        {
            QMessageBox::critical(this,"Error","Error copying project to temp folder.");
            return NULL;
        }
        pathname = destPath;
    }

    Project *project = new Project; // deleted by destructor or removeProject().
    // make connection to pass on the indexing complete signal
    connect(project,SIGNAL(indexingComplete(Project *)),this,SIGNAL(projectIndexingComplete(Project*)));
    // inform MainWindow that a project was created so MainWindow can connect to the project index requests.
    emit projectAdded(project);

    // open the project
    if(!project->open(pathname))
    {
        project->deleteLater();
        project = NULL;
        return NULL;
    }

    // successfully opened project, add it to the navigator
    projectList.append(project);

    // add project to tree by scanning directory
    QTreeWidgetItem* item = new QTreeWidgetItem();
    item->setText(0,project->getName());
    item->setData(0,NavTree::ProjectName,project->getName());
    item->setData(0,NavTree::ProjectFolder,project->getProjectFolder());
    item->setData(0,NavTree::FilePath,project->getProjectFolder());

    item->setIcon(0,QIcon(":/icons/icons/folder.png"));
    addChildren(item,project,project->getProjectFolder());
    addTopLevelItem(item);
    setCurrentItem(item);
    emit sigSelectionChanged(project,project->getProjectFolder());

    return project;
}

//!-----------------------------------------------------------------------------
//! \brief   Get a new filename.
//!
//! \param pathname : The old full pathname that we want a new filename for.
//!-----------------------------------------------------------------------------
QString NavTree::getNewFileName(QString &pathname)
{
    bool found;

    QFileInfo destFileInfo(pathname);
    QString destFolderPath = destFileInfo.dir().path();

    do{
        found = false;
        destFileInfo = QFileInfo(pathname);
        if(destFileInfo.exists())
        {
            found = true;
            bool ok;
            QString text = QInputDialog::getText(this, "Rename",
                                                 tr("Enter new name:"), QLineEdit::Normal,
                                                 destFileInfo.fileName(), &ok);
            if (ok && !text.isEmpty())
                pathname =  destFolderPath + "/" + text;
            else
                return QString();
        }
        else
        {
            // test if valid path by creating file, then removing it.
            QDir().mkpath(pathname);
            QFileInfo info(pathname);
            if(!info.exists())
                found = true;
            else
                QDir().remove(pathname);
        }
    } while(found);
    return pathname;
}

//!-----------------------------------------------------------------------------
//! \brief   Updates the project tree for a given project. Useful anytime files
//!          may have been added or deleted such as after a build.
//!
//! \param[in]   project - pointer to project in tree to update.
//!-----------------------------------------------------------------------------
void NavTree::updateProjectTree(Project *project)
{
    if(project == NULL) return;

    // save selected item so we can restore selection after update
    QTreeWidgetItem *selItem = currentItem();
    QString selFilePath, selPrjFolder;
    if(selItem != NULL)
    {
        selFilePath = selItem->data(0,NavTree::FilePath).toString();
        selPrjFolder = selItem->data(0,NavTree::ProjectFolder).toString();
    }

    // update tree for the given project
    int i = findTopLevelItem(project->getProjectFolder());
    if (i==-1)
    {
        // couldn't find top level item
        return;
    }
    QTreeWidgetItem *item = topLevelItem(i);
    if(item == NULL)
    {
        return;
    }
    // create a list of pathnames of all tree items that are expanded
    // so we can restore them to expanded after we re-load the tree.
    QStringList list;
    if(item->isExpanded())
        list.append(item->data(0,NavTree::FilePath).toString());
    addExpandedChildrenToList(item,&list);

    // remove all children
    item->takeChildren();
    // update name
    QString name = item->data(0,NavTree::ProjectName).toString();
    item->setText(0,name);
    // scan project directory and add all children to tree
    addChildren(item,project,project->getProjectFolder());
    // expand children that were previously expanded and still exist
    if(list.contains(item->data(0,NavTree::FilePath).toString()))
        item->setExpanded(true);
    expandChildrenInList(item,&list);

    // restore selected item
    if(!selFilePath.isEmpty() && !selPrjFolder.isEmpty())
        selectFile(selFilePath);
}

//!-----------------------------------------------------------------------------
//! \brief   Add children to a tree item by scanning the passed directory path.
//!          Operates recursively when a subdirectory is found.
//!
//! \param[in]   item - pointer to QTreeWidgetItem to add children to.
//! \param[in]   project - pointer to associated project.
//! \param[in]   filePath - directory path to scan.
//!-----------------------------------------------------------------------------
void NavTree::addChildren(QTreeWidgetItem* item,Project *project, QString filePath)
{
    QDir* rootDir = new QDir(filePath);
    QFileInfoList filesList = rootDir->entryInfoList( QDir::NoFilter, QDir::DirsFirst);

    foreach(QFileInfo fileInfo, filesList)
    {
        if((fileInfo.fileName() != "..") && (fileInfo.fileName() != "."))
        {
            QTreeWidgetItem* child = new QTreeWidgetItem();
            child->setText(0,fileInfo.fileName());
            child->setData(0,NavTree::ProjectName,project->getName());
            child->setData(0,NavTree::ProjectFolder,project->getProjectFolder());
            child->setData(0,NavTree::FilePath,fileInfo.absolutePath()+"/"+fileInfo.fileName());

            if(fileInfo.isDir() && !fileInfo.fileName().endsWith("."))
                addChildren(child,project,fileInfo.filePath());
            setIcon(fileInfo,child);
            item->addChild(child);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief   Expands tree item children that are in a list, if found.
//!
//! \param[in]   item - pointer to parent tree item.
//! \param[in]   list - pointer to list of filepaths for the children to be expanded.
//!-----------------------------------------------------------------------------
void NavTree::expandChildrenInList(QTreeWidgetItem *item, QStringList *list)
{
    int n = item->childCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *child = item->child(i);
        if(list->contains(child->data(0,NavTree::FilePath).toString()))
            child->setExpanded(true);
        if(child->childCount() > 0)
            expandChildrenInList(child,list);
    }
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void NavTree::addExpandedChildrenToList(QTreeWidgetItem *item, QStringList *list)
{
    int n = item->childCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *child = item->child(i);
        if(child->isExpanded())
            list->append(child->data(0,NavTree::FilePath).toString());
        if(child->childCount() > 0)
            addExpandedChildrenToList(child,list);
    }
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool NavTree::openFile(QString pathname,int line)
{
    // see if project for this file is open
    Project *prj = getProjectFromFile(pathname);
    // if project is not open, open it.
    if(prj == NULL)
    {
        QString prjFolder = FileUtility::getProjectFolderFromPathname(pathname);
        if(prjFolder.isEmpty()) return false;
        if(addProject(prjFolder) == NULL) return false;
        prj = getProjectFromFile(pathname);
        if(prj == NULL) return false;
    }
    emit sigOpenFile(prj,pathname,line);
    return true;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
Project *NavTree::getProjectFromFolder(QString projectFolder)
{
    for(int i=0;i<projectList.size();i++)
    {
        Project *prj = projectList.at(i);
        if(prj == NULL) continue;
        QString prjFolder = prj->getProjectFolder();
        if(prjFolder == projectFolder)
            return prj;
    }
    return NULL;
}


//!-----------------------------------------------------------------------------
//! \brief  Returns a pointer to the open project that has the given pathname
//!         in its directory, or NULL if no project is found.
//!-----------------------------------------------------------------------------
Project *NavTree::getProjectFromFile(QString pathname)
{
    if(pathname.isEmpty()) return NULL;

    for(int i=0;i<projectList.size();i++)
    {
        Project *prj = projectList.at(i);
        QString prjPath = prj->getProjectFolder();
        if(pathname.startsWith(prjPath+"/"))
            return prj;
        else if(pathname == prjPath)
            return prj;
    }
    return NULL;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
int NavTree::findTopLevelItem(QString projectFolder)
{
    int i;
    int n = topLevelItemCount();
    for(i=0;i<n;i++)
    {
        QTreeWidgetItem *item = topLevelItem(i);
        if(item != NULL)
        {
            QString prjfolder = item->data(0,NavTree::ProjectFolder).toString();
            if(prjfolder == projectFolder)
                return i;
        }
    }
    return -1;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool NavTree::removeProject(Project *prj)
{
    int i;

    if(prj == NULL)
        return false;

    i = findTopLevelItem(prj->getProjectFolder());
    if(i == -1)
        return false;

    QString path = prj->getProjectFolder();
    QString tmpPath = FileUtility::getDirTemp() + "/";
    if(path.startsWith(tmpPath))
    {
        int ret = QMessageBox::information(this,"Warning",prj->getName() + " is in the temp folder and will be deleted.",QMessageBox::Save|QMessageBox::Close);
        if(ret == QMessageBox::Save)
        {
            selectFile(path);
            // get new project name and parent folder from user via dialog.
            ProjectNameDialog dlg;
            QFileInfo info;
            if(prj->getProjectFolder().startsWith(FileUtility::getDirTemp()))
                info.setFile(FileUtility::getDirProjects()+"/"+prj->getName());
            else
                info.setFile(prj->getProjectFolder());
            dlg.setInitialDirectory(info.path());
            dlg.setInitialName(prj->getName());
            dlg.setMessage("Enter new project name.");
            dlg.setTitle("Project SaveAs");
            if(!dlg.exec())
                return false;

            QString destFolder = dlg.getProjectFolder();
            destFolder.replace("\\","/");
            destFolder.replace("//","/");
            // save project to new directory
            prj->saveAs(destFolder);
        }
    }

    // remove project from tree
    takeTopLevelItem(i);

    // remove project from list
    i = projectList.indexOf(prj);
    if(i == -1)
        return false;
    projectList.removeAt(i);

    // close project
    prj->close();

    // free memory
    prj->deleteLater();
    prj = NULL;
    return true;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void NavTree::setIcon(QFileInfo fileInfo, QTreeWidgetItem *item)
{
    if(fileInfo.isFile())
    {
        if(fileInfo.fileName().endsWith(".c"))
            item->setIcon(0,QIcon(":/icons/icons/source_c.png"));
        else if(fileInfo.fileName().endsWith(".cpp"))
            item->setIcon(0,QIcon(":/icons/icons/source_c.png"));
        else if(fileInfo.fileName().endsWith(".h"))
            item->setIcon(0,QIcon(":/icons/icons/source_h.png"));
        else if(fileInfo.fileName().endsWith(".hpp"))
            item->setIcon(0,QIcon(":/icons/icons/source_h.png"));
        else if(fileInfo.fileName().endsWith(".bin"))
            item->setIcon(0,QIcon(":/icons/icons/binary.png"));
        else if(fileInfo.fileName().endsWith(".cprj"))
            item->setIcon(0,QIcon(":/icons/icons/config.png"));
        else if(fileInfo.fileName().endsWith(".elf"))
            item->setIcon(0,QIcon(":/icons/icons/elf.png"));
        else if(fileInfo.fileName().endsWith(".txt"))
            item->setIcon(0,QIcon(":/icons/icons/text.png"));
        else if(fileInfo.fileName().endsWith(".lst"))
            item->setIcon(0,QIcon(":/icons/icons/text.png"));
        else
            item->setIcon(0,QIcon(":/icons/icons/document.png"));
    }
    else if(fileInfo.isDir())
        item->setIcon(0,QIcon(":/icons/icons/folder.png"));
}


//!-----------------------------------------------------------------------------
//! \brief   Returns a pointer to the Project associated with a tree item.
//!
//! \param[in]   item - pointer to tree item.
//! \return  Pointer to project or NULL.
//!-----------------------------------------------------------------------------
Project *NavTree::getProject(QTreeWidgetItem *item)
{
    if(item == NULL)
        return NULL;
    QString projectFolder = item->data(0,NavTree::ProjectFolder).toString();

    for(int i=0;i<projectList.size();i++)
    {
        Project *prj = projectList.at(i);
        if(prj->getProjectFolder() == projectFolder)
            return prj;
    }
    return NULL;
}

//!-----------------------------------------------------------------------------
//! \brief   Copy or move a file on disk.
//!
//! \param[in]   sourcePath - full pathname of file to copy or move.
//! \param[in]   destFolderPath - full pathname of destination folder.
//! \param[in]   move - true = move file, false = copy file.
//! \return      true if successful, false otherwise.
//!-----------------------------------------------------------------------------
bool NavTree::copyFile(QString &sourcePath, QString &destFolderPath, bool move)
{
    // make sure source exists
    QFileInfo sourceInfo(sourcePath);
    if(!sourceInfo.exists())
    {
        QMessageBox::information(this,"Error","Source file doesn't exist.");
        return false;
    }

    // make sure destination specifies a folder and exists
    QFileInfo destDirInfo(destFolderPath);
    if(!destDirInfo.exists() || !destDirInfo.isDir())
    {
        QMessageBox::information(this,"Error","Target folder doesn't exist.");
        return false;
    }

    // determine destination pathname
    QString destPathname;
    if(sourceInfo.isDir() && (sourcePath == destFolderPath))
    {
        // we are here because the user is attempting to copy a directory onto itself
        // this is ok but will require the user to rename the destination below
        destPathname = destFolderPath;
        destFolderPath = destDirInfo.dir().path();
    }
    else if(sourceInfo.isDir() && sourcePath.endsWith("/"))
        destPathname = destFolderPath + "/" + sourceInfo.dir().dirName();
    else
        destPathname = destFolderPath + "/" + sourceInfo.fileName();

    // make sure source filename doesn't exist in dest directory, have user rename target if so.
    bool found;
    do{
        found = false;
        QFileInfo destFileInfo(destPathname);
        if(destFileInfo.exists())
        {
            found = true;
            bool ok;
            QString text = QInputDialog::getText(this, "Error: "+destFileInfo.fileName()+" exists.",
                                                 tr("Enter new name:"), QLineEdit::Normal,
                                                 destFileInfo.fileName(), &ok);
            if (ok && !text.isEmpty())
                destPathname =  destFolderPath + "/" + text;
            else
                return false;
        }
    } while(found);

    if(sourceInfo.isDir())
    {
        // make a new folder in dest folder
        if(!QDir().mkpath(destPathname))
        {
            QMessageBox::information(this,"Error","Unable to create folder.");
            return false;
        }
        // get a list of all the files in the source folder
        QDir sourceDir(sourcePath);
        QFileInfoList sourceList = sourceDir.entryInfoList();
        // recusrive calls to copy source files
        foreach(QFileInfo info, sourceList)
        {
            QString path = info.absoluteFilePath();
            if(path.length() > sourcePath.length())
                if(!copyFile(path,destPathname,move))
                    return false;
        }
        // delete the source file if this is a move operation
        if(move)
            if(!QDir().rmpath(sourceInfo.absoluteFilePath()))
            {
                QMessageBox::information(this,"Error","Unable to delete file:"+sourceInfo.fileName());
                return false;
            }
    }
    else if(sourceInfo.isFile())
    {
        // open source file for reading
        QFile sourceFile(sourcePath);
        if (!sourceFile.open(QIODevice::ReadOnly))
        {
            QMessageBox::information(this,"Error","Unable to copy file.");
            return false;
        }
        // open destination file for writing
        QFile destFile(destPathname);
        if (!destFile.open(QIODevice::WriteOnly))
        {
            sourceFile.close();
            QMessageBox::information(this,"Error","Unable to copy file.");
            return false;
        }

        // read and write entire file
        QByteArray data = sourceFile.readAll();
        qint64 ret = destFile.write(data);
        destFile.close();
        sourceFile.close();
        if(ret == -1)
        {
            QMessageBox::information(this,"Error","Unable to copy file.");
            return false;
        }
        // extra work if this is a move operation
        if(move)
        {
            // delete the source file if this is a move operation
            if(!QFile(sourcePath).remove())
            {
                QMessageBox::information(this,"Error","Unable to remove file.");
                return false;
            }
            // inform TabManager via signal so it can update tab if required.
            Project *destPrj = getProjectFromFile(destPathname);
            emit sigFileMoved(sourcePath,destPathname,destPrj);
        }
    }
    return true;
}

QString NavTree::getPathname(QTreeWidgetItem *item)
{
    QString ret;
    if(item != NULL)
        ret = item->data(0,NavTree::FilePath).toString();
    return ret;
}

//!-----------------------------------------------------------------------------
//! \brief   Returns the parent foldername of item if the item is a file,
//!          returns the items foldername if the item is a folder.
//!-----------------------------------------------------------------------------
QString NavTree::getPath(QTreeWidgetItem *item)
{
    QString ret;
    QString path = getPathname(item);
    if(!path.isEmpty())
    {
        QFileInfo info(path);
        if(info.isDir())
            ret = path;
        else
            ret = info.path();
    }
    return ret;
}
QString NavTree::getProjectFolder(QTreeWidgetItem *item)
{
    QString ret;
    if(item != NULL)
        ret = item->data(0,NavTree::ProjectFolder).toString();
    return ret;
}
QString NavTree::getProjectName(QTreeWidgetItem *item)
{
    QString ret;
    if(item != NULL)
        ret = item->data(0,NavTree::ProjectName).toString();
    return ret;
}
bool NavTree::isProjectFolder(QTreeWidgetItem *item)
{
    if(item == NULL)
        return false;
    if(getProjectFolder(item) == getPathname(item))
        return true;
    return false;
}
void NavTree::setPathname(QTreeWidgetItem *item, QString pathname)
{
    if(item == NULL)
        return;
    item->setData(0,NavTree::FilePath,pathname);
}
void NavTree::setProjectFolder(QTreeWidgetItem *item, QString projectFolder)
{
    if(item == NULL)
        return;
    item->setData(0,NavTree::ProjectFolder,projectFolder);
}
void NavTree::setProjectName(QTreeWidgetItem *item, QString projectName)
{
    if(item == NULL)
        return;
    item->setData(0,NavTree::ProjectName,projectName);
}
void NavTree::closeTempProjects()
{
    foreach(Project *prj,projectList)
    {
        QString path = prj->getProjectFolder();
        QString tmpPath = FileUtility::getDirTemp() + "/";
        if(path.startsWith(tmpPath))
            removeProject(prj);
    }
}

//!-----------------------------------------------------------------------------
//! \brief   Determine if a tree item is a folder (directory).
//!-----------------------------------------------------------------------------
bool NavTree::isFolder(QTreeWidgetItem *item)
{
    if(item == NULL)
        return false;
    QString pathname = item->data(0,NavTree::FilePath).toString();
    if(pathname == "/")
        return false;
    QFileInfo info(pathname);
    if(info.isDir() && info.exists())
        return true;
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief   Select the tree item that has a given pathname.
//!
//! \param[in]   pathname - pathname of item to select.
//!-----------------------------------------------------------------------------
void NavTree::selectFile(QString pathname)
{
    if(pathname.isEmpty())
        return;

    QTreeWidgetItem *item = findItem(pathname);

    qDebug() << "NavTree:selectFile:" << pathname;

    if(item != NULL)
    {
        // if it's already selected then return.
        if(item->isSelected())
            return;
        clearSelection();
        setCurrentItem(item);
        item->setSelected(true);
        scrollToItem(item);
    }
    else
        clearSelection();
}


//!-----------------------------------------------------------------------------
//! \brief  Returns a pointer to a QTreeWidgetItem that has the associated
//!         pathname, or NULL if no matches are found.
//!-----------------------------------------------------------------------------
QTreeWidgetItem *NavTree::findItem(QString pathname)
{
    Project *prj = getProjectFromFile(pathname);
    if(prj == NULL) return NULL;
    QString projectFolder = prj->getProjectFolder();

    for(int i=0;i<topLevelItemCount();i++)
    {
        QTreeWidgetItem *topitem = topLevelItem(i);
        QString itemPrjFolder = topitem->data(0,NavTree::ProjectFolder).toString();

        if(projectFolder == itemPrjFolder)
        {
            QTreeWidgetItem *item = findItem(topitem,pathname);
            if(item != NULL)
                return item;
        }
    }
    return NULL;
}

//!-----------------------------------------------------------------------------
//! \brief  Returns a pointer to a QTreeWidgetItem that has the associated
//!         pathname and QTreeWidgetItem "item" in its parent tree.
//!-----------------------------------------------------------------------------
QTreeWidgetItem *NavTree::findItem(QTreeWidgetItem *item, QString pathname)
{
    QString itemPath = item->data(0,NavTree::FilePath).toString();
    if(itemPath == pathname)
        return item;

    for(int i=0;i<item->childCount();i++)
    {
        QTreeWidgetItem *child = item->child(i);
        QTreeWidgetItem *widget = findItem(child,pathname);
        if(widget != NULL)
            return widget;
    }
    return NULL;
}

