#ifndef CONFIGOBJECTSFORM_H
#define CONFIGOBJECTSFORM_H

#include <QWidget>
#include <QListWidget>

class Target;

namespace Ui {
class ConfigObjectsForm;
}

class ConfigObjectsForm : public QWidget
{
    Q_OBJECT
    
public:
    explicit ConfigObjectsForm(Target *target, QWidget *parent = 0);
    ~ConfigObjectsForm();

public slots:
    void updateForm();

private slots:
    void on_addIncludeFolder_clicked();
    void on_removeIncludeFolder_clicked();
    void on_addObject_clicked();
    void on_removeObject_clicked();
    void on_startupFileButton_clicked();
    void on_stubsFileButton_clicked();
    void on_linkerScriptButton_clicked();
    void on_startupFileClear_clicked();
    void on_stubsFileClear_clicked();
    void on_linkerScriptClear_clicked();

    void on_addStdLib_clicked();

    void on_addLibraryFile_clicked();

    void on_removeLibraryFile_clicked();

private:
    QStringList removeSelectedItemsFromList(QListWidget *widget);

private:
    Ui::ConfigObjectsForm *ui;
    Target *target;
};

#endif // CONFIGOBJECTSFORM_H
