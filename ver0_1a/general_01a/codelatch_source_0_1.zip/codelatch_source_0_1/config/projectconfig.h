#ifndef PROJECTCONFIG_H
#define PROJECTCONFIG_H

#include <QWidget>
#include <QTabWidget>

class Project;

//class ProjectConfig : public QTabWidget
class ProjectConfig : public QWidget
{
    Q_OBJECT
public:
    explicit ProjectConfig(Project *project, QWidget *parent = 0);
    
    QString getPathname();
    QString getProjectFolder();
    Project* getProject() {return prj;}
    void setProject(Project *project) {prj = project;}

signals:
    
public slots:
    
private:
    Project *prj;
};

#endif // PROJECTCONFIG_H
