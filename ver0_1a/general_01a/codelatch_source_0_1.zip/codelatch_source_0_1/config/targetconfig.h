#ifndef TARGETCONFIG_H
#define TARGETCONFIG_H

#include <QWidget>
#include <QTabWidget>
#include "project/project.h"
#include "target.h"

class Project;

class TargetConfig : public QTabWidget
{
    Q_OBJECT
public:
    explicit TargetConfig(QWidget *parent = 0);
    static QString getPathname();
    QString getProjectFolder();
    Project* getProject() {return NULL;}
    void updateForm();

    Target target;

signals:
    void updateTabs();
    void updateTargetList();

public slots:
    
private:

};

#endif // TARGETCONFIG_H
