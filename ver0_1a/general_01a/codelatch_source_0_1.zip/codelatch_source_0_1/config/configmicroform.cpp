#include "configmicroform.h"
#include "ui_configmicroform.h"
#include "target.h"
#include "utility/fileutility.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QFile>
#include <QFileDialog>

ConfigMicroForm::ConfigMicroForm(Target *target, QWidget *parent):
    QWidget(parent),
    ui(new Ui::ConfigMicroForm)
{
    ui->setupUi(this);
    this->target = target;
    updateForm();
}

ConfigMicroForm::~ConfigMicroForm()
{
    delete ui;
}

void ConfigMicroForm::updateForm()
{
    if(target == NULL) return;

    ui->configDescription->blockSignals(true);
    ui->configDescription->setPlainText(target->getDescription());
    ui->configDescription->blockSignals(false);

    // load gdb startup commands
    QStringList list = target->getGdbStartupCmds();
    QString text;
    foreach(QString s,list)
        text += s + "\n";

    ui->gdbCommands->blockSignals(true);
    ui->gdbCommands->setText(text);
    ui->gdbCommands->blockSignals(false);

    ui->compilerPath->blockSignals(true);
    ui->compilerPath->setText(FileUtility::replacePathWithKey(NULL,target->getCompilerToolPrefix()));
    ui->compilerPath->blockSignals(false);

    ui->flashPrgTool->blockSignals(true);
    ui->flashPrgTool->setText(FileUtility::replacePathWithKey(NULL,target->getFlashProgramTool()));
    ui->flashPrgTool->blockSignals(false);

    ui->flashPrgArgs->blockSignals(true);
    ui->flashPrgArgs->setText(FileUtility::replacePathWithKey(NULL,target->getFlashProgramArgs()));
    ui->flashPrgArgs->blockSignals(false);

    ui->gdbServerTool->blockSignals(true);
    ui->gdbServerTool->setText(FileUtility::replacePathWithKey(NULL,target->getGdbServerTool()));
    ui->gdbServerTool->blockSignals(false);

    ui->gdbServerArgs->blockSignals(true);
    ui->gdbServerArgs->setText(FileUtility::replacePathWithKey(NULL,target->getGdbServerArgs()));
    ui->gdbServerArgs->blockSignals(false);

    ui->maxHWBreakpoints->blockSignals(true);
    ui->maxHWBreakpoints->setText(QString::number(target->getMaxHWBreakpoints()));
    ui->maxHWBreakpoints->blockSignals(false);

    ui->cbUpdateLPCUserCode->blockSignals(true);
    ui->cbUpdateLPCUserCode->setChecked(target->getUpdateLPCUserCode());
    ui->cbUpdateLPCUserCode->blockSignals(false);
}

void ConfigMicroForm::on_configHelp_clicked()
{

}

void ConfigMicroForm::on_pbNewTarget_clicked()
{
    if(target == NULL) return;

    QString newName = getNewTargetName();
    if(newName.isEmpty()) return;

    QString newPath = FileUtility::getDirTargets() + "/" + newName;
    if(!newPath.endsWith(".tgt"))
        newPath += ".tgt";

    // open file and save dummy data
    QFile file(newPath);
    if(file.open(QIODevice::ReadWrite))
    {
        QTextStream stream(&file);
        stream << "empty" << endl;
        stream.flush();
        file.close();
    }
    else
    {
        // couldn't create file
        QMessageBox::critical(this,"Target","Failed to create file.");
        return;
    }
    // load the empty target
    target->load(newName);
    emit targetSelectionChanged();
    emit updateTargetList();
}
/*
void ConfigMicroForm::on_comboTargetName_currentIndexChanged(const QString &arg1)
{
    if(target == NULL) return;
    target->load(arg1);
    emit targetSelectionChanged();
}
*/

void ConfigMicroForm::on_btnAdd_clicked()
{

}

void ConfigMicroForm::on_btnRemove_clicked()
{
}



QString ConfigMicroForm::getNewTargetName(QString newName)
{
    bool ok = false;
    while(!ok)
    {
        newName = QInputDialog::getText(this,"New Target","Enter New Target Name:", QLineEdit::Normal,newName, &ok);
        if(!ok) return QString();
        if(newName.isEmpty())
            ok = false;
        else
        {
            // try to open file for writing
            QString newPath = FileUtility::getDirTargets() + "/" + newName;
            if(!newPath.endsWith(".tgt"))
                newPath += ".tgt";

            // open file and save dummy data
            QFile file(newPath);
            if(file.exists())
            {
                QMessageBox::warning(this,"Target","Target name already exists.");
                ok = false;
            }
            else if(file.open(QIODevice::ReadWrite))
                ok = true;
            else
            {
                // couldn't create file
                QMessageBox::critical(this,"Target","Failed to create file.");
                ok = false;
            }
        }
    }
    return newName;
}

void ConfigMicroForm::on_pbSaveAs_clicked()
{
    if(target == NULL) return;
    QString newName = getNewTargetName(target->getTargetName());
    if(newName.isEmpty()) return;

    // save the target to the new name
    target->saveAs(newName);
    emit targetSelectionChanged();
    emit updateTargetList();
}

void ConfigMicroForm::on_configDescription_textChanged()
{
    if(target == NULL) return;
    target->setDescription(ui->configDescription->toPlainText());
    target->save();
}

void ConfigMicroForm::on_tbCompilerPath_clicked()
{
    if(target == NULL) return;
    QString path = QFileDialog::getExistingDirectory(this,"Select compiler bin directory.",FileUtility::getDirCompiler());
    // get a list of files in this directory
    QDir dir(path);

#ifdef Q_OS_WIN
    QStringList fileList = dir.entryList(QStringList("*-gcc.exe"));
#else
    QStringList fileList = dir.entryList(QStringList("*-gcc"));
#endif

    if(fileList.size() != 1)
    {
        QMessageBox::critical(this,"Error","Couldn't find gcc tools in the specified directory. Select the directory that contains the -gcc binary");
        return;
    }
    path = path + "/" + fileList.first();
    path = path.left(path.lastIndexOf('-')+1);
#ifdef Q_OS_WIN
    path = path.remove(".exe");
#endif

    target->setCompilerToolPrefix(path);
    target->save();
    path = FileUtility::replacePathWithKey(NULL,path);
    ui->compilerPath->setText(path);
}

void ConfigMicroForm::on_tbFlashPrg_clicked()
{
    if(target == NULL) return;
    QString path = QFileDialog::getOpenFileName(this,"Select flash programming application.",FileUtility::getDirTools());

    if(path.isEmpty())
        return;
#ifdef Q_OS_WIN
    path = path.remove(".exe");
#endif

    target->setFlashProgramTool(path);
    target->save();
    path = FileUtility::replacePathWithKey(NULL,path);
    ui->flashPrgTool->setText(path);
}

void ConfigMicroForm::on_flashPrgArgs_textChanged(const QString &arg1)
{
    if(target == NULL) return;
    target->setFlashProgramArgs(arg1);
    target->save();
}

void ConfigMicroForm::on_tbGdbServer_clicked()
{
    if(target == NULL) return;
    QString path = QFileDialog::getOpenFileName(this,"Select gdb server application.",FileUtility::getDirTools());

    if(path.isEmpty())
        return;
#ifdef Q_OS_WIN
    path = path.remove(".exe");
#endif

    target->setGdbServerTool(path);
    target->save();
    path = FileUtility::replacePathWithKey(NULL,path);
    ui->gdbServerTool->setText(path);
}

void ConfigMicroForm::on_gdbServerArgs_textChanged(const QString &arg1)
{
    if(target == NULL) return;
    target->setGdbServerArgs(arg1);
    target->save();
}

void ConfigMicroForm::on_gdbCommands_textChanged()
{
    QString text = ui->gdbCommands->toPlainText();
    QStringList list = text.split('\n');
    QStringList newList;

    foreach(QString s,list)
    {
        s = s.trimmed();
        if(!s.isEmpty())
            newList.append(s);
    }

    target->setGdbStartupCmds(newList);
    target->save();
}

void ConfigMicroForm::on_maxHWBreakpoints_textChanged(const QString &arg1)
{
    if(target == NULL) return;
    QString str = arg1;
    bool ok;
    int val = str.toInt(&ok);
    if(!ok || (val < 2) || (val > 8))
    {
        QMessageBox::information(this,"Error","Number must be 2 to 8.");
        return;
    }
    target->setMaxHWBreakpoints(val);
    target->save();
}

void ConfigMicroForm::on_cbUpdateLPCUserCode_clicked(bool checked)
{
    if(target == NULL) return;
    target->setUpdateLPCUserCode(checked);
    target->save();
}
