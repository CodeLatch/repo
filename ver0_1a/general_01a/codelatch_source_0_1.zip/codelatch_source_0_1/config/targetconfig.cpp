#include "targetconfig.h"
#include <QScrollArea>
#include <QVariant>
//#include "config/configlibraryform.h"
#include "config/configobjectsform.h"
#include "config/configmicroform.h"
#include "target.h"
#include "programconfig.h"

// The TargetConfig class is a QTabWidget that holds other widgets in tabs. These widgets
// are other forms that let the user modify the configuration. The individual tabs are not
// closable, only the TargetConfig is closable. When it's closed the main window TabManager
// will get a signal and that's when/where we will save the config.

TargetConfig::TargetConfig(QWidget *parent) :
    QTabWidget(parent)
{
    setDocumentMode(true);
    setTabsClosable(false);
    setMovable(false);

    QString targetName = ProgramConfig::get(TARGET_NAME).toString();
    target.load(targetName);

    // create and populate the tabs...
    ConfigMicroForm *form1 = new ConfigMicroForm(&target);
    connect(form1,SIGNAL(updateTargetList()),this,SIGNAL(updateTargetList()));

//    ConfigLibraryForm *form2 = new ConfigLibraryForm(&target);
    ConfigObjectsForm *form3 = new ConfigObjectsForm(&target);

    QScrollArea *scroll1 = new QScrollArea(this);
//    QScrollArea *scroll2 = new QScrollArea(this);
    QScrollArea *scroll3 = new QScrollArea(this);

    scroll1->setWidget(form1);
//    scroll2->setWidget(form2);
    scroll3->setWidget(form3);

    addTab(scroll1,"Target");
//    addTab(scroll2,"Libraries");
    addTab(scroll3,"Objects");

    connect(this,SIGNAL(updateTabs()),form1,SLOT(updateForm()));
//    connect(this,SIGNAL(updateTabs()),form2,SLOT(updateForm()));
    connect(this,SIGNAL(updateTabs()),form3,SLOT(updateForm()));
}

QString TargetConfig::getPathname()
{
    return QString("Target");
}

QString TargetConfig::getProjectFolder()
{
    return QString();
}

void TargetConfig::updateForm()
{
    QString targetName = ProgramConfig::get(TARGET_NAME).toString();
    target.load(targetName);
    emit updateTabs();
}
