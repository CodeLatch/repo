#include "config/projectconfig.h"
#include "config/configtoolsform.h"
//#include "config/configpostbuildform.h"
#include <QScrollArea>
#include "project/project.h"
#include <QGridLayout>

ProjectConfig::ProjectConfig(Project *project, QWidget *parent) :
    QWidget(parent)
{
    prj = project;
    if(project == NULL) return;

    QScrollArea *scroll = new QScrollArea(this);
    ConfigToolsForm *form = new ConfigToolsForm(project);
    scroll->setWidget(form);

    QGridLayout *layout = new QGridLayout(this);
    layout->addWidget(scroll);
    layout->setSpacing(0);
    layout->setMargin(0);
    setLayout(layout);
}

QString ProjectConfig::getPathname()
{
    if(prj == NULL) return QString();
    QString pathname = getProjectFolder() + "/" + prj->getConfigFilename();
    return pathname;
}

QString ProjectConfig::getProjectFolder()
{
    if(prj == NULL) return QString();
    QString projectFolder = prj->getProjectFolder();
    return projectFolder;
}
