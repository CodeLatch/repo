#include "configtoolsform.h"
#include "ui_configtoolsform.h"
#include "utility/fileutility.h"
#include <QFileDialog>
#include <QInputDialog>

ConfigToolsForm::ConfigToolsForm(Project *project, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ConfigToolsForm)
{
    prj = NULL;
    ui->setupUi(this);

    // don't show blue focus rectangle around listWidgets
    ui->listCompilerOptions->setAttribute(Qt::WA_MacShowFocusRect,false);
    ui->listLinkerOptions->setAttribute(Qt::WA_MacShowFocusRect,false);

    setProject(project);
}

ConfigToolsForm::~ConfigToolsForm()
{
    delete ui;
}

void ConfigToolsForm::setProject(Project *project)
{
    prj = project;
    if(prj == NULL) return;
    Target target = prj->getTarget();

    // store temporarily becuase addItems will cause a save of first added item.
    QString optLevel = prj->getOptimization();
    QString buildType = prj->getBuildType();

    ui->comboBuildType->addItems(prj->getBuildTypes());
    ui->comboOptimization->addItems(prj->getOptimizationLevels());

    ui->comboBuildType->setCurrentIndex(ui->comboBuildType->findText(buildType));
    ui->comboOptimization->setCurrentIndex(ui->comboOptimization->findText(optLevel));

    ui->cbDynamicMem->setChecked(prj->getDynamicMemorySupport());
    ui->cbRemoveUnused->setChecked(prj->getRemoveUnused());

    QString cmd = prj->getCompilerCmd();
    cmd = cmd.right(cmd.length() - cmd.lastIndexOf('-') - 1);
#ifdef Q_OS_WIN
    if(cmd.endsWith(".exe")) cmd.remove(".exe");
#endif
    ui->compilerCmd->setText(cmd);

    ui->listCompilerOptions->addItems(prj->getCompilerOptions());
    ui->listLinkerOptions->addItems(prj->getLinkerOptions());
}

void ConfigToolsForm::on_comboOptimization_currentIndexChanged(const QString &arg1)
{
    if(prj == NULL) return;
    prj->setOptimization(arg1);
    prj->save();
}

void ConfigToolsForm::on_comboBuildType_currentIndexChanged(const QString &arg1)
{
    if(prj == NULL) return;
    prj->setBuildType(arg1);
    prj->save();
}

void ConfigToolsForm::on_cbRemoveUnused_clicked()
{
    if(prj == NULL) return;
    prj->setRemoveUnused(ui->cbRemoveUnused->isChecked());
    prj->save();
}

void ConfigToolsForm::on_cbDynamicMem_clicked()
{
    if(prj == NULL) return;
    prj->setDynamicMemorySupport(ui->cbDynamicMem->isChecked());
    prj->save();
}

void ConfigToolsForm::on_addCompilerOption_clicked()
{
    if(prj == NULL) return;
    QString text;

    bool ok;
    text = QInputDialog::getText(this, "Add", "Option", QLineEdit::Normal, text, &ok);
    if (!ok || text.isEmpty())
        return;
    QStringList list = prj->getCompilerOptions();
    list.append(text);
    prj->setCompilerOptions(list);
    ui->listCompilerOptions->clear();
    ui->listCompilerOptions->addItems(list);
    prj->save();
}

void ConfigToolsForm::on_removeCompilerOption_clicked()
{
    if(prj == NULL) return;
    QStringList list = removeSelectedItemsFromList(ui->listCompilerOptions);
    prj->setCompilerOptions(list);
    prj->save();
}

void ConfigToolsForm::on_editCompilerOption_clicked()
{
    if(prj == NULL) return;
    QListWidgetItem *item =  ui->listCompilerOptions->currentItem();
    if(item == NULL) return;
    QString text = item->text();

    bool ok;
    text = QInputDialog::getText(this, "Edit", "Option:", QLineEdit::Normal, text, &ok);
    if (ok && !text.isEmpty())
    {
        item->setText(text);
        ui->listCompilerOptions->setCurrentItem(item);
        // copy ui items to prj
        QStringList list;
        for(int i=0;i<ui->listCompilerOptions->count();i++)
            list.append(ui->listCompilerOptions->item(i)->text());
        prj->setCompilerOptions(list);
        prj->save();
    }
}

void ConfigToolsForm::on_addLinkerOption_clicked()
{
    if(prj == NULL) return;
    QString text;

    bool ok;
    text = QInputDialog::getText(this, "Add", "Option", QLineEdit::Normal, text, &ok);
    if (!ok || text.isEmpty())
        return;
    QStringList list = prj->getLinkerOptions();
    list.append(text);
    prj->setLinkerOptions(list);
    ui->listLinkerOptions->clear();
    ui->listLinkerOptions->addItems(list);
    prj->save();
}

void ConfigToolsForm::on_removeLinkerOption_clicked()
{
    if(prj == NULL) return;
    QStringList list = removeSelectedItemsFromList(ui->listLinkerOptions);
    prj->setLinkerOptions(list);
    prj->save();
}

void ConfigToolsForm::on_editLinkerOption_clicked()
{
    if(prj == NULL) return;
    QListWidgetItem *item =  ui->listLinkerOptions->currentItem();
    if(item == NULL) return;
    QString text = item->text();

    bool ok;
    text = QInputDialog::getText(this, "Edit", "Option:", QLineEdit::Normal, text, &ok);
    if (ok && !text.isEmpty())
    {
        item->setText(text);
        ui->listLinkerOptions->setCurrentItem(item);
        // copy ui items to prj
        QStringList list;
        for(int i=0;i<ui->listLinkerOptions->count();i++)
            list.append(ui->listLinkerOptions->item(i)->text());
        prj->setLinkerOptions(list);
        prj->save();
    }
}

QStringList ConfigToolsForm::removeSelectedItemsFromList(QListWidget *widget)
{
    QStringList strlist;
    qDeleteAll(widget->selectedItems());
    for(int i=0;i<widget->count();i++)
        strlist.append(widget->item(i)->text());
    return strlist;
}

QString ConfigToolsForm::getPathname()
{
    if(prj == NULL) return QString();
    QString pathname = prj->getProjectFolder() + "/" + prj->getConfigFilename();
    return pathname;
}

QString ConfigToolsForm::getProjectFolder()
{
    if(prj == NULL) return QString();
    return prj->getProjectFolder();
}

Project* ConfigToolsForm::getProject()
{
    return prj;
}

void ConfigToolsForm::on_compilerCmd_textChanged(const QString &arg1)
{
    if(prj == NULL) return;
    prj->setCompilerCmd(arg1);
    prj->save();
}
