#include "configobjectsform.h"
#include "ui_configobjectsform.h"
#include <QFileDialog>
#include "utility/fileutility.h"
#include "libraryfiledialog.h"
#include <QInputDialog>
#include "target.h"

ConfigObjectsForm::ConfigObjectsForm(Target *target, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ConfigObjectsForm)
{
    ui->setupUi(this);

    // don't show blue focus rectangle around listWidget
    ui->listIncludeFolders->setAttribute(Qt::WA_MacShowFocusRect,false);
    ui->listLibraryFiles->setAttribute(Qt::WA_MacShowFocusRect,false);
    ui->listObjects->setAttribute(Qt::WA_MacShowFocusRect,false);

    this->target = target;
    updateForm();
}

ConfigObjectsForm::~ConfigObjectsForm()
{
    delete ui;
}

void ConfigObjectsForm::updateForm()
{
    if(target == NULL) return;

    QStringList objFiles,includeFolders;
    QString startupFilename,stubsFilename,scriptFilename;

    objFiles = target->getObjectFiles();
    includeFolders = target->getExternalIncludeFolders();
    startupFilename = target->getStartupFile();
    stubsFilename = target->getStubsFile();
    scriptFilename = target->getLinkerScriptFile();

    for(int i=0;i<objFiles.size();i++)
        objFiles.replace(i,FileUtility::replacePathWithKey(NULL,objFiles.at(i)));
    for(int i=0;i<includeFolders.size();i++)
        includeFolders.replace(i,FileUtility::replacePathWithKey(NULL,includeFolders.at(i)));

    startupFilename = FileUtility::replacePathWithKey(NULL,startupFilename);
    stubsFilename = FileUtility::replacePathWithKey(NULL,stubsFilename);
    scriptFilename = FileUtility::replacePathWithKey(NULL,scriptFilename);

    QStringList libFiles = target->getLibraryFiles();
    for(int i=0;i<libFiles.size();i++)
        libFiles.replace(i,FileUtility::replacePathWithKey(NULL,libFiles.at(i)));

    ui->listLibraryFiles->clear();
    ui->listLibraryFiles->addItems(libFiles);
    ui->listLibraryFiles->addItems(target->getStandardLibs());

    ui->listObjects->clear();
    ui->listIncludeFolders->clear();
    ui->startupFileName->clear();
    ui->stubsFileName->clear();
    ui->linkerScriptFilename->clear();

    ui->listObjects->addItems(objFiles);
    ui->listIncludeFolders->addItems(includeFolders);
    ui->startupFileName->setText(startupFilename);
    ui->stubsFileName->setText(stubsFilename);
    ui->linkerScriptFilename->setText(scriptFilename);
}

void ConfigObjectsForm::on_addIncludeFolder_clicked()
{
    if(target == NULL) return;

    QFileDialog dlg;
    QString dir = FileUtility::getDirLibrary();
    dlg.setDirectory(dir);
    dlg.setOption(QFileDialog::ShowDirsOnly,true);
    if(!dlg.exec())
        return;
    QStringList list = dlg.selectedFiles();
    QStringList plist = target->getExternalIncludeFolders();
    plist.append(list);
    plist.removeDuplicates();
    target->setExternalIncludeFolders(plist);
    target->save();

    for(int i=0;i<plist.size();i++)
        plist.replace(i,FileUtility::replacePathWithKey(NULL,plist.at(i)));

    ui->listIncludeFolders->clear();
    ui->listIncludeFolders->addItems(plist);
}

void ConfigObjectsForm::on_removeIncludeFolder_clicked()
{
    if(target == NULL) return;

    QStringList list = removeSelectedItemsFromList(ui->listIncludeFolders);
    for(int i=0;i<list.size();i++)
        list.replace(i,FileUtility::replaceKeyWithPath(NULL,list.at(i)));
    target->setExternalIncludeFolders(list);
    target->save();
}

void ConfigObjectsForm::on_addObject_clicked()
{
    if(target == NULL) return;

    QFileDialog dlg;
    dlg.setDirectory(FileUtility::getDirLibrary());
    dlg.setNameFilter("Object Files (*.o)");
    if(!dlg.exec())
        return;
    QStringList list = dlg.selectedFiles();
    QStringList plist = target->getObjectFiles();
    plist.append(list);
    plist.removeDuplicates();
    target->setObjectFiles(plist);
    target->save();

    for(int i=0;i<plist.size();i++)
        plist.replace(i,FileUtility::replacePathWithKey(NULL,plist.at(i)));

    ui->listObjects->clear();
    ui->listObjects->addItems(plist);
}

void ConfigObjectsForm::on_removeObject_clicked()
{
    if(target == NULL) return;

    QStringList list = removeSelectedItemsFromList(ui->listObjects);
    for(int i=0;i<list.size();i++)
        list.replace(i,FileUtility::replaceKeyWithPath(NULL,list.at(i)));
    target->setObjectFiles(list);
    target->save();
}


void ConfigObjectsForm::on_startupFileButton_clicked()
{
    if(target == NULL) return;

    QFileDialog dlg;
    dlg.setDirectory(FileUtility::getDirLibrary());
    dlg.setNameFilter("Startup File (*.o)");
    if(!dlg.exec())
        return;
    QStringList list = dlg.selectedFiles();
    if(list.size() != 1)
        return;
    QString filename = list.at(0);
    target->setStartupFile(filename);
    target->save();
    filename = FileUtility::replacePathWithKey(NULL,filename);
    ui->startupFileName->setText(filename);
}

void ConfigObjectsForm::on_stubsFileButton_clicked()
{
    if(target == NULL) return;

    QFileDialog dlg;
    dlg.setDirectory(FileUtility::getDirLibrary());
    dlg.setNameFilter("Stubs File (*.o)");
    if(!dlg.exec())
        return;
    QStringList list = dlg.selectedFiles();
    if(list.size() != 1)
        return;
    QString filename = list.at(0);
    target->setStubsFile(filename);
    target->save();

    filename = FileUtility::replacePathWithKey(NULL,filename);
    ui->stubsFileName->setText(filename);
}

QStringList ConfigObjectsForm::removeSelectedItemsFromList(QListWidget *widget)
{
    QStringList strlist;
    qDeleteAll(widget->selectedItems());
    for(int i=0;i<widget->count();i++)
        strlist.append(widget->item(i)->text());
    return strlist;
}

void ConfigObjectsForm::on_linkerScriptButton_clicked()
{
    if(target == NULL) return;

    QFileDialog dlg;
    dlg.setDirectory(FileUtility::getDirLibrary());
    dlg.setNameFilter("Linker Script (*.ld)");
    if(!dlg.exec())
        return;
    QStringList list = dlg.selectedFiles();
    if(list.size() != 1)
        return;
    QString filename = list.at(0);
    target->setLinkerScriptFile(filename);
    target->save();

    filename = FileUtility::replacePathWithKey(NULL,filename);
    ui->linkerScriptFilename->setText(filename);
}

void ConfigObjectsForm::on_startupFileClear_clicked()
{
    if(target == NULL) return;

    target->setStartupFile("");
    target->save();
    ui->startupFileName->setText("");
}

void ConfigObjectsForm::on_stubsFileClear_clicked()
{
    if(target == NULL) return;

    target->setStubsFile("");
    target->save();
    ui->stubsFileName->setText("");
}

void ConfigObjectsForm::on_linkerScriptClear_clicked()
{
    if(target == NULL) return;

    target->setLinkerScriptFile("");
    target->save();
    ui->linkerScriptFilename->setText("");
}


void ConfigObjectsForm::on_addStdLib_clicked()
{
    if(target == NULL) return;

    // get a generic gcc library name
    QInputDialog dlg;
    dlg.setWindowTitle("Enter standard library name");
    dlg.setLabelText("Name:");
    int ret = dlg.exec();
    if(ret == QInputDialog::Rejected) return;
    QString text = dlg.textValue();
    QStringList libs = target->getStandardLibs();
    libs.append(text);
    libs.removeDuplicates();
    target->setStandardLibs(libs);
    target->save();
    updateForm();
}

void ConfigObjectsForm::on_addLibraryFile_clicked()
{
    if(target == NULL) return;

    LibraryFileDialog dlg;
    if(!dlg.exec())
        return;

    QString pathName = dlg.pathName;
    QStringList list = target->getLibraryFiles();
    list.append(pathName);
    list.removeDuplicates();
    target->setLibraryFiles(list);
    target->save();
    updateForm();
}

void ConfigObjectsForm::on_removeLibraryFile_clicked()
{
    if(target == NULL) return;

    qDeleteAll(ui->listLibraryFiles->selectedItems());

    QStringList list;
    for(int i=0;i<ui->listLibraryFiles->count();i++)
        list.append(ui->listLibraryFiles->item(i)->text());

    QStringList fileList,standardList;
    foreach(QString s,list)
    {
        QString pathname = FileUtility::replaceKeyWithPath(NULL,s);
        QFileInfo info(pathname);
        if(info.exists())
            fileList.append(pathname);
        else
            standardList.append(s);
    }

    target->setLibraryFiles(fileList);
    target->setStandardLibs(standardList);
    target->save();
}
