//!----------------------------------------------------------------------------
//! file: gdbcontrol.cpp
//!
//! Implements interface with arm-none-eabi-gdb. Call start (passing pointer
//! to project and gdbserver) to launch gdb.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

/*
//----------------------------- gdb/mi ----------------------------------

arm-none-eabi-gdb -q --interpreter=mi

commands should get a response with last two lines being...
^done
(gdb)

-file-exec-and-symbols stm32_aread_blink.elf
^done
(gdb)

-target-select remote localhost:2525
=thread-group-created,id="42000"
=thread-created,id="1",group-id="42000"
*stopped,frame={addr="0x08000480",func="Default_Reset_Handler",args=[],file="startup_stm32f10x.cpp",fullname="/Users/johnmaloney/Desktop/code/cside/lib/src/stm32f10x/stm32f10x_startup/startup_stm32f10x.cpp",line="55"},thread-id="1",stopped-threads="all"
^connected
(gdb)

-break-insert main
^done,bkpt={number="1",type="breakpoint",disp="keep",enabled="y",addr="0x080001de",func="main",file="/Users/johnmaloney/Desktop/work/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/work/projects/stm32_aread_blink/main.cpp",line="48",times="0",original-location="main"}
(gdb)

-exec-continue
^running
*running,thread-id="all"
(gdb)
*stopped,reason="breakpoint-hit",disp="keep",bkptno="1",frame={addr="0x080001de",func="main",args=[],file="/Users/johnmaloney/Desktop/work/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/work/projects/stm32_aread_blink/main.cpp",line="48"},thread-id="1",stopped-threads="all"
(gdb)

-exec-continue
^running
*running,thread-id="all"
(gdb)
*stopped,reason="signal-received",signal-name="SIGTRAP",signal-meaning="Trace/breakpoint trap",frame={addr="0x08001866",func="delay",args=[{name="milliseconds",value="500"}],file="timer.cpp",fullname="/Users/johnmaloney/Desktop/code/cside/lib/src/stm32f10x/stm32f10x_lib/timer.cpp",line="9"},thread-id="1",stopped-threads="all"
(gdb)

- or -
*stopped,reason="breakpoint-hit",disp="keep",bkptno="2",frame={addr="0x08000270",func="main",args=[],file="/users/johnmaloney/desktop/dev/build-codelatchdebug/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/projects/stm32_aread_blink/main.cpp",line="52"},thread-id="1",stopped-threads="all"
(gdb)

- or -
=thread-group-exited,id="42000"
^error,msg="Remote connection closed"
(gdb)

-stack-list-locals 2
^done,locals=[{name="a",type="char",value="32 ' '"},{name="c",type="u8",value="79 'O'"},{name="s",type="myStruct"},{name="str",type="const char *",value="0xed7fefef \"\""},{name="adcVal",type="u32",value="72000"},{name="b",type="unsigned char",value="0 '\\000'"},{name="d",type="double",value="-2.2470799872852543e+307"},{name="mybird",type="Bird"}]
(gdb)

-stack-list-locals --all-values
^done,locals=[{name="a",value="32 ' '"},{name="c",value="79 'O'"},{name="s",value="{a = 536870912, b = 6.4323068697426199e-314}"},{name="str",value="0xed7fefef \"\""},{name="adcVal",value="72000"},{name="b",value="0 '\\000'"},{name="d",value="-2.2470799872852543e+307"},{name="mybird",value="{a = -310382609, b = 72000, s = {a = 536891376, b = 3.8397644212035823e-270}, c = 536891296, d = -1}"}]
(gdb)

-stack-list-locals 0
^done,locals=[name="a",name="c",name="s",name="str",name="adcVal",name="b",name="d",name="mybird"]
(gdb)

whatis a
&"whatis a\n"
~"type = char\n"
^done
(gdb)



*/

#include "gdb/gdbcontrol.h"
#include "project/project.h"
#include "utility/fileutility.h"
#include <QFileInfo>
#include <QTimer>
#include <QDebug>
#include "signal.h"
#include "target.h"
#ifdef Q_OS_WIN
#include <windows.h>
#include <wincon.h>  // for sending signals
#endif

#define MAX_FRAME_DEPTH     20      // maximum number of frames to return

GdbControl::GdbControl(QObject *parent) :
    QObject(parent)
{
    prj = NULL;
    //    atPrompt = false;
    targetRunning = true;
    serverConnected = true;
    atPrompt = false;
    gdbError = false;
    rxBytes = new QByteArray;
    rxBytes->reserve(32768); // reserve more space than we should need
    rxBytes->clear();
}

GdbControl::~GdbControl()
{
    rxBytes->clear();
    delete rxBytes;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
bool GdbControl::start(Project *project)
{
    if(project == NULL) return false;
    Target target = prj->getTarget();

    prj = project;
    rxBytes->clear();

    QString buildFolder = prj->getBuildFolder();
    QString debugCmd = prj->getCompilerBaseCmd() + "gdb";
    QStringList args;
    args << "-q" << "--interpreter=mi";

    QString prjName = prj->getName();
    QString elfFilename = prjName + ".elf";
    QString elfPathname =  buildFolder + "/" + elfFilename;
    QFileInfo info;

    info = QFileInfo(elfPathname);
    if(!info.exists())
        return false;

    // launch gdb process
    // debugCmd += " -q --interpreter=mi";
    gdb = new QProcess(this);
    //    connect(gdb,SIGNAL(readyRead()),this,SLOT(slotGdbRead()),Qt::QueuedConnection);
    connect(gdb,SIGNAL(readyReadStandardOutput()),this,SLOT(slotGdbReadyRead()),Qt::QueuedConnection);
    connect(gdb,SIGNAL(readyReadStandardError()),this,SLOT(slotGdbReadError()),Qt::QueuedConnection);
    connect(gdb,SIGNAL(finished(int)),this,SLOT(slotGdbExited(int)),Qt::QueuedConnection);
    gdb->setWorkingDirectory(buildFolder);
    //    gdb->setTextModeEnabled(true);
    gdb->start(debugCmd,args);

    QProcess::ProcessError error = gdb->error();
    if(error != QProcess::UnknownError)
    {
        qDebug() << "gdb startup error:" << error;
        return false;
    }

    // TODO *** probably get rid of this and just rely on waitForPrompt
    if (!gdb->waitForStarted(1000))
    {
        qDebug() << "gdb start failed\n";
        return false;
    }

    // TODO come up with a nice way to handle any startup errors
    // after the program is started we need to wait for the (gdb)
    // prompt before sending our first command.
    if(!waitForPrompt(1000))
    {
        // didn't get a prompt
        qDebug() << "gdb: didn't get startup command prompt\n";
        return false;
    }

    // set number of characters that can be in one line to unlimited
    if(!send("set width 0\n"))
    {
        qDebug() << "gdb: set width error\n";
        return false;
    }
    // set height to 0 so there is never a pause after multi-line outputs are printed
    if(!send("set height 0\n"))
    {
        qDebug() << "gdb: set height error\n";
        return false;
    }
    // set radix to base 16 to always print in hexidecimal
    if(!send("set radix 0x10\n"))
    {
        qDebug() << "gdb: set radix error\n";
        return false;
    }
    // set to never ask for confirmation
    if(!send("set confirm off\n"))
    {
        qDebug() << "gdb: set confirm error\n";
        return false;
    }
    // disable unnecessary gdb messages
    if(!send("set verbose off\n"))
    {
        qDebug() << "gdb: set verbose on error\n";
        return false;
    }
    // do not use shorthand to print repeating values, print every entry
    if(!send("set print repeats 0\n"))
    {
        qDebug() << "gdb: set print repeats 0 error\n";
        return false;
    }
    // no limit on number of elements in an array gdb can print
    if(!send("set print elements 0\n"))
    {
        qDebug() << "gdb: set print elements 0 error\n";
        return false;
    }
    // set async mode so we can stop execution without ctrl-c
    if(!send("-gdb-set target-async 1\n"))
    {
        qDebug() << "gdb: set print elements 0 error\n";
        return false;
    }

    // load elf file
#ifdef WIN32
    elfFilename = elfFilename.replace('/','\\');
#endif
    if(!send("-file-exec-and-symbols \""+elfFilename+"\"\n"))
    {
        qDebug() << "gdb file error\n";
        return false;
    }
    return true;
}

//! *** unsuccessful ***
//! -target-select remote localhost:2525
//! =thread-group-created,id="42000"
//! =thread-created,id="1",group-id="42000"
//! *stopped,frame={addr="0x00000000",func="??",args=[]},thread-id="1",stopped-threads="all"
//! ^connected
//! (gdb)

//! *** successfull ***
//! -target-select remote localhost:2525
//! =thread-group-created,id="42000"
//! =thread-created,id="1",group-id="42000"
//! *stopped,frame={addr="0x08000368",func="Default_Reset_Handler",args=[],file="/users/johnmaloney/desktop/codelatch/codelatch-build-desktop_qt_5_0_1_clang_64bit-debug/lib/stm32f10x/stm32f10x_startup/startup_stm32f10x.cpp",fullname="/Users/johnmaloney/Desktop/codelatch/codelatch-build-Desktop_Qt_5_0_1_clang_64bit-Debug/lib/stm32f10x/stm32f10x_startup/startup_stm32f10x.cpp",line="55"},thread-id="1",stopped-threads="all"
//! ^connected
//! (gdb)

bool GdbControl::connectToTarget(int port, int timeout_ms)
{
    QString cmd = "-target-select remote localhost:"+QString::number(port)+"\n";
    qDebug() << "Connecting to Target:" << cmd;
    if(!send(cmd,timeout_ms))
    {
        qDebug() << "connect to remote localhost error\n";
        return false;
    }
    qDebug() << "Returning success from connectToTarget\n";
    return true;
}

void GdbControl::print(QString str)
{
    emit appendConsoleLine(str);
}

bool GdbControl::sendBreak(int timeout_ms)
{
    gdbReadList.clear();

    // note: for this to work we had to send -gdb-set target-async 1\n in initialization sequence.
    bool ret = send("-exec-interrupt\n",timeout_ms);
    if(!ret)
        qDebug() << "control sendBreak Timed out.\n";
    return ret;
}

bool GdbControl::waitForTargetStop(int timeout_ms)
{
    // wait for the target to stop
    QTimer timer;
    connect(&timer, SIGNAL(timeout()), this, SLOT(slotWaitForStopTimeout()));
    timer.start(timeout_ms);
    int ret = waitForTargetStopEventLoop.exec(); // 0=timeout 1=at prompt
    disconnect(&timer, SIGNAL(timeout()), this, SLOT(slotWaitForStopTimeout()));
    timer.stop();
    if(ret != 1)
        return false;
    return true;
}

bool GdbControl::waitForPrompt(int timeout_ms)
{
    QTimer timer ;
    connect(&timer, SIGNAL(timeout()), this, SLOT(slotWaitForPromptTimeout()));
    timer.start(timeout_ms);
    qDebug() << "waitForPromptEventLoop:" << waitForPromptEventLoop.isRunning();
    int ret = waitForPromptEventLoop.exec(); // 0=timeout 1=at prompt
    timer.stop();
    disconnect(&timer, SIGNAL(timeout()), this, SLOT(slotWaitForPromptTimeout()));

    if(ret != 1)
        return false;
    return true;
}

bool GdbControl::send(QString str, int timeout_ms)
{
        qDebug() << "GdbControl::send:" << str;
    gdbError = false;
    if(gdb == NULL) return false;
    if(!gdb->isOpen()) return false;

    gdbReadList.clear();
    //    qDebug() << "control Tx:" << str;
    int n = str.length();
    char *buf = new char[n+1];
    memset(buf,0,n+1);
    for(int i=0;i<n;i++)
        //        buf[i] = str.at(i).toAscii();
        //        buf[i] = str.at(i).toLatin1();
        buf[i] = str.at(i).toLatin1();

    if(gdb->write(buf,n) == -1) // maybe change this to if(gdb->write(buf,n) != n)
    {
        delete [] buf;
        qDebug() << "control write failed";
        return false;
    }
    delete [] buf;
    //    qDebug() << "calling waitForPrompt:" << timeout_ms;
    bool ret = waitForPrompt(timeout_ms);
    //    qDebug() << "returned from waitForPrompt:" << gdbError << " : " << ret;
    if(gdbError)
    {
        gdbError = false;
        return false;
    }
    return ret;
}

void GdbControl::slotGdbReadyRead()
{
    bool receivedTargetStopped = false;
    atPrompt = false;

    if(gdb == NULL) return;
    if(!gdb->isOpen()) return;

    QByteArray newBytes = gdb->readAllStandardOutput();
    rxBytes->append(newBytes);

    // check for a line feed. a line feed indicates the end of something. until
    // then keep accumulating bytes.
    int i = rxBytes->indexOf(QByteArray("\n"));
    if(i == -1)
        return;

    QByteArray remainder = rxBytes->right(rxBytes->length()-i-1);
    *rxBytes = rxBytes->left(i+1);
    //    QList<QByteArray> list = rxBytes->split('\n');

    //    qDebug() << "rxBytes:" << *rxBytes;
    //    qDebug() << "gdblist length:" << list.size();

    //    foreach(QByteArray array,list)
    //    {
    //        QString str(array);
    QString str(*rxBytes);

    //    qDebug() << "  rx str:" << str;

    gdbReadList.append(str);

    // check for these special strings...
    // *running,thread-id="all"
    // *stopped,reason="breakpoint-hit",disp="keep",bkptno="1",frame={addr="0x080001de",func="main",args=[],file="/Users/johnmaloney/Desktop/work/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/work/projects/stm32_aread_blink/main.cpp",line="48"},thread-id="1",stopped-threads="all"
    // *stopped,reason="signal-received",signal-name="SIGTRAP",signal-meaning="Trace/breakpoint trap",frame={addr="0x08001866",func="delay",args=[{name="milliseconds",value="500"}],file="timer.cpp",fullname="/Users/johnmaloney/Desktop/code/cside/lib/src/stm32f10x/stm32f10x_lib/timer.cpp",line="9"},thread-id="1",stopped-threads="all"
    // ^error,msg="Remote connection closed"
    // ^connected
    if(str.startsWith("*running,"))
        targetRunning = true;
    else if(str.startsWith("*stopped,"))
    {
        targetRunning = false;
        receivedTargetStopped = true;
    }
    else if(str.startsWith("^connected"))
        serverConnected = true;
    else if(str.startsWith("^error,"))
    {
        //        qDebug() << str;
        // note: we can get an error that is non-critical if we ask for the address of a variable that the compiler
        // has decided to assign directly to a register, not a memory location.
        if(!str.startsWith("^error,msg=\"Address requested for identifier"))
            gdbError = true;
    }
    else if(str.startsWith("(gdb) \n"))
        atPrompt = true;
    //    }

    rxBytes->clear();
    rxBytes->append(remainder);

    if(waitForPromptEventLoop.isRunning() && atPrompt)
        waitForPromptEventLoop.exit(1);
    else if(waitForTargetStopEventLoop.isRunning() && receivedTargetStopped)
        waitForTargetStopEventLoop.exit(1);
    else if(!gdbError && (atPrompt || receivedTargetStopped))
    {
        // no event loop is running, send signal to debug that we reached a prompt without someone waiting for it.
        // this will happen if we are running and come to a break point or the target aborts.
        // don't emit on an error, doing this will ultimately cause a memory access error when
        // this program exits.
        emit signalAtPrompt();
    }

    if(rxBytes->contains('\n'))
        slotGdbReadyRead();
}

void GdbControl::slotWaitForPromptTimeout()
{
    // timeout waiting for gdb prompt
    qDebug() << "*** timed out waiting for gdb prompt ***";
    if(waitForPromptEventLoop.isRunning())
        waitForPromptEventLoop.exit(0);
}

void GdbControl::slotWaitForStopTimeout()
{
    // timeout waiting for target to stop
    qDebug() << "*** timed out waiting for target to stop ***";
    if(waitForTargetStopEventLoop.isRunning())
        waitForTargetStopEventLoop.exit(0);
}

void GdbControl::slotGdbReadError()
{
    QTextStream stream(gdb->readAllStandardError());
    QStringList list;
    while (!stream.atEnd())
        list.append(stream.readLine());
    foreach(QString str,list)
        qDebug() << "control Error Rx:" + str + "\n";
}

//-----------------------------------------------------------------------------
// \brief   Gets the current source file pathname and line number. GDB must be
//          at a command prompt when this is called.
//
//          Returns: false if failed, true otherwise.
//-----------------------------------------------------------------------------
// -stack-info-frame
// ^done,frame={level="0",addr="0x080001d8",func="main",file="/users/johnmaloney/desktop/dev/build-codelatchdebug/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/projects/stm32_aread_blink/main.cpp",line="36"}
// (gdb)

bool GdbControl::getSourceInfo(QString *pathname, QString *function, int *lineNumber)
{    
    if(!send("-stack-info-frame\n"))
        return false;
    QStringList list(gdbReadList);
    if(list.size() < 2)
        return false;
    QString str = list.first();

    if(!str.startsWith("^done,frame="))
        return false;

    int i = str.indexOf("\",func=\"");
    if(i == -1)
        return false;
    str = str.right(str.length()-i-8);
    i = str.indexOf("\"");
    if(i == -1)
        return false;
    QString functionName = str.left(i);

    i = str.indexOf("\",file=\"");
    if(i == -1)
        return false;
    str = str.right(str.length()-i-8);
    i = str.indexOf("\"");
    if(i == -1)
        return false;
    QString filepath = str.left(i);

    i = str.indexOf("\",line=\"");
    if(i == -1)
        return false;
    str = str.right(str.length()-i-8);
    i = str.indexOf("\"");
    if(i == -1)
        return false;
    QString lineStr = str.left(i);
    bool ok;
    int line = lineStr.toInt(&ok);
    if(!ok)
        return false;

    *pathname = filepath;
    *function = functionName;
    *lineNumber = line;

#ifdef WIN32
    *pathname = pathname->replace('\\','/');
#endif
//    *pathname = pathname->toLower();

    return true;
}


// get variable value
// print name
// eg  send: print adcVal
// response: $3 = 0x4dc

bool GdbControl::addBreakPoint(QString pathname,int line)
{
    if(breakPointList.size() >= 5) return false;

    bool needResume = false;
    if(targetRunning)
    {
        needResume = true;
        if(!sendBreak(250))
            return false;
    }

    //  QFileInfo info(pathname);
    //   QString filename = info.fileName();

#ifdef Q_OS_WIN
    //    pathname = pathname.replace("/","\\");
#endif

    //    QString cmd = "-break-insert \"" + pathname + "\":" + QString::number(line) + "\n";
    // can't use mi command because it won't tollerate spaces in the filename
    QString cmd = "b \"" + pathname + "\":" + QString::number(line) + "\n";
    if(!send(cmd,250))
    {
        if(needResume)
            send("-exec-continue\n");
        return false;
    }

    QStringList list(gdbReadList);

    // ^done,bkpt={number="4",type="breakpoint",disp="keep",enabled="y",addr="0x08000270",func="main",file="/users/johnmaloney/desktop/dev/build-codelatchdebug/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/projects/stm32_aread_blink/main.cpp",line="52",times="0",original-location="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/projects/stm32_aread_blink/main.cpp:52"}
    // (gdb)
    // - or -
    // ^error,....


    if(list.size() < 2)
    {
        // TODO: this is an error condition we should bail
        if(needResume)
            send("-exec-continue\n");
        return false;
    }
    /*
    QString resp = list.first();
    if(!resp.startsWith("^done,"))
    {
        // TODO: this is an error condition we should bail
        if(needResume)
            send("-exec-continue\n");
        return false;
    }

    int i = resp.indexOf("number=\"");
    if(i == -1)
    {
        // TODO: this is an error condition we should bail
        if(needResume)
            send("-exec-continue\n");
        return false;
    }
    QString str = resp.right(resp.length()-i-8);
    i = str.indexOf("\"");
    str = str.left(i);
    bool ok;
    int bpNum = str.toInt(&ok);
    if(!ok)
    {
        // TODO: this is an error condition we should bail
        if(needResume)
            send("-exec-continue\n");
        return false;
    }
    */
    QString s = list.at(1);
    if(!s.startsWith("~\"Breakpoint "))
    {
        qDebug() << "error setting breakpoint!";
        if(needResume)
            send("-exec-continue\n");
        return false;
    }
    s = s.right(s.length()-13);
    int i = s.indexOf(' ');
    if(i==-1)
    {
        qDebug() << "error setting breakpoint2!";
        if(needResume)
            send("-exec-continue\n");
        return false;
    }
    s = s.left(i);
    bool ok;
    int bpNum = s.toInt(&ok);
    if(!ok)
    {
        // TODO: this is an error condition we should bail
        if(needResume)
            send("-exec-continue\n");
        return false;
    }
    BreakPointStruct item;
    item.number = bpNum;
    item.line = line;
    item.pathname = pathname;
    breakPointList.append(item);

    qDebug() << "added bkpt:" << item.number << " line:" << line << " path:" << pathname;

    if(needResume)
        if(!send("-exec-continue\n"))
            return false;

    return true;
}

bool GdbControl::removeBreakPoint(QString pathname, int line)
{
    bool needResume = false;
    if(targetRunning)
    {
        needResume = true;
        if(!sendBreak(250))
            return false;
    }

    bool ret = false;
    for(int i=0;i<breakPointList.size();i++)
    {
        BreakPointStruct item = breakPointList.at(i);
        if((item.pathname == pathname) && (item.line == line))
        {
            // send gdb command
            QString cmd = "-break-delete " + QString::number(item.number) + "\n";
            if(!send(cmd,250)) break;
            if(!gdbReadList.startsWith("^done"))
                return false;

            breakPointList.removeAt(i);
            ret = true;
            break;
        }
    }
    if(needResume)
        send("-exec-continue\n");
    return ret;
}

bool GdbControl::isSuspended()
{
    return !targetRunning;
}

bool GdbControl::readRegisters(QStringList *names, QStringList *values)
{
    bool ret = send("-data-list-register-names\n");
    if(!ret) return false;
    //    ^done,register-names=["r0","r1","r2","r3","r4","r5","r6","r7","r8","r9","r10","r11","r12","sp","lr","pc","f0","f1","f2","f3","f4","f5","f6","f7","fps","cpsr","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
    //    (gdb)
    QStringList list(gdbReadList);
    if(list.size() < 2) return false;
    QString line = list.first();
    if(!line.startsWith("^done,")) return false;
    int i = line.indexOf("[");
    if(i == -1) return false;
    line = line.right(line.length()-i-1);
    line = line.remove(']');
    line = line.remove('\"');
    line = line.remove('\n');
    QStringList lineList = line.split(',');
    foreach(QString entry,lineList)
        if(!entry.isEmpty())
            names->append(entry);


    ret = send("-data-list-register-values x\n");
    if(!ret) return false;
    // ^done,register-values=[{number="0",value="0x0"},{number="1",value="0xb"},{number="2",value="0x7"},{number="3",value="0x0"},{number="4",value="0xbffffffe"},{number="5",value="0x9efbfffc"},{number="6",value="0x6db55148"},{number="7",value="0x20004fe8"},{number="8",value="0xfffffffc"},{number="9",value="0xffff5fde"},{number="10",value="0xb6ef57c8"},{number="11",value="0xd2497243"},{number="12",value="0x0"},{number="13",value="0x20004fe8"},{number="14",value="0x80003f3"},{number="15",value="0x80001d8"},{number="16",value="0x0"},{number="17",value="0x8000000000000000"},{number="18",value="0x8000000000000000"},{number="19",value="0x8000000000000000"},{number="20",value="0x0"},{number="21",value="0x8000000000000000"},{number="22",value="0x8000000000000000"},{number="23",value="0x8000000000000000"},{number="24",value="0x81000000"},{number="25",value="0x20004fe8"}]
    // (gdb)
    list = gdbReadList;
    if(list.size() < 2) return false;
    line = list.first();
    if(!line.startsWith("^done,")) return false;
    i = line.indexOf('{');
    if(i == -1) return false;
    line = line.right(line.length()-i-1);
    line = line.remove("}]");
    line = line.remove('\"');
    line = line.remove('\n');
    QStringList entryList = line.split("},{");
    foreach(QString entry,entryList)
    {
        i = entry.indexOf("value=");
        if(i == -1)
            return false;
        QString substr = entry.right(entry.length()-i-6);
        values->append(substr);
    }
    return true;
}

/*
//-----------------------------------------------------------------------------
// \brief   Returns the root type of a variable.
//          For example if you typedef uint8_t unsigned char and then
//          declare a variable uint8_t a; if you ask gdb whatis a it will
//          return uint8_t if you whatis uint8_t it will return unsigned char
//          if you whatis unsigned char it will return unsigned car.
//-----------------------------------------------------------------------------
QString GdbControl::getVariableRootType(QString name)
{
    // &"whatis &Pin\n"
    // ~"type = CPin *\n"
    // ^done
    // (gdb)

    // &"whatis BKP_TypeDef\n"
    // &"No symbol \"BKP_TypeDef\" in current context.\n"
    // ^error,msg="No symbol \"BKP_TypeDef\" in current context."
    // (gdb)

    // &"whatis &SCB\n"
    // &"Attempt to take address of value not located in memory.\n"
    // ^error,msg="Attempt to take address of value not located in memory."
    // (gdb)

    QString str(name);
    QString lastStr;
    lastStr = str;
    bool ret = send("whatis "+str+"\n");
    if(!ret) return name; // avoid total failure, at least here.
    QStringList list(gdbReadList);

    foreach(QString line,list)
    {
        if(line.startsWith("~\"type ="))
        {
            line.remove("~\"type =");
            line.remove("\n\"");
            line = line.simplified();
            return line;
        }
    }

    return QString();
}
*/

//-----------------------------------------------------------------------------
// \brief   Returns the type of a variable.
//-----------------------------------------------------------------------------
QString GdbControl::getVariableType(QString name)
{
    //    qDebug() << "whatis " << name;

    bool ret = send("whatis "+name+"\n");
    if(!ret) return QString(); // avoid total failure, at least here.
    QStringList list(gdbReadList);
    foreach(QString line,list)
    {
        if(line.startsWith("~\"type = "))
        {
            line.remove("~\"type = ");
            line.remove("\\n\"");
            line = line.simplified();
            return line;
        }
    }

    return QString();
}


//!-----------------------------------------------------------------------------
//! \brief   Returns a gdb string containing all locals, or an empty string if
//! failure.
//!
//! return example:
//!  {name="i",type="int",value="0xffffffde"},{name="c",type="char",value="0xbf"},{name="array",type="int [10]"},{name="b",type="int",value="0x11940"},{name="d",type="wi",value="0x20004fe0"}
//!-----------------------------------------------------------------------------
QString GdbControl::getLocals(void)
{
    // -stack-list-locals 1
    // ^done,locals=[{name="a",value="0x62"},{name="str",value="\"Hello this is John Maloney\""},{name="c",value="0xf"},{name="s",value="{a = 0x4, b = 67.400000000000006}"},{name="adcVal",value="0x0"},{name="b",value="0xc"},{name="d",value="22.32"},{name="mybird",value="{array1d = {0x685aa2c}, a = 0x1e, b = 0x7f059835, s = {a = 0xcca3b70a, b = -2.6472918356657978e-34}, array4d = {0xf0e08fee, 0x7156ffd7, 0xa1208bab, 0x5d75c549}, c = 0x5556add4, d = 0x1ecbdeba}"},{name="myuni",value="{ch = 0xa8, i = 0xe7abfa8, l = 0xe7abfa8, f = 3.09071582e-30, d = 7.3553016434034279e+112}"}]
    // (gdb)

    bool ret = send("-stack-list-locals 1\n",2000);
    if(!ret) return QString();
    QStringList list(gdbReadList);
    if(list.size() < 2)
        return QString();
    QString line = list.first();
    if(!line.startsWith("^done,locals=["))
        return QString();
    line = line.right(line.length() - 14);
    line = line.left(line.length() - 1);
    return line;
}

QString GdbControl::getArgs(void)
{            
    //    -stack-list-arguments 2
    //    ^done,stack-args=[frame={level="0",args=[{name="this",type="CPin * const",value="0x20000214"},{name="pin",type="u32",value="0xd"},{name="mode",type="int",value="0x1"}]},frame={level="1",args=[]}]
    //    (gdb)
    //
    //    -stack-list-arguments 2
    //    ^done,stack-args=[frame={level="0",args=[]}]
    //    (gdb)

    bool ret = send("-stack-list-arguments 1\n",2000);
    if(!ret) return QString();
    QStringList list(gdbReadList);
    if(list.size() < 2) return QString();
    QString line = list.first();
    if(!line.startsWith("^done,stack-args=[")) return QString();
    line = line.right(line.length() - line.indexOf(",args=[") - 7);
    line = line.left(line.indexOf("]}")).simplified();
    return line;
}

bool GdbControl::writeVariable(QString name, QString value)
{
    QString str;
    str = "set variable " + name + " = " + value + "\n";

    bool ret = send(str,2000);
    return ret;
}

void GdbControl::terminate()
{
    if(gdb == NULL) return;
    //    if(!gdb->isOpen()) return;

    qDebug() << "GdbControl::terminate():" << gdb << "\n";

    if(gdb->isOpen())
    {
        sendBreak();
        // give a chance to stop
        QTimer timer;
        QEventLoop eloop;
        connect(&timer,SIGNAL(timeout()),&eloop,SLOT(quit()));
        timer.start(250);
        eloop.exec();

        // attempt to shudown gdb process gracefully
        qDebug() << "gdb->write(q)";
        gdb->write("q\n",2);
        // wait for gdb to terminate
        if(!gdb->waitForFinished(250))
        {
            qDebug() << "gdb: didn't shut down gracefully, killing it.\n";
            gdb->kill();
            // if we call gdb->kill() slotGdbExited will never be called, so we need
            // to handle the clean up here.
            gdb->deleteLater();
            gdb = NULL;
        }
    }
    //    gdb->deleteLater();
    //    gdb = NULL;
}

//-----------------------------------------------------------------------------
// \brief   GDB QProcess terminated. This gets called by the QProcess.finished
//          signal connected to in the GdbControl.start function.
//-----------------------------------------------------------------------------
void GdbControl::slotGdbExited(int exitval)
{
    qDebug() << "GdbControl::slotGdbExited:"<<exitval;

    if(gdb)
        gdb->deleteLater();
    gdb = NULL;
}

bool GdbControl::writeRegister(QString name, quint32 val)
{
    QString cmd = "set $" + name + "=0x" + QString::number(val,16) + "\n";
    return send(cmd);
}

/*
 -data-disassemble
    [ -s start-addr -e end-addr ]
  | [ -f filename -l linenum [ -n lines ] ]
  -- mode
Where:

`start-addr'
is the beginning address (or $pc)
`end-addr'
is the end address
`filename'
is the name of the file to disassemble
`linenum'
is the line number to disassemble around
`lines'
is the the number of disassembly lines to be produced. If it is -1, the whole function will be disassembled, in case no end-addr is specified. If end-addr is specified as a non-zero value, and lines is lower than the number of disassembly lines between start-addr and end-addr, only lines lines are displayed; if lines is higher than the number of lines between start-addr and end-addr, only the lines up to end-addr are displayed.
`mode'
is either 0 (meaning only disassembly) or 1 (meaning mixed source and disassembly).


-data-disassemble -s $pc -e "$pc + 0x30" -- 0
^done,asm_insns=[{address="0x080001d8",func-name="main",offset="4",inst="movw\tr0, #532\t; 0x214"},{address="0x080001dc",func-name="main",offset="8",inst="movt\tr0, #8192\t; 0x2000"},{address="0x080001e0",func-name="main",offset="12",inst="mov.w\tr1, #13"},{address="0x080001e4",func-name="main",offset="16",inst="mov.w\tr2, #1"},{address="0x080001e8",func-name="main",offset="20",inst="bl\t0x80004d8 <_ZN4CPin4modeEmi>"},{address="0x080001ec",func-name="main",offset="24",inst="movw\tr0, #532\t; 0x214"},{address="0x080001f0",func-name="main",offset="28",inst="movt\tr0, #8192\t; 0x2000"},{address="0x080001f4",func-name="main",offset="32",inst="mov.w\tr1, #3"},{address="0x080001f8",func-name="main",offset="36",inst="mov.w\tr2, #1"},{address="0x080001fc",func-name="main",offset="40",inst="bl\t0x80004d8 <_ZN4CPin4modeEmi>"},{address="0x08000200",func-name="main",offset="44",inst="movw\tr0, #532\t; 0x214"},{address="0x08000204",func-name="main",offset="48",inst="movt\tr0, #8192\t; 0x2000"}]
(gdb)

*/
QStringList GdbControl::getAssembly()
{
    //SEND:info line main
    //&"info line main\n"
    //~"Line 95 of \"/users/johnmaloney/desktop/dev/projects/stm32_aread_blink3/main.cpp\" starts at address 0x800023c <main> and ends at 0x8000242 <main+6>.\n"
    //^done
    //(gdb)

    // -data-disassemble -s $pc -e $pc+0x30
    // -data-disassemble -s $pc -e "$pc + 0x30" -- 0
    //    bool ret = send("disas /m\n",GdbControl::PromptWithTimeout,5000);
    // get our current function

    // get the name of the function we are in
    QString path,func;
    int line;
    if(!getSourceInfo(&path,&func,&line))
        return QStringList();

    // get the starting address of the function
    QString cmd = "info line " + func + "\n";
    bool ret = send(cmd,2000);
    if(!ret) return QStringList();

    if(gdbReadList.size() < 2) return QStringList();
    QString str = gdbReadList.at(1);
    int i = str.indexOf("starts at address 0x");
    if(i == -1) return QStringList();
    str = str.right(str.length() - i - 18);
    i = str.indexOf('<');
    str = str.left(i);
    str = str.trimmed();

    cmd = "disas /m " + str + "\n";
    ret = send(cmd,3000);

    //    ret = send("disas /m $pc,$pc+0x30\n",2000);
    if(!ret) return QStringList();

    QStringList list;
    foreach(QString s,gdbReadList)
    {
        s.remove("\\n\"");
        s.remove("~\"");
        s.replace("\\t","   ");
        list.append(s);
    }

    return list;
}


/*
-data-read-memory 0x2000020c x 4 1 10
^done,addr="0x2000020c",nr-bytes="40",total-bytes="40",next-row="0x20000234",prev-row="0x200001e4",next-page="0x20000234",prev-page="0x200001e4",memory=[{addr="0x2000020c",data=["0xc3eaa247","0x00000000","0x00000000","0x00000000","0x08003278","0x00000000","0x00000000","0x00000000","0x00000000","0x00000000"]}]
(gdb)

-data-read-memory 0x2000020c x 2 1 10
^done,addr="0x2000020c",nr-bytes="20",total-bytes="20",next-row="0x20000220",prev-row="0x200001f8",next-page="0x20000220",prev-page="0x200001f8",memory=[{addr="0x2000020c",data=["0xa247","0xc3ea","0x0000","0x0000","0x0000","0x0000","0x0000","0x0000","0x3278","0x0800"]}]
(gdb)

*/

QStringList GdbControl::readMemory(uint32_t start, int numwords)
{
    QStringList strList;
    QString str;

    str = str.sprintf("-data-read-memory 0x%x x 4 1 %d\n",start,numwords);
    bool ret = send(str,2000);
    if(!ret) return strList;
    QStringList list(gdbReadList);
    if(list.isEmpty()) return strList;
    QString line = list.first();
    if(!line.startsWith("^done,")) return strList;

    int i = line.lastIndexOf('\"');
    if(i == -1) return strList;
    line = line.left(i);
    i = line.indexOf(",data=[");
    if(i == -1) return strList;
    line = line.right(line.length()-i-7);
    line.remove('\"');
    strList = line.split(',');
    return strList;
}

bool GdbControl::writeMemory(uint32_t address, uint32_t data)
{
    QString cmd;
    cmd.sprintf("-data-write-memory 0x%08x x 4 0x%08x\n",address,data);
    return send(cmd);
}

uint32_t GdbControl::getVariableAddress(QString name, bool *ok)
{
    QString str;
    *ok = false;

    //    -data-evaluate-expression i
    //    ^done,value="-34"

    str = "-data-evaluate-expression " + name + "\n";
    bool ret = send(str,1000);
    if(!ret) return false;
    str = gdbReadList.first();
    if(!str.startsWith("^done,value=\"")) return 0;
    str = str.right(str.length() - str.indexOf('"') - 1);
    int i = str.indexOf(' ');
    if(i != -1)
        str = str.left(i);
    str.remove('"');

    uint32_t address = str.toUInt(ok,16);

    return address;
}

//^done,stack=[frame={level="0",addr="0x08000144",func="sub3",file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="10"},frame={level="1",addr="0x08000172",func="sub2",file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="18"},frame={level="2",addr="0x08000192",func="sub1",file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="26"},frame={level="3",addr="0x080001ae",func="main",file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="36"}]

QList<DebugFrame> GdbControl::getStackFrames()
{
    bool ret = send("-stack-list-frames\n",1000);
    if(!ret) return QList<DebugFrame>();
    QStringList list(gdbReadList);

    if(list.isEmpty()) return QList<DebugFrame>();
    QString line = list.first();

    QString key = "^done,stack=[";
    if(!line.startsWith(key)) return QList<DebugFrame>();
    line = line.right(line.length()-key.length());
    list = line.split("frame={");
    list.removeFirst();

    QList<DebugFrame> output;
    foreach(QString s,list)
    {
        DebugFrame fs;
        bool ok;

        QStringList subList = s.split(',');
        if(subList.length() < 6) continue;

        QString item = subList.at(0);
        if(!item.startsWith("level=")) continue;
        item.remove("level=\"");
        item.remove(item.length()-1,1);
        fs.frameNumber = item.toInt();

        item = subList.at(1);
        if(!item.startsWith("addr=")) continue;
        item.remove("addr=\"");
        item.remove(item.length()-1,1);
        fs.address = item.toULong(&ok,16);

        item = subList.at(2);
        if(!item.startsWith("func=")) continue;
        item.remove("func=\"");
        item.remove(item.length()-1,1);
        fs.functionName = item;

        item = subList.at(4);
        if(!item.startsWith("fullname=")) continue;
        item.remove("fullname=\"");
        item.remove(item.length()-1,1);
        fs.pathName = item;

        item = subList.at(5);
        if(!item.startsWith("line=")) continue;
        item.remove("line=\"");
        item = item.left(item.indexOf('"'));
        fs.lineNumber = item.toInt();

        output.append(fs);
        if(output.length() == MAX_FRAME_DEPTH) break;
    }
    return output;
}

int GdbControl::getCurrentThraedNumber()
{
    // SEND:-thread-info
    // ^done,threads=[{id="1",target-id="Thread <main>",frame={level="0",addr="0x08000144",func="sub3",args=[{name="a",value="0x2a"}],file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="10"},state="stopped"}],current-thread-id="1"
    bool ret = send("-thread-info\n");
    if(!ret) return -1;
    QStringList list(gdbReadList);
    QString line = list.first();
    if(!line.startsWith("^done,threads=")) return -1;
    QStringList split = line.split(',');
    line = split.last();
    QString key = "current-thread-id=";
    if(!line.startsWith(key)) return -1;
    line = line.right(line.length()-key.length());
    line.remove('"');
    bool ok;
    int id = line.toInt(&ok);
    if(!ok) return -1;
    return id;
}

///----------------------------------------------------------------------------
/// \brief Returns local variables and function arguments string.
/// return form: {name="x",value="11"},{name="s",value="{a = 1, b = 2}"}
///----------------------------------------------------------------------------
QString GdbControl::getVariables(int threadId, int frameNumber)
{
    // SEND: -stack-list-variables --thread 1 --frame 0 --all-values
    // ^done,variables=[{name="x",value="11"},{name="s",value="{a = 1, b = 2}"}]
    QString str;
    str.sprintf("-stack-list-variables --thread %d --frame %d --all-values\n",threadId,frameNumber);
    bool ret = send(str);
    if(!ret) return QString();
    QStringList list(gdbReadList);
    QString line = list.first();
    QString key = "^done,variables=[";
    if(!line.startsWith(key)) return QString();
    // remove leading key and trailing ]
    line = line.right(line.length()-key.length());
    int i = line.lastIndexOf(']');
    if(i == -1) return QString();
    line = line.left(i);
    return line;
}

QString GdbControl::evaluateExpression(QString expression)
{
    // SEND:-data-evaluate-expression myData
    // ^done,value="{0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}"
    QString str = "-data-evaluate-expression " + expression +"\n";
    bool ret = send(str);
    if(!ret) return QString();
    QStringList list(gdbReadList);
    QString line = list.first();
    QString key = "^done,value=\"";
    if(!line.startsWith(key)) return QString();
    // remove leading key
    line = line.right(line.length()-key.length());
    line = line.left(line.length() - 2);
    return line;
}

/*
SEND:info variables
&"info variables\n"
~"All defined variables:\n"
~"\nFile "
~"lib/target-headers/olimexino-stm32/target-pins.c:\n"
~"unsigned short GPIO_PIN_MAP[65];\n"
~"GPIO_TypeDef *GPIO_PORTS[4];\n"
~"unsigned char GPIO_PORT_MAP[65];\n"
~"signed char TABLE_ADCChannel[22];\n"
~"TIM_TypeDef *TABLE_Timer[8];\n"
~"unsigned char TABLE_pinTimer[16];\n"
~"unsigned char TABLE_pinTimerChannel[16];\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/lib/src/pin.cpp:\n"
~"CPin Pin;\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/cmsis/src/stm32f10x_rcc.c:\n"
~"static unsigned char ADCPrescTable[4];\n"
~"static unsigned char APBAHBPrescTable[16];\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/cmsis/src/system_stm32f10x.c:\n"
~"unsigned char AHBPrescTable[16];\n"
~"uint32_t SystemCoreClock;\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/cmsis/src/stm32f10x_it.c:\n"
~"volatile u32 systicks;\n"
~"\nFile "
~"projects/01-basic/blink led/main.cpp:\n"
~"int global1;\n"
~"int global2;\n"
~"\nFile "
~"/users/johnmaloney/desktop/dev/lib/stm32f10x/stm32f10x_startup/startup_stm32f10x.c:\n"
~"static void (*g_pfnVectors[67])(void);\n"
~"\nNon-debugging symbols:\n"
~"0x0800241c  __frame_dummy_init_array_entry\n"
~"0x0800241c  __init_array_start\n"
~"0x0800241c  __preinit_array_end\n"
~"0x0800241c  __preinit_array_start\n"
~"0x08002424  __do_global_dtors_aux_fini_array_entry\n"
~"0x08002424  __init_array_end\n"
~"0x2000003c  APBAHBPrescTable\n"
~"0x2000004c  ADCPrescTable\n"
~"0x20000064  impure_data\n"
~"0x20000154  _impure_ptr\n"
~"0x20000158  __JCR_END__\n"
~"0x20000158  __JCR_LIST__\n"
~"0x2000015c  _sbss\n"
~"0x2000015c  completed.3246\n"
~"0x20000168  _ebss\n"
^done
(gdb)
*/

/*
SEND:-data-evaluate-expression TABLE_pinTimer
^done,value="\"\\020\\001\\001\\001\\001\\002\\003\\000\\000\\000\\003c\\002\\002c\\003\""
(gdb)

SEND:-data-evaluate-expression systicks
^done,value="0x0"
(gdb)

SEND:-data-evaluate-expression Pin
^done,value="{callbackFuncPtr = 0}"
(gdb)
*/
///----------------------------------------------------------------------------
/// \brief Returns a list of global variable names.
///----------------------------------------------------------------------------
QStringList GdbControl::getGlobalVariableNames()
{
    QString str("info variables\n");
    bool ret = send(str);
    if(!ret) return QStringList();
    QStringList list(gdbReadList);
    QString first = list.first();
    QString key = "&\"info variables\\n";
    if(!first.startsWith(key)) return QStringList();

    QStringList output;
    int state = 0;
    foreach(QString line,list)
    {
        switch(state)
        {
        case 0: // waiting for ~"\nFile "
            if(line.startsWith("~\"\\nFile"))
                state++;
            break;
        case 1: // filepath
            state++;
            break;
        case 2:
            if(line.startsWith("~\"\\nFile"))
            {
                state = 1;
                break;
            }
            if((line.startsWith("~\"\\nNon-debugging symbols:")) ||
                    (line.startsWith("^done")) ||
                    (line.startsWith("(gdb")))
            {
                state = 0;
                break;
            }
            int i = line.indexOf('[');
            if(i > 0)
                line = line.left(i);
            i = line.indexOf(';');
            if(i > 0)
                line = line.left(i);
            line.remove('(');
            line.remove('*');
            i = line.lastIndexOf(' ');
            if(i > 0)
                line = line.right(line.length()-i-1);
            if(!line.isEmpty())
                output.append(line);
            break;
        }
    }
    return output;
}


/*
 mi replacement for whatis
   -var-create OBJ * <symbolname>
   -var-info-type OBJ
   -var-delete OBJ

-var-create OBJ * i
^done,name="OBJ",numchild="0",value="10",type="int",thread-id="1",has_more="0"
(gdb)
-var-info-type OBJ
^done,type="int"
(gdb)
-var-delete OBJ
^done,ndeleted="1"
(gdb)

*/
