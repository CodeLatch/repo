#ifndef GDBCONTROL_H
#define GDBCONTROL_H

#include <QObject>
#include <QProcess>
#include <QEventLoop>
#include <QTreeWidget>
#include <stdint.h>

class Project;
class VariablesView;

class DebugFrame
{
public:
    int frameNumber;
    int lineNumber;
    uint32_t address;
    QString pathName;
    QString functionName;
};

class GdbControl : public QObject
{
    Q_OBJECT

public:

    struct BreakPointStruct {
        int number;
        int line;
        QString pathname;
    };

public:
    explicit GdbControl(QObject *parent = 0);
    ~GdbControl();

    bool start(Project *project);
    bool connectToTarget(int port, int timeout_ms);
    void terminate();

    bool send(QString str, int timeout_ms = 1000);
    bool sendBreak(int timeout_ms = 1000);
    QStringList getReadList() {return gdbReadList;}

    // routines to support debug process

    bool getSourceInfo(QString *pathname, QString *function, int *lineNumber);
    bool addBreakPoint(QString pathname,int line);
    bool removeBreakPoint(QString pathname, int line);
    bool readRegisters(QStringList *names, QStringList *values);
    QString getLocals(void);
    QString getArgs(void);
    QStringList getAssembly();
    bool writeVariable(QString name, QString value);
    bool isSuspended();
    bool writeRegister(QString name, quint32 val);
    uint32_t getVariableAddress(QString name, bool *ok);
    QList<DebugFrame> getStackFrames();
    int getCurrentThraedNumber();
    QString getVariables(int threadId, int frameNumber);
    QStringList getGlobalVariableNames();
    QString evaluateExpression(QString expression);

//    QString getVariableRootType(QString name);
    QString getVariableType(QString name);
    QStringList readMemory(uint32_t start, int numwords);
    bool writeMemory(uint32_t address, uint32_t data);

//    bool waitForPrompt(WaitForType type, int timeout_ms, EventType etype = NormalEvent);
    bool waitForTargetStop(int timeout_ms);

private:
    bool waitForPrompt(int timeout_ms);

signals:
    void appendConsoleLine(QString);
    void signalAtPrompt();
    void gdbErrorOccurred();

public slots:
    void slotGdbExited(int exitval);

protected slots:
    void slotGdbReadyRead();
    void slotGdbReadError();
    void slotWaitForPromptTimeout();
    void slotWaitForStopTimeout();

protected:
    void print(QString str);

//    bool gdbOpen;
//    bool atPrompt;
    bool targetRunning;
    bool serverConnected;
    bool gdbError;
    bool atPrompt;
    QByteArray *rxBytes;

    QEventLoop waitForPromptEventLoop;
    QEventLoop waitForTargetStopEventLoop;
    QEventLoop delayExec;
    QProcess *gdb;
    Project *prj;
    QStringList gdbReadList;
    QList<BreakPointStruct> breakPointList;
};

#endif // GDBCONTROL_H
