﻿//!----------------------------------------------------------------------------
//! file: devicemonitor.cpp
//!
//! Implements Hid device attachment and removal monitoring. In OS Windows monitoring
//! can only be done from a window, that's why this class needs to be based on
//! QMainWindow.
//!
//! Example Usage:
//!
//!     DeviceMonitor *monitor = new DeviceMonitor(this);
//!     // a 32bit number indicating the location of the device will be passed back
//!     connect(monitor,SIGNAL(deviceRemoved(uint32_t)),this,SLOT(deviceRemoved(uint32_t)));
//!     connect(monitor,SIGNAL(deviceAttached(uint32_t)),this,SLOT(deviceAttached(uint32_t)));
//!     monitor->start(vid,pid);
//!
//!     Note: when start is called the device monitor will send a deviceAttached signal for
//!     each of the devices with matching vid/pid that are currently attached.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

/*
    1) Device is attached or device monitor is instantiated emitting deviceAttached(location)
    2) Main program slot: add location to list if not present.
                          if this location is selected open this device.
                          if a hid is not open and no location is selected then select and open this device.

    1) Device is removed emitting deviceRemoved(location)
    2) Main program slot: remove location from list,
                          if a hid is open with this location terminate it.

 */

#include "devicemonitor.h"
#include <QDebug>

#ifdef Q_OS_MAC
//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
DeviceMonitor::DeviceMonitor(QWidget *parent) :
    QMainWindow(parent)
{
    manager = NULL;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
DeviceMonitor::~DeviceMonitor()
{
    if(manager)
    {
        IOHIDManagerRegisterDeviceRemovalCallback(manager, NULL, this);
        IOHIDManagerRegisterDeviceMatchingCallback(manager, NULL,this);
        IOHIDManagerClose(manager, kIOHIDOptionsTypeNone);
        CFRelease(manager);
    }
}

//!-----------------------------------------------------------------------------
//! \brief Specifies the device vid and pid to monitor and starts monitoring.
//!-----------------------------------------------------------------------------
void DeviceMonitor::start(unsigned short vid, unsigned short pid)
{
    this->vid = vid;
    this->pid = pid;
    if(manager != NULL) return;
    manager = IOHIDManagerCreate(kCFAllocatorDefault, kIOHIDOptionsTypeNone);
    if(manager)
    {
        IOHIDManagerSetDeviceMatching(manager, NULL);
        IOHIDManagerScheduleWithRunLoop(manager, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode);
        IOHIDManagerRegisterDeviceRemovalCallback(manager, removalCallback, this);
        IOHIDManagerRegisterDeviceMatchingCallback(manager, connectCallback,this);
    }
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void DeviceMonitor::removalCallback(void *context, IOReturn result, void *sender, IOHIDDeviceRef dev_ref)
{
    Q_UNUSED(result);
    Q_UNUSED(sender);
    unsigned short dVid,dPid;

    if(context == NULL) return;
    DeviceMonitor *mon = (DeviceMonitor*) context;
    dVid = mon->getVID(dev_ref);
    dPid = mon->getPID(dev_ref);
    if((dVid==mon->vid)&&(dPid==mon->pid))
    {
        uint32_t loc = mon->getLocation(dev_ref);
        qDebug() << "device removal:" <<  QString::number(loc, 16);
        QString locStr = QString::number(loc,16);
        emit mon->deviceRemoved(locStr);
    }
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void DeviceMonitor::connectCallback(void *context, IOReturn result, void *sender, IOHIDDeviceRef dev_ref)
{
    Q_UNUSED(result);
    Q_UNUSED(sender);
    unsigned short dVid,dPid;

    if(context == NULL) return;
    DeviceMonitor *mon = (DeviceMonitor*) context;
    dVid = mon->getVID(dev_ref);
    dPid = mon->getPID(dev_ref);
    if((dVid==mon->vid)&&(dPid==mon->pid))
    {
        uint32_t loc = mon->getLocation(dev_ref);
        qDebug() << "device attached:" << QString::number(loc, 16);
        QString locStr = QString::number(loc,16);
        emit mon->deviceAttached(locStr);
    }
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
int32_t DeviceMonitor::getIntProperty(IOHIDDeviceRef device, CFStringRef key)
{
    CFTypeRef ref;
    int32_t value;

    ref = IOHIDDeviceGetProperty(device, key);
    if (ref)
    {
        if (CFGetTypeID(ref) == CFNumberGetTypeID())
        {
            CFNumberGetValue((CFNumberRef) ref, kCFNumberSInt32Type, &value);
            return value;
        }
    }
    return 0;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool DeviceMonitor::getStringProperty(IOHIDDeviceRef device, CFStringRef prop, wchar_t *buf, size_t len)
{
    if (!len) return false;

    CFStringRef str = (CFStringRef) IOHIDDeviceGetProperty(device, prop);
    buf[0] = 0;

    if (str)
    {
        len --;
        CFIndex str_len = CFStringGetLength(str);
        CFRange range;
        range.location = 0;
        range.length = (((size_t)str_len > len) ? len: (size_t)str_len);
        CFIndex used_buf_len;
        CFIndex chars_copied;
        chars_copied = CFStringGetBytes(str,range,kCFStringEncodingUTF32LE,(char)'?',FALSE,(UInt8*)buf,len,&used_buf_len);
        buf[chars_copied] = 0;
        return true;
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
unsigned short DeviceMonitor::getVID(IOHIDDeviceRef device)
{
    return getIntProperty(device, CFSTR(kIOHIDVendorIDKey));
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
unsigned short DeviceMonitor::getPID(IOHIDDeviceRef device)
{
    return getIntProperty(device, CFSTR(kIOHIDProductIDKey));
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString DeviceMonitor::getSerialNumber(IOHIDDeviceRef device)
{
    wchar_t buf[128];
    memset(buf,0,sizeof(buf));
    bool ret = getStringProperty(device, CFSTR(kIOHIDSerialNumberKey), buf, sizeof(buf));
    if(!ret) return QString();
    return QString::fromWCharArray(buf,sizeof(buf));
}

//!-----------------------------------------------------------------------------
//! \brief Returns a 32bit hex number that is a unique id for the device port.
//! A given device port id won't change as long as the hub hardware chain doesn't
//! change.
//!
//! The two most significant digits indicate the bus number. Each additional digit
//! represents a hub in the hub chain. The value of each digit is the port
//! number of the hub that is being used. Assigned port values can be 1..f.
//!
//! So for example a device location that is fa133000 indicates....
//!     USB Bus Number: fa
//!     root hub port 1 is attached to an internal hub(A).
//!     internal hub(A) port 3 is attached to an external hub(B).
//!     external hub(B) port 3 of attached to our device.
//!
//!  For windows try using....
//! SetupDiGetDeviceRegistryProperty with the property SPDRP_LOCATION_INFORMATION
//!-----------------------------------------------------------------------------
uint32_t DeviceMonitor::getLocation(IOHIDDeviceRef device)
{
    uint32_t location = getIntProperty(device,CFSTR(kIOHIDLocationIDKey));
    return location;
}

#elif defined Q_OS_WIN
//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
DeviceMonitor::DeviceMonitor(QWidget *parent) :
    QMainWindow(parent)
{
    hide(); // make sure window is hidden.
    attachTimer = NULL;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
DeviceMonitor::~DeviceMonitor()
{
    if(hDevNotify)
        UnregisterDeviceNotification(hDevNotify);
    attachTimer->stop();
    attachTimer->deleteLater();
    delete NotificationFilter;
}

//!-----------------------------------------------------------------------------
//! \brief  Intercept registered windows message events. We're looking for
//!         arrival and removal events here.
//!-----------------------------------------------------------------------------
bool DeviceMonitor::nativeEvent(const QByteArray &data, void *msg, long *result)
{
    Q_UNUSED(data);
    Q_UNUSED(result);

    MSG *message = static_cast<MSG*>(msg);
    if (message->message == WM_DEVICECHANGE)
    {
        switch(message->wParam)
        {
        case DBT_DEVICEARRIVAL:
            // when a device is attached windows needs some time
            // to enumerate the device and get to a happy state before we
            // try to access the device. apparently it's not in a happy
            // state when it sends us this event. if we don't wait a little
            // bit windows can lock up for a period of time (observed ~15sec).
            // on a relatively slow machine 500ms seems to be safe. similarly if we
            // try to open a device from within this event thread things will fail.
            // using a timers timeout to send the signal gets us out of this thread.
            attachTimer->start(1000);
            break;
        case DBT_DEVICEREMOVECOMPLETE:
            // figure out what detached and emit
            QStringList list = enumerate(vid,pid);
            for(int i=0;i<deviceList.size();)
            {
                QString device = deviceList.at(i);
                if(!list.contains(device))
                {
                    deviceList.removeAt(i);
                    emit deviceRemoved(device);
                }
                else
                    i++;
            }
            break;
        }
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void DeviceMonitor::attachTimerTimeout()
{
    attachTimer->stop();
    // figure out what attached and emit
    QStringList list = enumerate(vid,pid);
    foreach(QString device,list)
    {
        if(!deviceList.contains(device))
        {
            emit deviceAttached(device);
            deviceList.append(device);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief Specifies the device vid and pid to monitor and starts monitoring.
//!-----------------------------------------------------------------------------
void DeviceMonitor::start(unsigned short vid, unsigned short pid)
{
    this->vid = vid;
    this->pid = pid;
    if(attachTimer != NULL) return;

    attachTimer = new QTimer;
    connect(attachTimer,SIGNAL(timeout()),this,SLOT(attachTimerTimeout()));
    NotificationFilter = new DEV_BROADCAST_DEVICEINTERFACE;
    ZeroMemory(NotificationFilter, sizeof(DEV_BROADCAST_DEVICEINTERFACE) );
    GUID guid = { 0xA5DCBF10L, 0x6530, 0x11D2, { 0x90, 0x1F, 0x00, 0xC0, 0x4F, 0xB9, 0x51, 0xED } };
    NotificationFilter->dbcc_size = sizeof(DEV_BROADCAST_DEVICEINTERFACE);
    NotificationFilter->dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
    NotificationFilter->dbcc_classguid  = guid;
    hDevNotify = RegisterDeviceNotification((HANDLE) winId(), NotificationFilter,DEVICE_NOTIFY_WINDOW_HANDLE);
    if(!hDevNotify)
        qDebug() << "Error registering device notifications.";

    // the mac automatically generates notifications for all attached devices when
    // we start monitoring. on windows we have to explicitly check.
    deviceList = enumerate(vid,pid);
    foreach(QString device,deviceList)
        emit deviceAttached(device);
}

//!-----------------------------------------------------------------------------
//! \brief  Returns a list of device paths for the defined guid with matching
//!         vid and pid. If 0 is passed for an id then all id's will be added.
//!         If 0 is passed for both id's then all devices for the guid will be
//!         added.
//!-----------------------------------------------------------------------------
QStringList DeviceMonitor::enumerate(int vendorID,int productID)
{
    QStringList pathList;
    GUID guid = {0x4d1e55b2, 0xf16f, 0x11cf, {0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30}};
    HDEVINFO devInfo = SetupDiGetClassDevs(&guid, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if(devInfo == INVALID_HANDLE_VALUE) return pathList;

    SP_DEVICE_INTERFACE_DATA devData;
    devData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

    for(int i=0;SetupDiEnumDeviceInterfaces(devInfo,NULL,&guid,i,&devData);i++)
    {
        DWORD detailSize = 0;
        SP_DEVICE_INTERFACE_DETAIL_DATA_A *detailData;

        // get size required to hold data then allocate memory
        SetupDiGetDeviceInterfaceDetailA(devInfo,&devData,NULL,0,&detailSize,NULL);
        BYTE *detailBytes = new BYTE[detailSize];
        detailData = reinterpret_cast<SP_DEVICE_INTERFACE_DETAIL_DATA_A*> (detailBytes);
        detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_A);
        // get the data
        SetupDiGetDeviceInterfaceDetailA(devInfo,&devData,detailData,detailSize,NULL,NULL);
        // store paths with desired pid,vid
        QString path(detailData->DevicePath);
        QRegExp idRx(QLatin1String("VID_(\\w+)&PID_(\\w+)"));
        if(path.toUpper().contains(idRx))
        {
            bool ok;
            int vid = idRx.cap(1).toInt(&ok, 16);
            int pid = idRx.cap(2).toInt(&ok, 16);
            if(((vendorID == 0) || (vendorID == vid)) && ((productID == 0) || (productID == pid)))
                pathList.append(path);
        }
        delete [] detailBytes;
    }

    SetupDiDestroyDeviceInfoList(devInfo);
    return pathList;
}

/*
//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
int32_t DeviceMonitor::getIntProperty(IOHIDDeviceRef device, CFStringRef key)
{
    CFTypeRef ref;
    int32_t value;

    ref = IOHIDDeviceGetProperty(device, key);
    if (ref)
    {
        if (CFGetTypeID(ref) == CFNumberGetTypeID())
        {
            CFNumberGetValue((CFNumberRef) ref, kCFNumberSInt32Type, &value);
            return value;
        }
    }
    return 0;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool DeviceMonitor::getStringProperty(IOHIDDeviceRef device, CFStringRef prop, wchar_t *buf, size_t len)
{
    if (!len) return false;

    CFStringRef str = (CFStringRef) IOHIDDeviceGetProperty(device, prop);
    buf[0] = 0;

    if (str)
    {
        len --;
        CFIndex str_len = CFStringGetLength(str);
        CFRange range;
        range.location = 0;
        range.length = (((size_t)str_len > len) ? len: (size_t)str_len);
        CFIndex used_buf_len;
        CFIndex chars_copied;
        chars_copied = CFStringGetBytes(str,range,kCFStringEncodingUTF32LE,(char)'?',FALSE,(UInt8*)buf,len,&used_buf_len);
        buf[chars_copied] = 0;
        return true;
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
unsigned short DeviceMonitor::getVID(IOHIDDeviceRef device)
{
    return getIntProperty(device, CFSTR(kIOHIDVendorIDKey));
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
unsigned short DeviceMonitor::getPID(IOHIDDeviceRef device)
{
    return getIntProperty(device, CFSTR(kIOHIDProductIDKey));
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString DeviceMonitor::getSerialNumber(IOHIDDeviceRef device)
{
    wchar_t buf[128];
    memset(buf,0,sizeof(buf));
    bool ret = getStringProperty(device, CFSTR(kIOHIDSerialNumberKey), buf, sizeof(buf));
    if(!ret) return QString();
    return QString::fromWCharArray(buf,sizeof(buf));
}

//!-----------------------------------------------------------------------------
//! \brief Returns a 32bit hex number that is a unique id for the device port.
//! A given device port id won't change as long as the hub hardware chain doesn't
//! change.
//!
//! The two most significant digits indicate the bus number. Each additional digit
//! represents a hub in the hub chain. The value of each digit is the port
//! number of the hub that is being used. Assigned port values can be 1..f.
//!
//! So for example a device location that is fa133000 indicates....
//!     USB Bus Number: fa
//!     root hub port 1 is attached to an internal hub(A).
//!     internal hub(A) port 3 is attached to an external hub(B).
//!     external hub(B) port 3 of attached to our device.
//!
//!  For windows try using....
//! SetupDiGetDeviceRegistryProperty with the property SPDRP_LOCATION_INFORMATION
//!-----------------------------------------------------------------------------
uint32_t DeviceMonitor::getLocation(IOHIDDeviceRef device)
{
    uint32_t location = getIntProperty(device,CFSTR(kIOHIDLocationIDKey));
    return location;
}
*/


#elif defined Q_OS_UNIX

//#include <stdio.h>
//#include <stdlib.h>
#include <locale.h>
#include <unistd.h>

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
DeviceMonitor::DeviceMonitor(QWidget *parent) :
    QMainWindow(parent)
{
    udev = NULL;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
DeviceMonitor::~DeviceMonitor()
{
    disconnect(&timer,SIGNAL(timeout()),this,SLOT(checkDevices()));
    if(timer.isActive())
        timer.stop();

    if(udev)
        udev_unref(udev);
    // todo: do we need to unref the mon?
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void DeviceMonitor::start(unsigned short vid = 0, unsigned short pid = 0)
{
    this->vid = vid;
    this->pid = pid;

    if(!startMonitor()) return;
    if(!enumerate()) return;
    connect(&timer,SIGNAL(timeout()),this,SLOT(checkDevices()));
    timer.start(250);
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool DeviceMonitor::startMonitor()
{
    udev = udev_new();
    if (!udev)
    {
        qDebug() << "Can't create udev";
        return false;
    }

    /* This section sets up a monitor which will report events when
       devices attached to the system change.  Events include "add",
       "remove", "change", "online", and "offline".

       This section sets up and starts the monitoring. Events are
       polled for (and delivered) later in the file.

       It is important that the monitor be set up before the call to
       udev_enumerate_scan_devices() so that events (and devices) are
       not missed.  For example, if enumeration happened first, there
       would be no event generated for a device which was attached after
       enumeration but before monitoring began.

       Note that a filter is added so that we only get events for
       "hidraw" devices. */

    /* Set up a monitor to monitor hidraw devices */
    mon = udev_monitor_new_from_netlink(udev, "udev");
    udev_monitor_filter_add_match_subsystem_devtype(mon, "hidraw", NULL);
    udev_monitor_enable_receiving(mon);
    /* Get the file descriptor (fd) for the monitor.
       This fd will get passed to select() */
    fd = udev_monitor_get_fd(mon);

    return true;
}

void DeviceMonitor::showDeviceInfo(struct udev_device *dev)
{
    qDebug() << "Device Node Path: " << udev_device_get_devnode(dev);
    qDebug() << "  VID/PID: " << udev_device_get_sysattr_value(dev,"idVendor")
             << " " << udev_device_get_sysattr_value(dev, "idProduct");
    qDebug() << "  Manuf,product: "
             << udev_device_get_sysattr_value(dev,"manufacturer")
             << " " << udev_device_get_sysattr_value(dev,"product");
    qDebug() << "  serial: " <<
                udev_device_get_sysattr_value(dev, "serial");
    qDebug() << "path:" << udev_device_get_devnode(dev);
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool DeviceMonitor::enumerate()
{
    struct udev_enumerate *enumerate;
    struct udev_list_entry *devices, *dev_list_entry;
    struct udev_device *dev;

    /* Create a list of the devices in the 'hidraw' subsystem. */
    enumerate = udev_enumerate_new(udev);
    udev_enumerate_add_match_subsystem(enumerate, "hidraw");
    udev_enumerate_scan_devices(enumerate);
    devices = udev_enumerate_get_list_entry(enumerate);
    udev_list_entry_foreach(dev_list_entry, devices)
    {
        const char *path;
        path = udev_list_entry_get_name(dev_list_entry);
        dev = udev_device_new_from_syspath(udev, path);
        QString devPath = udev_device_get_devnode(dev);
        dev = udev_device_get_parent_with_subsystem_devtype(dev,"usb","usb_device");
        if (!dev)
        {
            qDebug() << "Unable to find parent usb device.";
            return false;
        }
        //        showDeviceInfo(dev);
        QString devVidStr = udev_device_get_sysattr_value(dev,"idVendor");
        QString devPidStr = udev_device_get_sysattr_value(dev,"idProduct");
        bool ok;
        unsigned short devVid = devVidStr.toInt(&ok,16);
        unsigned short devPid = devPidStr.toInt(&ok,16);
        if((devVid == vid) && (devPid == pid))
            emit deviceAttached(devPath);
        udev_device_unref(dev);
    }
    /* Free the enumerator object */
    udev_enumerate_unref(enumerate);

    return true;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void DeviceMonitor::checkDevices()
{
    struct udev_device *dev;
    fd_set fds;
    struct timeval tv;
    int ret;

    FD_ZERO(&fds);
    FD_SET(fd, &fds);
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    ret = select(fd+1, &fds, NULL, NULL, &tv);

    /* Check if our file descriptor has received data. */
    if (ret > 0 && FD_ISSET(fd, &fds))
    {
        dev = udev_monitor_receive_device(mon);
        if(!dev) return;
        QString devPath = udev_device_get_devnode(dev);
        QString action = udev_device_get_action(dev); // add, remove,
        dev = udev_device_get_parent_with_subsystem_devtype(dev,"usb","usb_device");
        if(!dev) return;
//        showDeviceInfo(dev);

        QString devVidStr = udev_device_get_sysattr_value(dev,"idVendor");
        QString devPidStr = udev_device_get_sysattr_value(dev,"idProduct");
        bool ok;
        unsigned short devVid = devVidStr.toInt(&ok,16);
        unsigned short devPid = devPidStr.toInt(&ok,16);

        udev_device_unref(dev);

        qDebug() << action;
        qDebug() << devPath;
        qDebug() << devVid << " " << vid;
        qDebug() << devPid << " " << pid;

        if((devVid == vid) && (devPid == pid) && (action == "add"))
            emit deviceAttached(devPath);
        else if(action == "remove")
            emit deviceRemoved(devPath);
    }
}

#endif
