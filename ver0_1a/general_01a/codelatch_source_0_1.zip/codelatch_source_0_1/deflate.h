#ifndef DECOMPRESS_H
#define DECOMPRESS_H
#include <QtGlobal>

typedef int (*tinfl_put_buf_func_ptr)(const void* pBuf, int len, void *pUser);
typedef quint8 uint8_t;
typedef quint32 uint32_t;
typedef quint16 uint16_t;
typedef qint32 int32_t;
typedef qint16 int16_t;

// Return status.
typedef enum
{
    TINFL_STATUS_BAD_PARAM = -3,
    TINFL_STATUS_ADLER32_MISMATCH = -2,
    TINFL_STATUS_FAILED = -1,
    TINFL_STATUS_DONE = 0,
    TINFL_STATUS_NEEDS_MORE_INPUT = 1,
    TINFL_STATUS_HAS_MORE_OUTPUT = 2
} tinfl_status;

struct tinfl_decompressor_tag;
typedef struct tinfl_decompressor_tag tinfl_decompressor;

class Deflate
{

public:
    explicit Deflate();

    bool expandToByteArray(uint8_t *pByteArray, void *data, uint32_t compressedSize, uint32_t uncompressedSize = 0);


private:
    // tinfl_decompress_mem_to_callback() decompresses a block in memory to an internal 32KB buffer, and a user provided callback function will be called to flush the buffer.
    // Returns 1 on success or 0 on failure.
    int tinfl_decompress_mem_to_callback(const void *pIn_buf, uint32_t *pIn_buf_size, tinfl_put_buf_func_ptr pPut_buf_func, void *pPut_buf_user, int flags);
    tinfl_status tinfl_decompress(tinfl_decompressor *r, const uint8_t *pIn_buf_next, uint32_t *pIn_buf_size, uint8_t *pOut_buf_start, uint8_t *pOut_buf_next, uint32_t *pOut_buf_size, const uint32_t decomp_flags);
    static int tinfl_toByteArray(const void* pBuf, int len, void *pUser);

};

#endif // DECOMPRESS_H
