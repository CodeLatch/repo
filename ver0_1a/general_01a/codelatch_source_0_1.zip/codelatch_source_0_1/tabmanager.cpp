#include "tabmanager.h"
#include <QWidget>
#include <QString>
#include <QVariant>
#include <QMessageBox>
#include <QFileInfo>
#include "project/project.h"
#include "sourceeditor.h"
#include "config/targetconfig.h"
#include "config/projectconfig.h"
#include "config/configeditor.h"
#include "utility/fileutility.h"

#define STR_DIRTY_FILE  " *"


void CursorHistory::update(SourceEditor *editor)
{
    int row,col;
    if(editor == NULL)
        return;
    editor->getCursorPosition(&row,&col);
    QString pathname = editor->getPathname();
    // ignore interline movement
    if((row == lastRow) && (pathname == lastPathname))
        return;

    lastRow = row;
    lastPathname = pathname;
    // log entry in cursor history
    CursorEntry entry;
    entry.pathname = editor->getPathname();
    entry.col = col;
    entry.row = row;

    // the head of backStack will contain our current location
    backStack.append(entry);
    if(backStack.size() > 50)
        backStack.takeFirst();
}
bool CursorHistory::back(CursorEntry *location)
{
    if(backStack.size() > 1)
    {
        // push our current location onto the fwdStack.
        CursorEntry entry = backStack.takeLast();
        fwdStack.append(entry);
        if(fwdStack.size() > 50)
            fwdStack.takeFirst();
        // pop our last location off the backStack and return it.
        entry = backStack.takeLast();
        *location = entry;
        return true;
    }
    return false;
}
bool CursorHistory::forward(CursorEntry *location)
{
    if(fwdStack.size() > 0)
    {
        // pop the location off the fwdStack and return it.
        CursorEntry entry = fwdStack.takeLast();
        *location = entry;
        return true;
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief  The TabManager is the main center widget that holds all the editors as
//! tabs.
//!-----------------------------------------------------------------------------
TabManager::TabManager(QWidget *parent) :
    QTabWidget(parent)
{
    // set tab close icon to make it consistent across platforms
    tabBar()->setStyleSheet("QTabBar::close-button {image: url(:/icons/icons/close_tab.png);}");
    connect(this,SIGNAL(tabCloseRequested(int)),this,SLOT(closeTab(int)));
    connect(this,SIGNAL(currentChanged(int)),this,SLOT(slotTabChanged(int)));
}

//!-----------------------------------------------------------------------------
//! \brief Activate a tab with the file pathname if it exists.
//!        returns true if activated, false if not.
//!-----------------------------------------------------------------------------
bool TabManager::activateTab(QString pathname)
{
    int n = count();
#if defined Q_OS_WIN
    pathname = pathname.replace('\\','/');
#endif
    for(int i=0;i<n;i++)
    {
        QString tabPathname = getTabPathname(i);
        if(pathname == tabPathname)
        {
            setCurrentIndex(i);
            return true;
        }
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Activate a tab with the file pathname if it exists. If not,
//!              attempt to open the file and go to the line number.
//!-----------------------------------------------------------------------------
bool TabManager::openEditor(Project *prj, QString pathname, int line)
{
    if(line < 1) line = 1;
    if(!openEditor(prj,pathname)) return false;
    SourceEditor *editor = currentEditor();
    if(editor == NULL) return false;
    editor->setCursorPosition(line-1,0);
    return true;
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Activate a tab with the file pathname if it exists. If not,
//!              attempt to open the file.
//!-----------------------------------------------------------------------------
bool TabManager::openEditor(Project *prj, QString pathname)
{
    // if there is a tab already open with this path then activate it.
    if(activateTab(pathname)) return true;

    // if this is a project config file open it using config editor
    if(pathname.endsWith("."+Project::getProjectExtension()) && (prj != NULL))
    {
        QString pathname = prj->getProjectFolder() + "/" + prj->getConfigFilename();
        if(activateTab(pathname)) return true;

        ProjectConfig *config = new ProjectConfig(prj);
        QString tabname = prj->getConfigFilename();
        int i = addTab(config,tabname);

        // this will cause slotTabChanged to be called which initiates other
        // required updating.
        setCurrentIndex(i);

        // TODO: add...
        // emit updateClassView(prj);

        //        if(dataView->getClassViewProject() != prj)
        //            dataView->updateClassView(prj);
        return true;
    }

    // all other cases....open file using source editor
    QFileInfo info(pathname);
    if(info.isFile())
        return openFileUsingSourceEditor(prj,pathname);
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Activate editor tab with the file pathname if it exists.
//!-----------------------------------------------------------------------------
void TabManager::selectEditor(Project *prj, QString pathname)
{
    Q_UNUSED(prj);
    activateTab(pathname);
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Activate editor tab with the file pathname if it exists.
//!-----------------------------------------------------------------------------
void TabManager::selectEditor(QString pathname, int line)
{
    if(!activateTab(pathname)) return;
    currentEditor()->setCursorPosition(line-1,0);
}

//!-----------------------------------------------------------------------------
//! \brief  Returns a list of open editors.
//!-----------------------------------------------------------------------------
QList<SourceEditor*> TabManager::editors()
{
    QList<SourceEditor*> list;
    for(int i=0;i<count();i++)
    {
        SourceEditor *editor = qobject_cast<SourceEditor *>(widget(i));
        if(editor != NULL)
            list.append(editor);
    }
    return list;
}

//!-----------------------------------------------------------------------------
//! \brief  Returns a pointer to the SourceEditor for the current tab or NULL
//!         if the tab is not a SourceEditor.
//!-----------------------------------------------------------------------------
SourceEditor* TabManager::currentEditor()
{
    return qobject_cast<SourceEditor *>(currentWidget());
}

//!-----------------------------------------------------------------------------
//! \brief  Returns a pointer to the SourceEditor at the tab index i or NULL
//!         if the tab is not a SourceEditor.
//!-----------------------------------------------------------------------------
SourceEditor* TabManager::getEditor(int i)
{
    if((i >= count()) || (i < 0)) return NULL;
    return qobject_cast<SourceEditor *>(widget(i));
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool TabManager::closeAllTabs(bool allowCancel)
{
    int n = count();
    for(int i=0;i<n;i++)
    {
        if(!closeTab(0,allowCancel) && allowCancel)
            return false;
    }
    emit setStatusMessage("Ready.");
    return true;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool TabManager::closeTabs(Project *prj)
{
    int n = count();
    for(int i=0;i<n;)
    {
        if(prj == getTabProject(i))
        {
            if(!closeTab(i))
                return false;
        }
        else
            i++;
    }
    return true;
}

//!-----------------------------------------------------------------------------
//! \brief Returns true if the tab at index is dirty.
//!-----------------------------------------------------------------------------
bool TabManager::isDirty(int index)
{
    if((index >= count()) || (index < 0)) return false;
    QWidget *tab = widget(index);
    if(tab == NULL) return false;
    QString name = tabText(index);
    if(name.endsWith(STR_DIRTY_FILE))
        return true;
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief Closes the editor tab at index. If the editor is dirty a dialog will
//!          open asking the user to Save, Discard, or Cancel. If the user
//!          selects Save or Discard the function will return true after closing
//!          the tab. If the user selects Cancel the editor will not be saved or
//!          closed and the function will return false.
//!-----------------------------------------------------------------------------
bool TabManager::closeTab(int index, bool allowCancel)
{
    if((index >= count()) || (index < 0)) return true;
    QWidget *tab = widget(index);
    if(tab == NULL) return false;
    QString name = tabText(index);

    if(name.endsWith(STR_DIRTY_FILE))
    {
        name.remove(STR_DIRTY_FILE);
        int ret = askToSaveDocument(name, allowCancel);
        switch (ret) {
        case QMessageBox::Save:
            // Save was clicked
            saveFile(index,true);
            break;
        case QMessageBox::Discard:
            // Don't Save was clicked
            break;
        case QMessageBox::Cancel:
            // Cancel was clicked
            return false;
            break;
        default:
            // should never be reached
            return true;
            break;
        }
    }

    removeTab(index);

    // make sure things are properly shut down and disposed of.
    tab->close();
    tab->deleteLater();
    tab = NULL;

    // note: update signals will be emited by the slotTabChanged function which will
    // be called after the tab is closed.

    return true;
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int TabManager::askToSaveDocument(QString pathname, bool allowCancel)
{
    QMessageBox msgBox(this);
    QFileInfo info(pathname);
    msgBox.setText(info.fileName() + " has been modified.");
    msgBox.setInformativeText("Do you want to save your changes?");
    if(allowCancel)
        msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
    else
        msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard);

    msgBox.setDefaultButton(QMessageBox::Save);

    return msgBox.exec();
}


//!-----------------------------------------------------------------------------
//! \brief SLOT: save file event.
//!-----------------------------------------------------------------------------
void TabManager::saveFile()
{
    if(count() == 0) return;
    // save the file associated with the active editor tab.
    saveFile(currentIndex(),true);
}

//!-----------------------------------------------------------------------------
//! \brief save file at editor tab index tabIndex
//!-----------------------------------------------------------------------------
void TabManager::saveFile(int tabIndex, bool runIndexer)
{
    QString text;

    QWidget *tab = widget(tabIndex);
    if(tab == NULL) return;
    QString pathname;

    if(tab->inherits("SourceEditor"))
    {
        SourceEditor *editor = (SourceEditor*)tab;
        if(editor == NULL) return;
        Project *prj = editor->getProject();
        pathname = editor->getPathname();
        text = editor->text();

        if (!pathname.isEmpty()) {
            QFile file(pathname);
            if (file.open(QIODevice::WriteOnly | QIODevice::Text))
            {
                QTextStream out(&file);
                out << text;
                file.close();
                // index project
                if(runIndexer)
                {
                    if(prj != NULL)
                        prj->runIndexer();
                }
                // update tab text to indicate file is not dirty
                QString name = tabText(tabIndex);
                if(name.endsWith(STR_DIRTY_FILE))
                {
                    QString tail = STR_DIRTY_FILE;
                    name = name.left(name.length()-tail.length());
                    setTabText(tabIndex,name);
                }
            }
            /*            // update project breakpoint list
            if(prj != NULL)
            {
                prj->removeBreakpoints(pathname);
                int bpLine = editor->markerFindNext(0,0xffff);
                while(bpLine != -1)
                {
                    qDebug() << bpLine;
                    prj->addBreakpoint(pathname,bpLine);
                    bpLine = editor->markerFindNext(bpLine+1,0xffff);
                }
            }
*/

        }
    }
    emit updateSaveSaveAll();
    emit updateToolbarState();
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: save file event.
//!-----------------------------------------------------------------------------
void TabManager::saveAllFile()
{
    if(count() == 0) return;
    for(int i=0;i<count()-1;i++)
        saveFile(i,false);
    saveFile(count()-1,true);
}

/*
//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::saveAsFile()
{
    QString sourcePathname = nav->getSelectedFilepath();
    if(sourcePathname.isEmpty()) return;
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;

    QFileInfo info(sourcePathname);
    if(!info.isFile()) return;
    QString filename = info.fileName();

    // get new file name
    bool ok;
    QString newname = QInputDialog::getText(NULL, "Rename","New Name", QLineEdit::Normal,filename, &ok);
    if (!ok || newname.isEmpty()) return;
    QString destPathname = info.path() + "/" + newname;
    QFileInfo newInfo(destPathname);
    if(newInfo.exists())
    {
        QMessageBox::warning(this,"Error","File already exists.");
        return;
    }

    // get text from editor if editor is open
    bool found = false;
    QString fileText;
    for(int i=0;i<tabManager->count();i++)
    {
        QWidget *widget = tabManager->widget(i);
        if(widget == NULL) continue;
        QString widgetPathname = widget->property("pathname").toString();
        if(widgetPathname == sourcePathname)
        {
            SourceEditor *editor = (SourceEditor*) widget;
            fileText = editor->text();
            found = true;
            break;
        }
    }

    if(!found)
    {
        // no open editor, just copy the file.
        if(!QFile::copy(sourcePathname,destPathname))
        {
            QMessageBox::critical(NULL, "Error","Error copying file.");
            return;
        }
    }
    else
    {
        // editor is opened, use text from editor to populate the new file.
        QFile file( destPathname );
        if (!file.open(QIODevice::ReadWrite))
        {
            QMessageBox::critical(NULL, "Error","Error saving new file.");
            return;
        }
        QTextStream stream( &file );
        stream << fileText;
        stream.flush();
        file.close();
    }

    prj->update();
    nav->updateProjectTree(prj);
}
*/

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::editorCursorPosChanged()
{
    QObject *sender = QObject::sender();
    SourceEditor *editor = qobject_cast<SourceEditor *>(sender);
    if(editor == NULL) return;
    cursorHistory.update(editor);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool TabManager::openFileUsingSourceEditor(Project *prj, QString pathname)
{
    QFileInfo pathInfo(pathname);
    QString fileName(pathInfo.fileName());
    if (pathname.isEmpty()) return false;
    QFile file(pathname);
    //    Project *prj = nav->getProjectFromFolder(projectFolder);
    qDebug() << "*** opening file:" << pathname;

    if (file.open(QFile::ReadOnly | QFile::Text))
    {
        // if .c, .cpp, .h, .hpp open with SourceEditor
        SourceEditor *editor = new SourceEditor(this);
        if(pathname.endsWith(".c")||
                pathname.endsWith(".cpp")||
                pathname.endsWith(".h")||
                pathname.endsWith(".hpp"))
            editor->setAutoFormat(true);

        // load file
        editor->setDocText(file.readAll());
        file.close();

        // set editor pathname and project, need to be done before we call addTab.
        editor->setPathname(pathname);
        editor->setProject(prj);

        // get list of project breakpoints
        QList<S_Breakpoint> bpList = prj->getBreakpoints();

        // add tab
        int i = addTab(editor,fileName);
        setCurrentIndex(i);
        // TODO look into installing an event filter to capture focus change events
        //        editor->installEventFilter();

        editor->setMarginWidth(0,QString::number(editor->lines()*10));

        //        statusBar()->showMessage(pathname);
        emit setStatusMessage(FileUtility::replacePathWithKey(prj,pathname));


        connect(editor,SIGNAL(textChanged()),this,SLOT(slotDocumentWasModified()));
        connect(editor,SIGNAL(blockCountChanged(int)),this,SLOT(slotDocumentLineCountChanged(int)));
//        connect(editor,SIGNAL(marginClicked(int,int)),this,SLOT(slotDocumentMarginClicked(int,int)));
        connect(editor,SIGNAL(outlineIndexingFinished()),this,SLOT(slotDocumentIndexFinished()));
        connect(editor,SIGNAL(requestFileOpen(QString,int,int)),this,SIGNAL(requestFileOpen(QString,int,int)));
        connect(editor,SIGNAL(cursorPositionChanged()),this,SLOT(editorCursorPosChanged()));

        if(prj != NULL)
        {
            connect(prj,SIGNAL(signalBreakpointAdded(QString,int)),this,SIGNAL(addBreakpoint(QString,int)),
                    static_cast<Qt::ConnectionType>(Qt::QueuedConnection | Qt::UniqueConnection));
            connect(prj,SIGNAL(signalBreakpointRemoved(QString,int)),this,SIGNAL(removeBreakpoint(QString,int)),
                    static_cast<Qt::ConnectionType>(Qt::QueuedConnection | Qt::UniqueConnection));
        }
        // start file indexing
        editor->updateIndexer();

        // set focus to tab widget
        widget(i)->setFocus();

        // add breakpoint markers
        if(prj != NULL)
        {
            foreach(S_Breakpoint bp,bpList)
            {
                if(bp.pathname == pathname)
                {
                    prj->addBreakpoint(bp.pathname,bp.lineNumber);
                    editor->markerAdd(bp.lineNumber,SourceEditor::DebugMarker);
                }
            }
            editor->update();
        }

        // go to last line edited

    }
    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::slotDocumentWasModified()
{
    QObject *object = QObject::sender();
    if(object == NULL) return;
    if(!object->isWidgetType()) return;
    QWidget *sender = (QWidget *) object;
    if(sender->inherits("SourceEditor"))
    {
        // indicate document is dirty
        int i = currentIndex();
        QString name = tabText(i);
        if(!name.endsWith(STR_DIRTY_FILE))
        {
            name.append(STR_DIRTY_FILE);
            setTabText(i,name);
        }
        emit updateSaveSaveAll();
        emit updateToolbarState();
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::slotDocumentLineCountChanged(int count)
{
    Q_UNUSED(count);
    emit updateOutlineView();
}

//!----------------------------------------------------------------------------
//! \brief This slot is called when a file indexer is complete.
//!----------------------------------------------------------------------------
void TabManager::slotDocumentIndexFinished()
{
    SourceEditor *editor = reinterpret_cast<SourceEditor*>(QObject::sender());
    //    QObject *object = QObject::sender();
    //    if(object == NULL) return;
    //    if(!object->isWidgetType()) return;
    //    QWidget *sender = (QWidget *) object;
    //    if(sender->inherits("SourceEditor"))
    if(editor != NULL)
    {
        //        SourceEditor *editor = (SourceEditor *) sender;
        Indexer *indexer = editor->getOutlineIndexer();
        emit documentIndexFinished(indexer);
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::slotTabChanged(int i)
{
    if((i >= count()) || (i < 0))
    {
        emit setStatusMessage("Ready.");
        emit updateOutlineView();
        emit updateSaveSaveAll();
        emit updateToolbarState();
        return;
    }

    QWidget *tab = widget(i);
    if(tab == NULL)
    {
        emit setStatusMessage("Ready.");
        emit updateOutlineView();
        emit updateSaveSaveAll();
        emit updateToolbarState();
        // log a null entry in cursor history
        return;
    }
    QString pathname = getTabPathname(i);
    SourceEditor *editor = currentEditor();
    Project *prj = NULL;
    if(editor == NULL)
        emit updateOutlineView();
    else if(editor->getProject() == NULL)
        emit updateOutlineView();
    else
        prj = editor->getProject();

    emit setStatusMessage(FileUtility::replacePathWithKey(prj,pathname));
    emit selectionChanged(pathname);
    emit updateSaveSaveAll();
    emit updateToolbarState();

    // inform InfoView that the selection changed
    emit updateBreakpointView(prj);

    //    emit updateOutlineView();
    //    emit updateClassView(prj);

    // log entry in cursor history
    cursorHistory.update(editor);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString TabManager::getTabPathname(int i)
{
    if((i >= count()) || (i < 0)) return QString();
    QWidget *tabwidget = widget(i);

    SourceEditor *sourceEditor = qobject_cast<SourceEditor *>(tabwidget);
    if(sourceEditor != NULL) return sourceEditor->getPathname();

    ProjectConfig *projectConfig = qobject_cast<ProjectConfig *>(tabwidget);
    if(projectConfig != NULL) return projectConfig->getPathname();

    TargetConfig *targetConfig = qobject_cast<TargetConfig *>(tabwidget);
    if(targetConfig != NULL) return targetConfig->getPathname();

    ConfigEditor *configView = qobject_cast<ConfigEditor *>(tabwidget);
    if(configView != NULL) return QString("Editor Config");

    return QString();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString TabManager::getTabProjectFolder(int i)
{
    if((i >= count()) || (i < 0)) return QString();
    QWidget *tabwidget = widget(i);
    SourceEditor *editor = qobject_cast<SourceEditor *>(tabwidget);
    if(editor != NULL) return editor->getProjectFolder();
    ProjectConfig *form = qobject_cast<ProjectConfig *>(tabwidget);
    if(form != NULL) return form->getProjectFolder();
    return QString();
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Project* TabManager::getTabProject(int i)
{
    if((i >= count()) || (i < 0)) return NULL;
    QWidget *tabwidget = widget(i);
    SourceEditor *editor = qobject_cast<SourceEditor *>(tabwidget);
    if(editor != NULL) return editor->getProject();
    ProjectConfig *form = qobject_cast<ProjectConfig *>(tabwidget);
    if(form != NULL) return form->getProject();
    return NULL;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::setTabPathname(int i, QString pathname)
{
    if((i >= count()) || (i < 0)) return;
    QWidget *tabwidget = widget(i);
    SourceEditor *editor = qobject_cast<SourceEditor *>(tabwidget);
    if(editor != NULL)
    {
        editor->setPathname(pathname);
        QFileInfo info(pathname);
        QString filename = info.fileName();
        QString text = tabText(i);
        if(text.contains(STR_DIRTY_FILE))
            setTabText(i,filename + STR_DIRTY_FILE);
        else
            setTabText(i,filename);
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::setTabProject(int i, Project *project)
{
    if((i >= count()) || (i < 0)) return;
    QWidget *tabwidget = widget(i);
    SourceEditor *editor = qobject_cast<SourceEditor *>(tabwidget);
    if(editor != NULL)
    {
        editor->setProject(project);
        return;
    }
    ProjectConfig *form = qobject_cast<ProjectConfig *>(tabwidget);
    if(form != NULL)
        form->setProject(project);
}

//!----------------------------------------------------------------------------
//! \brief  SLOT: Navigator sends us a message when a file has been renamed
//!         or moved. Search our tabs for the sourcePath, if found update it.
//!----------------------------------------------------------------------------
void TabManager::filePathChanged(QString sourcePath, QString destPath, Project *destProject)
{
    for(int i=0;i<count();i++)
    {
        QString tabPath = getTabPathname(i);
        if(tabPath == sourcePath)
        {
            setTabProject(i,destProject);
            setTabPathname(i,destPath);
            if(widget(i) == currentWidget())
            {
                // TODO fix this
                SourceEditor *editor = qobject_cast<SourceEditor *>(widget(i));
                if(editor == NULL)
                    emit setStatusMessage(destPath);
                else
                {
                    emit setStatusMessage(FileUtility::replacePathWithKey(editor->getProject(),destPath));
                }
            }
            return;
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::jumpToCode()
{
    SourceEditor *editor = currentEditor();
    if(editor == NULL) return;
    editor->jumpToCode();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::updateEditorSettings()
{
    // update each source editor that is open
    for(int i=0;i<count();i++)
    {
        QWidget *tabwidget = widget(i);
        SourceEditor *sourceEditor = qobject_cast<SourceEditor *>(tabwidget);
        if(sourceEditor != NULL)
            sourceEditor->loadColorScheme();
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::goBack()
{
    CursorEntry loc;
    bool ret = cursorHistory.back(&loc);
    if(!ret) return;

    QString pathname = loc.pathname;
    int row = loc.row;
    int col = loc.col;

    emit requestFileOpen(pathname,row+1,col);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TabManager::goForward()
{
    qDebug() << "Here is some text output.";

    CursorEntry loc;
    bool ret = cursorHistory.forward(&loc);
    if(!ret) return;

    QString pathname = loc.pathname;
    int row = loc.row;
    int col = loc.col;

    emit requestFileOpen(pathname,row+1,col);
}
