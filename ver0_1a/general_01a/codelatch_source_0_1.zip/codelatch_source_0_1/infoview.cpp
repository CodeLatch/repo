//! InfoView is the rectangular widget that resides below the editor windows (ie TabManger). The InfoView holds
//! informative views like the Console, FindReplace, and BreakpointsWidget.

#include "infoview.h"
#include "Views/console.h"
#include <QToolBar>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QToolButton>
#include <QTabWidget>
#include "Views/findreplacewidget.h"
#include "Views/breakpointswidget.h"
#include <QDebug>
#include "project/project.h"

// The MainWindow is our parent.
InfoView::InfoView(QWidget *parent) :
    QWidget(parent)
{
//    QToolBar *toolbar = new QToolBar;
    // x,y,w,h
    QVBoxLayout *layout = new QVBoxLayout;

//    toolbar->setIconSize(QSize(16,16));
//    toolbar->addAction(QIcon(":/icons/icons/clear_console.png"),"Clear console",this,SLOT(clearConsole()));
//    toolbar->setStyleSheet("QToolBar {spacing: 0px;} QToolButton { border-radius: 5px; border: none; }");

    tabWidget = new QTabWidget;
    tabWidget->setStyleSheet(
                "QTabBar {font-size: 11px;}"
                "QTabBar::tab {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #E1E1E1, stop: 0.4 #DDDDDD,stop: 0.5 #D8D8D8, stop: 1.0 #D3D3D3);}"
                "QTabBar::tab {border: 2px solid #C4C4C3;}"
                "QTabBar::tab {border-bottom-color: #C2C7CB;}"
                "QTabBar::tab {border-top-left-radius: 4px;}"
                "QTabBar::tab {border-top-right-radius: 4px;}"
                "QTabBar::tab {min-width: 5px;}"
                "QTabBar::tab {padding: 2px;}"
                "QTabBar::tab {padding-left: 2px;}"
                "QTabBar::tab {padding-right: 10px;}"
                "QTabBar::tab:selected, QTabBar::tab:hover {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #fafafa, stop: 0.4 #f4f4f4, stop: 0.5 #e7e7e7, stop: 1.0 #fafafa);}"
                "QTabBar::tab:selected {border-color: #9B9B9B; border-bottom-color: #ebebeb;}"
                "QTabBar::tab:!selected {margin-top: 1px;}"
                "QTabBar::close-button {subcontrol-position: left;}"
                "QTabBar::close-button:hover {image: NULL;}"
                );

    tabWidget->setDocumentMode(true);
    tabWidget->setTabsClosable(false);
    tabWidget->setMovable(false);

    console = new Console;
    tabWidget->addTab(console,"Console");

    findReplaceWidget = new FindReplaceWidget(parent); // FindReplaceWidget needs MainWindow as parent.
    tabWidget->addTab(findReplaceWidget,"Find/Replace");

    breakpointsWidget = new BreakpointsWidget(parent); // BreakpointsWidget needs MainWindow as parent.
    tabWidget->addTab(breakpointsWidget,"Breakpoints");

    layout->addWidget(tabWidget);
    layout->setSpacing(0);
    layout->setContentsMargins(0,0,0,0);
    setLayout(layout);

    connect(console,SIGNAL(showConsole()),this,SLOT(showConsole()));
    connect(breakpointsWidget,SIGNAL(breakpointClicked(QString,int)),this,SIGNAL(activateFile(QString,int)));
}

void InfoView::slotSetBreakpoints(Project *prj)
{
    if(breakpointsWidget != NULL)
        breakpointsWidget->setBreakpoints(prj);
}

void InfoView::updateBreakpointView(Project *prj)
{
    breakpointsWidget->setBreakpoints(prj);
}

void InfoView::initToolbar(QHBoxLayout *tbLayout)
{
    Q_UNUSED(tbLayout);
//    QToolBar *consoleToolbar = new QToolBar(this);
//    consoleToolbar->addAction(QIcon(":/icons/icons/clear_console.png"),"Clear console",this,SLOT(clearConsole()));
//    tbLayout->insertWidget(0,consoleToolbar);
}

void InfoView::addBreakpoint(QString pathname, int line)
{
    breakpointsWidget->addBreakpont(pathname,line);
}

void InfoView::removeBreakpoint(QString pathname, int line)
{
    breakpointsWidget->removeBreakpont(pathname,line);
}

void InfoView::navItemChanged(Project *prj,QString pathname)
{
    Q_UNUSED(pathname);
    breakpointsWidget->setBreakpoints(prj);
}

void InfoView::clearConsole()
{
    console->clear();
}

void InfoView::showConsole()
{
    if((tabWidget == NULL) || (console == NULL)) return;
    if(tabWidget->currentWidget() != console)
        tabWidget->setCurrentWidget(console);
}

void InfoView::showFinder()
{
    if((tabWidget == NULL) || (findReplaceWidget == NULL)) return;
    if(tabWidget->currentWidget() != findReplaceWidget)
        tabWidget->setCurrentWidget(findReplaceWidget);
    findReplaceWidget->setFocusToEdit();
}

void InfoView::finderSearchForText(const QString &text, int scope)
{
    if(findReplaceWidget == NULL) return;
    showFinder();
    if(text.isEmpty()) return;
    if(scope != -1) findReplaceWidget->setScope(scope);
    findReplaceWidget->setFindText(text);
//    findReplaceWidget->nextButtonPressed();
}
