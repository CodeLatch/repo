#ifndef TERMINALVIEW_H
#define TERMINALVIEW_H

#include <QLabel>
#include <QMainWindow>
//#include <QFutureWatcher>
//#include <QUdpSocket>
#include <QTcpSocket>
#include <QProcess>
#include <stdint.h>

class QLineEdit;
class QComboBox;
class QVBoxLayout;
class QTextEdit;
class QCheckBox;
class QPushButton;
class QStatusBar;
class DeviceMonitor;

class TerminalWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit TerminalWindow(QWidget *parent = 0);
    ~TerminalWindow();

    static int getFreePort();

signals:
    void updateRx(QString);
    void updateStatus(bool);
    void TerminalClosing();

public slots:
    void sendButtonPressed();
    void clearButtonPressed();
    void scrollToEndCheckBoxPressed();
    void comboSelectionChanged(QString location);
    void setRxText(QString text);
    void setStatus(bool connected);
    void serverFinished(int);

private slots:
    void deviceAttached(QString location);
    void deviceRemoved(QString location);
    void packetReceived();
    void serverReadyRead();

private:
    bool scrollToEnd;
    bool connected;
    QTextEdit *rxTextEdit;
    QCheckBox *checkBox;
    QComboBox *combo;
    QLineEdit *sendLineEdit;
    QPushButton *sendButton;
    QString currentPath;
//    QUdpSocket *udpsocket;
    QTcpSocket *socket;
    QProcess *server;

    uint16_t port;
    DeviceMonitor *deviceMonitor;
    QStringList deviceList;
    QString currentDevice;


protected:
    void closeEvent(QCloseEvent *event);

};

#endif // TERMINALVIEW_H
