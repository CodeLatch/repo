//!----------------------------------------------------------------------------
//! file: main.cpp
//!
//! Program entry point, launches mainwindow.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include <QApplication>
#include "mainwindow/mainwindow.h"
#include <QtGui>
#include <QtDebug>
#include <QFile>
#include <QTextStream>
#include "utility/fileutility.h"

bool g_logEnabled = false;
bool g_extendedLogEnabled = true;

/*
void defaultMessageHandler(QtMsgType type,const QMessageLogContext &context, const QString &msg)
{
    if(!g_logEnabled)
        return;

    QString text;

    switch(type)
    {
    case QtDebugMsg:
        text = msg;
        break;
    case QtWarningMsg:
        text = QString("WARNING: ") + msg;
        break;
    case QtCriticalMsg:
        text = QString("CRITICAL: ") + msg;
        break;
    case QtFatalMsg:
        text = QString("FATAL: ") + msg;
        break;
    default:
        text = QString("UNKNOWN: ") + msg;
        break;
    }

    if(g_extendedLogEnabled)
    {
        text += QString("\n  category: ") + QString(context.category) + QString("\n");
        text += QString("  function: ") + QString(context.function) + QString("\n");
        text += QString("  line: ") + QString::number(context.line) + QString("\n");
    }

    QFile file(FileUtility::getDirHome()+"/log.txt");
    file.open(QIODevice::WriteOnly | QIODevice::Append);
    QTextStream stream(&file);
    stream << text << endl;
    stream.flush();
    file.close();
}
*/

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    // re-route info messages (qDebug(), etc.) to our message handler
//   qInstallMessageHandler(defaultMessageHandler);

    // set application font so it's present for static builds

#if defined Q_OS_MAC
/*
    QFontDatabase database;
    QStringList fontFamilies = database.families();
    qDebug() << fontFamilies;
    QFont font = qApp->font();
    qDebug() << "appFont:" << font.family();
*/
#elif defined Q_OS_WIN
/*
    QFontDatabase database;
    database.addApplicationFont(":/fonts/fonts/Vera.ttf");
    QFont font = qApp->font();
    font.setFamily("Bitstream Vera Sans");
    qApp->setFont(font);
*/
#elif defined Q_OS_UNIX
    QFontDatabase database;
    database.addApplicationFont(":/fonts/fonts/Vera.ttf");
    QFont font = qApp->font();
    font.setFamily("Bitstream Vera Sans");
    qApp->setFont(font);
#endif

    MainWindow w;
    w.show();

    return a.exec();
}
