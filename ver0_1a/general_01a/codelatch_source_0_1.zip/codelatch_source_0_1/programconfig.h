#ifndef PROGRAMCONFIG_H
#define PROGRAMCONFIG_H

#include <QVariant>
#include <QString>
#include <QMap>

// configuration storage strings
#define MAIN_WINDOW_GEOMETRY                    "MainWindow Geometry"
#define MAIN_WINDOW_VSPLIT_STATE                "MainWindow VSPLIT STATE"
#define MAIN_WINDOW_HSPLIT_STATE                "MainWindow HSPLIT STATE"
#define NAVIGATOR_OPEN_PROJECT_LIST             "NavigatorOpenProjects"
#define TARGET_NAME                             "CurrentTargetName"
// editor settings
#define EDITOR_COLOR_SCHEME                     "EditorColorScheme"
#define EDITOR_AUTOFORMAT_ENABLED               "EditorAutoFormatEnabled"
#define EDITOR_AUTOINDENT_ENABLED               "EditorAutoIndentEnabled"
#define EDITOR_FORMAT_STYLE                     "EditorFormatStyle"
#define EDITOR_AUTOCOMPLETE_TIMEOUT             "EditorAutoCompleteTimeout"
#define EDITOR_FORMAT_FLAGS                     "EditorFormatFlags"
// terminal window
#define TERMINAL_WINDOW_GEOMETRY                "TerminalWindow Geometry"
// root storage folder - folder that holds examples, projects, libraries, targets
#define ROOT_STORAGE_FOLDER                     "RootStorageFolder"

class ProgramConfig
{

public:
    ProgramConfig();

    static bool load();
    static bool save();
    static void clear();
    static void set(QString key, QVariant value);
    static QVariant get(QString key);
    static bool contains(QString key);

private:


};

#endif // PROGRAMCONFIG_H
