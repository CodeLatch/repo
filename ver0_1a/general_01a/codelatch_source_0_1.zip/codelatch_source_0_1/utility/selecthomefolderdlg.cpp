#include "selecthomefolderdlg.h"
#include "ui_selecthomefolderdlg.h"
#include <QFileDialog>
#include "fileutility.h"

SelectHomeFolderDlg::SelectHomeFolderDlg(QWidget *parent, QString text) :
    QDialog(parent),
    ui(new Ui::SelectHomeFolderDlg)
{
    ui->setupUi(this);
    strHomeFolder = text;
    ui->lineEdit->setText(strHomeFolder);
    setWindowTitle("Home Folder Setup");
}

SelectHomeFolderDlg::~SelectHomeFolderDlg()
{
    delete ui;
}

void SelectHomeFolderDlg::on_pb_Ok_clicked()
{
    accept();
}

void SelectHomeFolderDlg::on_pb_Change_clicked()
{
    // ask user to select folder, allow new folder to be created
    QString path = QFileDialog::getExistingDirectory(this, tr("Select folder..."),
                                                     FileUtility::getDocumentsPath(),
                                                     QFileDialog::ShowDirsOnly
                                                     | QFileDialog::DontResolveSymlinks);
    if(path.isEmpty())
        return;
    strHomeFolder = path;
    ui->lineEdit->setText(strHomeFolder);
}
