//!----------------------------------------------------------------------------
//! file: fileutility.cpp
//!
//! Utility functions for file access.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "fileutility.h"
#include <QApplication>
#include <QFileInfo>
#include <QDir>
#include <QDebug>
#include <QtGlobal>
#include <project/project.h>
#include <QTemporaryFile>
#include <QStandardPaths>
#include "programconfig.h"

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
FileUtility::FileUtility()
{
}

/*
 // two ways to get directory...
 //   qDebug() << "adir:"<<QApplication::applicationDirPath();
 //   qDebug() << "cp:"<<QDir::currentPath();
 // QApplication method doesn't work properly on Windows systems.

   #ifdef Q_OS_LINUX
    return QString("Linux");
    #endif

    #ifdef Q_OS_MAC
    return QString("Mac");
    #endif

    #ifdef Q_OS_WIN
    return QString("Windows");
    #endif
    */

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirApp()
{
#if defined Q_OS_WIN
    QString dir = QDir::currentPath();
    QDir appdir = QDir(dir);
#elif defined Q_OS_MAC
    QString dir = QApplication::applicationDirPath();
    QDir appdir = QDir(dir);
    // note: on a mac the executable is in a bundle three directories down.
    appdir.cdUp(); // move to parent folder
#elif defined Q_OS_LINUX
    QString dir = QApplication::applicationDirPath();
    QDir appdir = QDir(dir);
#endif

    dir = appdir.path();
    return dir;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirHome()
{
    QString path = ProgramConfig::get(ROOT_STORAGE_FOLDER).toString();
    QDir appdir(path);

    if(path.isEmpty())
    {
        path = getDirApp();
#if defined Q_OS_MAC
        appdir.cdUp();
        appdir.cdUp();
        appdir.cdUp();
#endif
    }

    QString dir = appdir.path();
    return dir;
}

/*
 * old method that works without Documents based functionality
//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirHome()
{
#if defined Q_OS_WIN
    QString dir = QDir::currentPath();
#elif defined Q_OS_MAC
    QString dir = QApplication::applicationDirPath();
//    QString dir = QDir::currentPath();
//    QString text = "home dir:" + dir;
//    console->appendLine(text);
#elif defined Q_OS_LINUX
    QString dir = QApplication::applicationDirPath();
#endif
    QDir appdir = QDir(dir);
    appdir.cdUp(); // move to parent folder

    // on a mac the executable is in a bundle three directories down, back out of that
    // to get to the same level as the other os's.
#if defined Q_OS_MAC
    appdir.cdUp();
    appdir.cdUp();
    appdir.cdUp();
#endif

    dir = appdir.path();
    return dir;
}
*/

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirTargets()
{
    return getDirHome() + "/targets";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirExamples()
{
    return getDirHome() + "/examples";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirConfigs()
{
    return getDirHome() + "/configs";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirLibrary()
{
    return getDirHome() + "/lib";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirTemp()
{
    return getDirHome() + "/temp";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirCompiler()
{
    return getDirHome() + "/compiler";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirProjects()
{
    return getDirHome() + "/projects";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirTools()
{
    return getDirHome() + "/tools";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getDirDoc()
{
    return getDirHome() + "/doc";
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::replaceKeyWithPath(Project *prj, QString str)
{
    QString prjDir;

    if(prj != NULL)
        prjDir = prj->getProjectFolder();

    QString homeDir = getDirHome();
    QString examplesDir = getDirExamples();
    QString configsDir = getDirConfigs();
    QString libDir = getDirLibrary();
    QString tempDir = getDirTemp();
    QString toolsDir = getDirTools();
    QString compilerDir = getDirCompiler();
    QString projectsDir = getDirProjects();
    QString targetsDir = getDirTargets();

    // replacements should be ordered in inverse heirarchy

    if(str.contains("${examples}"))
        str = str.replace("${examples}", examplesDir);
    if(str.contains("${configs}"))
        str = str.replace("${configs}", configsDir);
    if(str.contains("${lib}"))
        str = str.replace("${lib}", libDir);
    if(str.contains("${temp}"))
        str = str.replace("${temp}", tempDir);
    if(str.contains("${tools}"))
        str = str.replace("${tools}", toolsDir);
    if(str.contains("${compiler}"))
        str = str.replace("${compiler}", compilerDir);
    if(str.contains("${projects}"))
        str = str.replace("${projects}", projectsDir);
    if(str.contains("${targets}"))
        str = str.replace("${targets}", targetsDir);

    if(str.contains("${build}") && (prj != NULL))
        str = str.replace("${build}",prj->getBuildFolder());
    if((prj != NULL) && (str.contains("${prj}")))
        str = str.replace("${prj}", prjDir);

    if(str.contains("${name}") && (prj != NULL))
        str = str.replace("${name}",prj->getName());
    if(str.contains("${exe}"))
    {
#ifdef Q_OS_WIN
        str.replace("${exe}",".exe");
#else
        str.remove("${exe}");
#endif
    }

    // home should be the last keyword replacement
    if(str.contains("${home}"))
        str = str.replace("${home}", homeDir);

    // replace all occurrences of \ with /
    str = str.replace("\\","/");
    // replace all occurrences of // with / (repeating separator)
    str = str.replace("//","/");
    // make sure we are using the correct file separator for this operating system.
    //  str = str.replace("/",File.separator);

    return str;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::replacePathWithKey(Project *prj, QString str)
{
    QString projectDir;

    if(prj != NULL)
        projectDir = prj->getProjectFolder();

    QString homeDir = getDirHome();
    QString examplesDir = getDirExamples();
    QString configsDir = getDirConfigs();
    QString libDir = getDirLibrary();
    QString tempDir = getDirTemp();
    QString toolsDir = getDirTools();
    QString compilerDir = getDirCompiler();
    QString projectsDir = getDirProjects();
    QString targetsDir = getDirTargets();
    QString name;
    QString prjFolder;
    QString buildFolder;
    if(prj != NULL)
    {
        name = prj->getName();
        prjFolder = prj->getProjectFolder();
        buildFolder = prj->getBuildFolder();
    }

    if((prj != NULL) && (str.contains(buildFolder+"/") || (str == buildFolder)))
        str = str.replace(buildFolder,"${build}/");
    //    if((prj != NULL) && (str.contains(prjFolder+"/") || (str == prjFolder)))
    //        str = str.replace(prjFolder,"${prj}/");
    if(str.contains(projectsDir+"/") || (str == projectsDir))
        str = str.replace(projectsDir,"${projects}/");
    if(str.contains(examplesDir+"/") || (str == examplesDir))
        str = str.replace(examplesDir,"${examples}/");
    if(str.contains(libDir+"/") || (str == libDir))
        str = str.replace(libDir,"${lib}/");
    if(str.contains(tempDir+"/") || (str == tempDir))
        str = str.replace(tempDir,"${temp}/");
    if(str.contains(targetsDir+"/") || (str == targetsDir))
        str = str.replace(targetsDir,"${targets}/");
    if(str.contains(configsDir+"/") || (str == configsDir))
        str = str.replace(configsDir,"${configs}/");
    if(str.contains(toolsDir+"/") || (str == toolsDir))
        str = str.replace(toolsDir,"${tools}/");
    if(str.contains(compilerDir+"/") || (str == compilerDir))
        str = str.replace(compilerDir,"${compiler}/");
    if(str.contains(homeDir+"/") || (str == homeDir))
        str = str.replace(homeDir,"${home}/");

    //    if((prj != NULL) && (str.contains(name)))
    //        str = str.replace(name,"${name}");

    // replace all occurrences of \ with /
    str = str.replace("\\","/");
    // replace all occurrences of // with / (remove repeating separator)
    str = str.replace("//","/");

    return str;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool FileUtility::eraseDir(const QString &dirName, bool deleteTopDir)
{
    bool result = true;
    QDir dir(dirName);

    if (dir.exists(dirName)) {
        Q_FOREACH(QFileInfo info, dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst)) {
            if (info.isDir()) {
                result = eraseDir(info.absoluteFilePath());
            }
            else {
                result = QFile::remove(info.absoluteFilePath());
            }

            if (!result) {
                return result;
            }
        }
        if(deleteTopDir)
            result = dir.rmdir(dirName);
    }
    return result;
}

//!-----------------------------------------------------------------------------
//! \brief  Copy a directory and all it's contents, excluding hidden files,
//! to a new directory. This routine is not optimized at all and shouldn't be
//! used where you want to copy large complex directory structures, like a
//! whole drive.
//!
//! srcFolderName - the name of the source folder.
//! destFolderName - the name of the destination folder.
//! overWrite - true = overWrite existing files, false = don't overwrite.
//!
//! Return: true if successful, false otherwise.
//!-----------------------------------------------------------------------------
bool FileUtility::copyDir(QString srcFolderName, QString destFolderName, bool overWrite)
{
    bool ret = true;

    // provide a little forgivness in the directory naming regarding slash
    // count and positioning, probably don't need it but could save a headache.
    srcFolderName = srcFolderName.replace("//","/");
    destFolderName = destFolderName.replace("//","/");
    if(srcFolderName.endsWith('/'))
        srcFolderName.remove(srcFolderName.length()-1,1);
    if(destFolderName.endsWith('/'))
        destFolderName.remove(destFolderName.length()-1,1);

    QDir srcDir(srcFolderName);
    if (!srcDir.exists())
        return false;

    QStringList dirList = srcDir.entryList(QDir::AllDirs);
    QStringList fileList = srcDir.entryList(QDir::Files);

    // copy directories
    foreach(QString dirName,dirList)
    {
        if(dirName=="." || dirName=="..")
            continue;
        QString srcPath = srcFolderName + "/" + dirName;
        QString destPath = destFolderName + "/" + dirName;

        QFileInfo info(srcPath);
        if(!info.isDir())
            continue;

        QDir destDir(destPath);
        destDir.mkpath(destDir.path());
        if(!copyDir(srcPath,destPath,overWrite))
            ret = false;
    }

    // copy files
    foreach(QString fileName,fileList)
    {
        QString srcPath = srcFolderName + "/" + fileName;
        QString destPath = destFolderName + "/" + fileName;

        QFileInfo info(srcPath);
        if(info.isDir())
            continue;

        QDir destDir(destFolderName);
        if(!destDir.exists())
            destDir.mkpath(destFolderName);

        QFile destFile(destPath);
        if(destFile.exists() && !overWrite)
            continue;
        if(destFile.exists() && overWrite)
            destFile.remove();
        QFile srcFile(srcPath);
        if(!srcFile.copy(destPath))
            ret = false;
    }
    return ret;
}

//!-----------------------------------------------------------------------------
//! \brief  Move a directory and all it's contents, excluding hidden files,
//! to a new directory. This routine is not optimized at all and shouldn't be
//! used where you want to copy large complex directory structures, like a
//! whole drive.
//!
//! srcFolderName - the name of the source folder.
//! destFolderName - the name of the destination folder.
//! overWrite - true = overWrite existing files, false = don't overwrite.
//!
//! Return: true if successful, false otherwise.
//!-----------------------------------------------------------------------------
bool FileUtility::moveDir(QString srcFolderName, QString destFolderName, bool overWrite)
{
    bool ret = true;

    // provide a little forgivness in the directory naming regarding slash
    // count and positioning, probably don't need it but could save a headache.
    srcFolderName = srcFolderName.replace("//","/");
    destFolderName = destFolderName.replace("//","/");
    if(srcFolderName.endsWith('/'))
        srcFolderName.remove(srcFolderName.length()-1,1);
    if(destFolderName.endsWith('/'))
        destFolderName.remove(destFolderName.length()-1,1);

    QDir srcDir(srcFolderName);
    if (!srcDir.exists())
        return false;

    QStringList dirList = srcDir.entryList(QDir::AllDirs);
    QStringList fileList = srcDir.entryList(QDir::Files);

    // move directories
    foreach(QString dirName,dirList)
    {
        if(dirName=="." || dirName=="..")
            continue;
        QString srcPath = srcFolderName + "/" + dirName;
        QString destPath = destFolderName + "/" + dirName;

        QFileInfo info(srcPath);
        if(!info.isDir())
            continue;

        QDir destDir(destPath);
        QDir srcDir(srcPath);
        destDir.mkpath(destDir.path());
        if(!moveDir(srcPath,destPath,overWrite))
            ret = false;
        else
            srcDir.rmdir(srcPath);
    }

    // move files
    foreach(QString fileName,fileList)
    {
        QString srcPath = srcFolderName + "/" + fileName;
        QString destPath = destFolderName + "/" + fileName;

        QFileInfo info(srcPath);
        if(info.isDir())
            continue;

        QDir destDir(destFolderName);
        if(!destDir.exists())
            destDir.mkpath(destFolderName);

        QFile destFile(destPath);
        QFile srcFile(srcPath);
        if(destFile.exists() && !overWrite)
            continue;
        if(destFile.exists() && overWrite)
            destFile.remove();
        if(!srcFile.copy(destPath))
            ret = false;
        else
            srcFile.remove();
    }
    return ret;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getProjectFolderFromPathname(QString pathname)
{
    QFileInfo info(pathname);
    if(!info.exists()) return QString();
    QString home = FileUtility::getDirHome();
    if(!pathname.startsWith(home)) return QString();
    QDir dir = info.dir();
    QStringList list = dir.entryList(QDir::AllEntries);
    while(!list.contains(Project::getConfigFilename()) && (pathname != home))
    {
        if(!dir.cdUp()) return QString();
        pathname = dir.path();
        list = dir.entryList(QDir::AllEntries);
    }
    if(pathname == home) return QString();
    return dir.path();
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
QString FileUtility::getProjectNameFromProjectFolder(QString projectFolder)
{
    if(projectFolder.isEmpty()) return QString();
    QFileInfo info(projectFolder);
    return info.fileName();
}

//!-----------------------------------------------------------------------------
//! \brief   Returns the full path to use as the start of a unique file name.
//! Doing this allows us to make the front of the filename unique to this
//! instance of the program. This will allow us to clean up the temp directory later.
//!-----------------------------------------------------------------------------
QString FileUtility::getTempDirFileLead()
{
    // get temporary directory for this OS
    QTemporaryFile file;
    if (!file.open()) return QString();
    QFileInfo info(file);
    QString dir = info.absoluteDir().path();
    file.close();
    QString filepath = dir + "/CodeLatch_";


    return filepath;
}

//!-----------------------------------------------------------------------------
//! \brief   Returns a unique filename in the temp directory. Empty string if fail.
//!
//! example: QString filepath = getUniqueTempFilename(".cpp");
//!-----------------------------------------------------------------------------
QString FileUtility::getUniqueTempFilename(QString extension)
{
    static unsigned int n = 0;
    QString filename;

    // get temporary directory for this OS
    QTemporaryFile file;
    if (!file.open()) return QString();
    QFileInfo info(file);
    QString dir = info.absoluteDir().path();
    file.close();

    int trys = 100;
    while(trys-- > 0)
    {
        filename = dir + "/" + "CodeLatch_" + QString::number(n++) + extension;
        QFile test(filename);
        if(!test.exists())
            break;
    }
    if(trys <= 0) return QString();
    return filename;
}

//!-----------------------------------------------------------------------------
//!
//!-----------------------------------------------------------------------------
QString FileUtility::getDocumentsPath()
{
    QStringList list = QStandardPaths::standardLocations(QStandardPaths::DocumentsLocation);
    return list.first();
}

