#ifndef UTILITY_H
#define UTILITY_H

#include <QString>
#include "project/project.h"

class FileUtility
{
public:
    FileUtility();

    static QString replacePathWithKey(Project *prj, QString str);
    static QString replaceKeyWithPath(Project *prj, QString str);

    static QString getDirApp();
    static QString getDirHome();
    static QString getDirTargets();
    static QString getDirExamples();
    static QString getDirConfigs();
    static QString getDirLibrary();
    static QString getDirTemp();
    static QString getDirTools();
    static QString getDirDoc();
    static QString getDirCompiler();
    static QString getDirProjects();
    static QString getUniqueTempFilename(QString extension = QString());
    static QString getTempDirFileLead();
    static QString getDocumentsPath();

    static bool eraseDir(const QString &dirName, bool deleteTopDir = true);
    static bool copyDir(QString srcFolderName, QString destFolderName, bool overWrite=true);
    static bool moveDir(QString srcFolderName, QString destFolderName, bool overWrite=true);

    static QString getProjectFolderFromPathname(QString pathname);
    static QString getProjectNameFromProjectFolder(QString projectFolder);

};

#endif // UTILITY_H
