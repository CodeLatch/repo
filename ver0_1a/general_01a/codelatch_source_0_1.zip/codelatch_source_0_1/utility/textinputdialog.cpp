#include "textinputdialog.h"
#include "ui_textinputdialog.h"

TextInputDialog::TextInputDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TextInputDialog)
{
    ui->setupUi(this);
}

TextInputDialog::~TextInputDialog()
{
    delete ui;
}

void TextInputDialog::setText(QString text)
{
    ui->plainTextEdit->setPlainText(text);
}

void TextInputDialog::on_buttonBox_accepted()
{
    _text = ui->plainTextEdit->toPlainText();
}

void TextInputDialog::on_buttonBox_rejected()
{
    _text.clear();
}
