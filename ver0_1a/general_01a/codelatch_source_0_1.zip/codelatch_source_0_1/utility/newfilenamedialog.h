#ifndef NEWFILENAMEDIALOG_H
#define NEWFILENAMEDIALOG_H

#include <QWidget>

class NewFileNameDialog : public QWidget
{
    Q_OBJECT
public:
    explicit NewFileNameDialog(QWidget *parent = 0);
    
signals:
    
public slots:
    
};

#endif // NEWFILENAMEDIALOG_H
