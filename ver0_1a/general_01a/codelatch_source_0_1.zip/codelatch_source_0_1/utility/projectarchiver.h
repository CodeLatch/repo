#ifndef PROJECTARCHIVER_H
#define PROJECTARCHIVER_H

#include <QDialog>
#include "project/project.h"

namespace Ui {
class ProjectArchiver;
}

class ProjectArchiver : public QDialog
{
    Q_OBJECT

public:
    explicit ProjectArchiver(Project *prj, QWidget *parent = 0);
    ~ProjectArchiver();

private slots:
    void on_pbAdd_clicked();
    void on_pbRestore_clicked();
    void on_pbDelete_clicked();
    void on_listWidget_itemSelectionChanged();

signals:
    void updateProjectTree(Project *project);
    void closeTabs(Project *project);

private:
    QStringList buildFileList(const QString &folder);
    bool copyFiles(const QStringList &filePathList, const QString &destFolder);
    void populateList();

    Ui::ProjectArchiver *ui;
    Project *project;
};

#endif // PROJECTARCHIVER_H
