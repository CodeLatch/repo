#ifndef PROGRESSDIALOG_H
#define PROGRESSDIALOG_H

#include <QWidget>
#include <QProgressDialog>

class ProgressDialog : public QWidget
{
    Q_OBJECT
public:
    explicit ProgressDialog(QWidget *parent = 0);

signals:
    void canceled();

public slots:
    void set(QString text, int val, int max);

private:
    QProgressDialog *dlg;

};

#endif // PROGRESSDIALOG_H
