#ifndef SELECTHOMEFOLDERDLG_H
#define SELECTHOMEFOLDERDLG_H

#include <QDialog>

namespace Ui {
class SelectHomeFolderDlg;
}

class SelectHomeFolderDlg : public QDialog
{
    Q_OBJECT

public:
    explicit SelectHomeFolderDlg(QWidget *parent, QString text);
    ~SelectHomeFolderDlg();

    QString homeFolder() {return strHomeFolder;}

private slots:
    void on_pb_Ok_clicked();
    void on_pb_Change_clicked();

private:
    Ui::SelectHomeFolderDlg *ui;
    QString strHomeFolder;
};

#endif // SELECTHOMEFOLDERDLG_H
