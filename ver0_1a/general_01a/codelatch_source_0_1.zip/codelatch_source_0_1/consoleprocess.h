#ifndef CONSOLEPROCESS_H
#define CONSOLEPROCESS_H

#include <QObject>
#include <QProcess>
#include <QEventLoop>

class ConsoleProcess : public QObject
{
    Q_OBJECT
public:
    explicit ConsoleProcess(QObject *parent = 0);
    bool start(QString cmd, QStringList args);

    bool waitForStarted(int msecs=1000);
    bool waitForFinished(int msecs=30000);
    bool waitForOutput(int timeout_ms);

private:
    QProcess *process;
    QStringList outputList;
    QEventLoop waitForOutputLoop;

signals:
    void finished();
    void output(QString);

public slots:
private slots:
    void processFinished(int exitcode);
    void readyRead();
    void waitLoopTimeout();

};

#endif // CONSOLEPROCESS_H
