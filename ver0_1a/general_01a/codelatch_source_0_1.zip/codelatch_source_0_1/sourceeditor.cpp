//!----------------------------------------------------------------------------
//! file: sourceeditor.cpp
//!
//! Source code text editor.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "sourceeditor.h"
#include <QFile>
#include <QFileInfo>
#include <QDebug>
#include <QMessageBox>
#include "QTextDocument"
#include <QGridLayout>
#include <QPainter>
#include <QPaintEvent>
#include <QFont>
#include <QTextBlock>
#include <QScrollBar>
#include <QStringListModel>
#include <QStandardItemModel>
#include <QShortcut>
#include <QTimer>
#include <QStackedWidget>
#include <indexer/indexer.h>
#include "completer.h"
#include <QApplication>
#include "programconfig.h"
#include <QProcess>
#include "utility/fileutility.h"
#include "consoleprocess.h"
#include <QTextDocumentFragment>
#include <QEventLoop>
#include "format.h"
#include "target.h"

// support indexing threads
#include <QFuture>
#include <QFutureWatcher>
#include <QtConcurrent/QtConcurrent>

#include <QListWidget>

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
SourceEditor::SourceEditor(QWidget *parent) : CodeEditor(parent)
{
    createWidgets();
    createConnections();

    bUndoAvailable = false;
    bRedoAvailable = false;
    isDirty = false;
    autoFormat = false;
    autoIndent = false;
    lastKeyPressed = 0;
    setUndoRedoEnabled(true);

    setWordWrapMode(QTextOption::NoWrap);
    QFontMetrics metrics(font());
    int tabWidth = metrics.width("    ");
    setTabStopWidth(tabWidth);

    loadColorScheme();

    connect(this,SIGNAL(marginClicked(int,int)),this,SLOT(slotMarginPressed(int,int)));
    connect(this, SIGNAL(updateBreakpoints()),this,SLOT(slotUpdateBreakpoints()));
    //    QStringList keywordList = keywords();
    //    keywordList << "include";
    //    keywordList << "define";
    //    setKeywords(keywordList);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::loadColorScheme()
{
    QString scheme = ProgramConfig::get(EDITOR_COLOR_SCHEME).toString();

    if(scheme == "Default")
    {
        // default
        setColor(CodeEditor::Background,    QColor("#ffffff")); // paper
        setColor(CodeEditor::Normal,        QColor("#000000")); // plain text
        setColor(CodeEditor::Comment,       QColor("#108010")); // comment
        setColor(CodeEditor::Number,        QColor("#FF7F00")); // number
        setColor(CodeEditor::String,        QColor("#a03030")); // string
        setColor(CodeEditor::Operator,      QColor("#1111FF")); // {}[]()+-#.*=/;:
        setColor(CodeEditor::Identifier,    QColor("#00FFFF")); // anything that starts with alpha or _ that's not a string, keyword, or knownid
        setColor(CodeEditor::Keyword,       QColor("#6A5ACD")); // m_keywords list
        setColor(CodeEditor::BuiltIn,       QColor("#1874CD")); // m_knownIds list
        setColor(CodeEditor::Cursor,        QColor("#FFFFC0")); // current line highlight color
        setColor(CodeEditor::Marker,        QColor("#DBF76C")); // word marker highlight color
        setColor(CodeEditor::BracketMatch,  QColor("#AFFF9C")); // matching brackets highlight color
        setColor(CodeEditor::BracketError,  QColor("#FFA3A3")); // unmatched bracket highlight color
    }
    else if(scheme == "Dark")
    {
        // dark
        setColor(CodeEditor::Background,    QColor("#0C152B"));
        setColor(CodeEditor::Normal,        QColor("#FFFFFF"));
        setColor(CodeEditor::Comment,       QColor("#666666"));
        setColor(CodeEditor::Number,        QColor("#DBF76C"));
        setColor(CodeEditor::String,        QColor("#5ED363"));
        setColor(CodeEditor::Operator,      QColor("#FF7729"));
        setColor(CodeEditor::Identifier,    QColor("#FFFFFF"));
        setColor(CodeEditor::Keyword,       QColor("#FDE15D"));
        setColor(CodeEditor::BuiltIn,       QColor("#9CB6D4"));
        setColor(CodeEditor::Cursor,        QColor("#1E346B"));
        setColor(CodeEditor::Marker,        QColor("#DBF76C"));
        setColor(CodeEditor::BracketMatch,  QColor("#1AB0A6"));
        setColor(CodeEditor::BracketError,  QColor("#A82224"));
    }
    else if(scheme == "Simple")
    {
        // simple
        setColor(CodeEditor::Background,    QColor("#ffffff"));
        setColor(CodeEditor::Normal,        QColor("#000000"));
        setColor(CodeEditor::Comment,       QColor("#808080"));
        setColor(CodeEditor::Number,        QColor("#008000"));
        setColor(CodeEditor::String,        QColor("#800000"));
        setColor(CodeEditor::Operator,      QColor("#8080ff"));
        setColor(CodeEditor::Identifier,    QColor("#000020"));
        setColor(CodeEditor::Cursor,        QColor("#FFFFC0"));
        setColor(CodeEditor::Keyword,       QColor("#000080"));
        setColor(CodeEditor::BuiltIn,       QColor("#008080"));
        setColor(CodeEditor::Marker,        QColor("#ffff00"));
        setColor(CodeEditor::BracketMatch,  QColor("#AFFF9C"));
        setColor(CodeEditor::BracketError,  QColor("#FFA3A3"));
    }
    else if(scheme == "Coco")
    {
        // dark
        setColor(CodeEditor::Background,    QColor("#3D3D3D"));
        setColor(CodeEditor::Normal,        QColor("#FFFFFF"));
        setColor(CodeEditor::Comment,       QColor("#2591FF"));
        setColor(CodeEditor::Operator,      QColor("#F03131"));
        setColor(CodeEditor::String,        QColor("#FF6E40"));

        setColor(CodeEditor::Number,        QColor("#DBF76C"));
        setColor(CodeEditor::Identifier,    QColor("#FFFFFF"));
        setColor(CodeEditor::Keyword,       QColor("#FDE15D"));
        setColor(CodeEditor::BuiltIn,       QColor("#9CB6D4"));
        setColor(CodeEditor::Cursor,        QColor("#1E346B"));
        setColor(CodeEditor::Marker,        QColor("#DBF76C"));
        setColor(CodeEditor::BracketMatch,  QColor("#1AB0A6"));
        setColor(CodeEditor::BracketError,  QColor("#A82224"));
    }

    //    updateHighlighter();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::createWidgets()
{
    timeToAutocompletePopup = 350;  // time in ms before autocomplete pops up if no key is pressed

    completer = new Completer(this);
    completer->hide();

    keypressTimer = new QTimer(this);       // timeToAutocompletePopup after keypress used to show autocompleter
    //    outlineIndexer = new Indexer(this);
    autoCompleteIndexer = new Indexer(this);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::createConnections()
{
    connect(autoCompleteIndexer,SIGNAL(indexingComplete()),this,SLOT(outlineIndexingComplete()));
    connect(autoCompleteIndexer,SIGNAL(indexingComplete()),this,SLOT(autocompleteIndexingComplete()));

    connect(completer, SIGNAL(activated(const QString&)),this, SLOT(insertCompletion(const QString&)));
    connect(completer, SIGNAL(keyPressed(QKeyEvent)),this,SLOT(completerKeyEvent(QKeyEvent)));

    connect(keypressTimer,SIGNAL(timeout()),this,SLOT(keypressTimeout()));

    connect(this,SIGNAL(textChanged()),this,SLOT(slotDocumentWasModified()));
    connect(this,SIGNAL(undoAvailable(bool)),this,SLOT(slotUndoAvailable(bool)));
    connect(this,SIGNAL(redoAvailable(bool)),this,SLOT(slotRedoAvailable(bool)));
    // this timer is used by this class to update the indexers after a timeout period, the
    // timer is started/restarted by a key press and calls to updateIndexer that are aborted
    // due to a currently running indexing process.
    connect(&indexingTimer,SIGNAL(timeout()),this,SLOT(updateIndexer()));

    // anytime the cursor moves we want to look at logging it so we can use the back and fwd arrows
    connect(this,SIGNAL(cursorPositionChanged()),this,SLOT(slotCursorPositionChanged()));
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::getCursorPosition(int *row, int *col)
{
    QTextCursor cursor = textCursor();
    // Current line text
    //    QString cur_line_text   = cursor.block().text().trimmed();

    *row = cursor.blockNumber();
    *col = cursor.columnNumber();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::setCursorPosition(int line, int col)
{
    //    qDebug() << "setCursorPosition:"<<line<<":"<<col;
    QTextCursor cursor = textCursor();
    int currentLine = cursor.blockNumber();

    cursor.movePosition(QTextCursor::StartOfLine);
    if(line <= 0)
        cursor.movePosition(QTextCursor::Start);
    else if(line >= lines())
        cursor.movePosition(QTextCursor::End);
    else
    {
        if(currentLine == 0)
        {
            cursor.movePosition(QTextCursor::Start);
            currentLine = cursor.blockNumber();
        }
        int delta = line - currentLine;
        if(delta < 0)
            cursor.movePosition(QTextCursor::PreviousBlock,QTextCursor::MoveAnchor,-delta);
        else if(delta > 0)
            cursor.movePosition(QTextCursor::NextBlock,QTextCursor::MoveAnchor,delta);
    }
    cursor.movePosition(QTextCursor::Right,QTextCursor::MoveAnchor,col);
    setTextCursor(cursor);

    // make sure the cursor is not hidden in code fold
    ensureCursorVisible();
    //    centerCursor();
    updateSidebar();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::setFirstVisibleLine(int line)
{
    verticalScrollBar()->setValue(qMax(0,line));
    updateSidebar();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int SourceEditor::getFirstVisibleLine()
{
    return firstVisibleBlock().blockNumber();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::setDocText(QString text)
{
    //     blockSignals(true);
    //     setPlainText(text);
    //     blockSignals(false);
    setPlainText(text);
    //    updateIndexer();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::updateIndexer()
{
    qDebug() << "SourceEditor::updateIndexer()";

    if(project == NULL) return;
    if(pathname.isEmpty()) return;

    // don't bother running if the completer selection box is visible
    if (completer->isVisible())
        return;

    // if any of the indexers are currently running restart timer to queue up a new event
    if(autoCompleteIndexer->isRunning() ||
            project->getIndexer()->isRunning())
    {
        indexingTimer.start(1000);
        return;
    }

    indexingTimer.stop();
    // when complete each indexer will emit indexingComplete
    autoCompleteIndexer->processText(project,pathname,this,true);
    //    project->runIndexer();

}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::autocompleteIndexingComplete()
{
    if(completer->isVisible())
        return;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::outlineIndexingComplete()
{
    emit outlineIndexingFinished();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Indexer *SourceEditor::getOutlineIndexer()
{
    //   if(project == NULL) return NULL;
    //    return project->getIndexer();
    return autoCompleteIndexer;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::setMarginWidth(int margin, QString text)
{
    Q_UNUSED(margin);
    Q_UNUSED(text);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int SourceEditor::lines()
{
    return document()->blockCount();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::markerAdd(int line, int type)
{
    Q_UNUSED(type);

    if(markersAtLine(line)) return;
    QList<int> list = getBreakpoints();
    list.append(line);
//    qSort(list);
    setBreakpoints(list);
    emit signalAddBreakpoint(pathname,line);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int SourceEditor::markerFindNext(int startLine, int mask)
{
    Q_UNUSED(mask);

    int i;
    QList<int> list = getBreakpoints();
    for(i=0;i<list.size();i++)
    {
        if(list.at(i) > startLine)
            break;
    }
    if(i >= list.size()) return -1;
    return list.at(i);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool SourceEditor::markersAtLine(int line)
{
    QList<int> list = getBreakpoints();
    return list.contains(line);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::markerDelete(int line, int mask)
{
    Q_UNUSED(mask);

    QList<int> list = getBreakpoints();
    list.removeAll(line);
    qSort(list);
    setBreakpoints(list);
    emit signalRemoveBreakpoint(pathname,line);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString SourceEditor::text()
{
    return toPlainText();
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::slotRedoAvailable(bool available)
{
    bRedoAvailable = available;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::slotUndoAvailable(bool available)
{
    bUndoAvailable = available;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool SourceEditor::isUndoAvailable()
{
    return bUndoAvailable;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool SourceEditor::isRedoAvailable()
{
    return bRedoAvailable;
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: document contents were modified.
//!-----------------------------------------------------------------------------
void SourceEditor::slotDocumentWasModified()
{
    if(pathname.isEmpty()) return;

    isDirty = true;
    indexingTimer.start(2000);

    if(completer->isVisible())
        updateAutoComplete();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::slotReplaceAll(QString findString, QRegExp findExpr, bool isExpr, QString replaceString, bool caseSensitively, bool wholeWords)
{
    QTextDocument *doc = document();
    QTextCursor cursor = textCursor();
    cursor.beginEditBlock();
    cursor.movePosition(QTextCursor::Start);
    QTextCursor newCursor = cursor;
    quint64 count = 0;

    QTextDocument::FindFlags options;
    if (caseSensitively) options = options | QTextDocument::FindCaseSensitively;
    if (wholeWords) options = options | QTextDocument::FindWholeWords;

    if (!findString.isEmpty())
    {
        while (true)
        {
            if (isExpr)
                newCursor = doc->find(findExpr, newCursor, options);
            else
                newCursor = doc->find(findString, newCursor, options);

            if (!newCursor.isNull())
            {
                if (newCursor.hasSelection())
                {
                    newCursor.insertText(replaceString);
                    count++;
                }
            }
            else
            {
                break;
            }
        }
    }
    cursor.endEditBlock();
    QMessageBox::information(this, tr("ReplaceAll"), tr("%1 occurrence(s) were replaced.").arg(count));
}

void SourceEditor::slotMarginPressed(int line, int x)
{
    qDebug() << "SourceEditor::marginPressEvent";
    Q_UNUSED(x);

    if(pathname.isEmpty()) return;
    if(project == NULL) return;

    Target target = project->getTarget();
    int maxBreakpoints = target.getMaxHWBreakpoints();

    if(markersAtLine(line) != 0)
    {
        // remove debug break point
        markerDelete(line,SourceEditor::DebugMarker);
        project->removeBreakpoint(pathname,line);
    }
    else
    {
        // add debug break point
        if(project->getBreakpointCount() >= maxBreakpoints)
        {
            QMessageBox msgBox;
            msgBox.setText("Maximum number of breakpoints reached.");
            msgBox.exec();
            return;
        }
        markerAdd(line,SourceEditor::DebugMarker);
        project->addBreakpoint(pathname,line);
    }
}

//!----------------------------------------------------------------------------
//! \brief Notify the project that breakpoints need updating due to editing.
//!----------------------------------------------------------------------------
void SourceEditor::slotUpdateBreakpoints()
{
    qDebug() << "SourceEditor::slotUpdateBreakpoints()";
    if(project == NULL) return;
    if(pathname.isEmpty()) return;
    /*
    Target target = project->getTarget();
    int maxBreakpoints = target.getMaxHWBreakpoints();

    if(markersAtLine(line) != 0)
    {
        // remove debug break point
        markerDelete(line,SourceEditor::DebugMarker);
        project->removeBreakpoint(pathname,line);
    }
    else
    {
        // add debug break point
        if(project->getBreakpointCount() >= maxBreakpoints)
        {
            QMessageBox msgBox;
            msgBox.setText("Maximum number of breakpoints reached.");
            msgBox.exec();
            return;
        }
        markerAdd(line,SourceEditor::DebugMarker);
        project->addBreakpoint(pathname,line);
    }
*/
    project->updateBreakpoints(this, pathname);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::getStates(int pos, int &state, int &braceState,
                             int &parenState, int &arrayState)
{
    // parsing state
    enum {
        Start = 0,
        LongComment = 1,
        InlineComment = 2
    };

    state = Start;
    braceState = 0;
    parenState = 0;
    arrayState = 0;

    // process text to determine current state
    QString txt = toPlainText();
    int n = txt.length();
    for(int i=0;i<pos;i++)
    {
        QChar ch = txt.at(i);
        QChar next = (i < (n-1)) ? txt.at(i+1) : QChar();
        switch(state)
        {
        case Start:
            if((ch == '/') && (next == '/'))
            {
                state = InlineComment;
                i++;
            }
            else if((ch == '/') && (next == '*'))
            {
                state = LongComment;
                i++;
            }
            else if(ch == '{')
                braceState++;
            else if(ch == '}')
                braceState--;
            else if(ch == '(')
                parenState++;
            else if(ch == ')')
                parenState--;
            else if(ch == '[')
                arrayState++;
            else if(ch == ']')
                arrayState--;
            break;

        case LongComment:
            if((ch == '*') && (next == '/'))
            {
                state = Start;
                i++;
            }
            break;

        case InlineComment:
            if(ch == '\n')
            {
                state = Start;
            }
            break;
        }
    }
}

//*****************************************************************************
//
//                              DOCUMENT FORMATTING
//
//*****************************************************************************

//!-----------------------------------------------------------------------------
//! \brief  Format selection.
//!-----------------------------------------------------------------------------
void SourceEditor::formatSelection()
{
    QTextCursor cursor = textCursor();
    int cursorStart = cursor.selectionStart();
    QString selText = cursor.selection().toPlainText();
    if(selText.isEmpty()) return;

    QString output;
    int topLineNumber = getFirstVisibleLine();

    Format fmt;
    bool ok;
    output = fmt.run(selText,ok,pathname);
    if(!ok) return;

    // replace selected text with newly formatted text
    cursor.insertText(output);

    setFirstVisibleLine(topLineNumber);

    // re-select text
    int pos = cursor.position();
    cursor.setPosition(cursorStart);
    cursor.setPosition(pos, QTextCursor::KeepAnchor);
    setTextCursor(cursor);
    return;
}

//!-----------------------------------------------------------------------------
//! \brief  Format entire document.
//!-----------------------------------------------------------------------------
void SourceEditor::formatDocument()
{
    QTextCursor cursor = textCursor();
    int pos = cursor.position();
    int topLineNumber = getFirstVisibleLine();
    int cursorLineNumber = cursor.blockNumber();
    QString text = toPlainText();
    if(text.isEmpty()) return;
    QString leadTextChars = text.left(pos).simplified().remove(' ');

    Format fmt;
    bool ok;
    QString output = fmt.run(text,ok,pathname);
    if(!ok) return;

    // replace selected text with newly formatted text
    cursor.select(QTextCursor::Document);
    cursor.insertText(output);

    // find where cursor should be
    int i=leadTextChars.length();
    int j=0;
    while((j < output.length()) && (i > 0))
    {
        QChar c = output.at(j++);
        //        if(c==' ' || c=='\t' || c=='\r' || c=='\n') continue;
        if(c.isSpace()) continue;
        i--;
    }
    // if there's whitespace to the right then move through it to the first character
    QChar c = output.at(j++);
    while((j < output.length()) && c.isSpace())
        c = output.at(j++);

    if(j < 1) j = 1;
    cursor.setPosition(j-1);
    setTextCursor(cursor);

    int delta = cursorLineNumber - topLineNumber;
    topLineNumber = cursor.blockNumber() - delta;
    if(topLineNumber < 0) topLineNumber = 0;
    setFirstVisibleLine(topLineNumber);
}

//!-----------------------------------------------------------------------------
//! \brief  Called everytime the { key is pressed.
//!-----------------------------------------------------------------------------
void SourceEditor::leftBracketPressed()
{
    // if there are fewer closing braces than opening braces then
    // insert a closing brace to the right of the cursor.
    QString s = text();
    int openingCnt = s.count('{');
    int closingCnt = s.count('}');
    if(openingCnt <= closingCnt) return;
    QTextCursor cursor = textCursor();
    cursor.insertText("}");
    cursor.movePosition(QTextCursor::Left);
    setTextCursor(cursor);
}

//!-----------------------------------------------------------------------------
//! \brief  Called everytime the } key is pressed.
//!-----------------------------------------------------------------------------
void SourceEditor::rightBracketPressed(QKeyEvent *event)
{
    Q_UNUSED(event);
    QTextCursor cursor = textCursor();
    QString line = cursor.block().text();

    // if the only thing on this line is whitespace and }
    if(line.trimmed()=="}")
    {
        QString lead = line.left(line.indexOf('}'));
        // remove the first tab found
        int i = lead.indexOf('\t');
        if(i != -1)
            line.remove(i,1);
        cursor.select(QTextCursor::LineUnderCursor);
        cursor.insertText(line);
        setTextCursor(cursor);
    }
}

//!-----------------------------------------------------------------------------
//! \brief  Called everytime the ( key is pressed.
//!-----------------------------------------------------------------------------
void SourceEditor::leftParenthesisPressed()
{
    // if there are fewer closing parenthesis than opening parenthesis then
    // insert a closing parenthesis to the right of the cursor.
    QString s = text();
    int openingCnt = s.count('(');
    int closingCnt = s.count(')');
    if(openingCnt <= closingCnt) return;
    QTextCursor cursor = textCursor();
    cursor.insertText(")");
    cursor.movePosition(QTextCursor::Left);
    setTextCursor(cursor);
}

//!-----------------------------------------------------------------------------
//! \brief  Called everytime the ) key is pressed.
//!-----------------------------------------------------------------------------
void SourceEditor::rightParenthesisPressed(QKeyEvent *event)
{
    // if the character to the right of the cursor is a closing
    // parenthesis then don't enter a parenthesis, just move to the right.
    QTextCursor cursor = textCursor();
    QString s = cursor.block().text();
    int pos = cursor.positionInBlock();
    if(pos == s.size())
        QPlainTextEdit::keyPressEvent(event);
    else if(s.at(pos) != ')')
        QPlainTextEdit::keyPressEvent(event);
    else
    {
        cursor.movePosition(QTextCursor::Right);
        setTextCursor(cursor);
    }
}

//!-----------------------------------------------------------------------------
//! \brief  Returns the indent for the first line above the current line that
//! contains text.
//!-----------------------------------------------------------------------------
QString SourceEditor::getPreviousIndent(QTextCursor cursor)
{
    QString indent;
    while(cursor.movePosition(QTextCursor::PreviousBlock))
    {
        QString text = cursor.block().text();
        QString trim = text.trimmed();
        if(trim.length() != 0)
        {
            // copy indent
            indent = text.left(text.indexOf(trim.at(0)));
            int leftBraces = text.count('{');
            int rightBraces = text.count('}');
            if((leftBraces > 0) && (leftBraces > rightBraces))
                indent += '\t';
            return indent;
        }
    }
    return indent;
}

//!-----------------------------------------------------------------------------
//! \brief Returns the previous text "paragraph", including the current line. Used
//! by auto format line processing. If this is a header file we return up to the point where
//! there is no indentation, the start of the file, or the previous 500 lines, which
//! ever comes first. If this is a source file we return up to the start of the
//! closest previous function or the start of the file, which ever comes first.
//!-----------------------------------------------------------------------------
QString SourceEditor::getPreviousParagraphForAutoformat(QString currentLine, QTextCursor cursor)
{
    int n = 0;
    QString output;
    bool isHeaderFile = false;

    if(pathname.endsWith(".h") || pathname.endsWith(".hpp"))
        isHeaderFile = true;

    // for header files take up to the previous 500 lines
    if(isHeaderFile)
    {
        n = cursor.blockNumber();
        if(n > 500) n = 500;
    }
    // for source files use the indexer to take up to the start of the function
    else
    {
        // find the first function above this line
        int lineNo = cursor.blockNumber() + 1;
        Tag *tag = autoCompleteIndexer->getFunctionForScope(pathname,lineNo);
        int funcLine = 1;
        if(tag != NULL)
            funcLine = tag->line;
        // n is the number of lines we need to back up
        n = lineNo - funcLine + 1;
    }

    // get the text
    output = currentLine;
    for(int i=1;i<n;i++)
    {
        if(cursor.movePosition(QTextCursor::PreviousBlock))
            output = cursor.block().text() + "\n" + output;
        else
            break;
        if(isHeaderFile)
        {
            QChar c = output.at(0);
            if(c!=' ' && c!='\t')
                break;
        }
    }
    return output;
}

//!-----------------------------------------------------------------------------
//! \brief Returns the text at the end of the paragraph that contains the
//! specified number of non-whitespace characters.
//!-----------------------------------------------------------------------------
QString SourceEditor::getTailText(int splitType, QString paragraph, int n)
{
    QString output;
    if(n >= paragraph.length())
        return paragraph;

    int i = paragraph.length()-1;

    // if splitType is 0 or 3 we added a character to the end to get formatting to
    // insert the correct number of tabs for the next line, remove the extra
    // character
    if((splitType == 0) || (splitType == 3))
    {
        n--;
        i--;
    }

    // get up to the start of the text
    while((n > 0) && (i > 0))
    {
        QChar c = paragraph.at(i--);
        output = c + output;
        if(c==' ' || c=='\t' || c=='\n' || c=='\r') continue;
        n--;
    }

    // split types
    //   0 = empty or all whitespace line, all other splits have text in the line.
    //   1 = cursor is at the far left or left of cursor is all whitespace.
    //   2 = cursor has text on both sides, splitting line.
    //   3 = cursor is at the far right.
    //
    // splitType      action needed
    //   0,1          backup to and include the next left-most line feed.
    //   2,3          backup to but not including the next left-most line feed.
    n = paragraph.length() - output.length();
    while((n > 0) && (i > 0))
    {
        QChar c = paragraph.at(i--);
        if(((splitType == 2) || (splitType == 3)) && (c=='\n')) break;
        output = c + output;
        if(c=='\n') break;
    }

    return output;
}

//!-----------------------------------------------------------------------------
//! \brief  Called everytime the return key is pressed. Auto-indent text.
//! Currently this is a very simple implementation that just copies the last indent.
//! Will also...
//!  1) elimnate any extra leading whitespace at the beginning of the new line.
//!  2) insert a leading tab if the text on the line before the return had a singular {
//!
//! Note: when } is pressed another function is called that removes a leading tab.
//!-----------------------------------------------------------------------------
void SourceEditor::formatAfterReturnPress(QKeyEvent *event)
{

    QTextCursor cursor = textCursor();
    int posInLine = cursor.positionInBlock();
    QString text = cursor.block().text();
    // insert line feed by normal event handeling
    QPlainTextEdit::keyPressEvent(event);
    // if the user was selecting multiple characters when return was pressed we're done.
    if((cursor.selection().toPlainText().length() > 0))
        return;

    QString leftText = text.left(posInLine);
    QString rightText = text.right(text.length()-leftText.length());
    // if there is leading or trailing whitespace in the text to the right of the cursor remove it.
    QString rightTrimmed = rightText.trimmed();
    if(rightTrimmed != rightText)
    {
        int pos = cursor.position();
        cursor.movePosition(QTextCursor::EndOfBlock,QTextCursor::KeepAnchor);
        cursor.removeSelectedText();
        cursor.insertText(rightTrimmed);
        cursor.setPosition(pos);
    }
    // get the indent of the current line
    QString indent;
    QString trim = text.trimmed();
    if(trim.length() != 0)
        indent = text.left(text.indexOf(trim.at(0)));
    else
        // if the line is all whitespace copy the space to the left of the cursor
        indent = leftText;

    // if the line we just entering contains a single opening brace add tab indent
    if(trim == "{")
        indent += "\t";

    // insert indent
    cursor.insertText(indent);
    setTextCursor(cursor);

    return;

    /*
#ifdef Q_OS_UNIX
    QString lineFeed = "\n";
#else
    QString lineFeed = "\r\n";
#endif

    QTextCursor cursor = textCursor();

    // if the user is selecting multiple characters, we're on the top line, or
    // autoFormat is off don't perform any formatting. just have the return
    // key function as a normal return key in a text editor.
    if((cursor.selection().toPlainText().length() > 0) ||
            (cursor.blockNumber() == 0) ||
            (!autoFormat && !autoIndent))
    {
        QPlainTextEdit::keyPressEvent(event);
        return;
    }

    int posInLine = cursor.positionInBlock();
    QString text = cursor.block().text();

    // if the line is all whitespace
    bool allWhitespace = false;
    if(text.trimmed().length() == 0)
        allWhitespace = true;

    // determine split type
    //   0 = empty or all whitespace line, all other splits have text in the line.
    //   1 = cursor is at the far left or left of cursor is all whitespace.
    //   2 = cursor has text on both sides, splitting line.
    //   3 = cursor is at the far right.
    int splitType;
    if(allWhitespace)
        splitType = 0;
    else if((posInLine == 0) || (text.left(posInLine).trimmed().isEmpty()))
        splitType = 1;
    else if((posInLine > 0) && (posInLine < text.length()))
        splitType = 2;
    else
        splitType = 3;

    // insert a line feed where the cursor is
    text.insert(posInLine,"\n");
    posInLine++;

    // for splitType 0 and 3 insert a character so formatting provides
    // the indentation for the new line. this character will be removed by
    // getTailText().
    if((splitType == 0) || (splitType == 3))
        text.append('x');

    // get the whitespace free text to the right of the cursor for use in
    // positioning the cursor when we are done formatting.
    QString rawTextPastCursor = text.right(text.length()-posInLine).simplified().remove(' ');

    // get whitespace free text for the current line for use in determining
    // what text to take from the formatted paragraph
    QString rawTextOnLine = text.simplified().remove(' ');

    // get a paragraph to format so that formatting works as desired
    QString paragraph = getPreviousParagraphForAutoformat(text,textCursor());

    // run formatting on the paragraph
    bool ok;
    Format fmt;
    QString formattedText = fmt.run(paragraph,ok,pathname,500);
    if(!ok)
    {
        QPlainTextEdit::keyPressEvent(event);
        return;
    }

    // get the formatted text for this line
    formattedText = getTailText(splitType,formattedText,rawTextOnLine.length());

    // replace the current line with the formatted text
    cursor.select(QTextCursor::LineUnderCursor);
    cursor.insertText(formattedText);

    // set the cursor position
    if(splitType == 1)
    {
        // for splitType 1 move past the leading whitespace.
        cursor.movePosition(QTextCursor::StartOfLine);
        text = cursor.block().text();
        int n = text.indexOf(text.trimmed().at(0));
        cursor.movePosition(QTextCursor::Right,QTextCursor::MoveAnchor,n);
        setTextCursor(cursor);
    }
    else if(splitType == 2)
    {
        // for splitType 2 backtrack rawTextPastCursor characters.
        int n = formattedText.length() - 1;
        int len = rawTextPastCursor.length();
        while((n > 0) && (len > 0))
        {
            QChar c = formattedText.at(n--);
            if(c==' ' || c=='\t' || c=='\r' || c=='\n') continue;
            len--;
        }
        n = formattedText.length() - n - 1;
        cursor.movePosition(QTextCursor::Left,QTextCursor::MoveAnchor,n);
        setTextCursor(cursor);
    }

    ensureCursorVisible();
    */
}

//*****************************************************************************
//
//                              AUTO COMPLETION
//
//*****************************************************************************

//!----------------------------------------------------------------------------
//! \brief  This is an override of the QPlainTextEditor virtual function. We
//!         override the key press handler because we don't always want the editor
//!         responding to key presses. Particularly return/enter/up&down arrow
//!         presses when we are using code completion.
//!----------------------------------------------------------------------------
void SourceEditor::keyPressEvent(QKeyEvent *event)
{
    // popup is not visible
    // start/reset keypress timer.
    keypressTimer->start(timeToAutocompletePopup);

    switch (event->key())
    {
    // autoformat when return key is pressed.
    case Qt::Key_Enter:
    case Qt::Key_Return:
        formatAfterReturnPress(event);
        break;
    case Qt::Key_Tab:
        // gcc is funny about having variables defined inside a case
        // statement, you need to bracket it.
    {
        // if there is a selection tabbify the whole selection
        QTextCursor cursor = textCursor();
        if(!cursor.hasSelection())
        {
            QPlainTextEdit::keyPressEvent(event);
            break;
        }
        QString text = cursor.selection().toPlainText();
        int startPos = cursor.selectionStart();
        text = "\t" + text;
        text.replace("\n","\n\t");
        if(text.endsWith("\n\t"))
            text = text.left(text.length()-1);
        cursor.insertText(text);
        cursor.setPosition(startPos);
        cursor.movePosition(QTextCursor::Right,QTextCursor::KeepAnchor,text.length());
        setTextCursor(cursor);
    }
        break;
    case Qt::Key_BraceRight:
        QPlainTextEdit::keyPressEvent(event);
        rightBracketPressed(event);
        break;
    default:
        QPlainTextEdit::keyPressEvent(event);
    }
    lastKeyPressed = event->key();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::keypressTimeout()
{
    keypressTimer->stop();
    updateAutoComplete();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString SourceEditor::getPrefixUnderCursor()
{
    QTextCursor cursor = textCursor();
    QTextBlock block = cursor.block();
    // get text under cursor (to the left)
    QString text = block.text();
    int i = cursor.columnNumber();
    // simplify our search by replacing tabs with spaces
    text.replace('\t',' ');
    // if the character to the right of the cursor is not a space or eol, don't
    // perform completion.
    if(i < text.length())
    {
        //        qDebug() << "i:" << i << " char:" << text.at(i);
        if(!text.at(i).isSpace())
            return QString();
    }
    if(i == 0)
        return QString();


    int istart = text.lastIndexOf(' ',qMax(0,i-1)) + 1;
    int iend = text.indexOf(' ',i);
    if(iend == -1) iend = text.length();
    QString subtext = text.mid(istart,iend-istart);

    QString prefix;
    int cursorPos = i-istart;
    if(cursorPos == 0)
        prefix.clear();
    else
        prefix = subtext;

    // we have our first cut at the prefix, now we need to do a little more work to deal with
    // function related issues.
    int j = prefix.lastIndexOf(')');
    i = prefix.lastIndexOf('(');
    if(i > j)  prefix = prefix.right(prefix.length() - i - 1);

    // keep right side of string until we hit a non alpha-numeric or underscore
    for(i=prefix.length()-1;i>=0;i--)
    {
        QChar c = prefix.at(i);
        if(c == ',') break;
    }

    if(i > 0)
        prefix = prefix.right(prefix.length() - i -1);

    qDebug() << "prefix:" << prefix;
    return prefix;
}

//!----------------------------------------------------------------------------
//! \brief  Return the statement under the cursor that can be used to
//!         resolve a tag that we can then jump to the implementation
//!         and/or definition of.
//!----------------------------------------------------------------------------
QString SourceEditor::getStatementUnderCursor()
{
    QTextCursor cursor = textCursor();
    QTextBlock block = cursor.block();
    QString text = block.text();
    int i = cursor.columnNumber();
    if(i <= 0) return QString();

    QString sel = cursor.selectedText();

    // the character returned by indexing the cursor position will be the character to the right of the cursor.
    // the columnNumber returned when a word is selected will be the rightmost position.

    // simplify our search by replacing tabs with spaces
    text.replace('\t',' ');
    // get valid statement text to the left of the cursor.
    // allow alpha-numeric, ".", "->", "::", "_"
    QChar c,cp;
    int istart = i-1;
    while(istart >= 0)
    {
        c = text.at(istart);
        if(istart > 0)
            cp = text.at(istart-1);
        else
            cp = '*';
        bool ok = false;
        if(c.isLetterOrNumber()) ok = true;
        if(c=='.') ok = true;
        if(c==':')  ok = true;
        if(c=='_')  ok = true;
        if(c==' ') ok = false;
        if((c=='>') && (cp=='-')) {istart--;ok = true;}
        if(!ok) break;
        istart--;
    }
    istart++;

    // find end of statement
    int iend = istart;
    while(iend < text.length())
    {
        c = text.at(iend);
        if((iend+1) < text.length())
            cp = text.at(iend+1);
        else
            cp = '*';
        bool ok = false;
        if(c.isLetterOrNumber()) ok = true;
        if(c=='.') ok = true;
        if(c==':') ok = true;
        if(c=='_')  ok = true;
        if(c==' ') ok = false;
        if((c=='-') && (cp=='>')) {iend++;ok = true;}
        if(!ok) break;
        iend++;
    }
    if(iend < text.length()) iend++;
    text = text.mid(istart,iend-istart-1);
    // if we are highlighting the left most item just use it
    if((sel.length() > 1) && (istart == (i-sel.length())))
        text = sel;
    return text;
}

//!----------------------------------------------------------------------------
//! \brief Someone called us to update the auto complete list. This is probably
//! either because the timeout triggered after a keypress for us to show
//! the popup, or the popup was already visable and a key was pressed so we
//! need to update it.
//!----------------------------------------------------------------------------
void SourceEditor::updateAutoComplete()
{
    // if we are in a comment section don't show completer
    QTextCursor cursor = textCursor();
    int pos = cursor.position();
    int state,braceState,parenState,arrayState;
    getStates(pos,state,braceState,parenState,arrayState);
    // don't show completer if we are in a comment section
    if(state != 0)
    {
        completer->hide();
        return;
    }

    QString prefix = getPrefixUnderCursor();
    //    if(prefix.isEmpty() || (prefix.length() < 3))
    //        completer->hide();
    //    else
    showAutoCompleteForPrefix(prefix);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::showAutoCompleteForPrefix(const QString &wordUnderCursor)
{
    // get completion list from indexer
    int line = textCursor().blockNumber();
    QList<Tag*> list = autoCompleteIndexer->getCompletions(wordUnderCursor,pathname,line);
    if(list.isEmpty())
    {
        completer->hide();
        return;
    }
    // show completer
    QPoint pos = cursorRect().bottomRight();
    pos = mapToGlobal(pos) + QPoint(getMarginWidgetWidth(),0);
    completer->showPopup(list,pos);
}

//!----------------------------------------------------------------------------
//! \brief  Inserts the currently selected completion into the document.
//!         Removes the existing fragment before inserting the completed
//!         word to end up with the complete and correct capitalization.
//!----------------------------------------------------------------------------
void SourceEditor::insertCompletion(const QString &completion)
{
    QString text(completion);
    int i = text.indexOf('(');
    if(i != -1)
        text = text.left(i).trimmed();

    //    QString prefix = getPrefixUnderCursor();
    QTextCursor cursor = textCursor();
    cursor.select(QTextCursor::WordUnderCursor);
    QString prefix = cursor.selectedText();

    cursor = textCursor();
    //    QTextCursor cursor = textCursor();
    cursor.movePosition(QTextCursor::Left,QTextCursor::KeepAnchor,prefix.length());
    cursor.removeSelectedText();
    cursor.insertText(text);
    setTextCursor(cursor);
}

//!----------------------------------------------------------------------------
//! \brief  The Completer class forwards us keypress events after it processes
//!         them when it's visible. We want to ignore certain keys when the
//!         completer is visible and act on others.
//!----------------------------------------------------------------------------
void SourceEditor::completerKeyEvent(QKeyEvent event)
{
    switch (event.key())
    {
    // ignore these keys when the completer is visible
    case Qt::Key_Enter:
    case Qt::Key_Return:
    case Qt::Key_Up:
    case Qt::Key_Down:
        break;
    case Qt::Key_Left:
    case Qt::Key_Right:
        completer->hide();
    default:
        // process key with editor which will trigger autocomplete update.
        QPlainTextEdit::keyPressEvent(&event);
        break;
    }
}

//!----------------------------------------------------------------------------
//! \brief  Jump to the declaration of the statement under the cursor. If we are
//!         on the declaration and this is a prototype jump to the function
//!         implementation and vice versa.
//!----------------------------------------------------------------------------
void SourceEditor::jumpToCode()
{
    completer->hide();
    int line = textCursor().blockNumber()+1;
    QString text = getStatementUnderCursor();
    if(text.isEmpty())
    {
        // if the cursor isn't on any text try getting the first text on the line.
        text = textCursor().block().text().trimmed();
        if(text.indexOf('(') != -1)
            text = text.left(text.indexOf('('));
        if(text.isEmpty())
            return;
    }

    // get include pathnames from autoCompleteIndexer indexer
    QStringList pathnames = autoCompleteIndexer->getIndexedPaths();
    // get tags that match, if there's no matching tags see if there are any tags on this line.
    QList<Tag*> tags = autoCompleteIndexer->getTagsForStatement(text,pathname,pathnames,line);
    QList<Tag*> itags = autoCompleteIndexer->getTagsOnLine(line);
    // only keep itags that are in this file
    for(int i=0;i<itags.size();)
    {
        Tag *tag = itags.at(i);
        if(tag->pathname != pathname)
            itags.removeAt(i);
        else
            i++;
    }
    if(tags.size() == 0)
        tags = itags;
    if(tags.size() == 0) return;

    Tag *tag = tags.first();
    if(tags.size() > 1)
    {
        // more than one tag with the same name. see if we are on the same line of the same path
        // for one of the tags, if so select it.
        foreach(Tag *t,tags)
        {
            if((t->pathname == pathname) && (t->line == line))
                tag = t;
        }
    }

    QString tagPathname = tag->pathname;
    int tagLine = tag->line;

    // if this is a function/prototype switch between implementaton and declaration
    if((tag->tagType == Tag::Prototype) || (tag->tagType == Tag::Function))
    {
        if((pathname == tagPathname) && (tagLine == line))
        {
            // use the project indexer to locate the implementation/declaration
            if(project != NULL)
            {
                Indexer *prjIndexer = project->getIndexer();
                if(prjIndexer != NULL)
                {
                    QList<Tag*> ftags;
                    if(tag->containerName.isEmpty())
                        ftags = prjIndexer->getFunctionList();
                    else
                        ftags = prjIndexer->getMemberFunctionList();
                    foreach(Tag *t,ftags)
                    {
                        if(t->name != tag->name) continue;
                        // if we are currently on a prototype
                        if((tag->tagType == Tag::Prototype) && (t->protoPathname == tag->pathname) && (t->protoline == tag->line))
                        {
                            tagPathname = t->pathname;
                            tagLine = t->line;
                            break;
                        }
                        // if we are currently on a function
                        else if((tag->tagType == Tag::Function) && (t->pathname == tag->pathname) && (t->line == tag->line))
                        {
                            tagPathname = t->protoPathname;
                            tagLine = t->protoline;
                            break;
                        }
                    }
                }
            }
        }
    }

    // ask tab manager to open the file at this line
    emit requestFileOpen(tagPathname,tagLine,0);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void SourceEditor::slotCursorPositionChanged()
{
    static int lastLine = 0;

    int line = textCursor().blockNumber()+1;

    // don't log if we are on the same line
    if(line == lastLine)
        return;
    lastLine = line;
}
