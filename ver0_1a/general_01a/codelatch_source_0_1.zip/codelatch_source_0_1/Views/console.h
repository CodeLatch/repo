#ifndef CONSOLEVIEW_H
#define CONSOLEVIEW_H

#include <QListWidget>
#include <QTextEdit>
#include <QWidget>
#include <QTextBrowser>

//class Console : public QTextBrowser
class Console : public QWidget
{
    Q_OBJECT
public:
    explicit Console(QWidget *parent = 0);
    ~Console();

    void clear();
    void appendText(const QString &text, QString color = QString("black"));
    void appendLine(const QString &text, QString color = QString("black"));
    void appendLink(const QStringList &list);


signals:
//    void browserAnchorClicked(QUrl url);
    void signalAppendConsoleText(const QString str, const bool linefeed, const QString color);
    void signalAppendConsoleLink(const QStringList list);
    void signalClear();
    void showConsole();
    void signalOpenEditor(QString pathname,int linenumber);

public slots:
    void btnClearPressed();
    void btnMinimizePressed();
    void btnMaximizePressed();

    void slotAppendConsoleText(const QString text, const bool linefeed, const QString color);
    void slotAppendConsoleLink(const QStringList list);
    void slotClear();

    void linkClicked(QUrl url);

private:
    void privateAppendText(const QString &text, bool linefeed, QString color);
    void privateAppendLink(const QStringList &list);

    QTextBrowser *browser;    
};

// global declaration in console.cpp, want this to be global
// so anyone can write to the console from anywhere.
extern Console *console;

#endif // CONSOLEVIEW_H
