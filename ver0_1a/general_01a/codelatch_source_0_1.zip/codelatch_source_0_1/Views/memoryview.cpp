//!----------------------------------------------------------------------------
//! file: memoryview.cpp
//!
//! Implements memory view.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "memoryview.h"
#include "ui_memoryview.h"
#include <QDebug>
#include <QFont>
#include <QFontMetrics>
#include <QInputDialog>
#include "utility/hexinput.h"

MemoryView::MemoryView(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MemoryView)
{
    ui->setupUi(this);

    //    ui->listWidget  this is the variable or address input list
    //    ui->tableWidget this is the actual memory printout
    // user enters a variable (&index) or memory location

    // memory table
    // col 0 = address, col1 = hex contents, col2 = ascii
    ui->memTable->setColumnCount(3);
    ui->memTable->setRowCount(32);
    ui->memTable->verticalHeader()->hide();
    QStringList sl;
    sl << "Address" << "Value" << "Ascii";
    ui->memTable->setHorizontalHeaderLabels(sl);
    ui->memTable->setAlternatingRowColors(true);
    QFont memFont = ui->memTable->font();
    QFontMetrics memMetric(memFont);
    int memWidth = memMetric.width("00000000");
    cellHeight = memMetric.height();
    for (int i = 0; i < ui->memTable->rowCount(); i++)
        ui->memTable->verticalHeader()->resizeSection(i, cellHeight);
    for (int i = 0; i < ui->memTable->columnCount(); i++)
        ui->memTable->setColumnWidth(i,memWidth);

    // variables table
    ui->itemTable->setColumnCount(1);
    ui->itemTable->setRowCount(0);
    ui->itemTable->verticalHeader()->hide();
    QStringList itList;
    itList << "Item";
    ui->itemTable->setHorizontalHeaderLabels(itList);
    ui->itemTable->setShowGrid(false);
}

MemoryView::~MemoryView()
{
    for(int i=0;i<itemList.size();i++)
        delete itemList.at(i);
    itemList.clear();

    ui->itemTable->clear();
    ui->memTable->clear();

    delete ui;
}

void MemoryView::setProject(Project *project)
{
    prj = project;
}

// add item
void MemoryView::on_toolButton_clicked()
{
    QInputDialog *dlg = new QInputDialog;
    dlg->setWindowTitle("Enter memory address");
    dlg->setLabelText("Address:");
    int ret = dlg->exec();
    QString text = dlg->textValue();
    dlg->deleteLater();
    if(ret == QInputDialog::Rejected) return;

    text = text.trimmed();

    bool ok;
    S_MemoryViewItem *item = new S_MemoryViewItem;
    uint32_t address = 0;

    item->isVariable = false;
    address = text.toUInt(&ok,16);
    if(!ok)
    {
        //QString varname = text.right(text.length()-1);
        item->isVariable = true;
        if(debug != NULL)
        {
            address = debug->getVariableAddress(text,&ok);
            // if !ok show a dialog box
        }
    }
    item->address = address;
    item->name = text;
    itemList.append(item);

    QTableWidgetItem *widget = new QTableWidgetItem;

    int row = ui->itemTable->rowCount();
    //int col = ui->itemTable->columnCount();
    ui->itemTable->blockSignals(true);
    ui->itemTable->insertRow(row);
    ui->itemTable->setItem(row, 0, widget);
    widget->setText(text);
    ui->itemTable->setCurrentCell(row,0);
    ui->itemTable->blockSignals(false);
    ui->itemTable->verticalHeader()->resizeSection(row, cellHeight);
    ui->itemTable->resizeColumnsToContents();
    updateView(debug);
}

// remove item
void MemoryView::on_toolButton_2_clicked()
{
    int i = ui->itemTable->currentRow();
    if(i == -1) return;
    ui->itemTable->removeRow(i);
    itemList.removeAt(i);
    ui->memTable->clear();
    i--;
    if(i < 0) i = 0;
    if(ui->itemTable->rowCount() > 0)
        ui->itemTable->selectRow(i);
    ui->itemTable->resizeColumnsToContents();
    updateView(debug);
}

void MemoryView::on_itemTable_itemSelectionChanged()
{
    ui->memTable->clear();
    updateView(debug);
}

void MemoryView::on_memTable_itemDoubleClicked(QTableWidgetItem *item)
{
    (void) item; // unused
}


void MemoryView::on_memTable_cellChanged(int row, int column)
{
    // update memory
    QTableWidgetItem *dataItem = ui->memTable->item(row,column);
    QTableWidgetItem *addressItem = ui->memTable->item(row,0);

    QString dataStr = dataItem->text();
    QString addressStr = addressItem->text();

    bool ok;
    uint32_t address = addressStr.toUInt(&ok,16);
    if(!ok)
    {
        updateView(debug);
        return;
    }
    uint32_t data = dataStr.toUInt(&ok,16);
    if(!ok)
    {
        updateView(debug);
        return;
    }
    debug->writeMemory(address,data);
}


void MemoryView::on_itemTable_cellChanged(int row, int column)
{
    QTableWidgetItem *widgetItem = ui->itemTable->item(row,column);

    QString text = widgetItem->text();
    text = text.trimmed();

    bool ok;
    S_MemoryViewItem *item = itemList.at(row);

    uint32_t address = text.toUInt(&ok,16);
    if(!ok)
    {
        item->isVariable = true;
    }
    else
    {
        item->isVariable = false;
        if(address > 0xffffffff)
        {
            widgetItem->setText(item->name);
            return;
        }
        text = text.sprintf("0x%08x",address);
        widgetItem->setText(text);
        ui->itemTable->setItem(row, 0, widgetItem);
    }
    item->address = address;
    item->name = text;
    itemList.replace(row,item);

    ui->itemTable->resizeColumnsToContents();
    updateView(debug);
}

void MemoryView::updateView(Debug *debug)
{
    this->debug = debug;
    if(debug == NULL) return;

    int i = ui->itemTable->currentRow();
    if((i >= itemList.size()) || (i < 0)) return;

    ui->memTable->blockSignals(true);

    S_MemoryViewItem *item = itemList.at(i);
    int n = ui->memTable->rowCount();
    uint32_t address = item->address;
    item->values = debug->readMemory(address,n);
    ui->memTable->clear();
    if(item->values.size() < ui->memTable->rowCount())
        n = item->values.size();
    QString str;
    for(int i=0;i<n;i++)
    {
        // address
        str = str.sprintf("0x%08x",address);
        address += 4;
        ui->memTable->setItem(i, 0, new QTableWidgetItem(str));
        // value
        ui->memTable->setItem(i, 1, new QTableWidgetItem(item->values.at(i)));
    }
    // resize to fit
    ui->memTable->resizeColumnsToContents();
    ui->memTable->blockSignals(false);
}


