#ifndef DATAVIEW_H
#define DATAVIEW_H

#include <QWidget>
#include <QTableWidget>
#include "gdb/debugcontrol.h"

class MemoryView;
class BreakpointsWidget;
class OutlineView;
class RegistersView;
class VariablesView;
class VariableView;
class AssemblyView;
class ClassView;
class Indexer;
class GdbView;

class DataView : public QTabWidget
{
    Q_OBJECT
public:
    explicit DataView(QWidget *parent = 0);
    ~DataView();

    void updateView(Debug *debug);
    void showDebugViews(bool enable);

    Project *getClassViewProject() {return classViewProject;}

    MemoryView *memoryView;
    BreakpointsWidget *breakpointsView;
    ClassView *classView;
    ClassView *outlineView;
    RegistersView *registersView;
    VariableView *variablesView;
    AssemblyView *assemblyView;
    GdbView *gdbView;

signals:
    void activateFile(QString pathname, int lineNumber);

public slots:
    void updateClassView(Project *project);
    void updateOutlineView(Indexer *indexer, QString pathname);
private slots:
    void showOutlineMenu();

protected:
    Project *prj;
    Project *classViewProject;

    bool debugViewsVisible;

};

#endif // DATAVIEW_H
