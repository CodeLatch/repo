#ifndef REGISTERSVIEW_H
#define REGISTERSVIEW_H

#include <QWidget>
#include <QTableWidget>
#include <QColor>

class Debug;
/*
namespace Ui {
class RegistersView;
}
*/
class RegistersView : public QWidget
{
    Q_OBJECT
    
public:
    explicit RegistersView(QWidget *parent = 0);
    ~RegistersView();
    void updateView(Debug *debug);

private slots:
    void slotTableCellChanged(int row, int column);

private:
    QTableWidget *table;
    bool updatingView;
    QStringList *registerValues;
    QStringList *registerNames;
    Debug *debug;

    void updateRow(int row, quint32 val);

//    QStringList *lastValue;
//    QColor colorLtBlue;
//    QColor colorLtYellow;
//    QColor colorWhite;

//    Ui::RegistersView *ui;
};

#endif // REGISTERSVIEW_H
