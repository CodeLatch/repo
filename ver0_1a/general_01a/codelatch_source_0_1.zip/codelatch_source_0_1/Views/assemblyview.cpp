//!----------------------------------------------------------------------------
//! file: assemblyview.cpp
//!
//! Implements assembly view.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "assemblyview.h"
#include <QTextBrowser>
#include <QGridLayout>

/*

Dump of assembler code for function main:
69	{
   0x080001ec <+0>:	push	{r7, lr}
   0x080001ee <+2>:	sub	sp, #72	; 0x48
   0x080001f0 <+4>:	add	r7, sp, #0

70		u32 adcVal = 0;
   0x080001f2 <+6>:	mov.w	r3, #0
   0x080001f6 <+10>:	str	r3, [r7, #68]	; 0x44

71		char a;
72		unsigned char b;
73		u8 c;
74		double d;
75		myStruct s;
76		Bird mybird;
77		DATATYPE myuni;
78
79		//	const char *str = "Hello = this, string =, has { stuff }";
80
81		a = 'b';
=> 0x080001f8 <+12>:	mov.w	r3, #98	; 0x62
   0x080001fc <+16>:	strb.w	r3, [r7, #67]	; 0x43

82		b = 12;
   0x08000200 <+20>:	mov.w	r3, #12
   0x08000204 <+24>:	strb.w	r3, [r7, #66]	; 0x42

83		c = 15;
   0x08000208 <+28>:	mov.w	r3, #15
   0x0800020c <+32>:	strb.w	r3, [r7, #65]	; 0x41

84		d = 22.32;
   0x08000210 <+36>:	add	r3, pc, #412	; (adr r3, 0x80003b0 <main+452>)
   0x08000212 <+38>:	ldrd	r2, r3, [r3]
   0x08000216 <+42>:	strd	r2, r3, [r7, #56]	; 0x38

85		s.a = 4;
   0x0800021a <+46>:	mov.w	r3, #4
   0x0800021e <+50>:	str	r3, [r7, #40]	; 0x28

86		s.b = 67.4;
   0x08000220 <+52>:	add	r3, pc, #404	; (adr r3, 0x80003b8 <main+460>)
   0x08000222 <+54>:	ldrd	r2, r3, [r3]
   0x08000226 <+58>:	strd	r2, r3, [r7, #48]	; 0x30

87
88		mybird.a = 30;
   0x0800022a <+62>:	mov.w	r3, #30
   0x0800022e <+66>:	str	r3, [r7, #0]

89
90		// setup pins
91		Pin.mode(LED_GREEN, OUTPUT);    // output pin to drive led
   0x08000230 <+68>:	movw	r0, #600	; 0x258
   0x08000234 <+72>:	movt	r0, #8192	; 0x2000
   0x08000238 <+76>:	mov.w	r1, #13
   0x0800023c <+80>:	mov.w	r2, #1
   0x08000240 <+84>:	bl	0x8000600 <_ZN4CPin4modeEmi>

92		Pin.mode(LED_AMBER, OUTPUT);    // output pin to drive led
   0x08000244 <+88>:	movw	r0, #600	; 0x258
   0x08000248 <+92>:	movt	r0, #8192	; 0x2000
   0x0800024c <+96>:	mov.w	r1, #3
   0x08000250 <+100>:	mov.w	r2, #1
   0x08000254 <+104>:	bl	0x8000600 <_ZN4CPin4modeEmi>

93		Pin.mode(INT_IN, INPUT | PULLUP);    // input pin with a pull-up
   0x08000258 <+108>:	movw	r0, #600	; 0x258
   0x0800025c <+112>:	movt	r0, #8192	; 0x2000
   0x08000260 <+116>:	mov.w	r1, #0
   0x08000264 <+120>:	mov.w	r2, #6
   0x08000268 <+124>:	bl	0x8000600 <_ZN4CPin4modeEmi>

94
95		Pin.clr(LED_GREEN);
   0x0800026c <+128>:	movw	r0, #600	; 0x258
   0x08000270 <+132>:	movt	r0, #8192	; 0x2000
   0x08000274 <+136>:	mov.w	r1, #13
   0x08000278 <+140>:	bl	0x8000580 <_ZN4CPin3clrEi>

96
97		// set rx callback function and start hid
98		Terminal.setRxCallback(hidRxCallback);
   0x0800027c <+144>:	movw	r0, #608	; 0x260
   0x08000280 <+148>:	movt	r0, #8192	; 0x2000
   0x08000284 <+152>:	movw	r1, #341	; 0x155
   0x08000288 <+156>:	movt	r1, #2048	; 0x800
   0x0800028c <+160>:	bl	0x8001834 <_ZN9CTerminal13setRxCallbackEPFvvE>

99		Terminal.setTxTimeout(10);
   0x08000290 <+164>:	movw	r0, #608	; 0x260
   0x08000294 <+168>:	movt	r0, #8192	; 0x2000
   0x08000298 <+172>:	mov.w	r1, #10
   0x0800029c <+176>:	bl	0x80017d2 <_ZN9CTerminal12setTxTimeoutEh>

100		Terminal.start();
   0x080002a0 <+180>:	movw	r0, #608	; 0x260
   0x080002a4 <+184>:	movt	r0, #8192	; 0x2000
   0x080002a8 <+188>:	bl	0x800179c <_ZN9CTerminal5startEv>

101		//	Terminal.println(str);
102
103		Pin.mode(19, ADC);
   0x080002ac <+192>:	movw	r0, #600	; 0x258
   0x080002b0 <+196>:	movt	r0, #8192	; 0x2000
   0x080002b4 <+200>:	mov.w	r1, #19
   0x080002b8 <+204>:	mov.w	r2, #128	; 0x80
   0x080002bc <+208>:	bl	0x8000600 <_ZN4CPin4modeEmi>

104		ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_55Cycles5);
   0x080002c0 <+212>:	mov.w	r0, #9216	; 0x2400
   0x080002c4 <+216>:	movt	r0, #16385	; 0x4001
   0x080002c8 <+220>:	mov.w	r1, #14
   0x080002cc <+224>:	mov.w	r2, #1
   0x080002d0 <+228>:	mov.w	r3, #5
   0x080002d4 <+232>:	bl	0x8000c1e <ADC_RegularChannelConfig>

105
106		delay(500);    // give usb time to enumerate
   0x080002d8 <+236>:	mov.w	r0, #500	; 0x1f4
   0x080002dc <+240>:	bl	0x8001860 <_Z5delaym>

107
108		while (true)
   0x080003a8 <+444>:	b.n	0x80002e0 <main+244>
   0x080003aa <+446>:	nop
   0x080003ac <+448>:	nop.w
   0x080003b0 <+452>:	ldrhi	r11, [lr, #-2130]	; 0x852
   0x080003b4 <+456>:	eorsmi	r5, r6, r11, ror #3
   0x080003b8 <+460>:	ldmibls	r9, {r1, r3, r4, r7, r8, r11, r12, pc}
   0x080003bc <+464>:			; <UNDEFINED> instruction: 0x4050d999

109		{
110
111			Pin.toggle(LED_AMBER);
   0x080002e0 <+244>:	movw	r0, #600	; 0x258
   0x080002e4 <+248>:	movt	r0, #8192	; 0x2000
   0x080002e8 <+252>:	mov.w	r1, #3
   0x080002ec <+256>:	bl	0x80005a4 <_ZN4CPin6toggleEi>

112
113			ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_55Cycles5);
   0x080002f0 <+260>:	mov.w	r0, #9216	; 0x2400
   0x080002f4 <+264>:	movt	r0, #16385	; 0x4001
   0x080002f8 <+268>:	mov.w	r1, #14
   0x080002fc <+272>:	mov.w	r2, #1
   0x08000300 <+276>:	mov.w	r3, #5
   0x08000304 <+280>:	bl	0x8000c1e <ADC_RegularChannelConfig>

114			ADC_SoftwareStartConvCmd(ADC1, ENABLE);
   0x08000308 <+284>:	mov.w	r0, #9216	; 0x2400
   0x0800030c <+288>:	movt	r0, #16385	; 0x4001
   0x08000310 <+292>:	mov.w	r1, #1
   0x08000314 <+296>:	bl	0x8000bde <ADC_SoftwareStartConvCmd>

115			while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
   0x08000318 <+300>:	nop
   0x0800031a <+302>:	mov.w	r0, #9216	; 0x2400
   0x0800031e <+306>:	movt	r0, #16385	; 0x4001
   0x08000322 <+310>:	mov.w	r1, #2
   0x08000326 <+314>:	bl	0x8000e18 <ADC_GetFlagStatus>
   0x0800032a <+318>:	mov	r3, r0
   0x0800032c <+320>:	cmp	r3, #0
   0x0800032e <+322>:	ite	ne
   0x08000330 <+324>:	movne	r3, #0
   0x08000332 <+326>:	moveq	r3, #1
   0x08000334 <+328>:	uxtb	r3, r3
   0x08000336 <+330>:	cmp	r3, #0
   0x08000338 <+332>:	bne.n	0x800031a <main+302>

116			adcVal = ADC_GetConversionValue(ADC1);
   0x0800033a <+334>:	mov.w	r0, #9216	; 0x2400
   0x0800033e <+338>:	movt	r0, #16385	; 0x4001
   0x08000342 <+342>:	bl	0x8000cc0 <ADC_GetConversionValue>
   0x08000346 <+346>:	mov	r3, r0
   0x08000348 <+348>:	str	r3, [r7, #68]	; 0x44

117
118			Terminal.print("Timer: ");
   0x0800034a <+350>:	movw	r0, #608	; 0x260
   0x0800034e <+354>:	movt	r0, #8192	; 0x2000
   0x08000352 <+358>:	movw	r1, #13788	; 0x35dc
   0x08000356 <+362>:	movt	r1, #2048	; 0x800
   0x0800035a <+366>:	bl	0x80009c8 <_ZN6CPrint5printEPKc>

119			Terminal.print(systicks);
   0x0800035e <+370>:	movw	r3, #604	; 0x25c
   0x08000362 <+374>:	movt	r3, #8192	; 0x2000
   0x08000366 <+378>:	ldr	r3, [r3, #0]
   0x08000368 <+380>:	movw	r0, #608	; 0x260
   0x0800036c <+384>:	movt	r0, #8192	; 0x2000
   0x08000370 <+388>:	mov	r1, r3
   0x08000372 <+390>:	mov.w	r2, #10
   0x08000376 <+394>:	bl	0x80009ee <_ZN6CPrint5printEmh>

120			Terminal.print(" ADC: ");
   0x0800037a <+398>:	movw	r0, #608	; 0x260
   0x0800037e <+402>:	movt	r0, #8192	; 0x2000
   0x08000382 <+406>:	movw	r1, #13796	; 0x35e4
   0x08000386 <+410>:	movt	r1, #2048	; 0x800
   0x0800038a <+414>:	bl	0x80009c8 <_ZN6CPrint5printEPKc>

121			Terminal.println(adcVal);
   0x0800038e <+418>:	movw	r0, #608	; 0x260
   0x08000392 <+422>:	movt	r0, #8192	; 0x2000
   0x08000396 <+426>:	ldr	r1, [r7, #68]	; 0x44
   0x08000398 <+428>:	mov.w	r2, #10
   0x0800039c <+432>:	bl	0x8000a66 <_ZN6CPrint7printlnEmh>

122			delay(500);
   0x080003a0 <+436>:	mov.w	r0, #500	; 0x1f4
   0x080003a4 <+440>:	bl	0x8001860 <_Z5delaym>

End of assembler dump.
(gdb)

*/

AssemblyView::AssemblyView(QWidget *parent)
{
    (void) parent; // unused

    editor = new SourceEditor(this);
    firstVisibleLine = 0;
    numLines = 0;
//    browser->setWordWrapMode(QTextOption::NoWrap);
//    QFont font = browser->font();
//    font.setPointSize(11);
//    browser->setFont(font);

    QGridLayout *layout = new QGridLayout(this);
    layout->addWidget(editor);
    layout->setSpacing(0);
    layout->setMargin(0);
    setLayout(layout);
}

AssemblyView::~AssemblyView()
{

}

void AssemblyView::updateView(Debug *debug)
{
    QStringList list = debug->getAssembly();
    if(list.isEmpty()) return;
    // remove info lines at top and bottom
    if(list.size() > 3)
    {
        list.takeFirst();
        list.takeLast();
        list.takeLast();
    }
    QString listing;
    int line = -1;
    for(int i=0;i<list.size();i++)
    {
        QString str = list.at(i);
        str.remove('\n');
        listing += str + "\n";
        if(str.simplified().startsWith("=>"))
            line = i;
    }
    editor->setDocText(listing);
    editor->setMarginWidth(0,QString::number(editor->lines()*10));

    if(line != -1)
    {
        editor->setCursorPosition(line,0);
        if(numLines != list.size())
        {
            qDebug() << "new number of assembly lines.";
            // number of lines changed
            firstVisibleLine = qMax(0,line-4);
            editor->setFirstVisibleLine(firstVisibleLine);
        }
        else
        {
            qDebug() << "same number of assembly lines.";
            // same number of lines
            if((line-firstVisibleLine) > 20)
            {
                firstVisibleLine = qMax(0,line-4);
                editor->setFirstVisibleLine(firstVisibleLine);
            }
        }
        numLines = list.size();
 //       int numlines = sci->SendScintilla(QsciScintillaBase::SCI_GETLINECOUNT);
 //       if(numlines > firstVisibleLine) firstVisibleLine = 0;
 //       sci->SendScintilla(QsciScintillaBase::SCI_SETFIRSTVISIBLELINE,firstVisibleLine);
 //       int firstline = sci->SendScintilla(QsciScintillaBase::SCI_GETFIRSTVISIBLELINE);
        qDebug() << "Line: " << line << " firstVisibleLine: " << firstVisibleLine;

 //       if((line-firstVisibleLine) > 25)
 //           sci->SendScintilla(QsciScintillaBase::SCI_SETFIRSTVISIBLELINE,firstVisibleLine);
    }
}

