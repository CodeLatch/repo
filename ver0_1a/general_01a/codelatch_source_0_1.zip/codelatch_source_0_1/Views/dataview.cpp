//!----------------------------------------------------------------------------
//! file: dataview.cpp
//!
//! This view displays data views (project/file outlines, debug views such as variables, memory, etc.) in tabs.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "dataview.h"
#include "memoryview.h"
#include "registersview.h"
#include "variableview.h"
#include "assemblyview.h"
#include "classview.h"
#include "gdbview.h"
#include "gdb/debugcontrol.h"
#include <QScrollArea>
#include "indexer/indexer.h"
#include <QFont>

#include <QComboBox>
#include <QToolButton>
#include <QMenu>
#include <completer.h>
#include <QStackedWidget>

DataView::DataView(QWidget *parent) :
    QTabWidget(parent)
{
    setStyleSheet(
                //                "QTabWidget::pane {border-top: 2px solid #C2C7CB;}"
                //                "QTabWidget::tab-bar {background-color: #E1E1E1;}"
                "QTabBar {font-size: 11px;}"
                //                "QTabBar {color: white;}"
                "QTabBar::tab {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #E1E1E1, stop: 0.4 #DDDDDD,stop: 0.5 #D8D8D8, stop: 1.0 #D3D3D3);}"
                "QTabBar::tab {border: 2px solid #C4C4C3;}"
                "QTabBar::tab {border-bottom-color: #C2C7CB;}"
                "QTabBar::tab {border-top-left-radius: 4px;}"
                "QTabBar::tab {border-top-right-radius: 4px;}"
                "QTabBar::tab {min-width: 5px;}"
                "QTabBar::tab {padding: 2px;}"
                "QTabBar::tab {padding-left: 2px;}"
                "QTabBar::tab {padding-right: 10px;}"
                "QTabBar::tab:selected, QTabBar::tab:hover {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #fafafa, stop: 0.4 #f4f4f4, stop: 0.5 #e7e7e7, stop: 1.0 #fafafa);}"
                "QTabBar::tab:selected {border-color: #9B9B9B; border-bottom-color: #ebebeb;}"
                "QTabBar::tab:!selected {margin-top: 1px;}"
                "QTabBar::close-button {subcontrol-position: left;}"
                //                "QTabBar::close-button:hover {visible: false;}"
                "QTabBar::close-button {closable: false;}"
                );

    setDocumentMode(true);
    setTabsClosable(false);
    setMovable(false);
    prj = NULL;
    classViewProject = NULL;
    debugViewsVisible = false;

    // create and populate the tabs...
    // memory managment notes:
    // - setWidget causes scroll(n) to become the parent of form(n),
    //   so each form(n) will be deleted when each scroll(n) is deleted.
    // - scroll(n)'s are created with this class as the parent, so
    //   each scrollarea will be deleted when this class is deleted.

    classView = new ClassView;
    outlineView = new ClassView;

    variablesView = new VariableView;
    connect(variablesView,SIGNAL(activateFile(QString,int)),this,SIGNAL(activateFile(QString,int)));

    memoryView = new MemoryView;
    registersView = new RegistersView;
    assemblyView = new AssemblyView;
    gdbView = new GdbView;

    QStackedWidget *stackedWidget = new QStackedWidget(this);
    stackedWidget->addWidget(classView);
    stackedWidget->addWidget(outlineView);
    stackedWidget->setCurrentIndex(0);
    addTab(stackedWidget,"Project Outline");

    //    addTab(classView,"Project Outline");
    //   addTab(outlineView,"File");

    QToolButton *widget = new QToolButton(this);
    widget->setIcon(QIcon(":/icons/icons/arrow_down.png"));
    widget->setIconSize(QSize(11,11));
    widget->setStyleSheet("QToolButton {border: 0px;}");
    tabBar()->setTabButton(0,QTabBar::LeftSide,widget);
    connect(widget,SIGNAL(clicked()),this,SLOT(showOutlineMenu()));

    showDebugViews(false);
}

DataView::~DataView()
{
    int i;

    i = indexOf(outlineView);
    if(i != -1)  removeTab(i);

    i = indexOf(classView);
    if(i != -1)  removeTab(i);

    i = indexOf(registersView);
    if(i != -1)  removeTab(i);

    i = indexOf(variablesView);
    if(i != -1)  removeTab(i);

    i = indexOf(memoryView);
    if(i != -1)  removeTab(i);

    i = indexOf(assemblyView);
    if(i != -1)  removeTab(i);

    i = indexOf(gdbView);
    if(i != -1)  removeTab(i);

    outlineView->deleteLater();
    classView->deleteLater();

    variablesView->deleteLater();
    registersView->deleteLater();
    assemblyView->deleteLater();
    gdbView->deleteLater();
}

void DataView::showOutlineMenu()
{
    QMenu myMenu;
    QPoint globalPos = QCursor::pos();
    myMenu.addAction("Project Outline");
    myMenu.addAction("File Outline");

    QAction* selectedItem = myMenu.exec(globalPos);
    if (selectedItem)
    {
        QStackedWidget *stackedWidget = static_cast<QStackedWidget*>(widget(0));
        if(stackedWidget == NULL) return;
        if(selectedItem->text() == "Project Outline")
        {
            setTabText(0,"Project Outline");
            stackedWidget->setCurrentIndex(0);
        }
        else
        {
            setTabText(0,"File Outline");
            stackedWidget->setCurrentIndex(1);
        }
    }
}

void DataView::updateClassView(Project *project)
{
    if(project == NULL) return;
    if(classView == NULL) return;
    Indexer *indexer = NULL;
    classViewProject = project;
    if(project != NULL)
        indexer = project->getIndexer();
    classView->updateClassView(indexer);
}

void DataView::updateOutlineView(Indexer *indexer, QString pathname)
{
    if(outlineView == NULL) return;
    if(indexer == NULL) return;
    outlineView->updateOutlineView(indexer,pathname);
}

void DataView::showDebugViews(bool enable)
{
    int i;

    debugViewsVisible = enable;
    // prevent flicker
    setUpdatesEnabled(false);
    // add or remove based on mode
    if(enable)
    {
        i = indexOf(registersView);
        if(i == -1)  addTab(registersView,"Regs");

        i = indexOf(variablesView);
        if(i == -1)  addTab(variablesView,"Vars");

        i = indexOf(memoryView);
        if(i == -1)  addTab(memoryView,"Mem");

        i = indexOf(assemblyView);
        if(i == -1)  addTab(assemblyView,"Assy");

        i = indexOf(gdbView);
        if(i == -1)  addTab(gdbView,"Gdb");
    }
    else
    {
        i = indexOf(registersView);
        if(i != -1)  removeTab(i);

        i = indexOf(variablesView);
        if(i != -1)  removeTab(i);

        i = indexOf(memoryView);
        if(i != -1)  removeTab(i);

        i = indexOf(assemblyView);
        if(i != -1)  removeTab(i);

        i = indexOf(gdbView);
        if(i != -1)  removeTab(i);
    }
    setUpdatesEnabled(true);
}

void DataView::updateView(Debug *debug)
{
    QWidget *widget = currentWidget();

    setEnabled(false);
    if(debugViewsVisible && widget->inherits("RegistersView"))
    {
        RegistersView *view = (RegistersView*)widget;
        view->updateView(debug);
    }
    else if(debugViewsVisible && widget->inherits("VariableView"))
    {
        VariableView *view = (VariableView*)widget;
        view->updateView(debug);
    }
    else if(debugViewsVisible && widget->inherits("MemoryView"))
    {
        MemoryView *view = (MemoryView*)widget;
        view->updateView(debug);
    }
    else if(debugViewsVisible && widget->inherits("AssemblyView"))
    {
        AssemblyView *view = (AssemblyView*)widget;
        view->updateView(debug);
    }
    else if(debugViewsVisible && widget->inherits("GdbView"))
    {
        GdbView *view = (GdbView*)widget;
        view->updateView(debug);
    }
    setEnabled(true);
}
