//!----------------------------------------------------------------------------
//! file: findandreplacewidget.cpp
//!
//! Implements text find and replace widget.
//!
//! Utilizes MainWindow to gain access to NavTree and TabManager.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "findreplacewidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QLabel>
#include "mainwindow/mainwindow.h"
#include "navtree.h"
#include <QTreeWidget>
#include <sourceeditor.h>
#include <QTextCursor>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QHeaderView>
#include "utility/fileutility.h"
#include <QMessageBox>
#include "tabmanager.h"

#define STR_CURRENT_FILE        "Current File"
#define STR_CURRENT_PROJECT     "Current Project"
#define STR_OPEN_PROJECTS       "Open Projects"
#define STR_ALL_PROJECTS        "All Projects"

//!----------------------------------------------------------------------------
//! \brief  Constructor
//!----------------------------------------------------------------------------
FindReplaceWidget::FindReplaceWidget(QWidget *parent) :
    QWidget(parent)
{
    // MainWindow needs to be passed as this classes parent so
    // we can get access to the NavTree and TabManager.
    mainWindow = reinterpret_cast<MainWindow*>(parent);

    // create contents
    QLabel *scopeLabel = new QLabel("Scope:");
    QLabel *findLabel = new QLabel("Search For:");
    QLabel *replaceLabel = new QLabel("Replace With:");
    scopeCombo = new QComboBox;
    findEdit = new QComboBox;
    replaceEdit = new QLineEdit;
    caseSensitiveCheck = new QCheckBox("Case sensitive");
    wholeWordsCheck = new QCheckBox("Whole words only");
    findNextButton = new QPushButton(tr("&Find Next"));
    searchButton = new QPushButton(" Search ");
    replaceButton = new QPushButton("Replace/Next");
    replaceAllButton = new QPushButton("Replace All");
    treeWidget = new QTreeWidget;

    // initialize some things
    scopeLabel->setMinimumWidth(90);
    findLabel->setMinimumWidth(90);
    replaceLabel->setMinimumWidth(90);
    scopeCombo->setMinimumWidth(200);
    findEdit->setEditable(true);
    findEdit->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);
    replaceEdit->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);
    caseSensitiveCheck->setChecked(true);

    QStringList scopeItems;
    scopeItems << STR_CURRENT_FILE << STR_CURRENT_PROJECT << STR_OPEN_PROJECTS << STR_ALL_PROJECTS;
    scopeCombo->addItems(scopeItems);
    scopeCombo->setCurrentText(STR_CURRENT_FILE);

    findNextButton->setEnabled(false);
    replaceButton->setEnabled(false);
    replaceAllButton->setEnabled(false);
    searchButton->setEnabled(false);
    searchButton->hide();

    treeWidget->header()->hide();
    treeWidget->hide();

    QHBoxLayout *line1 = new QHBoxLayout;
    line1->addWidget(scopeLabel);
    line1->addWidget(scopeCombo);
    line1->addWidget(caseSensitiveCheck);
    line1->addWidget(wholeWordsCheck);
    line1->setAlignment(Qt::AlignLeft);
    line1->setSpacing(10);

    QHBoxLayout *line2 = new QHBoxLayout;
    line2->addWidget(findLabel);
    line2->addWidget(findEdit);
    line2->addWidget(searchButton);
    line2->addWidget(findNextButton);
    line2->setAlignment(Qt::AlignLeft);
    line2->setSpacing(10);

    QHBoxLayout *line3 = new QHBoxLayout;
    line3->addWidget(replaceLabel);
    line3->addWidget(replaceEdit);
    line3->addWidget(replaceButton);
    line3->addWidget(replaceAllButton);
    line3->setSpacing(10);

    QVBoxLayout *vlayout = new QVBoxLayout;
    vlayout->addLayout(line1);
    vlayout->addLayout(line2);
    vlayout->addLayout(line3);
    vlayout->addWidget(treeWidget);
    vlayout->setAlignment(Qt::AlignTop);
    vlayout->setSpacing(3);
    vlayout->setMargin(0);
    setLayout(vlayout);

    // add connections
    // searchButton is visible for all but STR_CURRENT_FILE operations.
    // otherwise findNextButton is visible.
    connect(findEdit,SIGNAL(editTextChanged(QString)),this,SLOT(findEditChanged(QString)));
    connect(findEdit,SIGNAL(activated(QString)),this,SLOT(findEditReturnPressed()));
    connect(findNextButton,SIGNAL(clicked()),this,SLOT(findNextButtonPressed()));
    connect(searchButton,SIGNAL(clicked()),this,SLOT(searchButtonPressed()));
    connect(replaceButton,SIGNAL(clicked()),this,SLOT(replaceButtonPressed()));
    connect(replaceAllButton,SIGNAL(clicked()),this,SLOT(replaceAllButtonPressed()));
    connect(scopeCombo,SIGNAL(currentTextChanged(QString)),this,SLOT(scopeChanged(QString)));
    connect(treeWidget,SIGNAL(itemActivated(QTreeWidgetItem*,int)),this,SLOT(treeItemActivated(QTreeWidgetItem*,int)));
    connect(treeWidget,SIGNAL(itemDoubleClicked(QTreeWidgetItem*,int)),this,SLOT(treeItemDoubleClicked(QTreeWidgetItem*,int)));
}

//!----------------------------------------------------------------------------
//! \brief  Slot - findEdit (widget that holds search text) was pressed.
//!----------------------------------------------------------------------------
void FindReplaceWidget::findEditReturnPressed(void)
{
    QString scope = scopeCombo->currentText();
    if(scope == STR_CURRENT_FILE)
        findNextButtonPressed();
    else
        searchButtonPressed();
}

//!----------------------------------------------------------------------------
//! \brief  Slot - User changed the text in the "Find Next" box.
//!----------------------------------------------------------------------------
void FindReplaceWidget::findEditChanged(QString text)
{
    bool enabled = true;
    if(text.isEmpty())
        enabled = false;

    // if we are seaching only the current file enable the find next button
    // if there is text in the search box, disable the replace and replace all
    // buttons, these will get enabled after the find next button is pressed.
    // if we are not searching only the current file and the search text was
    // changed then disable the next, replace, and replace all buttons. these
    // will get enabled after the search button is pressed.
    QString scope = scopeCombo->currentText();
    if(scope == STR_CURRENT_FILE)
        findNextButton->setEnabled(enabled);
    else
        findNextButton->setEnabled(false);

    searchButton->setEnabled(enabled);
    replaceButton->setEnabled(false);
    replaceAllButton->setEnabled(false);
    treeWidget->clear();
}

//!----------------------------------------------------------------------------
//! \brief  Slot - User changed the scope combo selection.
//!----------------------------------------------------------------------------
void FindReplaceWidget::scopeChanged(QString scope)
{
    if(scope == STR_CURRENT_FILE)
    {
        searchButton->hide();
        treeWidget->hide();
    }
    else
    {
        if(treeWidget->topLevelItemCount() == 0)
            findNextButton->setEnabled(false);
        else
            findNextButton->setEnabled(true);
        searchButton->show();
        treeWidget->show();
    }
}

//!----------------------------------------------------------------------------
//! \brief  Slot - Find Next button pressed.
//!----------------------------------------------------------------------------
void FindReplaceWidget::findNextButtonPressed(void)
{
    updateHistory();    // store history of search words/phrases
    findNext(true);     // perform search, wrap around

    SourceEditor *editor = getCurrentSourceEditor();
    if(editor == NULL)
    {
        replaceButton->setEnabled(false);
        replaceAllButton->setEnabled(false);
        return;
    }
    QTextCursor cursor = editor->textCursor();
    QString selText = cursor.selectedText();
    QString searchText = findEdit->currentText();
    if(selText == searchText)
    {
        replaceButton->setEnabled(true);
        replaceAllButton->setEnabled(true);
    }
}

//!----------------------------------------------------------------------------
//! \brief  Slot - Search button pressed.
//!----------------------------------------------------------------------------
void FindReplaceWidget::searchButtonPressed(void)
{
    QString str = findEdit->currentText();
    if(str.isEmpty()) return;

    updateHistory();   // store history of search words/phrases
    search();

    QString scope = scopeCombo->currentText();
    QString searchText = findEdit->currentText();

    // if results found enable the next button
    bool enabled = false;
    if(treeWidget->topLevelItemCount() != 0)
        enabled = true;

    findNextButton->setEnabled(true);
    replaceButton->setEnabled(enabled);
    replaceAllButton->setEnabled(enabled);

    if(scope == STR_CURRENT_FILE)
    {
        SourceEditor *editor = getCurrentSourceEditor();
        if(editor == NULL) return;
        QTextCursor cursor = editor->textCursor();
        QString selText = cursor.selectedText();
        if(selText == searchText)
        {
            replaceButton->setEnabled(true);
            replaceAllButton->setEnabled(true);
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief  Slot - Replace / Next button pressed.
//!----------------------------------------------------------------------------
void FindReplaceWidget::replaceButtonPressed(void)
{
    replaceAndFindNext(true);
}

//!----------------------------------------------------------------------------
//! \brief  Slot - Replace All button pressed.
//!----------------------------------------------------------------------------
void FindReplaceWidget::replaceAllButtonPressed(void)
{
    if(findEdit->currentText().isEmpty()) return;
    QString scope = scopeCombo->currentText();
    SourceEditor *editor = getCurrentSourceEditor();
    int cnt = 0;

    // save editor state for restore
    QTextCursor cursor;
    int firstLine = 1;
    if(editor != NULL)
    {
        cursor = editor->textCursor();
        firstLine = editor->getFirstVisibleLine();
    }

    // perform replace all
    if(scope == STR_CURRENT_FILE)
    {
        if(editor == NULL) return;
        QTextCursor newCursor = editor->textCursor();
        newCursor.setPosition(0);
        editor->setTextCursor(newCursor);
        while(replaceAndFindNext(false))
            cnt++;
    }
    else
    {
        if(treeWidget->topLevelItemCount() == 0) return;
        // start at the top
        treeWidget->setCurrentItem(NULL);
        while(replaceAndFindNext(false))
            cnt++;
    }

    // restore editor cursor position
    if(editor != NULL)
    {
        editor->setTextCursor(cursor);
        editor->setFirstVisibleLine(firstLine);
    }

    QString msg = "Replaced " + QString::number(cnt) + " occurrences.";
    QMessageBox::information(this,"Replace All",msg);
}

//!----------------------------------------------------------------------------
//! \brief  Returns a pointer to the active source editor in the main window.
//!----------------------------------------------------------------------------
SourceEditor *FindReplaceWidget::getCurrentSourceEditor()
{
    if(mainWindow == NULL) return NULL;
    TabManager *tabWidget = mainWindow->getTabManager();
    if(tabWidget == NULL) return NULL;
    QWidget *widget = tabWidget->currentWidget();
    SourceEditor *editor = qobject_cast<SourceEditor *>(widget);
    return editor;
}

//!----------------------------------------------------------------------------
//! \brief  Checks to see if a source editor with the specified pathname is
//!         open, if so returns the source editor contents, otherwise
//!         reads the file and returns the contents.
//!
//! \return Text from editor if open, text from file if not, empty string if
//!         neither is found.
//!----------------------------------------------------------------------------
QString FindReplaceWidget::getContents(const QString &pathname)
{
    if(mainWindow == NULL) return QString();

    // check for open editor with matching pathname, if found return text.
    TabManager *tabWidget = mainWindow->getTabManager();
    if(tabWidget != NULL)
    {
        int n = tabWidget->count();
        for(int i=0;i<n;i++)
        {
            QWidget *widget = tabWidget->widget(i);
            if(widget == NULL) continue;
            if(!widget->inherits("SourceEditor")) continue;
            SourceEditor *editor = (SourceEditor*)widget;
            QString path = editor->getPathname();
            if(path != pathname) continue;
            return editor->text();
        }
    }
    // editor not found, try to read file contents
    QFile file(pathname);
    if(!file.exists()) return QString();
    bool ret = file.open(QIODevice::ReadOnly | QIODevice::Text);
    if(!ret) return QString();
    QTextStream stream(&file);
    QString contents = stream.readAll();
    file.close();
    return contents;
}

//!----------------------------------------------------------------------------
//! \brief  Search and update tree based on current search parameters.
//!----------------------------------------------------------------------------
void FindReplaceWidget::search()
{
    if(mainWindow == NULL) return;

    QStringList fileList; // we will populate this with a list of file paths to search
    QString scope = scopeCombo->currentText();

    QTextDocument::FindFlags flags = 0;
    if(caseSensitiveCheck->checkState())
        flags |= QTextDocument::FindCaseSensitively;
    if(wholeWordsCheck->checkState())
        flags |= QTextDocument::FindWholeWords;

    // clear current results from tree
    treeWidget->clear();
    // get nav
    NavTree *nav = mainWindow->getNav();
    if(nav == NULL) return;

    // create list of files to search
    if(scope == STR_CURRENT_PROJECT)
    {
        Project *prj = nav->getSelectedProject();
        if(prj == NULL) return;
        // get a list of source files in the project
        listFiles(prj->getProjectFolder(),fileList);
    }
    else if(scope == STR_OPEN_PROJECTS)
    {
        QStringList prjList;
        nav->getOpenProjectsList(&prjList);
        foreach(QString prjFolder,prjList)
        {
            Project *prj = nav->getProjectFromFolder(prjFolder);
            if(prj == NULL) continue;
            // get a list of source files in the project
            listFiles(prj->getProjectFolder(),fileList);
        }
    }
    else if(scope == STR_ALL_PROJECTS)
    {
        QStringList dirList;
        dirList.append(FileUtility::getDirExamples());
        dirList.append(FileUtility::getDirProjects());
        dirList.append(FileUtility::getDirLibrary());
        foreach(QString dirName,dirList)
            listFiles(dirName,fileList);
    }
    else return;

    // search files in filelist and populate the results tree with matches.
    fileList.removeDuplicates();
    foreach(QString pathname,fileList)
    {
        QList<S_FindItemInfo> list;
        findOccurences(pathname,list);
        int n = list.size();
        if(n == 0) continue;
        // update tree
        QTreeWidgetItem *item;
        item = new QTreeWidgetItem;
        item->setText(0,FileUtility::replacePathWithKey(NULL,pathname) + " ("+QString::number(n)+")");
        treeWidget->addTopLevelItem(item);
        if(item == NULL) continue;
        foreach(S_FindItemInfo info,list)
        {
            QTreeWidgetItem *child = new QTreeWidgetItem;
            QString entry = QString::number(info.linenumber) + "\t" + QString::number(info.col) + "\t" + info.linetext;
            child->setText(0,entry);
            item->addChild(child);
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief  Append to the string list provided a list of source pathnames in the
//!         specified folder.
//!
//! \param  folder - reference to folder to search.
//! \param  pathList - list to append results to.
//!----------------------------------------------------------------------------
void FindReplaceWidget::listFiles(const QString &folder, QStringList &pathList)
{
    QDir dir(folder);
    QStringList pathnameList = dir.entryList(QDir::AllEntries);
    foreach(QString pathname,pathnameList)
    {
        pathname = folder + "/" + pathname;
        QFileInfo info(pathname);
        if((info.fileName()==".") || (info.fileName()=="..")) continue;
        if(info.isDir())
            listFiles(pathname,pathList);
        else
        {
            if(pathname.endsWith(".cpp") || pathname.endsWith(".hpp") ||
                    pathname.endsWith(".c") || pathname.endsWith(".h") ||
                    pathname.endsWith(".S"))
            {
                pathList.append(pathname);
            }
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief  Find the next match based on current search parameters. If we
//!         are searching multiple files then traverse through the treeWidget
//!         to select the next match.
//!
//! \param  wrapToTop - true: wrap search to top of file when bottom is reached.
//!
//! \return True if find succeeded and selected text matches
//!         findEdit text, false otherwise.
//!----------------------------------------------------------------------------
bool FindReplaceWidget::findNext(bool wrapToTop)
{
    QString scope = scopeCombo->currentText();
    QString findText = findEdit->currentText();

    QTextDocument::FindFlags flags = 0;
    if(caseSensitiveCheck->checkState())
        flags |= QTextDocument::FindCaseSensitively;
    if(wholeWordsCheck->checkState())
        flags |= QTextDocument::FindWholeWords;

    if(scope == STR_CURRENT_FILE)
    {
        // get current editor
        SourceEditor *editor = getCurrentSourceEditor();
        if(editor == NULL) return false;
        bool ret = editor->find(findText,flags);
        // if not found, move to the topmost found if specified
        if((ret == false) && wrapToTop)
        {
            ret = true;
            while(ret != false)
                ret = editor->find(findText,flags|QTextDocument::FindBackward);
        }
        else
            return ret;
    }
    else
    {
        // find the next item in the results tree
        // if nothing is selected in the tree then select the first item
        // else select the next item in the tree, wrap to top if required
        if(treeWidget->topLevelItemCount() == 0) return false;
        QTreeWidgetItem *item = treeWidget->currentItem();
        if(item == NULL)
        {
            item = treeWidget->topLevelItem(0);
            if(item->childCount() == 0) return false;
            item = item->child(0);
            if(item == NULL) return false;
        }
        else
        {
            item = treeWidget->itemBelow(item);
            if(item == NULL)
            {
                if(!wrapToTop) return false;
                item = treeWidget->topLevelItem(0);
            }
            if(item->childCount() != 0)
                item = item->child(0);
            if(item == NULL) return false;
        }
        treeWidget->setCurrentItem(item);
        treeItemActivated(item,0);
    }

    // verify that we have selected the findText
    SourceEditor *editor = getCurrentSourceEditor();
    if(editor == NULL)
        return false;
    QTextCursor cursor = editor->textCursor();
    QString selText = cursor.selectedText();
    if(selText == findText)
        return true;
    return false;
}

//!----------------------------------------------------------------------------
//! \brief  Replace the currently selected text if it matches the replacement
//!         text. Then search for the next match, return true if match found,
//!         false otherwise. If a match is found the text will be selected.
//!
//! \param  wrapToTop - If true start searching at the top of the document when
//!                     the bottom is reached.
//!
//! \return True if search found and selected another match, false otherwise.
//!----------------------------------------------------------------------------
bool FindReplaceWidget::replaceAndFindNext(bool wrapToTop)
{
    SourceEditor *editor = getCurrentSourceEditor();
    if(editor != NULL)
    {
        QTextCursor cursor = editor->textCursor();
        QString selText = cursor.selectedText();
        QString findText = findEdit->currentText();
        if(!caseSensitiveCheck->isChecked())
        {
            selText = selText.toLower();
            findText = findText.toLower();
        }
        QString replacementText = replaceEdit->text();
        if(selText == findText)
            cursor.insertText(replacementText);
    }
    return findNext(wrapToTop);
}

//!----------------------------------------------------------------------------
//! \brief  Find occurence of findEdit text in a file. Append occurence item
//!         information to provided list.
//!
//! \param  pathname - pathname to search.
//! \param  list - reference to list to add found items to.
//!----------------------------------------------------------------------------
void FindReplaceWidget::findOccurences(QString &pathname, QList<S_FindItemInfo> &list)
{
    QString contents = getContents(pathname);

    int pos = 0;
    Qt::CaseSensitivity sense = Qt::CaseInsensitive;
    if(caseSensitiveCheck->checkState())
        sense = Qt::CaseSensitive;
    bool wholeWords = wholeWordsCheck->checkState();
    QString key = findEdit->currentText();
    pos = contents.indexOf(key,pos,sense);
    while(pos != -1)
    {
        bool skip = false;
        if(wholeWords)
        {
            int prevCharPos = pos-1;
            int nextCharPos = pos+key.length();
            if(prevCharPos >= 0)
                if(contents.at(prevCharPos).isLetterOrNumber())
                    skip = true;
            if((nextCharPos >= 0) && (nextCharPos < contents.length()))
                if(contents.at(nextCharPos).isLetterOrNumber())
                    skip = true;
        }
        if(!skip)
        {
            S_FindItemInfo item;
            QString substr = contents.left(pos);
            item.linenumber = substr.count('\n') + 1;
            item.pathname = pathname;
            item.pos = pos;
            int startOfLinePos = contents.lastIndexOf('\n',pos) + 1;
            int endOfLinePos = contents.indexOf('\n',pos);
            item.col = pos - startOfLinePos;
            item.linetext = contents.mid(startOfLinePos,endOfLinePos-startOfLinePos);
            list.append(item);
        }
        pos++; // point to next character
        pos = contents.indexOf(key,pos,sense);
    }
}

//!----------------------------------------------------------------------------
//! \brief  Slot - Search result tree item is double clicked.
//!         This is just to change the expanded state of a top level item.
//!         Other action is done by treeItemActivated slot.
//!
//! \param  item - pointer to item that was activated.
//! \param  col - column number of item (not used)
//!----------------------------------------------------------------------------
void FindReplaceWidget::treeItemDoubleClicked(QTreeWidgetItem* item,int col)
{
    Q_UNUSED(col);
    if(item->childCount() != 0)
        item->setExpanded(!item->isExpanded());
}

//!----------------------------------------------------------------------------
//! \brief  Slot - Search result tree item is activated (double
//!         clicked or enter pressed).
//!
//! \param  item - pointer to item that was activated.
//! \param  col - column number of item (not used)
//!----------------------------------------------------------------------------
void FindReplaceWidget::treeItemActivated(QTreeWidgetItem* item,int col)
{
    Q_UNUSED(col);
    if(mainWindow == NULL) return;

    // if this is a top level item just change expanded state.
    if(item->childCount() != 0)
    {
        item->setExpanded(!item->isExpanded());
        return;
    }

    // not a top level item, open in editor and highlight specified line,col text.
    QString text = item->text(0);
    QStringList list = text.split('\t');
    if(list.size() < 3) return;
    bool ok;
    int linenumber = list.at(0).toInt(&ok);
    if(!ok) return;
    int colnumber = list.at(1).toInt(&ok);
    if(!ok) return;
    QTreeWidgetItem *pitem = item->parent();
    if(pitem == NULL) return;
    QString pathname = pitem->text(0);
    if(pathname.isEmpty()) return;
    pathname = pathname.left(pathname.lastIndexOf('(')).trimmed();
    pathname = FileUtility::replaceKeyWithPath(NULL,pathname);

    // activate source editor if found, otherwise open source editor
    if(!mainWindow->getTabManager()->activateTab(pathname))
    {
        QString projectFolder = FileUtility::getProjectFolderFromPathname(pathname);
        NavTree *nav = mainWindow->getNav();
        if(nav == NULL) return;
        Project *prj = nav->getProjectFromFolder(projectFolder);
        if(prj == NULL) return;
        TabManager *tabManager = mainWindow->getTabManager();
        if(tabManager == NULL) return;
        if(!tabManager->openFileUsingSourceEditor(prj,pathname))
            return;
    }
    // active editor should be for our pathname
    SourceEditor *editor = getCurrentSourceEditor();
    if(editor == NULL) return;
    // set line and col number
    editor->setCursorPosition(linenumber-1,colnumber);
    // selected text
    QString seltext = findEdit->currentText();
    QTextCursor cursor = editor->textCursor();
    cursor.movePosition(QTextCursor::Right,QTextCursor::KeepAnchor,seltext.length());
    // verify text matches
    QString cursorText = cursor.selectedText();
    if(seltext.toLower() == cursorText.toLower())
        editor->setTextCursor(cursor);
    treeWidget->setFocus();
}

//!----------------------------------------------------------------------------
//! \brief  Updates the history in the findEdit combo box.
//!----------------------------------------------------------------------------
void FindReplaceWidget::updateHistory()
{
    if(findEdit == NULL) return;
    if(findEdit->currentText().isEmpty()) return;

    findEdit->blockSignals(true);
    QString text = findEdit->currentText();
    int n = findEdit->count();
    QStringList list;
    list.append(text);
    for(int i=0;i<n;i++)
        list.append(findEdit->itemText(i));
    list.removeDuplicates();
    findEdit->clear();
    findEdit->addItems(list);
    findEdit->setCurrentText(text);
    findEdit->blockSignals(false);
}

//!----------------------------------------------------------------------------
//! \brief  Programmatically sets the scope combo box.
//!
//! \param  scope - desired scope:
//!                 CurrentFile, CurrentProject, OpenProjects, AllProjects
//!----------------------------------------------------------------------------
void FindReplaceWidget::setScope(int scope)
{
    QString s;
    if(scope == CurrentFile)
        s = STR_CURRENT_FILE;
    else if(scope == CurrentProject)
        s = STR_CURRENT_PROJECT;
    else if(scope == OpenProjects)
        s = STR_OPEN_PROJECTS;
    else if(scope == AllProjects)
        s = STR_ALL_PROJECTS;
    else return;

    for(int i=0;i<scopeCombo->count();i++)
    {
        if(scopeCombo->itemText(i) == s)
        {
            scopeCombo->setCurrentIndex(i);
            return;
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief  Programmatically sets the text in the findEdit combo box.
//!
//! \param  text - string to put in search box.
//!----------------------------------------------------------------------------
void FindReplaceWidget::setFindText(const QString &text)
{
    if(findEdit == NULL) return;
    updateHistory();
    findEdit->lineEdit()->setText(text);
}

//!----------------------------------------------------------------------------
//! \brief  Programmatically sets focus to the findEdit control.
//!----------------------------------------------------------------------------
void FindReplaceWidget::setFocusToEdit(void)
{
    findEdit->setFocus();
}

