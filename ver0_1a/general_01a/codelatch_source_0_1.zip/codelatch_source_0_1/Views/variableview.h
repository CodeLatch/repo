#ifndef VARIABLEVIEW_H
#define VARIABLEVIEW_H

#include <QWidget>
#include <QTreeWidget>
#include <QListWidget>

class Debug;

class Variable
{
public:
    Variable();
    Variable(Variable &v);
    Variable(const Variable &v);
    ~Variable();

    QString parentName;
    QString name;
    QString fullName;
    QString type;       // named type
    QString rootType;   // rootType is the originating generic type of the variable, will have '*' if it's a pointer.
    QString baseType;   // baseType is the rootType without an '*' if rootType is a pointer
    QString address;    // address of variable.
    QString value;
    int format;
    int entryType;      // class/struct/union container, array container, array entry, general entry

private:
};
Q_DECLARE_METATYPE(Variable)

class VariableView : public QWidget
{
    Q_OBJECT
public:
    explicit VariableView(QWidget *parent = 0);
    
    void updateView(Debug *debug);

    enum VariableViewConstants {
        VarData = Qt::UserRole+1,
        FormatHex = 1,
        FormatDecimal = 2,
        FormatAscii = 3,
        FormatString = 4,
        FormatOctal = 5
    };

signals:
    void activateFile(QString pathname, int lineNumber);

public slots:
    void itemDoubleClicked(QTreeWidgetItem* item,int col);
    void itemCollapsed(QTreeWidgetItem *item);
    void itemExpanded(QTreeWidgetItem *item);
    void contextMenu(QPoint pt);
    void stackItemClicked(QTreeWidgetItem *item,int col);
    void addGlobalVariable();
    void removeGlobalVariable();

private:
    Debug *debug;
    QTreeWidget *tree;
    QTreeWidget *stackWidget;
    QStringList globalVariableList;
    QString stackFrameInfo;

    bool parseLine( QString line, QString parentName = "", QTreeWidgetItem *parent = NULL);

    QString getRootType(QString variableType);
    QString getName(QString line);
    QString getData(QString name, QString type);
    QString getHexData(Variable &var);
    QString getAddress(QString name, QString type);
    QString getNextContainerMember(QString *data);
    void addContainer(QString parentName, QString name, QString *data, QTreeWidgetItem *item);
    void addArray(Variable &container, QString varValue, QTreeWidgetItem *item);
    QTreeWidgetItem* insertRow(Variable &var, QTreeWidgetItem *parent);
    void updateWidths();
    QStringList getExpandedItemsList();
    void addExpandedChildrenToList(QTreeWidgetItem *item, QStringList &list);
    void restoreExpandedItems(QStringList &list);
    void expandChildrenInList(QTreeWidgetItem *item, QStringList &list);
    bool hasStackFrameChanged();
    void updateVariableView(int frameNumber);
    void updateFrameView();
    void parseAndUpdateVariables(QString str);
    QString getGlobals();

    QTreeWidgetItem* findItem(QString fullName);
    QTreeWidgetItem* findItemInChildren(QString &fullName, QTreeWidgetItem *item);
};

#endif // VARIABLEVIEW_H
