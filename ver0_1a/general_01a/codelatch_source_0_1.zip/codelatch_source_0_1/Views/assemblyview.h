#ifndef ASSEMBLYVIEW_H
#define ASSEMBLYVIEW_H

#include <QWidget>
#include <QTextBrowser>
#include <QTextEdit>
#include "gdb/debugcontrol.h"
#include "sourceeditor.h"

/*
namespace Ui {
class AssemblyView;
}
*/

class AssemblyView : public QWidget
{
    Q_OBJECT
    
public:
    explicit AssemblyView(QWidget *parent = 0);
    ~AssemblyView();
    void updateView(Debug *debug);

private:
//    QTextEdit *browser;
    SourceEditor *editor;
    int firstVisibleLine;
    int numLines;
//    Ui::AssemblyView *ui;
};

#endif // ASSEMBLYVIEW_H
