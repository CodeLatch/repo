#ifndef FINDREPLACEWIDGET_H
#define FINDREPLACEWIDGET_H

#include <QWidget>

class QComboBox;
class QLineEdit;
class QCheckBox;
class QPushButton;
class SourceEditor;
class Project;
class QTreeWidget;
class QTreeWidgetItem;
class MainWindow;

struct S_FindItemInfo
{
    QString pathname;
    int pos;
    int col;
    int linenumber;
    QString linetext;
};

enum FindScopeOptions {
    CurrentFile = 0,
    CurrentProject = 1,
    OpenProjects = 2,
    AllProjects = 3
};

class FindReplaceWidget : public QWidget
{
    Q_OBJECT
public:
    explicit FindReplaceWidget(QWidget *parent = 0);
    void setFindText(const QString &text);
    void setFocusToEdit(void);
    void setScope(int scope);

private:
    SourceEditor *getCurrentSourceEditor();
    QString getContents(const QString &pathname);
    bool findNext(bool wrapToTop);
    bool replaceAndFindNext(bool wrapToTop);
    void findOccurences(QString &pathname, QList<S_FindItemInfo> &list);
    void updateHistory();
    void search();
    void listFiles(const QString &folder, QStringList &pathList);

signals:
    
public slots:
    void findNextButtonPressed(void);
    void searchButtonPressed(void);
    void replaceButtonPressed(void);
    void replaceAllButtonPressed(void);
    void findEditChanged(QString);
    void scopeChanged(QString);
    void treeItemActivated(QTreeWidgetItem* item,int col);
    void treeItemDoubleClicked(QTreeWidgetItem* item,int col);
    void findEditReturnPressed(void);

private:
    QComboBox *scopeCombo,*findEdit;
    QLineEdit *replaceEdit;
    QCheckBox *caseSensitiveCheck ,*wholeWordsCheck;
    QPushButton *findNextButton,*searchButton,*replaceButton,*replaceAllButton;
    QTreeWidget *treeWidget;
    MainWindow *mainWindow;
};

#endif // FINDREPLACEWIDGET_H
