#ifndef BREAKPOINTSWIDGET_H
#define BREAKPOINTSWIDGET_H

#include <QWidget>
#include "project/project.h"

class MainWindow;
class QListWidget;
class QListWidgetItem;

class BreakpointsWidget : public QWidget
{
    Q_OBJECT
    
public:
    explicit BreakpointsWidget(QWidget *parent = 0);

signals:
    void breakpointClicked(QString filename, int line);

public slots:
    void setBreakpoints(QList<S_Breakpoint> breakpoints);
    void setBreakpoints(Project *prj);
    void addBreakpont(QString pathname,int line);
    void removeBreakpont(QString pathname,int line);

private slots:
    void itemClicked(QListWidgetItem *item);

private:
    QList<S_Breakpoint> sort(QList<S_Breakpoint> list);

    MainWindow *mainWindow;
    QListWidget *listWidget;
    QList<S_Breakpoint> breakpointList;

};

#endif // BREAKPOINTSWIDGET_H
