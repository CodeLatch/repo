#ifndef MEMORYVIEW_H
#define MEMORYVIEW_H

#include <QWidget>
#include <QTableWidgetItem>
#include "project/project.h"
#include "gdb/debugcontrol.h"
#include <QInputDialog>

namespace Ui {
class MemoryView;
}

class MemoryView : public QWidget
{
    Q_OBJECT
    struct S_MemoryViewItem {
        QString name;
        uint32_t address;
        bool isVariable;
        QStringList values;
    };

public:
    explicit MemoryView(QWidget *parent = 0);
    ~MemoryView();
    
    void setProject(Project *project);
    void updateView(Debug *debug);

private slots:
    void on_toolButton_clicked();
    void on_toolButton_2_clicked();
    void on_itemTable_itemSelectionChanged();
    void on_memTable_itemDoubleClicked(QTableWidgetItem *item);


    void on_memTable_cellChanged(int row, int column);

    void on_itemTable_cellChanged(int row, int column);

private:
    Ui::MemoryView *ui;
    Project *prj;
    QList<S_MemoryViewItem*> itemList;
    QInputDialog *dlg;
    Debug *debug;
    int cellHeight;
};

#endif // MEMORYVIEW_H
