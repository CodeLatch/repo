//!----------------------------------------------------------------------------
//! file: registersview.cpp
//!
//! Implements registers view.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "registersview.h"
//#include "ui_registersview.h"
#include "gdb/debugcontrol.h"
#include <QTableWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGridLayout>
#include <QScrollArea>
#include <QHeaderView>
#include <QLineEdit>
#include <QColor>

RegistersView::RegistersView(QWidget *parent)
{
    (void) parent; // unused

    registerValues = new QStringList;
    registerNames = new QStringList;

    // create a list
    table = new QTableWidget;
    table->setColumnCount(4);
    table->setRowCount(26);
    table->verticalHeader()->hide();
    QStringList sl;
    sl << "Reg" << "Hex" << "Decimal" << "Ascii";
    table->setHorizontalHeaderLabels(sl);
    table->setAlternatingRowColors(true);

    //    QFont font("Courier New",14);
    //    font.setBold(true);
    QFont font = table->font();
    //    table->setFont(font);
    QFontMetrics metrics(font);
    int fontWidthName = metrics.width("RegXX");
    int fontWidthHex = metrics.width("0x00000000XX");
    int fontWidthDec = metrics.width("0000000000XX");
    int fontWidthAscii = metrics.width("AsciiXX");
    int fontHeight = metrics.height();

    for (int i = 0; i < table->rowCount(); i++)
        table->verticalHeader()->resizeSection(i, fontHeight+4);

    // get width of parent

    table->setColumnWidth(0,fontWidthName);
    table->setColumnWidth(1,fontWidthHex);
    table->setColumnWidth(2,fontWidthDec);
    table->setColumnWidth(3,fontWidthAscii);

    // create widgets to hold data
    for(int i=0;i<table->columnCount();i++)
    {
        for (int j = 0; j < table->rowCount(); j++)
        {
            table->setItem(j,i,new QTableWidgetItem());
            table->item(j,i)->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            if((i == 0) || (i==3))
                table->item(j,i)->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
        }
    }

    //    colorLtBlue = QColor(237,243,254);
    //    colorLtYellow = QColor(255,255,210);
    //    colorWhite = QColor(Qt::white);

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(table);
    layout->setSpacing(0);
    layout->setMargin(0);
    setLayout(layout);
    /*
    lastValue = new QStringList;
    for (int j = 0; j < table->rowCount(); j++)
        lastValue->append("");
*/
    connect(table,SIGNAL(cellChanged(int,int)),this,SLOT(slotTableCellChanged(int,int)));
    updatingView = false;
}

RegistersView::~RegistersView()
{
    //   delete ui;
    disconnect(table,SIGNAL(cellChanged(int,int)),this,SLOT(slotTableCellChanged(int,int)));

    for (int i=0;i<table->columnCount(); i++)
    {
        for (int j=0;j<table->rowCount();j++)
        {
            QTableWidgetItem *item = table->takeItem(j,i);
            delete item;
        }
    }

    table->deleteLater();
    registerValues->clear();
    delete registerValues;
    registerNames->clear();
    delete registerNames;
}

void RegistersView::updateView(Debug *debug)
{
    registerValues->clear();
    registerNames->clear();
    this->debug = debug;
    if(debug->getRegisters(registerNames,registerValues))
    {
        if(registerNames->size() != table->rowCount())
            table->setRowCount(registerNames->size());

        updatingView = true;

        for(int i=0;i<registerNames->size();i++)
        {
            table->item(i, 0)->setText(registerNames->at(i));
            QString valstr = registerValues->at(i);
            if(valstr.startsWith("0x"))
            {
                valstr = valstr.right(valstr.length()-2);
                bool ok;
                quint32 val = valstr.toUInt(&ok,16);
                if(ok)
                    updateRow(i,val);
                else
                {
                    table->item(i, 2)->setText("");
                    table->item(i, 3)->setText("");
                }
            }
            else
            {
                table->item(i, 1)->setText(valstr);
                table->item(i, 2)->setText("");
                table->item(i, 3)->setText("");
            }
        }
    }
    updatingView = false;
}

void RegistersView::updateRow(int row, quint32 val)
{
    QString hexStr;
    QString charStr;

    hexStr.sprintf("0x%08X",val);
    table->item(row, 1)->setText(hexStr);
    table->item(row, 2)->setText(QString::number(val,10));

    if(val == 0) charStr = "NULL";
    else if(val == 9) charStr = "TAB";
    else if(val == 10) charStr = "LF";
    else if(val == 13) charStr = "CR";
    else if(val == 27) charStr = "ESC";
    else if((val > 31)&&(val < 127))
        charStr = "'"+QString((char)val)+"'";
    else charStr = "";
    table->item(row, 3)->setText(charStr);
}

void RegistersView::slotTableCellChanged(int row, int column)
{
    QTableWidgetItem *item = table->item(row,column);
    if(item == NULL) return;

    if(!updatingView)
    {
        // cell changed because user entered a value.
        // validate the value and then send it to the target.
        // 0..15, 24..25
        if(((row < 16) || (row > 23)) && ((column == 1) || (column == 2)))
        {
            // validate text
            QString str = item->text();
            bool ok;
            quint32 val;
            if(column == 1) // hex
                val = str.toUInt(&ok,16);
            else // column == 2  decimal
                val = str.toUInt(&ok,10);
            if(ok)
            {
                debug->writeRegister(registerNames->at(row),val);
                QString hexStr;
                hexStr.sprintf("0x%x",val);
                registerValues->replace(row,hexStr);
            }
            else
                val = registerValues->at(row).toUInt(&ok,16);
            if(ok)
                updateRow(row,val);
        }
    }
    //    qDebug() << "cell " << row << " " << column;
    //    qDebug() << "contents:" << item->text();
    // this function was called for one of two reasons...
    // 1) a table value changed due to a call to updateView.
    // 2) the user entered a value.
}

/*                    QString last = lastValue->at(i);
                    if(!last.isEmpty() && (last != hexStr))
                        color = colorLtYellow;
                    else if(i&0x01)
                        color = colorWhite;
                    else
                        color = colorLtBlue;

                    for(int j=0;j<table->columnCount();j++)
                        table->item(i,j)->setBackground(color);

                    lastValue->replace(i,hexStr);
*/
