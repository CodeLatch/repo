#include "zip.h"
#include <QFile>
#include <QFileInfo>
#include <QFileDevice>
#include <QDir>
#include <QFileInfoList>
#include <QDateTime>
#include <QDebug>
#include <utime.h>
#include "deflate.h"
#include "utility/progressdialog.h"


//! implementation notes:
//!
//! 1) don't zip or expand files starting with __MACOSX/
//! 2) don't zip or expand hidden files and/or filename starts with "."
//!
//!

#define FILE_IS_EXECUTABLE    1
#define FILE_IS_FOLDER        2
#define FILE_IS_OTHER         4

static uint32_t crc32_tab[] = {
    0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
    0xe963a535, 0x9e6495a3,	0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
    0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
    0xf3b97148, 0x84be41de,	0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
    0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec,	0x14015c4f, 0x63066cd9,
    0xfa0f3d63, 0x8d080df5,	0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
    0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b,	0x35b5a8fa, 0x42b2986c,
    0xdbbbc9d6, 0xacbcf940,	0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
    0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
    0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
    0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d,	0x76dc4190, 0x01db7106,
    0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
    0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
    0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
    0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
    0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
    0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
    0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
    0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
    0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
    0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
    0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
    0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
    0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
    0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
    0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
    0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
    0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
    0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
    0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
    0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
    0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
    0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
    0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
    0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
    0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
    0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
    0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
    0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
    0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
    0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
    0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
    0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Zip::Zip(QObject *parent) :
    QObject(parent)
{
    zipReadArray = NULL;
    records.endRecord.header.commentLength = 0;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Zip::~Zip()
{
    freeMemory();
}

//!----------------------------------------------------------------------------
//! \brief Create a .zip file from a file or folder.
//!
//! sourceFilePath = absolute file location of file/folder to zip.
//!
//! destFilePath = absolute file pathname to store .zip file in. If this
//!                is left empty the .zip file will be given the name of
//!                the sourceFilePath basename.zip and stored in
//!                sourceFilePath's parent folder.
//!
//! return true if success, false otherwise.
//!----------------------------------------------------------------------------
bool Zip::zip(QString sourceFilePath, bool overwrite, QString destFilePath)
{
    sourceFilePath = sourceFilePath.replace("\\","/");
    sourceFilePath = sourceFilePath.replace("//","/");

    QFileInfo srcInfo(sourceFilePath);
    if(destFilePath.isEmpty())
        destFilePath = srcInfo.absolutePath() + "/" + srcInfo.baseName() + ".zip";
    destFilePath = destFilePath.replace("//","/");
    if(sourceFilePath == destFilePath) return false;

    QFile srcFile(sourceFilePath);
    QFile destFile(destFilePath);
    if(!srcFile.exists()) return false;
    if(destFile.exists() && !overwrite) return false;

    // open output file
    if(!destFile.open(QIODevice::WriteOnly))
        return false;

    // create records
    freeMemory();
    fileCount = 0;
    totalFiles = 1;

    zipCreateLocalFileRecords(sourceFilePath,srcInfo.absolutePath());
    // write file records
    foreach(LocalFileRecord *record,records.fileList)
    {
        record->pos = destFile.pos();
        zipWriteFileRecord(destFile,record);
    }

    zipCreateCentralDirectoryRecords();
    // write directory records
    uint32_t startDirPos = destFile.pos();
    foreach(CentralDirectoryRecord *record,records.directoryList)
        zipWriteCentralDirectoryRecord(destFile,record);
    uint32_t endDirPos = destFile.pos();


    zipCreateEndDirectoryRecord();
    // write end record
    records.endRecord.header.centralDirecotryOffset = startDirPos;
    records.endRecord.header.centralDirectorySize = endDirPos - startDirPos;
    zipWriteEndRecord(destFile);

    destFile.close();
    return true;
}

//!----------------------------------------------------------------------------
//! \brief Helper function that creates the central directory structure
//! from the LocalFileRecord records in records.fileList.
//!----------------------------------------------------------------------------
void Zip::zipCreateCentralDirectoryRecords()
{
    foreach(LocalFileRecord *record,records.fileList)
    {
        CentralDirectoryRecord *dir = new CentralDirectoryRecord;
        dir->header.signature = 0x02014b50;
        dir->header.version = 0x315; // unix zip ver 0x15
        dir->header.minVersion = record->header.version;
        dir->header.flag = record->header.flag;
        dir->header.compressionMethod = record->header.compressionMethod;
        dir->header.lastModifiedTime = record->header.lastModifiedTime;
        dir->header.lastModifiedDate = record->header.lastModifiedDate;
        dir->header.filenameLength = record->header.filenameLength;
        dir->header.extraFieldLength = record->header.extraFieldLength;
        dir->header.fileCommentLength = 0;
        dir->header.diskNumber = 0;
        dir->header.internalFileAttributes = 0;
        dir->header.externalFileAttributes = record->fileAttributes;
        dir->header.relativeOffset = record->pos;

        if(record->header.flag & 0x08)
        {
            dir->header.compressedSize = record->optionalDescriptor.compressedSize;
            dir->header.uncompressedSize = record->optionalDescriptor.uncompressedSize;
            dir->header.crc32 = record->optionalDescriptor.crc32;
        }
        else
        {
            dir->header.compressedSize = record->header.compressedSize;
            dir->header.uncompressedSize = record->header.uncompressedSize;
            dir->header.crc32 = record->header.crc32;
        }
        if(dir->header.extraFieldLength > 0)
            dir->extraField = record->extraField;
        dir->filename = record->filename;
        records.directoryList.append(dir);
    }
}

//!----------------------------------------------------------------------------
//! \brief Helper function that creates the the end directory record.
//!----------------------------------------------------------------------------
void Zip::zipCreateEndDirectoryRecord()
{
    // create end record
//    records.endRecord.header.commentLength = 0;
    records.endRecord.header.centralDirecotryOffset = 0;        // this needs to be set later
    records.endRecord.header.centralDirectorySize = 0;          // this needs to be set later
    records.endRecord.header.diskNumber = 0;
    records.endRecord.header.diskStartNumber = 0;
    records.endRecord.header.numDirRecordsOnDisk = records.directoryList.size();
    records.endRecord.header.signature = 0x6054b50;
    records.endRecord.header.totalDirRecords = records.directoryList.size();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::zipCreateLocalFileRecords(const QString &sourceFilePath, const QString &rootFolder)
{
    QFileInfo info(sourceFilePath);

    // add file/folder to archive
//    if(!sourceFilePath.startsWith(".") && !sourceFilePath.contains("__MACOSX/"))
//        zipAppendFileRecord(sourceFilePath,rootFolder);

    if(info.fileName().startsWith('.')) return;
    if(info.absoluteFilePath().contains("__MACOSX/")) return;
    if(info.isHidden()) return;
    zipAppendFileRecord(sourceFilePath,rootFolder);

    // if this is a folder process it's contents
    if(info.isDir())
    {
        QDir dir(sourceFilePath);
        QFileInfoList infoList = dir.entryInfoList();
        totalFiles += infoList.size(); // for progress update signal
        foreach(QFileInfo pathInfo,infoList)
        {
            // ignore ".","..",hidden files, and __MACOSX files
            if(pathInfo.fileName().startsWith('.')) continue;
            if(pathInfo.absoluteFilePath().contains("__MACOSX/")) continue;
            if(pathInfo.isHidden()) continue;

                // recurse into if it's a directory
                if(pathInfo.isDir())
                    zipCreateLocalFileRecords(pathInfo.absoluteFilePath(),rootFolder);
                else
                    zipAppendFileRecord(pathInfo.absoluteFilePath(),rootFolder);
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief Create a LocalFileRecord record from a disk file specified byte the
//! full pathname sourceFilePath. rootFolder specifies the archives parent folder.
//! Append the newly created record to the records fileList.
//!----------------------------------------------------------------------------
void Zip::zipAppendFileRecord(const QString &sourceFilePath, const QString &rootFolder)
{    
    QString srcFilePath = sourceFilePath;
    srcFilePath = srcFilePath.replace("\\","/");
    srcFilePath = srcFilePath.replace("//","/");
    emit progress(sourceFilePath,++fileCount,totalFiles);

    QFile file(srcFilePath);
    QFileInfo info(srcFilePath);
    QDateTime dateTime = info.lastModified();
    QDate date = dateTime.date();
    QTime time = dateTime.time();

    uint16_t date_u16 = ((date.year()-1980) << 9) | (date.month() << 5) | date.day();
    uint16_t time_u16 = (time.hour() << 11) | (time.minute() << 5) | (time.second()/2);

    // create file record
    LocalFileRecord *record = new LocalFileRecord;
    record->filename = sourceFilePath.right(srcFilePath.size()-(rootFolder.size()+1)).toUtf8();
    if(info.isDir() && !record->filename.endsWith("/"))
        record->filename.append("/");
    record->header.compressedSize = 0;
    record->header.compressionMethod = 0; // no compression
    record->header.crc32 = 0;
    record->header.extraFieldLength = 0;
    record->header.filenameLength = record->filename.size();
    record->header.flag = 0;
    record->header.lastModifiedDate = date_u16;
    record->header.lastModifiedTime = time_u16;
    record->header.signature = 0x04034b50;
    record->header.uncompressedSize = 0;
    record->header.version = 10;

    // use unix flags...see zip.h
    if(info.isDir())
        record->fileAttributes = 0x41ed4000;
    else if(info.isExecutable())
        record->fileAttributes = 0x81ed4000;
    else
        record->fileAttributes = 0x81a44000;

    if(info.isFile() && (info.size() > 0))
    {
        record->header.version = 20;
        record->header.compressionMethod = 8;
        // read data
        file.open(QIODevice::ReadOnly);
        QByteArray uData = file.readAll();
        file.close();
        record->compressedData = qCompress(uData);
        // remove qCompress header and footer
        record->compressedData = record->compressedData.remove(0,6);
        record->compressedData = record->compressedData.remove(record->compressedData.size()-4,4);
        // get crc of uncompressed data
        uint32_t crc = crc32(0,uData.data(),uData.size());

        record->header.uncompressedSize = (uint32_t) uData.size();
        record->header.compressedSize = (uint32_t) record->compressedData.size();
        record->header.crc32 = crc;
    }

    records.fileList.append(record);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
uint32_t Zip::zipWriteFileRecord(QFile &file, LocalFileRecord *record)
{
    // header
    // filename
    // extra field
    // compressed data
    // data descriptor

    if(!file.isOpen()) return 0;

    uint32_t n = 0;

    // write header, have to do it this way because mingw doesn't let us pack bytes reliably.
    // so rocks and clubs write out the structure.

    n+=file.write((char*)&record->header.signature,4);
    n+=file.write((char*)&record->header.version,2);
    n+=file.write((char*)&record->header.flag,2);
    n+=file.write((char*)&record->header.compressionMethod,2);
    n+=file.write((char*)&record->header.lastModifiedTime,2);
    n+=file.write((char*)&record->header.lastModifiedDate,2);
    n+=file.write((char*)&record->header.crc32,4);
    n+=file.write((char*)&record->header.compressedSize,4);
    n+=file.write((char*)&record->header.uncompressedSize,4);
    n+=file.write((char*)&record->header.filenameLength,2);
    n+=file.write((char*)&record->header.extraFieldLength,2);

    n+=file.write((char*)record->filename.data(),record->header.filenameLength);
    if(record->header.extraFieldLength > 0)
        n+=file.write((char*)record->extraField.data(),record->header.extraFieldLength);
    if(record->compressedData.size() > 0)
        n+=file.write((char*)record->compressedData.data(),record->compressedData.size());
    if(record->header.flag & 0x08)
    {
        n+=file.write((char*)&record->optionalDescriptor.signature,4);
        n+=file.write((char*)&record->optionalDescriptor.crc32,4);
        n+=file.write((char*)&record->optionalDescriptor.compressedSize,4);
        n+=file.write((char*)&record->optionalDescriptor.uncompressedSize,4);
    }

    return n;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
uint32_t Zip::zipWriteCentralDirectoryRecord(QFile &file, CentralDirectoryRecord *record)
{
    if(!file.isOpen()) return 0;

    uint32_t n = 0;

    // write header, have to do it this way because mingw doesn't let us pack bytes reliably.
    // so rocks and clubs write out the structure.

    n+=file.write((char*)&record->header.signature,4);
    n+=file.write((char*)&record->header.version,2);
    n+=file.write((char*)&record->header.minVersion,2);
    n+=file.write((char*)&record->header.flag,2);
    n+=file.write((char*)&record->header.compressionMethod,2);
    n+=file.write((char*)&record->header.lastModifiedTime,2);
    n+=file.write((char*)&record->header.lastModifiedDate,2);
    n+=file.write((char*)&record->header.crc32,4);
    n+=file.write((char*)&record->header.compressedSize,4);
    n+=file.write((char*)&record->header.uncompressedSize,4);
    n+=file.write((char*)&record->header.filenameLength,2);
    n+=file.write((char*)&record->header.extraFieldLength,2);
    n+=file.write((char*)&record->header.fileCommentLength,2);
    n+=file.write((char*)&record->header.diskNumber,2);
    n+=file.write((char*)&record->header.internalFileAttributes,2);
    n+=file.write((char*)&record->header.externalFileAttributes,4);
    n+=file.write((char*)&record->header.relativeOffset,4);

    n+=file.write((char*)record->filename.data(),record->header.filenameLength);

    if(record->header.extraFieldLength > 0)
        n+= file.write((char*)record->extraField.data(),record->header.extraFieldLength);

    if(record->header.fileCommentLength > 0)
        n+= file.write((char*)record->fileComment.data(),record->header.fileCommentLength);

    return n;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
uint32_t Zip::zipWriteEndRecord(QFile &file)
{
    if(!file.isOpen()) return 0;

    uint32_t n = 0;

    // write header, have to do it this way because mingw doesn't let us pack bytes reliably.
    // so rocks and clubs write out the structure.

    n+=file.write((char*)&records.endRecord.header.signature,4);
    n+=file.write((char*)&records.endRecord.header.diskNumber,2);
    n+=file.write((char*)&records.endRecord.header.diskStartNumber,2);
    n+=file.write((char*)&records.endRecord.header.numDirRecordsOnDisk,2);
    n+=file.write((char*)&records.endRecord.header.totalDirRecords,2);
    n+=file.write((char*)&records.endRecord.header.centralDirectorySize,4);
    n+=file.write((char*)&records.endRecord.header.centralDirecotryOffset,4);
    n+=file.write((char*)&records.endRecord.header.commentLength,2);

    if(records.endRecord.header.commentLength > 0)
        n+= file.write((char*)records.endRecord.comment.data(),records.endRecord.header.commentLength);

    return n;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Zip::unzip(QString zipFilePath, bool overwrite, QString destFolder)
{
    Deflate deflate;

    // read the zip into memory and parse the records.
    if(!unzipReadZipFile(zipFilePath)) return false;

    QFileInfo srcInfo(zipFilePath);
    // if destFolder is an empty string then expand into the folder where the zipFile resides.
    if(destFolder.isEmpty())
        destFolder = srcInfo.absolutePath();

    bool error = false;
    int16_t cnt = 0;
    uint16_t numFiles = records.endRecord.header.totalDirRecords;
    emit progress("Unzipping "+srcInfo.fileName(),cnt,numFiles);

    foreach(LocalFileRecord *record,records.fileList)
    {
        cnt++;
        emit progress(record->filename,cnt,numFiles);
        // skip files we don't want
        QFileInfo testInfo(record->filename);
        if(testInfo.absoluteFilePath().contains("__MACOSX/")) continue;
        if(testInfo.fileName().startsWith(".")) continue;

        uint32_t uncompressedSize;
        uint32_t compressedSize;
        uint32_t crc;
        if(record->header.flag & 0x08)
        {
            uncompressedSize = record->optionalDescriptor.uncompressedSize;
            compressedSize = record->optionalDescriptor.compressedSize;
            crc = record->optionalDescriptor.crc32;
        }
        else
        {
            uncompressedSize = record->header.uncompressedSize;
            compressedSize = record->header.compressedSize;
            crc = record->header.crc32;
        }

        uint8_t *buf = NULL;
        if(compressedSize != 0)
        {
            buf = new uint8_t[uncompressedSize];
            bool ret = deflate.expandToByteArray(buf,record->compressedData.data(),compressedSize,uncompressedSize);
            if(!ret)
            {
                qDebug() << "Error: zip expand failed";
                error = true;
            }
            if(!error)
            {
                uint32_t testCrc = crc32(0,buf,uncompressedSize);
                if(testCrc != crc)
                {
                    qDebug() << "Error: zip crc mismatch";
                    error = true;
                }
            }
        }

        if(!unzipCreateFile(record,buf,uncompressedSize,destFolder,overwrite))
            error = true;
        if(buf != NULL)
            delete [] buf;

        if(error)
        {
            emit progress("Error.",cnt,numFiles);
            freeMemory();
            return false;
        }
    }

    // if we get here there were no errors, update all the file/folder date and times
    // the folders time stamps will have been changed because we modified their contents during unzipping.
    emit progress("Updating...",cnt,numFiles);
    unzipUpdateFoldersDateTime(destFolder);
    freeMemory();
    return true;
}

//!----------------------------------------------------------------------------
//! \brief This is the function that creates a file when unzipping.
//!----------------------------------------------------------------------------
bool Zip::unzipCreateFile(LocalFileRecord *record, const uint8_t *data, uint32_t numbytes, const QString &destFolder, bool overwrite)
{
    QString destFilePath = destFolder +"/" + record->filename;
    destFilePath = destFilePath.replace("\\","/");
    destFilePath = destFilePath.replace("//","/");
    QFile outputFile(destFilePath);
    QFileInfo info(outputFile);
    QString outputFolder = info.absolutePath();
    QFileInfo dirInfo(outputFolder);
    bool isDir = destFilePath.endsWith('/');

    if(outputFile.exists() && !overwrite)
    {
        // skip this entry if we don't want to overwrite and the file exists.
    }
    else if(!isDir)
    {
        // this is a file
        if(outputFile.exists())
        {
            if(!outputFile.remove())
                return false;
        }
        // create directory if needed
        if(!dirInfo.exists())
        {
            QDir dir;
            dir.mkpath(outputFolder);
        }
        // create file
        if(!outputFile.open(QIODevice::WriteOnly))
            return false;
        if(numbytes != 0)
        {
            // write data
            if(outputFile.write((char*)data,numbytes) == -1)
            {
                outputFile.close();
                return false;
            }
        }
        outputFile.close();
    }
    else
    {
        // this is a directory
        QDir dir;
        if(!dir.mkpath(destFilePath))
            return false;
    }

    // set permissions/attributes
    unzipSetFilePermissions(destFilePath,record);

    // set file date and time
    unzipSetFileDateTime(destFilePath,record);

    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::unzipSetFilePermissions(const QString &filePath, LocalFileRecord *record)
{
    //
    // TTTT
    // ----
    // 0001 named pipe (fifo)
    // 0010 character special
    // 0100 directory
    // 0110 block special
    // 1000 regular
    // 1010 symbolic link
    // 1100 socket
    //
    // sst
    // ---
    // 001 sticky bit - only owner or root user can delete or rename the file
    // 010 set group id on execution
    // 100 set user id on execution
    //
    // rwx rwx rwx - read write execution permissions for owner, group, and other
    //
    // ADVSHR
    // 1       Archive
    //  1      Directory
    //   1     Volume
    //    1    System
    //     1   Hidden
    //      1  Read-only
    //
    // TTTT sstr wxrw xrwx 0000 0000 00AD VSHR
    // ^^^^ ___________________________________ file type as explained above
    //      ^^^________________________________ setuid, setgid, sticky
    //         ^ ^^^^ ^^^^_____________________ permissions
    //                     ^^^^ ^^^^___________
    //                               ^^^^ ^^^^_ DOS attribute bits
    //
    // TTTT sstr wxrw xrwx 0000 0000 00AD VSHR
    // 0100 0001 1110 1101 0100 0000 0000 0000 folder           0x41ed4000
    // 1000 0001 1010 0100 0100 0000 0000 0000 text/data file   0x81a44000
    // 1000 0001 1110 1101 0100 0000 0000 0000 executable file  0x81ed4000

    //         user group world
    // folder  rwx  r-x   r-x
    // exec    rwx  r-x   r-x
    // text    rw-  r--   r--

    uint32_t p = record->fileAttributes;
    bool isDir = (p & 0x40000010L) > 0;
    bool isExe = (p & 0x00490000L) > 0;

    uint16_t permissions = 0;
    uint16_t writePriv = QFileDevice::WriteOwner | QFileDevice::WriteUser;
    uint16_t exePriv   = QFileDevice::ExeOwner   | QFileDevice::ExeUser   | QFileDevice::ExeGroup   | QFileDevice::ExeOther;
    uint16_t readPriv  = QFileDevice::ReadOwner  | QFileDevice::ReadUser  | QFileDevice::ReadGroup  | QFileDevice::ReadOther;

    if(isDir || isExe)
        permissions |= writePriv | readPriv | exePriv;
    else
        permissions = writePriv | readPriv;
    QFile::setPermissions(filePath,(QFile::Permissions)permissions);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::unzipSetFileDateTime(const QString &filePath, LocalFileRecord *record)
{
    // set file date and time
    uint16_t date = record->header.lastModifiedDate;
    uint16_t time = record->header.lastModifiedTime;

    uint16_t year = (date >> 9) + 1980;
    uint16_t month = (date >> 5) & 0x0f;
    uint16_t day = date & 0x1f;

    uint16_t hour = time >> 11;
    uint16_t minute = (time >> 5) & 0x3f;
    uint16_t sec = (time & 0x1f) << 1;

    QDateTime modTime;
    modTime.setDate(QDate(year,month,day));
    modTime.setTime(QTime(hour,minute,sec));
    utimbuf timebuf;
    timebuf.actime = timebuf.modtime = (time_t) modTime.toTime_t();
    QByteArray filePathByteArray = filePath.toUtf8();
    const char* filePathCharPtr = filePathByteArray.constData();
    utime(filePathCharPtr,&timebuf);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Zip::unzipUpdateFoldersDateTime(QString destFolder)
{
    foreach(LocalFileRecord *record,records.fileList)
    {
        QString filePath = destFolder +"/" + record->filename;
        filePath = filePath.replace("\\","/");
        filePath = filePath.replace("//","/");
        if(!filePath.endsWith('/')) continue;
        QFile file(filePath);
        if(!file.exists()) continue;

        unzipSetFileDateTime(filePath,record);
    }

    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Zip::unzipReadZipFile(QString filepath)
{
    qDebug() << "reading zip file:" << filepath;

    QFile file(filepath);
    QFileInfo info(filepath);

    if(!info.exists())
    {
        qDebug() << "file doesn't exist";
        return false;
    }

    if(!file.open(QIODevice::ReadOnly))
        return false;
    zipReadArray.clear();
    zipReadArray = file.readAll();
    file.close();

    if(!unzipPopulateRecords(zipReadArray))
        return false;

    // show the records
    //    foreach(LocalFileRecord *record,records.fileList)
    //        printLocalFileRecord(record);
    //    foreach(CentralDirectoryRecord *record,records.directoryList)
    //        printCentralDirRecord(record);
    //    printEndRecord(records.endRecord);

    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Zip::unzipPopulateRecords(const QByteArray &data)
{
    uint32_t i = 0;
    uint32_t n = data.size();
    uint8_t *ptr = (uint8_t*) data.data();

    freeMemory();

    // scan for the end record, we have to scan because the end directory could have a comment.
    qDebug() << "scanning for end record:" << n;
    uint32_t m = 0;
    while(i < n)
    {
        uint32_t signature = *(uint32_t*)(&ptr[i]);
        if(signature == 0x06054b50) // end of central directory record
            m = i;
        i++;
    }
    if(m == 0)
        return false;

    // m should be the start of the end central directory record.
    // note: m should be no more that file length - 22.
    // read end of directory record
    unzipReadEndingRecord(&ptr[m]);
    if(records.endRecord.header.signature != 0x06054b50)
        return false;

    // read central directory entries
    i = records.endRecord.header.centralDirecotryOffset;   // starting file pos of central directory
    m = i + records.endRecord.header.centralDirectorySize; // ending file pos of central directory
    int firstCentralDirOffset = i;
    while(i < m)
    {
        uint32_t signature = *(uint32_t*)(&ptr[i]);
        if(signature == 0x02014b50)
        {
            CentralDirectoryRecord *dirRecord = new CentralDirectoryRecord;
            i += unzipReadCentralDirectoryRecord(&ptr[i],dirRecord);
            records.directoryList.append(dirRecord);
        }
        else
            return false; // we should get here.
    }

    // read file records
    //  if the record has a descriptor it will start at sizeof(descriptor) before the
    //  next record.
    n = records.directoryList.size();
    for(uint32_t j=0;j<n;j++)
    {
        CentralDirectoryRecord *r = records.directoryList.at(j);
        uint32_t nextRecordOffset;
        if(j < (n-1))
            nextRecordOffset = records.directoryList.at(j+1)->header.relativeOffset;
        else
            nextRecordOffset = firstCentralDirOffset;

        i = r->header.relativeOffset;
        nextRecordOffset -= i;
        uint32_t signature = *(uint32_t*)(&ptr[i]);
        if(signature == 0x04034b50)
        {
            LocalFileRecord *fileRecord = new LocalFileRecord;
            unzipReadLocalFileRecord(&ptr[i],fileRecord,nextRecordOffset);
            // copy file attribute from directory entry to our record for use when creating the file.
            fileRecord->fileAttributes = r->header.externalFileAttributes;
            records.fileList.append(fileRecord);
        }
        else
            return false;

    }
    return true;
}

// note: this does not duplicate data in the passed buffer, it references it. so,
// don't go deleting the original data buffer and expect the record to be intact.
//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
uint32_t Zip::unzipReadLocalFileRecord(void *buf, LocalFileRecord *record,uint32_t nextOffset)
{
    char *ptr = (char*) buf;

    // read header
    record->header.signature =           *(uint32_t*)(&ptr[0]);
    record->header.version =             *(uint16_t*)(&ptr[4]);
    record->header.flag =                *(uint16_t*)(&ptr[6]);
    record->header.compressionMethod =   *(uint16_t*)(&ptr[8]);
    record->header.lastModifiedTime =    *(uint16_t*)(&ptr[10]);
    record->header.lastModifiedDate =    *(uint16_t*)(&ptr[12]);
    record->header.crc32 =               *(uint32_t*)(&ptr[14]);
    record->header.compressedSize =      *(uint32_t*)(&ptr[18]);
    record->header.uncompressedSize =    *(uint32_t*)(&ptr[22]);
    record->header.filenameLength =      *(uint16_t*)(&ptr[26]);
    record->header.extraFieldLength =    *(uint16_t*)(&ptr[28]);
    uint32_t n = 30;

    // read filename
    record->filename.setRawData(&ptr[n],record->header.filenameLength);
    n+=record->header.filenameLength;

    // read extra field if any
    record->extraField.setRawData(&ptr[n],record->header.extraFieldLength);
    n+=record->header.extraFieldLength;

    // read compressed data
    // save this position, we have to delay reading until after optional descriptor
    uint32_t m = n;
    if(record->header.compressedSize != 0)
    {
        record->compressedData.setRawData(&ptr[n],record->header.compressedSize);
        n+=record->header.compressedSize;
    }

    // read data record if it exists
    if(record->header.flag & 0x08)
    {
        n = nextOffset - sizeof(LocalFileDataDescriptor);
        // the signature is optional
        uint32_t optSig = *(uint32_t*)(&ptr[n]);
        record->optionalDescriptor.signature = optSig;
        n+=4;
        record->optionalDescriptor.crc32 = *(uint32_t*)(&ptr[n]);
        n+=4;
        record->optionalDescriptor.compressedSize = *(uint32_t*)(&ptr[n]);
        n+=4;
        record->optionalDescriptor.uncompressedSize = *(uint32_t*)(&ptr[n]);
        n+=4;
        // now that we know how what size the data is we can read it
        if(record->optionalDescriptor.compressedSize != 0)
            record->compressedData.setRawData(&ptr[m],record->optionalDescriptor.compressedSize);
    }
    else
    {
        record->optionalDescriptor.signature = 0;
        record->optionalDescriptor.compressedSize = 0;
        record->optionalDescriptor.crc32 = 0;
        record->optionalDescriptor.uncompressedSize = 0;
    }

    return n;
}

// note: this does not duplicate data in the passed buffer, it references it. so,
// don't go deleting the original data buffer and expect the record to be intact.
//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
uint32_t Zip::unzipReadCentralDirectoryRecord(void *buf, CentralDirectoryRecord *record)
{
    char *ptr = (char*) buf;

    // read header
    record->header.signature =              *(uint32_t*)(&ptr[0]);
    record->header.version =                *(uint16_t*)(&ptr[4]);
    record->header.minVersion =             *(uint16_t*)(&ptr[6]);
    record->header.flag =                   *(uint16_t*)(&ptr[8]);
    record->header.compressionMethod =      *(uint16_t*)(&ptr[10]);
    record->header.lastModifiedTime =       *(uint16_t*)(&ptr[12]);
    record->header.lastModifiedDate =       *(uint16_t*)(&ptr[14]);
    record->header.crc32 =                  *(uint32_t*)(&ptr[16]);
    record->header.compressedSize =         *(uint32_t*)(&ptr[20]);
    record->header.uncompressedSize =       *(uint32_t*)(&ptr[24]);
    record->header.filenameLength =         *(uint16_t*)(&ptr[28]);
    record->header.extraFieldLength =       *(uint16_t*)(&ptr[30]);
    record->header.fileCommentLength =      *(uint16_t*)(&ptr[32]);
    record->header.diskNumber =             *(uint16_t*)(&ptr[34]);
    record->header.internalFileAttributes = *(uint16_t*)(&ptr[36]);
    record->header.externalFileAttributes = *(uint32_t*)(&ptr[38]);
    record->header.relativeOffset =         *(uint32_t*)(&ptr[42]);

    uint32_t n = 46;

    // read filename
    record->filename.setRawData(&ptr[n],record->header.filenameLength);
    n+=record->header.filenameLength;

    // read extra field if any
    record->extraField.setRawData(&ptr[n],record->header.extraFieldLength);
    n+=record->header.extraFieldLength;

    // read file comment if any
    record->fileComment.setRawData(&ptr[n],record->header.fileCommentLength);
    n+=record->header.fileCommentLength;

    return n;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::unzipReadEndingRecord(void *buf)
{
    char *ptr = (char*) buf;

    // read header
    records.endRecord.header.signature =              *(uint32_t*)(&ptr[0]);
    records.endRecord.header.diskNumber =             *(uint16_t*)(&ptr[4]);
    records.endRecord.header.diskStartNumber =        *(uint16_t*)(&ptr[6]);
    records.endRecord.header.numDirRecordsOnDisk =    *(uint16_t*)(&ptr[8]);
    records.endRecord.header.totalDirRecords =        *(uint16_t*)(&ptr[10]);
    records.endRecord.header.centralDirectorySize =   *(uint32_t*)(&ptr[12]);
    records.endRecord.header.centralDirecotryOffset = *(uint32_t*)(&ptr[16]);
    records.endRecord.header.commentLength =          *(uint16_t*)(&ptr[20]);

    // read comment
    if(records.endRecord.header.commentLength > 0)
        records.endRecord.comment.setRawData(&ptr[22],records.endRecord.header.commentLength);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::freeMemory()
{
    foreach(LocalFileRecord *file,records.fileList)
        delete file;
    records.fileList.clear();

    foreach(CentralDirectoryRecord *dir,records.directoryList)
        delete dir;
    records.directoryList.clear();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
uint32_t Zip::crc32(uint32_t crc, const QByteArray &data)
{
    uint8_t *p = (uint8_t*) data.data();
    return crc32(crc,p,data.size());
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
uint32_t Zip::crc32(uint32_t crc, void *buf, uint32_t size)
{
    uint8_t *p = (uint8_t*) buf;
    if(size == 0) return crc ^ ~0U;

    crc = crc ^ ~0U;

    while (size--)
        crc = crc32_tab[(crc ^ *p++) & 0xFF] ^ (crc >> 8);

    return crc ^ ~0U;
}

//!----------------------------------------------------------------------------
//! \brief Compute Adler32 check word on data array. General 1st call
//! pass adler=1.
//!----------------------------------------------------------------------------
uint32_t Zip::adler32(uint32_t adler, const QByteArray &data)
{
    const uint8_t *p = (uint8_t*) data.data();
    unsigned long s1 = adler & 0xffff;
    unsigned long s2 = (adler >> 16) & 0xffff;
    int size = data.size();
    while(size--)
    {
        s1 = (s1 + *p++) % 65521;
        s2 = (s2 + s1) % 65521;
    }
    return (s2 << 16) + s1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::setComment(QString comment)
{
    records.endRecord.comment = comment.toUtf8();
    records.endRecord.header.commentLength = records.endRecord.comment.size();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString Zip::readComment(QString zipFilePath)
{
    QFile file(zipFilePath);
    QFileInfo info(zipFilePath);

    if(!info.exists())
    {
        qDebug() << "file doesn't exist";
        return QString();
    }

    if(!file.open(QIODevice::ReadOnly))
        return QString();

    QByteArray data = file.readAll();
    file.close();

    uint32_t i = 0;
    uint32_t m = 0;
    uint32_t n = data.size();
    uint8_t *ptr = (uint8_t*) data.data();

    // scan for the end record, we have to scan because the end directory could have a comment.
    while(i < n)
    {
        uint32_t signature = *(uint32_t*)(&ptr[i]);
        if(signature == 0x06054b50) // end of central directory record
            m = i;
        i++;
    }
    unzipReadEndingRecord(&ptr[m]);

    QString comment = QString(records.endRecord.comment);

    return comment;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::printLocalFileRecord(LocalFileRecord *record)
{
    qDebug() << "------------------------------------------";
    qDebug() << " FILE";
    qDebug() << "------------------------------------------";
    qDebug() << "signature:" << hex << record->header.signature;
    qDebug() << "version:" << record->header.version;
    qDebug() << "flag:" << record->header.flag;
    qDebug() << "compressionMethod:" << record->header.compressionMethod;
    qDebug() << "lastModifiedTime:" << record->header.lastModifiedTime;
    qDebug() << "lastModifiedDate:" << record->header.lastModifiedDate;
    qDebug() << "crc32:" << hex << record->header.crc32;
    qDebug() << "compressedSize:" << record->header.compressedSize;
    qDebug() << "uncompressedSize:" << record->header.uncompressedSize;
    qDebug() << "filenameLength:" << record->header.filenameLength;
    qDebug() << "extraFieldLength:" << record->header.extraFieldLength;
    qDebug() << "filename:" << QString(record->filename);
    if(record->header.flag & 0x08)
    {
        qDebug() << "optional signature:" << hex << record->optionalDescriptor.signature;
        qDebug() << "optional crc:" << hex << record->optionalDescriptor.crc32;
        qDebug() << "optional uncompressedSize:" << record->optionalDescriptor.uncompressedSize;
        qDebug() << "optional compressedSize:" << record->optionalDescriptor.compressedSize;
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::printCentralDirRecord(CentralDirectoryRecord *record)
{
    qDebug() << "------------------------------------------";
    qDebug() << " DIRECTORY";
    qDebug() << "------------------------------------------";
    qDebug() << "signature:" << hex << record->header.signature;
    qDebug() << "version:" << hex << record->header.version;
    qDebug() << "minVersion:" << record->header.minVersion;
    qDebug() << "flag:" << record->header.flag;
    qDebug() << "compressionMethod:" << record->header.compressionMethod;
    qDebug() << "lastModifiedTime:" << record->header.lastModifiedTime;
    qDebug() << "lastModifiedDate:" << record->header.lastModifiedDate;
    qDebug() << "crc32:" << hex << record->header.crc32;
    qDebug() << "compressedSize:" << record->header.compressedSize;
    qDebug() << "uncompressedSize:" << record->header.uncompressedSize;
    qDebug() << "filenameLength:" << record->header.filenameLength;
    qDebug() << "extraFieldLength:" << record->header.extraFieldLength;
    qDebug() << "fileCommentLength:" << record->header.fileCommentLength;
    qDebug() << "diskNumber:" << record->header.diskNumber;
    qDebug() << "internalFileAttributes:" << hex << record->header.internalFileAttributes;
    qDebug() << "externalFileAttributes:" << hex << record->header.externalFileAttributes;
    qDebug() << "relativeOffset:" << record->header.relativeOffset;
    qDebug() << "filename:" << QString(record->filename);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Zip::printEndRecord(EndCentralDirectoryRecord record)
{
    qDebug() << "------------------------------------------";
    qDebug() << " ENDING";
    qDebug() << "------------------------------------------";
    qDebug() << "signature:" << hex << record.header.signature;
    qDebug() << "diskNumber:" << record.header.diskNumber;
    qDebug() << "diskStartNumber:" << record.header.diskStartNumber;
    qDebug() << "numDirRecordsOnDisk:" << record.header.numDirRecordsOnDisk;
    qDebug() << "totalDirRecords:" << record.header.totalDirRecords;
    qDebug() << "centralDirectorySize:" << record.header.centralDirectorySize;
    qDebug() << "centralDirecotryOffset:" << record.header.centralDirecotryOffset;
    qDebug() << "commentLength:" << record.header.commentLength;
    qDebug() << "comment:" << QString(record.comment);
}



