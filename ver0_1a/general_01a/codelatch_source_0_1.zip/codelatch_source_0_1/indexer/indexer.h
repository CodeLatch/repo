#ifndef INDEXER_H
#define INDEXER_H

#include <QObject>
#include <QStringList>
#include <QFuture>
#include <QHash>
#include <QProcess>

class SourceEditor;
class Project;
class QTreeWidget;
class QTreeWidgetItem;
class TabManager;

class Tag
{
public:
    enum Access {
        NoAccess    = 0,
        Public      = 1,
        Private     = 2,
        Protected   = 3
    };

    enum EntryType {
        NoType              = 0,
        TypeDef             = 1,
        Class               = 2,
        Structure           = 3,
        Union               = 4,
        Macro               = 5,
        Enum                = 6,
        EnumVal             = 7,
        Member              = 8,
        Function            = 9,
        Prototype           = 10,
        LocalVar            = 11,
        GlobalVar           = 12,
        Extern              = 13,
        MacroGroup          = 14
    };

    Tag();
    Tag(const Tag &other);
    ~Tag();
    static QIcon getIcon(Tag *tag);

    // core tag info
    QString name;               // tag item name. this is the name of the variable, function, class, union, structure, typedef, enum...
    QString pathname;           // file pathname that the item is in
    QString statement;          // the origninal line of text that is responsible for causing this tag to be created
    int line;                   // the line number in the file the statement is at
    EntryType tagType;          // the tag type, one of EntryType enum values.
    QStringList fields;         // additional fields in the tag that we pull all other info from
    QString text;               // original ctags text

    // container info
    QString containerName;      // the name of the container that this item is part of
    EntryType containerType;    // the type of container that this item is a part of
    QList<Tag*> members;        // members of this container (not including inherited members)
    QString typeRefName;  // the containerName that this item is the parent of

    // extra class specific container info
    Access access;                  // access type; Tag::Public, Tag::Private, Tag::Protected
    QHash<QString,Tag*> inherits;   // inherited classes

    // variable related info
    QString varType;            // the variable type as resolved by parseVariableType(statement)

    // function/prototype info (function and prototype tags will be combined when successfully paired)
    QString funcParameters;     // the parameter list
    QString protoParameters;    // similar to funcParameters but proto parameters can have default assignments included in them
    QString protoPathname;      // pathname of associated prototype
    int firstline;              // first line of the function
    int lastline;               // last line of the function
    int protoline;              // line the prototype is on

    // enum info
    QString enumVal;            // if this tag is an enumeration value, this contains the value string
};

Q_DECLARE_METATYPE(Tag*)

class Indexer : public QObject
{
    Q_OBJECT
public:
    explicit Indexer(QObject *parent = 0);
    ~Indexer();

    bool indexProject(Project *project, TabManager *tabManager);
    bool processText(Project *project, QString pathname, SourceEditor *editor, bool processIncludes = true);
    void populateTree(QTreeWidget *tree);
    void populateTree(QTreeWidget *tree, QString pathname);
    void populateTreeUsingGroups(QTreeWidget *tree);

    QList<Tag*> getCompletions(QString prefixString, QString pathname, int line);
    QList<Tag *> getTagsForStatement(QString statement, QString pathname, const QStringList &pathnameList, int line);
    Tag* getFunctionForScope(QString pathname, int line);
    Project *getProject() {return prj;}

    QStringList getIndexedPaths() {return pathnameList;}
    QStringList getSourcePaths() {return sourceList;}
    QStringList getTagList() {return tagList;}

    QList<Tag*> getTagItems() {return tagItems;}
    QList<Tag*> getLocalsList() {return localVariableList;}
    QList<Tag*> getGlobalsList() {return globalVariableList;}
    QList<Tag*> getMemberVariableList() {return memberVariableList;}
    QList<Tag*> getFunctionList() {return functionList;}
    QList<Tag*> getMemberFunctionList() {return memberFunctionList;}
    QList<Tag*> getContainerList() {return containerList;}
    QList<Tag*> getTypedefList() {return typedefList;}
    QList<Tag*> getExternList() {return externList;}
    QList<Tag*> getTagsOnLine(int line) {return lineHash.values(line);}
    QList<Tag*> getTagsInPath(QString path) {return pathHash.values(path);}

    bool isRunning() {return running;}

signals:
    void indexingComplete();

public slots:

private slots:
    void ctagsFinished(int exitcode);

private:
    QStringList tagList;                    // list of raw tag text items produced by ctags, excluding comment lines which are stripped out
    QList<Tag*> tagItems;                   // list of tagList items converted to meaningful Tag objects
    QHash<QString,Tag*> tagHash;            // hash table of all tags indexed by tag name (can return multiple tags for a given name)
    QHash<QString,Tag*> pathHash;           // hash table of all tags indexed by pathname
    QHash<int,Tag*> lineHash;               // hash table of all tags indexed by line number
    QHash<QString,Tag*> typeRefHash;        // hash table of all tags that have a typeRefName, indexed by typeRefName

    // variables for running ctags    
    QProcess *ctagsProcess;
    QString ctagsOutputFilename;
    QString ctagsInputFilename;
    QStringList pathReplacementList;        // this list contains pathname pairs, the first entry is the actual pathname, the second
                                            // is the temporary pathname the file was processed as. this is used to process dirty files.
    Project *prj;
    QStringList includePaths;
    QStringList pathnameList;
    QStringList sourceList;

    bool running;

    QList<Tag*> localVariableList;
    QList<Tag*> globalVariableList;
    QList<Tag*> memberVariableList;
    QList<Tag*> functionList;
    QList<Tag*> memberFunctionList;
    QList<Tag*> containerList;
    QList<Tag*> typedefList;
    QList<Tag*> externList;

    void parseTags();
    QStringList parseTag(const QString &tag);
    void parseEnumVal(Tag *item, QString &field);
    QString parseVariableType(QString statement);
    void clearTag(Tag *tag);
    bool isVarBasicPointer(QString name, QString type, QString statement);
    void populateFunctionList();
    void populateVariableLists();
    void populateExternList();
    void populateTypedefList();
    void populateContainerList();
    void populateTreeContainerMembers(QTreeWidgetItem* item, Tag *tag);
    int findLastLineOfFunction(QStringList *textlist, QString &functionName, int firstline);
    QString formatFuncParameters(QString param);
    void parseRawTags();
    QString getBaseType(QString type);
    QTreeWidgetItem *newTreeTag(Tag *tag);
    Tag *getTagFromName(QString name);
    QHash<QString,Tag*> getAllMembers(Tag *tag);
    QHash<QString,Tag*> getTagsInScope(QString pathname, QStringList headerPaths, int line);



    // ctags interface
    void findHeadersInText(QStringList *textList);
    void findHeadersInFile(const QString &filename);
    QString findPathname(const QString &filename);
    void replacePathname(QString oldPathname, QString newPathname);
    bool runCtags(QStringList fileList, QString options);

};


#endif // INDEXER_H
