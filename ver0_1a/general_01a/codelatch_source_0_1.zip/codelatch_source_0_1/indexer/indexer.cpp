//!----------------------------------------------------------------------------
//! file: indexer.cpp
//!
//! Implements source file indexing functionality. An external command line
//! program "ctags" is called to process source file(s) and generate tags.
//!
//! Usage:
//! Two functions are available to call for creating tags....
//!
//!    processText(Project *project, const QString &pathname, SourceEditor *editor,bool processIncludes = true);
//!    processFileList(Project *project, QStringList &fileList);
//!
//! Calling either of these functions starts the tag creation process, when
//! complete the signal indexingComplete() is emitted.
//!
//! The raw text tags are stored in QStringList tagList, this list is parsed and
//! Tag objects are created and stored in the list QList<Tag*> tagItems.
//! Various hash lists are created to speed processing.
//!
//! Each projects has a project outline indexer. Each open file has an auto-complete indexer.
//! To optimize the process once the initial indexing is done only update the index when
//! changes are made to a file. Maybe only update the project index when a file is saved.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "indexer/indexer.h"
#include "project/project.h"
#include "utility/fileutility.h"
#include "target.h"
#include "sourceeditor.h"
#include "tabmanager.h" // need this to access open dirty files
#include "mainwindow/mainwindow.h" // need this for STR_DIRTY_FILE

#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QTreeWidget>
#include <QTreeWidgetItem>


//!----------------------------------------------------------------------------
//! \brief  Default constructor.
//!----------------------------------------------------------------------------
Tag::Tag()
{
}
//!----------------------------------------------------------------------------
//! \brief  Copy constructor.
//! a copy constructor is required to make this class usable with QVariant
//! by using Q_DECLARE_METATYPE in the class header.
//! since we create all the tags and just pass pointers around we don't need
//! to copy the contents. under other circumstances we would need to assign all
//! our members to the values of the "other" tag class members.
//!----------------------------------------------------------------------------
Tag::Tag(const Tag &other)
{
    Q_UNUSED(other);
}

//!----------------------------------------------------------------------------
//! \brief  Deconstructor.
//!----------------------------------------------------------------------------
Tag::~Tag()
{
}

//!----------------------------------------------------------------------------
//! \brief  Returns an icon based on the passed tags tagType. This is used
//! for enhancing tag display in trees.
//!----------------------------------------------------------------------------
QIcon Tag::getIcon(Tag *tag)
{
    QIcon icon;
    switch(tag->tagType)
    {
    case Tag::Class:
        icon = QIcon(":/icons/icons/types/class.png");
        break;
    case Tag::Structure:
        icon = QIcon(":/icons/icons/types/structure.png");
        break;
    case Tag::Union:
        icon = QIcon(":/icons/icons/types/union.png");
        break;
    case Tag::Function:
    case Tag::Prototype:
        if(tag->containerName.isEmpty())
            icon = QIcon(":/icons/icons/types/function.png");
        else
        {
            if(tag->access == Tag::Public)
                icon = QIcon(":/icons/icons/types/public_func.png");
            else if(tag->access == Tag::Private)
                icon = QIcon(":/icons/icons/types/private_func.png");
            else // protected
                icon = QIcon(":/icons/icons/types/protected_func.png");
        }
        break;
    case Tag::Member:
        if(tag->containerName.isEmpty())
            icon = QIcon(":/icons/icons/types/member.png");
        else
        {
            if(tag->access == Tag::Public)
                icon = QIcon(":/icons/icons/types/public_var.png");
            else if(tag->access == Tag::Private)
                icon = QIcon(":/icons/icons/types/private_var.png");
            else // protected
                icon = QIcon(":/icons/icons/types/protected_var.png");
        }
        break;
    case Tag::GlobalVar:
        icon = QIcon(":/icons/icons/types/global.png");
        break;
    case Tag::LocalVar:
        icon = QIcon(":/icons/icons/types/local.png");
        break;
    case Tag::TypeDef:
        if(tag->containerName.isEmpty())
            icon = QIcon(":/icons/icons/types/typedef_item.png");
        else if(tag->containerType == Tag::Structure)
            icon = QIcon(":/icons/icons/types/typedef_struct.png");
        else if(tag->containerType == Tag::Union)
            icon = QIcon(":/icons/icons/types/typedef_union.png");
        else if(tag->containerType == Tag::Enum)
            icon = QIcon(":/icons/icons/types/typedef_enum.png");
        break;
    case Tag::Extern:
        break;
    case Tag::Enum:
        icon = QIcon(":/icons/icons/types/enum.png");
        break;
    case Tag::Macro:
        icon = QIcon(":/icons/icons/types/macro.png");
        break;
    default:
        break;
    }
    return icon;
}

//!----------------------------------------------------------------------------
//! \brief  Default constructor.
//!----------------------------------------------------------------------------
Indexer::Indexer(QObject *parent) :
    QObject(parent)
{
    ctagsProcess = NULL;
    running = false;
}

//!----------------------------------------------------------------------------
//! \brief  Default destructor. Delete allocated memory.
//!----------------------------------------------------------------------------
Indexer::~Indexer()
{
    foreach(Tag *item,tagItems)
        if(item != NULL) delete item;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Indexer::parseTags()
{
    parseRawTags();
    populateFunctionList();
    populateVariableLists();
    populateExternList();
    populateTypedefList();
    populateContainerList();    //containers must be populated last

    // create extra hash lists
    pathHash.clear();
    lineHash.clear();
    foreach(Tag *tag,tagItems)
    {
        pathHash.insertMulti(tag->pathname,tag);
        lineHash.insertMulti(tag->line,tag);
    }

    /*
    qDebug() << "name,tagType,varType,containerType,containerName,typeRefName,memberCnt";
    foreach(Tag *tag,tagItems)
    {
        qDebug() << tag->name << "\t\t" << tag->tagType << "\t\t" << tag->varType << "\t\t" << tag->containerType <<
 "\t\t\t" << tag->containerName << "\t\t\t\t" << tag->typeRefName << "\t" << tag->members.size();
    }
*/
}

//!----------------------------------------------------------------------------
//! \brief  Pasrse the tag entry into fields.
//!         Format = Name\tPathname\tOptionalStatement\tTagType\tOptionalFields
//!         There should be a minimum of 4 fields; name,pathname,tag type, and
//!         line number.
//!----------------------------------------------------------------------------
QStringList Indexer::parseTag(const QString &tag)
{
    QStringList list;
    if(tag.count('\t') < 4) return list;
    // get name
    int i = tag.indexOf('\t');
    list.append(tag.left(i));

    // get pathname
    int j = tag.indexOf('\t',i+1);
    QString pathname = tag.mid(i+1,j-i-1);
    list.append(pathname);

    j = tag.indexOf('\t',j+1);
    // look for statement
    QString statement;
    int iStart = tag.indexOf("\t/^");
    if(iStart != -1)
    {
        int iEnd = tag.indexOf("$/;\"\t",iStart);
        if(iEnd != -1)
        {
            j = tag.indexOf('\t',iEnd);
            statement = tag.mid(iStart+3,iEnd-iStart-3);
            int commentIndex = statement.indexOf("\\/");
            if(commentIndex != -1)
                statement = statement.left(commentIndex).simplified();
        }
    }
    list.append(statement);

    // get additional fields
    if(j == -1) return list;
    QString remainder = tag.right(tag.length()-(j+1));
    QStringList sublist = remainder.split('\t');
    list.append(sublist);
    return list;
}

//!----------------------------------------------------------------------------
//! \brief  Process the raw tag items in tagList to populate the tagItems list.
//!----------------------------------------------------------------------------
void Indexer::parseRawTags()
{
    // free memory and clear tagItems list
    foreach(Tag *item,tagItems)
        if(item != NULL) delete item;
    tagItems.clear();
    tagHash.clear();
    typeRefHash.clear();
    //    containerTagHash.clear();

    foreach(QString tag,tagList)
    {
        //qDebug() << tag;
        QStringList fields = parseTag(tag);
        if(fields.size() < 4) continue;
        //---------------------------
        //     create a new tag
        //---------------------------
        Tag *item = new Tag;
        if(item == NULL) continue;
        clearTag(item);

        item->name = fields.takeFirst();
        item->pathname = fields.takeFirst();
        item->statement = fields.takeFirst();
        item->text = tag;
        char entryType = fields.takeFirst().at(0).toLatin1();

        switch(entryType)
        {
        case 'c': item->tagType = Tag::Class; break;
        case 'd': item->tagType = Tag::Macro; break;
        case 'e': item->tagType = Tag::EnumVal; break;
        case 'f': item->tagType = Tag::Function; break;
        case 'g': item->tagType = Tag::Enum; break;
        case 'l': item->tagType = Tag::LocalVar; break;
        case 'm': item->tagType = Tag::Member; break;
        case 'p': item->tagType = Tag::Prototype; break;
        case 's': item->tagType = Tag::Structure; break;
        case 't': item->tagType = Tag::TypeDef; break;
        case 'u': item->tagType = Tag::Union; break;
        case 'v': item->tagType = Tag::GlobalVar; break;
        case 'x': item->tagType = Tag::Extern; break;
        default: qDebug() << "Error unknown entryType:" << entryType << " name:" << item->name; break;
        }

        // parse remaining fields
        foreach(QString field,fields)
        {
            field = field.simplified();
            // file line number
            if(field.startsWith("line:"))
            {
                field.remove("line:");
                bool ok;
                int line = field.toInt(&ok);
                if(ok) item->line = line;
            }
            // class member access
            else if(field.startsWith("access:"))
            {
                field.remove("access:");
                if(field == "public")
                    item->access = Tag::Public;
                else if(field == "private")
                    item->access = Tag::Private;
                else if(field == "protected")
                    item->access = Tag::Protected;
                else
                    qDebug() << "unknown access:" << field;
            }
            // the signature is the function/prototype parameter list surrounded by parenthesis
            else if(field.startsWith("signature:"))
            {
                field.remove("signature:");
                // for prototypes we keep the unmodified parameter list in a seperate variable
                // this allows us to later reference it so the user can see what parameters have default assignments.
                if(item->tagType == Tag::Prototype)
                    item->protoParameters = field;
                // format and save the parameter list so that the formatting is predictable and we remove
                // any default assignments so we can compare and match functions to prototypes.
                item->funcParameters = formatFuncParameters(field);
            }
            // indicates the scope is local to this file
            else if(field.startsWith("file:"))
            {
                // ignore this for now
            }
            // class inheritance
            else if(field.startsWith("inherits:"))
            {
                field.remove("inherits:");
                QStringList inames = field.split(',');
                foreach(QString iname,inames)
                    item->inherits.insert(iname,NULL);
            }
            // member of a class
            else if(field.startsWith("class:"))
            {
                field.remove("class:");
                item->containerName = field;
                item->containerType = Tag::Class;
            }
            // member of a structure
            else if(field.startsWith("struct:"))
            {
                field.remove("struct:");
                item->containerName = field;
                item->containerType = Tag::Structure;
            }
            // member of a union
            else if(field.startsWith("union:"))
            {
                field.remove("union:");
                item->containerName = field;
                item->containerType = Tag::Union;
            }
            // enumeration value
            else if((item->tagType == Tag::EnumVal) && (field.startsWith("enum:")))
            {
                parseEnumVal(item,field);
            }
            // structure, union, and enum typeref's
            else if(field.startsWith("typeref:struct:"))
            {
                field.remove("typeref:struct:");
                item->typeRefName = field;
                item->containerType = Tag::Structure;
                typeRefHash.insert(field,item);
            }
            else if(field.startsWith("typeref:union:"))
            {
                field.remove("typeref:union:");
                item->typeRefName = field;
                item->containerType = Tag::Union;
                typeRefHash.insert(field,item);
            }
            else if(field.startsWith("typeref:enum:"))
            {
                field.remove("typeref:enum:");
                item->typeRefName = field;
                item->containerType = Tag::Enum;
                typeRefHash.insert(field,item);
            }
            else
            {
                qDebug() << "unhandled field:" << field;
                item->fields.append(field);
            }
        }

        // assign the variable type. we can post process these later to resolve to actual types if we want to (re unravel typedefs).
        // make enums an int, don't really need to but just for grins.
        if((item->tagType == Tag::Enum) || (item->tagType == Tag::EnumVal))
            item->varType = QString("int");
        // containers are their own types
        else if((item->tagType == Tag::Class) || (item->tagType == Tag::Structure) ||
                (item->tagType == Tag::Union) || (item->tagType == Tag::TypeDef))
        {
            if(item->containerName.isEmpty())
                item->varType = item->name;
            else
                item->varType = item->containerName + "::" + item->name;
        }
        // items that have a typeref statement get assigned the typeRefName
        else if(!item->typeRefName.isEmpty())
            item->varType = item->typeRefName;
        // for everything else parse the statement to determine the type
        else
            item->varType = parseVariableType(item->statement);
        // deal with non-container (ie single line) typedef's
        if((item->tagType == Tag::TypeDef) && (item->statement.startsWith("typedef ")))
        {
            QString s(item->statement);
            s.remove("typedef ");
            item->varType = parseVariableType(s);
        }

        // determine for basic declarations if this is a pointer.
        // this is not foolproof and we can't resolve if var is pointer because a typedef type is a pointer here.
        //        bool isPointer = isVarBasicPointer(item->name,item->varType,item->statement);

        // add item to the lists
        tagItems.append(item);
        tagHash.insertMulti(item->name,item);
    }

    //    foreach(Tag *tag,tagItems)
    //        qDebug() << tag->name << " " << tag->tagType << " " << tag->varType << " " << tag->statement << " " <<
    //    tag->containerName << " " << tag->containerType << " " << tag->line;
}

//!----------------------------------------------------------------------------
//! \brief  Called by parseTags to parse an enumeration value entry.
//!----------------------------------------------------------------------------
void Indexer::parseEnumVal(Tag *item, QString &field)
{
    field.remove("enum:");
    item->containerName = field;
    QString s(item->statement);
    // the enumeration value is not always directly specified. But if it is, get the value.
    QString nameSearch(item->name + " = ");
    int istart = s.indexOf(nameSearch);
    if(istart == -1) return;

    istart += nameSearch.length();
    int iend = s.indexOf(',',istart);
    if(iend == -1) iend = s.length();
    s = s.mid(istart,iend-istart);
    s = s.toLower();
    bool ok;
    int val;
    if(s.startsWith("0x"))
        val = s.toInt(&ok,16);
    else
        val = s.toInt(&ok,10);
    if(ok)
        item->enumVal = s + ":" + QString::number(val);
}

//!----------------------------------------------------------------------------
//! \brief  Returns the variable type section of the variable declaration.
//!         Currently removes any pointer and or array information.
//!----------------------------------------------------------------------------
QString Indexer::parseVariableType(QString statement)
{
    QString type(statement);
    // might see a closing bracket if this is a variable defined following a struct or union
    type = type.remove('}');

    // remove keywords that don't help us
    type = " " + type;
    QStringList list;
    list << " extern " << " static " << " inline " << " _inline " << " __inline ";
    list << " struct" << " union";
    list << " INLINE " << " _INLINE " << " __INLINE ";
    foreach(QString s,list)
    {
        if(type.contains(s))
            type.remove(s);
    }
    type = type.simplified();

    // remove anything to the right of and including '='
    int iend = type.length();
    int i = type.indexOf('=');
    if((i > -1) && (i < iend)) iend = i;
    // remove anything to the right of and including ';'
    i = type.indexOf(';');
    if((i > -1) && (i < iend)) iend = i;
    // remove anything to the right of and incluing '['
    i = type.indexOf('[');
    if((i > -1) && (i < iend)) iend = i;
    // remove anything to the right of and incluing '('
    i = type.indexOf('(');
    if((i > -1) && (i < iend)) iend = i;
    // remove anything to the right of and incluing '{'
    i = type.indexOf('{');
    if((i > -1) && (i < iend)) iend = i;
    // remove anything to the right of and incluing '/'
    i = type.indexOf('/');
    if((i > -1) && (i < iend)) iend = i;
    // remove anything to the right of and incluing ','
    i = type.indexOf(',');
    if((i > -1) && (i < iend)) iend = i;

    // trim the string and remove any pointer asterisks
    if(iend != -1) type = type.left(iend);
    type = type.remove('*');
    type = type.simplified();

    // we should now have the variable type followed by a space and the first part of the
    // variable or function name. remove the variable or function name.
    // if there is no space this is likely a constructor or destructor with no type so return void.
    i = type.lastIndexOf(' ');
    if(i != -1)
        type = type.left(i);
    else
        type = QString("void");

    return type;

    /*
    // if this is a variable defined following a structure or union definition it's a little different.
    if(str.contains("\ttyperef:union:"))
    {
        for(i=1;i<split.size();i++)
            if(split.at(i).startsWith("typeref:union:"))
                type = split.at(i);
        type = type.remove("typeref:union:");
        type = type.simplified();
    }
    else if(str.contains("\ttyperef:struct:"))
    {
        for(i=1;i<split.size();i++)
            if(split.at(i).startsWith("typeref:struct:"))
                type = split.at(i);
        type = type.remove("typeref:struct:");
        type = type.simplified();
    }
*/
}

//!----------------------------------------------------------------------------
//! \brief  Basic attempt to determine if a variable is declared as a pointer.
//!         In this version won't work if pointer is somehow implied by typedef.
//!----------------------------------------------------------------------------
bool Indexer::isVarBasicPointer(QString name, QString type, QString statement)
{
    int itype = statement.indexOf(type);

    // there can be more than one variable declared and the leading text of
    // one of the other variables can be the same as our variable name. ugh.
    // example our var is a: int aaa, aa, *a; So, we need a way to isolate
    // only our variable....turn int aaa, aa, *a; into int,aaa,,aa,,,a, and
    // search for ,a, add one and done.
    QString s(statement);
    s.replace(' ',',');
    s.replace('*',',');
    s.replace('&',',');
    s.replace(';',',');
    QString tname = ","+name+",";

    int iname = s.indexOf(tname);
    if((iname == -1) || (itype == -1)) return false;
    iname++; // move past comma we inserted

    // if the character to the left of our name is '*' or the character to the right of the type is '*' then
    // this is a pointer. There can be one space before our name and after the type as well.
    QChar nm = statement.at(iname-1);
    if(nm.isSpace()) nm = statement.at(iname-2);
    if(nm == QChar('*')) return true;
    itype = itype + type.length();
    nm = statement.at(itype);
    if(nm.isSpace()) nm = statement.at(itype+1);
    if(nm == QChar('*')) return true;

    return false;
}

//!----------------------------------------------------------------------------
//! \brief  Initialize a tags items.
//!----------------------------------------------------------------------------
void Indexer::clearTag(Tag *tag)
{
    tag->name.clear();
    tag->pathname.clear();
    tag->statement.clear();
    tag->tagType = Tag::NoType;
    tag->access = Tag::NoAccess;
    tag->funcParameters.clear();
    tag->protoParameters.clear();
    tag->protoPathname.clear();
    tag->inherits.clear();
    tag->containerName.clear();
    tag->containerType = Tag::NoType;
    tag->enumVal.clear();
    tag->fields.clear();
    tag->members.clear();
    tag->varType.clear();
    tag->typeRefName.clear();
    tag->line = 0;
    tag->firstline = 0;
    tag->lastline = 0;
    tag->protoline = 0;
}


//!----------------------------------------------------------------------------
//! \brief Resolve base type by iterrating types. Continue looping until the
//!----------------------------------------------------------------------------
QString Indexer::getBaseType(QString type)
{
    // up to 10 levels of typedef chasing
    int i;
    for(int j=0;j<10;j++)
    {
        for(i=0;i<tagItems.size();i++)
        {
            Tag *tag = tagItems.at(i);
            if(tag->name == type)
            {
                type = tag->varType;
                if(tag->tagType != Tag::TypeDef)
                    return type;
                break;
            }
        }
        // if we went through all items and didn't find a match return where we are at.
        if(i==tagItems.size())
            return type;
    }
    // chased our tail through ten typedef's, either bad code or recursive so return.
    return type;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Indexer::populateTypedefList()
{
    typedefList.clear();

    // temporary list to track typedefs that are containers so we can fill them
    QList<Tag*> list;
    QHash<QString,Tag*> typeDefHash;

    // populate list and find the base typedef type if possible
    foreach(Tag *tag,tagItems)
    {
        if(tag->tagType == Tag::TypeDef)
        {
            typedefList.append(tag);
            typeDefHash.insertMulti(tag->name,tag);
            // if a tag is Tag::Typedef and has a containerType Tag::Structure or Tag::Union then it's a container type.
            // it will be associated with members by an anonymous containerName (such as __anon123).
            if((tag->containerType == Tag::Structure) || (tag->containerType == Tag::Union) || (tag->containerType == Tag::Enum))
                list.append(tag);

            QString baseType = getBaseType(tag->varType);

            if(tag->varType == baseType) continue;

            QList<Tag*> hlist = tagHash.values(baseType);

            if(hlist.isEmpty()) continue;
            qDebug() << "basetype:" << baseType << " " << tag->varType << " " << tag->name << " " << hlist.size();
            Tag *htag = hlist.first(); // todo: need to resolve which is correct choice
            qDebug() << tag->varType << " " << tag->containerName << " " << tag->containerType;
            qDebug() << htag->varType << " " << htag->containerName << " " << htag->containerType;
            tag->varType = htag->varType;
            tag->containerName = htag->containerName;
            tag->containerType = htag->containerType;
        }
    }

    // find global, local, and member variables that are typedefs and update them
    foreach(Tag *tag,tagItems)
    {
        if((tag->tagType == Tag::GlobalVar) || (tag->tagType == Tag::LocalVar) || (tag->tagType == Tag::Member))
        {
            QString varType = tag->varType;
            QList<Tag*> htaglist = typeDefHash.values(varType);
            if(htaglist.isEmpty()) continue;

            //            qDebug() << "*** " << htaglist.size() << " " << varType << " " << tag->name << htaglist.at(0)->name <<
            //            htaglist.at(0)->varType << htaglist.at(0)->containerName;
            QString hvarType = htaglist.at(0)->varType;
            QList<Tag*> staglist = tagHash.values(hvarType);
            if(staglist.isEmpty()) continue;
            //            qDebug() << "*** " << staglist.size() << " " << varType << " " << tag->name << staglist.at(0)->name <<
            //            staglist.at(0)->varType << staglist.at(0)->containerName;
            Tag *stag = staglist.at(0);
            tag->varType = stag->name;
            tag->typeRefName = stag->name;
            tag->containerType = stag->tagType;
        }
    }

    // populate containers with members
    foreach(Tag *tag,list)
    {
        tag->members.clear();
        // add members
        foreach(Tag *m,memberVariableList)
        {
            if(m->containerName == tag->containerName)
                tag->members.append(m);
        }
        // add enumerations
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Indexer::populateContainerList()
{
    QList<Tag*> list;

    containerList.clear();

    // make a temp list of all tags that are containers
    // load containerList with tags that are top level containers
    foreach(Tag *tag,tagItems)
    {
        // basic container types
        if((tag->tagType == Tag::Class) || (tag->tagType == Tag::Structure) || (tag->tagType == Tag::Union))
        {
            list.append(tag);
            // only add top level containers to containerList
            if(tag->containerName.isEmpty())
                containerList.append(tag);
        }
        // variables that are containers
        else if(((tag->containerType == Tag::Structure) || (tag->containerType == Tag::Union)) && (!tag->typeRefName.isEmpty()))
        {
            list.append(tag);
            // only add top level containers to containerList
            if(tag->containerName.isEmpty())
                containerList.append(tag);
        }
    }

    // populate items that are containers with members
    foreach(Tag *tag,list)
    {
        QString containerName = tag->name;
        if(!tag->containerName.isEmpty())
            containerName = tag->containerName + "::" + containerName;

        tag->members.clear();

        // if this is a class add functions and prototypes
        if(tag->tagType == Tag::Class)
        {
            foreach(Tag *m,memberFunctionList)
            {
                if(m->containerName == containerName)
                    tag->members.append(m);
            }
        }

        // add variables
        foreach(Tag *m,memberVariableList)
        {
            if(m == tag) continue;
            if((tag->tagType == Tag::Class) || (tag->tagType == Tag::Structure) || (tag->tagType == Tag::Union))
            {
                if(m->containerName == containerName)
                    tag->members.append(m);
            }
            // deal with container tags in the list that have a typeRefName (ie variables/members that are structures)
            else if(m->containerName == tag->typeRefName) // could be (m->containerName == tag->varType)
            {
                //                qDebug() << "adding " << m->name << " to " << tag->name;
                tag->members.append(m);
            }
        }

        // add enumerations
        // update inheritance
        QList<QString> ilist = tag->inherits.keys();
        tag->inherits.clear();
        foreach(QString iname,ilist)
        {
            Tag *itag = tagHash.value(iname);
            tag->inherits.insert(iname,itag);
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief  Populate variable lists from tagItems list. There are three lists
//!         of variables; locals, globals, and members.
//!----------------------------------------------------------------------------
void Indexer::populateVariableLists()
{
    // clear existing variable lists
    localVariableList.clear();
    globalVariableList.clear();
    memberVariableList.clear();

    foreach(Tag *tag,tagItems)
    {
        if(tag->tagType == Tag::LocalVar)
            localVariableList.append(tag);
        else if(tag->tagType == Tag::GlobalVar)
            globalVariableList.append(tag);
        else if(tag->tagType == Tag::Member)
            memberVariableList.append(tag);
    }
}

//!-----------------------------------------------------------------------------
//! \brief  Popluate functionList and memberFunctionList from tagItems list.
//!         Updates tags that are functions lastLine parameter and prototype info.
//!         Do this intelligently so we don't open and read the same file
//!         repeatedly.
//!-----------------------------------------------------------------------------
void Indexer::populateFunctionList()
{
    // create temporary lists of functions and prototypes as well as a list of all the pathnames
    // that have functions.
    QList<Tag*> funcList, protoList;
    QStringList pathList;
    foreach(Tag *tag,tagItems)
    {
        if(tag->tagType == Tag::Function)
        {
            tag->firstline = tag->line;
            funcList.append(tag);
            pathList.append(tag->pathname);
        }
        else if(tag->tagType == Tag::Prototype)
            protoList.append(tag);
    }
    pathList.removeDuplicates();

    // update functions with matching prototype info
    foreach(Tag *fTag,funcList)
    {
        for(int i=0;i<protoList.size();i++)
        {
            Tag *pTag = protoList.at(i);
            if((pTag->name == fTag->name) && (pTag->funcParameters == fTag->funcParameters))
            {
                // found a match
                fTag->protoPathname = pTag->pathname;
                fTag->protoParameters = pTag->protoParameters;
                fTag->protoline = pTag->line;
                fTag->access = pTag->access;
                // remove this prototype from the list since we paired it.
                protoList.takeAt(i);
                break;
            }
        }
    }

    // for each pathname in the pathList load the text and search for the last line of each function in that pathname.
    foreach(QString pathname,pathList)
    {
        // read the contents of the file into a stringlist
        QFile file(pathname);
        if(!file.exists()) continue;
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) continue;
        QString text(file.readAll());
        file.close();
        text = text.remove('\r');
        QStringList textList = text.split('\n');

        // find last line of the function for functions with this pathanme
        for(int i=0;i<funcList.size();i++)
        {
            Tag *tag = funcList.at(i);
            if(tag->pathname == pathname)
                tag->lastline = findLastLineOfFunction(&textList,tag->name,tag->firstline);
        }
    }

    // populate the functions lists
    functionList.clear();
    memberFunctionList.clear();
    funcList.append(protoList);
    foreach(Tag *tag,funcList)
    {
        if(tag->containerName.isEmpty())
            functionList.append(tag);
        else
            memberFunctionList.append(tag);
    }
    /*
    // Delete prototypes at this point because they are (currently) no longer useful.
    // The needed information from paired prototypes has been included in the function items.
    // With ctags any function call that is made in the code will show up as a prototype.
    // So we have lots of duplicate prototypes that aren't actually prototypes, they are
    // just function calls. Maybe that will be useful for some future feature, but not now.
    for(int i=0;i<tagItems.size();i++)
    {
        Tag *tag = tagItems.at(i);
        if(tag->tagType == Tag::Prototype)
        {
            tagItems.removeAt(i--);
            delete tag;
        }
    }
*/
}

//!-----------------------------------------------------------------------------
//! \brief  Populate externList with externals. We don't know much about what
//!         an external is, could be a variable, could be a function.
//!-----------------------------------------------------------------------------
void Indexer::populateExternList()
{
    externList.clear();
    foreach(Tag *tag,tagItems)
    {
        if(tag->tagType == Tag::Extern)
            externList.append(tag);
    }

    // TODO: maybe look at scanning the tagItems to try and pair them
    /*    foreach(Tag *tag,externList)
    {
        foreach(Tag *t,tagItems)
        {
            if((t->name == tag->name) && (t != tag))
            {
                qDebug() << "duplicate extern name";
            }
        }
    }
*/
}

//!-----------------------------------------------------------------------------
//! \brief  Support function for createFunctionList. Finds the last line in a function.
//!         This will be useful information for the ide trying to decide what
//!         variables are in-scope.
//!
//! \param textlist      String List containing text to search.
//! \param functionName  Name of the function to search for.
//! \param firstline     Line number (not zero based) that the function start on.
//!
//! \return  Functions ending line number or last line in file if not found or
//!          -1 if error occurs.
//!-----------------------------------------------------------------------------
int Indexer::findLastLineOfFunction(QStringList *textlist, QString &functionName, int firstline)
{
    int numlines = textlist->size();
    int i = firstline-1;
    if(i >= numlines) return -1;
    if(i < 0) return -1;

    // get the index of the function name
    QString name = functionName;
    QStringList split = name.split("::");
    if(split.size() > 1)
        name = split.last();
    QString lineText = textlist->at(i);
    int index = lineText.indexOf(name);
    if (index == -1) return -1;

    // look for the opening brace, start looking at the start of the function name
    int bi;
    do{
        bi = textlist->at(i).indexOf('{',index);
        // if no opening brace is found, move to the next line
        if(bi == -1)
        {
            index = 0;
            i++;
        }
    }while((bi == -1) && (i < numlines));
    if(bi == -1) return -1;

    // bi is the character index of the opening brace, i is the line index in the list

    // search for the closing brace
    int j = bi + 1;
    int cnt = 1;
    int len = textlist->at(i).length();
    while((cnt > 0) && (i < numlines))
    {
        if(j >= len)
        {
            j = 0;
            i++;
            if(i >= numlines) break;
            len = textlist->at(i).length();
        }
        if(len > 0)
        {
            if(textlist->at(i).at(j) == '{')
                cnt++;
            else if(textlist->at(i).at(j) == '}')
                cnt--;
        }
        j++;
    }
    return i+1; // return non-zero index line number
}

//!----------------------------------------------------------------------------
//! \brief  Format function/prototype parameter list so that it's consistently
//!         formatted. Remove any defaults set in the parameter list. This is
//!         so we can exactly match the prototype and function parameter lists
//!         to correctly link them together when utilizing the switch from
//!         implementaton to defintion feature in the ide.
//!----------------------------------------------------------------------------
QString Indexer::formatFuncParameters(QString param)
{    
    // create minimum consistent spacing, multiple spaces will be elimiated before returning.
    // add minimum of one space around parenthesis
    param.replace("(","( ");
    param.replace(")"," )");
    // add minimum of one space around commas
    param.replace(","," , ");
    // add minimum of one space around array brackets
    param.replace("["," [ ");
    param.replace("]"," ] ");
    // add minimum of one space around astericks
    param.replace("*"," * ");

    // reduce multiple space to one
    param = param.simplified();
    // make multiple astericks contiguous
    for(int i=2;i<param.length();i++)
    {
        QChar c0 = param.at(i-2);
        QChar c1 = param.at(i-1);
        QChar c2 = param.at(i);
        if(c0=='*' && c1==' ' && c2=='*')
            param = param.remove(i-1,1);
    }
    // remove any defaults that may be in a prototype param list
    bool done = false;
    while(!done)
    {
        int i = param.indexOf('=');
        if(i == -1)
            done = true;
        else
        {
            int j = param.indexOf(',',i+1);
            if(j == -1)
                j = param.indexOf(')',i+1);
            if(j == -1)
                return param.simplified(); // shouldn't ever happen, but hey..
            param = param.remove(i,j-i);
        }
    }
    // reduce multiple space to one
    return param.simplified();
}



//!----------------------------------------------------------------------------
//! \brief  Returns the tag that has the given name.
//!----------------------------------------------------------------------------
Tag *Indexer::getTagFromName(QString name)
{
    return tagHash.value(name);
}

//!----------------------------------------------------------------------------
//! \brief  Returns a list of tags that are candidates for completion.
//!
//!
//!----------------------------------------------------------------------------
QList<Tag *> Indexer::getCompletions(QString prefixString, QString pathname, int line)
{
    prefixString.replace(".","::");
    prefixString.replace("->","::");
    QStringList prefixList = prefixString.split("::");
    if(prefixList.isEmpty()) return QList<Tag*>();
    if((prefixList.size() == 1) && (prefixString.length() < 2)) return QList<Tag*>();

    // get the tag for the function we are in if we are in a function.
    Tag *funcTag = getFunctionForScope(pathname,line);
    // if we are in a class function get the container name.
    bool showClassMembers = true;
    QString funcContainerName;
    if(funcTag != NULL)
    {
        funcContainerName = funcTag->containerName;
        // if we are not in a class function and there is only one item in the prefix then
        // don't show class members. We will show them if there are more items
        // in the prefix, including a blank second item in which case we will list all members
        // for example myClass. or this->
        if((funcTag->containerType != Tag::Class) && (prefixList.size() == 1))
            showClassMembers = false;
    }

    // start with tags that are in "view". In "view" covers tags that are in-scope (globals
    // in-scope or locals in our current function) as well as members that are visible due to header files.
    QStringList pathnameList = getIndexedPaths();
    QHash<QString,Tag*> hash = getTagsInScope(pathname,pathnameList,line);

    // fields before the final field must be case-sensitive exact matches
    for(int i=0;i<(prefixList.size()-1);i++)
    {
        // see if we have any tags in our hash with a matching name
        QList<Tag*> tags;
        // if the first item in the prefix is the "this" keyword we only want this classes class members.
        if((i==0) && (prefixList.at(i) == "this"))
        {
            if(funcTag == NULL) return QList<Tag*>();
            if(funcTag->containerType != Tag::Class) return QList<Tag*>();
            // get the tags that start with the functions containerName, the class
            // members will be added a little farther down.
            tags = hash.values(funcTag->containerName);
        }
        // otherwise use word matching
        else
            tags = hash.values(prefixList.at(i));

        // the first item cannont be a child member of a container unless it's a
        // member of a class and we are in one of that classes functions.
        if(i==0)
        {
            QList<Tag*> mtags;
            foreach(Tag *mtag,tags)
            {
                if(mtag->containerName.isEmpty() || (mtag->containerName == funcContainerName))
                    mtags.append(mtag);
            }
            tags.clear();
            tags.append(mtags);
        }

        if(tags.size() == 0) return QList<Tag*>();
        Tag *tag = NULL;
        if(tags.size() == 1)
            tag = tags.first();
        else
        {
            // there's more than one tag that matches.
            // we need to pick the appropriate one. elimiate out of scope tags, elimiate constructors.
            // need to modify the search to deal with functions
            foreach(Tag *t,tags)
            {
                tag = t;
                // heirarchy order: local, member, global, extern, other
                if(tag->tagType == Tag::LocalVar) break;
                if(tag->tagType == Tag::Class) break;
                if(tag->tagType == Tag::GlobalVar) break;
                if(tag->tagType == Tag::Extern) break;
                if(tag->tagType == Tag::Structure) break;
                if(tag->tagType == Tag::Union) break;
            }
        }

        // create a list of tags that have the identified tags varType, this is going
        // to add all the members of a class tag.
        QList<Tag*> varTags = tagHash.values(tag->varType);
        // add all the tags that have a typeRefName = tag->varType, this is going to add
        // all members of a structure/union tag.
        varTags.append(typeRefHash.values(tag->varType));
        if(varTags.size() == 0) return QList<Tag*>();
        Tag *varTag = NULL;
        if(varTags.size() == 1)
            varTag = varTags.first();
        else
        {
            foreach(Tag *t,varTags)
            {
                // need to pick the appropriate one.
                varTag = t;
                if(varTag->tagType == Tag::LocalVar) break;
                if(varTag->tagType == Tag::Class) break;
                if(varTag->tagType == Tag::GlobalVar) break;
                if(varTag->tagType == Tag::Extern) break;
                if(varTag->tagType == Tag::Structure) break;
                if(varTag->tagType == Tag::Union) break;
            }
        }
        // for the next iterration the hash needs to contain the varTag members and inherited members
        hash = getAllMembers(varTag);
        if(hash.size() == 0) return QList<Tag*>();
    }

    // the final field is case-insenstive and looks for a startsWith match
    QList<Tag*> ret;
    QString prefix = prefixList.last().toLower();
    QList<Tag*> tags = hash.values();

    // in the case that we are looking for members by (for example) pressing '.' but
    // haven't entered any further characters.
    if(prefix.isEmpty())
        return tags;

    foreach(Tag *tag,tags)
    {
        if(!showClassMembers && (tag->containerType == Tag::Class)) continue;

        if(!tag->containerName.isEmpty() && (prefixList.size() == 1))
        {
            if(tag->containerName != funcContainerName) continue;
        }
        // if the tag starts with the prefix then add it to the list.
        if(tag->name.toLower().startsWith(prefix))
            ret.append(tag);
    }
    return ret;
}

//!----------------------------------------------------------------------------
//! \brief  Return the tag for the function we are in if we are on a given line
//!         in a given pathname, or NULL if none found.
//!----------------------------------------------------------------------------
Tag* Indexer::getFunctionForScope(QString pathname, int line)
{
    // first check raw functions
    foreach(Tag *tag,functionList)
    {
        if(tag->pathname == pathname)
        {
            if((tag->firstline <= line) && (tag->lastline >= line))
                return tag;
        }
    }

    // next check class functions
    foreach(Tag *tag,memberFunctionList)
    {
        if(tag->pathname == pathname)
        {
            if((tag->firstline <= line) && (tag->lastline >= line))
                return tag;
        }
    }
    return NULL;
}

//!----------------------------------------------------------------------------
//! \brief  Return a subset of tags that are in scope, if any.
//!----------------------------------------------------------------------------
QHash<QString,Tag*> Indexer::getTagsInScope(QString pathname, QStringList headerPaths, int line)
{
    QList<Tag*> list;
    QList<Tag*> locals;

    if(headerPaths.contains(pathname))
        headerPaths.removeOne(pathname);

    // get the tag for the function we are in if any.
    Tag *func = getFunctionForScope(pathname,line);

    foreach(Tag *tag,tagItems)
    {
        // if the tag is a local it must be in our current function above or at our current line.
        if((tag->tagType == Tag::LocalVar) && (func != NULL))
        {
            if((tag->pathname == func->pathname) && (tag->line >= func->firstline) && (tag->line <= func->lastline) && (tag->line <= line))
                locals.append(tag);
        }
        // if the tag is in our pathname but is not a local it must be defined above or at our line.
        else if(tag->pathname == pathname)
        {
            if(tag->line <= line)
                list.append(tag);
        }
        // if it's not in our pathname but it's in a header file use it.
        else if(headerPaths.contains(tag->pathname))
            list.append(tag);
    }

    // create hash of everything except locals
    QHash<QString,Tag*> hash;
    foreach(Tag *tag,list)
        hash.insertMulti(tag->name,tag);

    // any hash entries that have the same name as a local that made it this far should be eliminated
    // because the local will override the other entries.
    foreach(Tag *tag,locals)
        hash.remove(tag->name);

    // add locals to hash
    foreach(Tag *tag,locals)
        hash.insertMulti(tag->name,tag);

    return hash;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QList<Tag *> Indexer::getTagsForStatement(QString statement, QString pathname, const QStringList &pathnameList, int line)
{
    if(statement.isEmpty()) return QList<Tag*>();

    // split the statement on part seperators . -> ::
    statement.replace(".","::");
    statement.replace("->","::");
    QStringList partList = statement.split("::");
    if(partList.isEmpty()) return QList<Tag*>();

    // limit the initial tags to tags that are in-scope.
    QHash<QString,Tag*> hash = getTagsInScope(pathname,pathnameList,line);

    // go through each part of the statement
    for(int i=0;i<partList.size();i++)
    {
        QString part = partList.at(i);
        // get tags from the hash that match this part of the statement
        QList<Tag*> tags = hash.values(part);

        // if there are no matches return an empty list
        if(tags.size() == 0) return QList<Tag*>();
        // if this is the last part return the tags that match
        if(i == (partList.size()-1)) return tags;

        // If we get this far we have at least another iteration to go which means the tags
        // must be containers. If there are not, eliminate them.

        // clear the hash and load it with the tags that are children of the matching tags,
        // these are the cadidates for the next pass.
        hash.clear();
        foreach(Tag *tag,tags)
        {
            // get the tag for the variable type for this tag
            QList<Tag*> subtags = tagHash.values(tag->varType);
            // the subtags can include class constructors, remove constructors from list
            for(int j=0;j<subtags.size();j++)
            {
                Tag *stag = subtags.at(j);
                if(stag->name == stag->containerName)
                    subtags.removeAt(j--);
            }
            if(subtags.size() > 1)
                qDebug() << "this is a problem.";
            if(subtags.size() == 0) continue;
            // add all the children
            hash = getAllMembers(subtags.at(0));
        }
    }

    // will never get here
    return QList<Tag*>();
}

//!----------------------------------------------------------------------------
//! \brief  Returns a hash of all tag members and inherited members excluding
//!         constructors and destructors.
//!----------------------------------------------------------------------------
QHash<QString,Tag*> Indexer::getAllMembers(Tag *tag)
{
    if(tag == NULL) return QHash<QString,Tag*>();
    QHash<QString,Tag*> hash;
    foreach(Tag *m,tag->members)
    {
        // ignore constructors and destructors
        if(m->name.startsWith('~')) continue;
        if(m->name == tag->name) continue;
        hash.insertMulti(m->name,m);
    }
    foreach(Tag *itag,tag->inherits)
    {
        QHash<QString,Tag*> ihash = getAllMembers(itag);
        QHash<QString,Tag*>::iterator i;
        for(i = ihash.begin(); i != ihash.end(); i++)
            hash.insertMulti(i.key(),i.value());
    }
    return hash;
}

//!----------------------------------------------------------------------------
//! \brief  Returns a new QTreeWidgetItem for a given tag.
//!----------------------------------------------------------------------------
QTreeWidgetItem *Indexer::newTreeTag(Tag *tag)
{
    QTreeWidgetItem* item = new QTreeWidgetItem;

    item->setData(0,Qt::UserRole+1,QVariant::fromValue<Tag*>(tag));
    item->setIcon(0,Tag::getIcon(tag));

    switch(tag->tagType)
    {
    case Tag::Function:
        item->setText(0,tag->name + " " + tag->funcParameters);
        break;
    case Tag::Prototype:
        item->setText(0,tag->name + "  " + tag->protoParameters);
        break;
    default:
        item->setText(0,tag->name);
        break;
    }
    return item;
}

//!----------------------------------------------------------------------------
//! \brief  Populates a QTreeWidget with the items in the indexer, excluding
//!         local variables.
//!----------------------------------------------------------------------------
void Indexer::populateTreeUsingGroups(QTreeWidget *tree)
{
    tree->clear();

    // -------- add containers to tree ----------
    // classes
    QTreeWidgetItem* classes = NULL;
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Class) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            if(tag->tagType == Tag::Prototype) continue;
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        if(classes == NULL)
        {
            classes = new QTreeWidgetItem;
            classes->setText(0,"Classes");
        }
        classes->addChild(item);
    }
    if(classes != NULL)
        tree->addTopLevelItem(classes);

    // structures
    QTreeWidgetItem* structures = NULL;
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Structure) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        if(structures == NULL)
        {
            structures = new QTreeWidgetItem;
            structures->setText(0,"Structures");
        }
        structures->addChild(item);
    }
    if(structures != NULL)
        tree->addTopLevelItem(structures);


    // unions
    QTreeWidgetItem* unions = NULL;
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Union) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        if(unions == NULL)
        {
            unions = new QTreeWidgetItem;
            unions->setText(0,"Unions");
        }
        unions->addChild(item);
    }
    if(unions != NULL)
        tree->addTopLevelItem(unions);

    // -------- functions ----------
    QTreeWidgetItem *functions = NULL;
    foreach(Tag *tag,functionList)
    {
        if(tag->tagType == Tag::Prototype) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        if(functions == NULL)
        {
            functions = new QTreeWidgetItem;
            functions->setText(0,"Functions");
        }
        functions->addChild(item);
    }
    if(functions != NULL)
        tree->addTopLevelItem(functions);

    // global variables, we're not going to show locals
    QTreeWidgetItem *globals = NULL;
    foreach(Tag *tag,globalVariableList)
    {
        QTreeWidgetItem* item = newTreeTag(tag);
        if(globals == NULL)
        {
            globals = new QTreeWidgetItem;
            globals->setText(0,"Globals");
        }
        globals->addChild(item);
    }
    if(globals != NULL)
        tree->addTopLevelItem(globals);

    // add tyepdefs
    QTreeWidgetItem *typedefs = NULL;
    foreach(Tag *tag,typedefList)
    {
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        if(typedefs == NULL)
        {
            typedefs = new QTreeWidgetItem;
            typedefs->setText(0,"Typedefs");
        }
        typedefs->addChild(item);
    }
    if(typedefs != NULL)
        tree->addTopLevelItem(typedefs);

    // add macros
    QTreeWidgetItem* macros = NULL;
    foreach(Tag *tag,tagItems)
    {
        if(tag->tagType == Tag::Macro)
        {
            QTreeWidgetItem* item = newTreeTag(tag);
            if(macros == NULL)
            {
                macros = new QTreeWidgetItem;
                macros->setText(0,"Macros");
            }
            macros->addChild(item);
        }
    }
    if(macros != NULL)
        tree->addTopLevelItem(macros);
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Indexer::populateTreeContainerMembers(QTreeWidgetItem* item, Tag *tag)
{
    foreach(Tag *m,tag->members)
    {
        QTreeWidgetItem* subitem = newTreeTag(m);
        item->addChild(subitem);
        if(m->members.size() > 0)
            populateTreeContainerMembers(subitem,m);
        else if(!m->typeRefName.isEmpty())
        {
            // find the container with typeRefName
            //            qDebug() << "this is a container member.";

        }
    }
}

//!----------------------------------------------------------------------------
//! \brief  Populates a QTreeWidget with the items in the indexer, excluding
//!         local variables.
//!----------------------------------------------------------------------------
void Indexer::populateTree(QTreeWidget *tree)
{
    // QTreeWidget::clear() removes all existing items from the tree and deletes them.
    // This deletes the tree items, but not the tags.
    QList<QTreeWidgetItem *> itemList;

    // classes
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Class) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            if(m->tagType == Tag::Prototype) continue;
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        itemList << item;
    }

    // structures
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Structure) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        populateTreeContainerMembers(item,tag);
        itemList << item;
    }

    // unions
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Union) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        itemList << item;
    }


    // -------- functions ----------
    foreach(Tag *tag,functionList)
    {
        if(tag->tagType == Tag::Prototype) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        itemList << item;
    }

    // global variables, we're not going to show locals
    foreach(Tag *tag,globalVariableList)
    {
        QTreeWidgetItem* item = newTreeTag(tag);
        itemList << item;
    }

    // add tyepdefs
    foreach(Tag *tag,typedefList)
    {
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        itemList << item;
    }
    /*
    // add macros
    QTreeWidgetItem* macroContainer = new QTreeWidgetItem();
    macroContainer->setText(0,"Defines");
    foreach(Tag *tag,tagItems)
    {
        if(tag->tagType == Tag::Macro)
        {
            QTreeWidgetItem* item = newTreeTag(tag);
            macroContainer->addChild(item);
        }
    }
    if(macroContainer->childCount() > 0)
        itemList << macroContainer;
    else
        delete macroContainer;
*/
    tree->clear();
    tree->addTopLevelItems(itemList);
}

//!----------------------------------------------------------------------------
//! \brief  Populates a QTreeWidget with the items in the indexer that are in
//! the specified filename, excluding local variables. This is used for
//! File index viewing.
//!----------------------------------------------------------------------------
void Indexer::populateTree(QTreeWidget *tree, QString pathname)
{
    qDebug() << "Indexer::populateTree " << pathname;
    // QTreeWidget::clear() removes all existing items from the tree and deletes them.
    // This deletes the tree items, but not the tags.
    QList<QTreeWidgetItem *> itemList;

    // -------- add containers to tree ----------
    // class members
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Class) continue;
        // add members
        foreach(Tag *m,tag->members)
        {
            if((m->tagType == Tag::Function) || (m->tagType == Tag::Prototype))
            {
                if((m->pathname!=pathname) && (m->protoPathname!=pathname))
                    continue;
            }
            else
                if(m->pathname != pathname) continue;
            QTreeWidgetItem* item = newTreeTag(m);
            QString memberName = m->containerName + "::" + item->text(0);
            item->setText(0,memberName);
            itemList << item;
        }
    }

    // structures
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Structure) continue;
        if(tag->pathname != pathname) continue;

        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        itemList << item;
    }

    // unions
    foreach(Tag *tag,containerList)
    {
        if(tag->tagType != Tag::Union) continue;
        if(tag->pathname != pathname) continue;

        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        itemList << item;
    }

    // -------- functions ----------
    foreach(Tag *tag,functionList)
    {
        if((tag->pathname != pathname) && (tag->protoPathname != pathname)) continue;
        // don't show prototypes that don't have corresponding implementation
        if(tag->tagType == Tag::Prototype) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        itemList << item;
    }

    // global variables, we're not going to show locals
    foreach(Tag *tag,globalVariableList)
    {
        if(tag->pathname != pathname) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        itemList << item;
    }
    /*
    // add externals and defines, put defines in a container
    QTreeWidgetItem* macroContainer = new QTreeWidgetItem();
    macroContainer->setText(0,"Defines");
    foreach(Tag *tag,tagItems)
    {
        if(tag->pathname != pathname) continue;
        if(tag->tagType == Tag::Macro)
        {
            QTreeWidgetItem* item = newTreeTag(tag);
            macroContainer->addChild(item);
        }
        else if(tag->tagType == Tag::Extern)
        {
            QTreeWidgetItem* item = newTreeTag(tag);
            itemList << item;
        }
    }
    if(macroContainer->childCount() > 0)
        itemList << macroContainer;
    else
        delete macroContainer;
*/
    // add typedefs
    foreach(Tag *tag,typedefList)
    {
        if(tag->pathname != pathname) continue;
        QTreeWidgetItem* item = newTreeTag(tag);
        // add members
        foreach(Tag *m,tag->members)
        {
            QTreeWidgetItem* subitem = newTreeTag(m);
            item->addChild(subitem);
        }
        itemList << item;
    }

    tree->clear();
    tree->addTopLevelItems(itemList);
}

///-----------------------------------------------------------------------------
/// \brief  Start indexing a list of filepaths. When indexing is complete
/// the signal indexingComplete will be emitted.
///-----------------------------------------------------------------------------
bool Indexer::indexProject(Project *project, TabManager *tabManager)
{
    // return false if this indexer is already running.
    if(ctagsProcess != NULL)
    {
        qDebug() << "ctagsProcess != NULL";
        return false;
    }

    if(project == NULL) return false;
    if(tabManager == NULL) return false;
    prj = project;

    QStringList pathnames;

    // get a list of all the source files in the project
    QStringList fileList;
    fileList.append(project->getSourceFiles());
    fileList.append(project->getHeaderFiles());
    pathnameList.clear();
    sourceList.clear();
    foreach(QString filepath,fileList)
        pathnameList.append(FileUtility::replaceKeyWithPath(project,filepath));
    sourceList = pathnameList;

    // if there are no files don't do anything
    if(pathnameList.isEmpty())
        return true;

    pathnames.append(pathnameList);

    // deal with open dirty files for this project
    pathReplacementList.clear();
    for(int i=0;i<tabManager->count();i++)
    {
        if(project->getProjectFolder() == tabManager->getTabProjectFolder(i))
        {
            QString name = tabManager->tabText(i);
            if(name.endsWith(STR_DIRTY_FILE))
            {
                // save dirty text to a temporary file
                QString pathname = tabManager->getTabPathname(i);
                QString ext = pathname.right(pathname.length()-pathname.lastIndexOf('.'));
                QString tempPathname = FileUtility::getUniqueTempFilename(ext);
                // save pathname pair; original name first, temporary name second.
                pathReplacementList.append(pathname);
                pathReplacementList.append(tempPathname);
                // remove original filepath from list
                int j = pathnames.indexOf(pathname);
                if(j != -1) // should never be -1
                    pathnames.removeAt(j);
                // add temporary filepath to list
                pathnames.append(tempPathname);
                // save dirty file text to the temporary file
                QString text = tabManager->getEditor(i)->text();
                QFile textFile(tempPathname);
                if(!textFile.open(QIODevice::WriteOnly | QIODevice::Text))
                {
                    qDebug() << "*** ERROR OPENING INDEXER WRITE FILE";
                    return false;
                }
                QTextStream tout(&textFile);
                tout << text;
                textFile.close();
            }
        }
    }

    // run ctags
    QString ctagsOptions = "--c-kinds=+px --c++-kinds=+px --fields=+iasSn --language-force=C++ --c-types=lvfpcmsutxged --c++-types=lvfpcmsutxged";
    bool ret = runCtags(pathnames,ctagsOptions);
    return ret;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
bool Indexer::processText(Project *project, QString pathname, SourceEditor *editor, bool processIncludes)
{
    //    Project *prj = project;
    prj = project;
    if(prj == NULL) return false;
    if(editor == NULL) return false;
    if(ctagsProcess != NULL)
    {
        qDebug() << "ctagsProcess != NULL";
        return false;
    }
    QString text = editor->text();
    Target target = prj->getTarget();

    QStringList textList = text.split('\n');
    pathname = FileUtility::replaceKeyWithPath(prj,pathname);

    sourceList.clear();
    sourceList.append(pathname);

    // save text to a temporary file
    QString ext = pathname.right(pathname.length()-pathname.lastIndexOf('.'));
    QString tempPathname = FileUtility::getUniqueTempFilename(ext);
    QFile textFile(tempPathname);
    if(!textFile.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug() << "*** ERROR OPENING INDEXER WRITE FILE";
        return false;
    }
    QTextStream tout(&textFile);
    tout << text;
    textFile.close();
    // save pathname pair; original name first, temporary name second.
    pathReplacementList.clear();
    pathReplacementList.append(pathname);
    pathReplacementList.append(tempPathname);

    // create a list that contains all the located pathnames from #include statements in this text
    // as well as those included and located via the #include statements in the #included files.
    pathnameList.clear();
    if(processIncludes)
    {
        // get a list of all include directories for this project
        includePaths = prj->getIncludeFolders();
        includePaths.append(target.getExternalIncludeFolders());

        for(int i=0;i<includePaths.size();i++)
            includePaths.replace(i,FileUtility::replaceKeyWithPath(prj,includePaths.at(i)));
        // make sure the project folder itself is included
        includePaths.prepend(FileUtility::replaceKeyWithPath(prj,prj->getProjectFolder()));
        // make sure the path that this file is in is included
        QFileInfo pinfo(pathname);
        includePaths.prepend(pinfo.path());
        // remove duplicate paths
        includePaths.removeDuplicates();
        findHeadersInText(&textList);
    }

    pathnameList.append(tempPathname);
    pathnameList.removeDuplicates();

    // run ctags
    QString ctagsOptions = "--c-kinds=+px --c++-kinds=+px --fields=+iasSn --language-force=C++ --c-types=lvfpcmsutxged --c++-types=lvfpcmsutxged";
    bool ret = runCtags(pathnameList,ctagsOptions);
    return ret;
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void Indexer::replacePathname(QString oldPathname, QString newPathname)
{
    QStringList *list = new QStringList;
    oldPathname = "\t" + oldPathname + "\t";
    newPathname = "\t" + newPathname + "\t";

    for(int i=0;i<tagList.size();i++)
    {
        QString s = tagList.at(i);
        if(s.contains(oldPathname))
            s = s.replace(oldPathname,newPathname);
        list->append(s);
    }
    tagList.clear();
    tagList.append(*list);
    list->clear();
    delete list;
}


///-----------------------------------------------------------------------------
/// \brief   Searches through the directories specified in "includePaths" list for
///          the specified filename. If the file is found returns a full pathname,
///          if it's not found returns and empty string.
///-----------------------------------------------------------------------------
QString Indexer::findPathname(const QString &filename)
{
    foreach(QString path,includePaths)
    {
        QString pathname = path + "/" + filename;
        QFileInfo info(pathname);
        if(info.exists())
            return pathname;
    }
    return QString();
}

///-----------------------------------------------------------------------------
/// \brief   Search for the file specified by "filename" and the class list
///          "includePaths", if found read in the file text and process it to
///          append "pathnameList" with all the found #include files.
///-----------------------------------------------------------------------------
void Indexer::findHeadersInFile(const QString &filename)
{
    // see if we can find the file specified. this is done by searching the
    // projects include directory list for the file. If found, read in the files
    // contents, then call the overloaded version of this function to process
    // the contents.

    QString pathname = findPathname(filename);
    if(pathname.isEmpty()) return;

    // if we have already processed this file just return. This is very
    // important so we avoid infinite recursive loops because we are not
    // processing #ifndef statements.
    if(pathnameList.contains(pathname)) return;

    // read the contents of the file into a stringlist
    QFile file(pathname);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    // create a new list to hold the contents
    QStringList *textList = new QStringList;
    if(textList == NULL) return;
    QTextStream in(&file);
    while(!in.atEnd()) {
        QString line = in.readLine();
        textList->append(line);
    }
    file.close();

    // add the file pathname to the list
    pathnameList.append(pathname);
    // process the contents of the file
    findHeadersInText(textList);
    // free memory
    textList->clear();
    delete textList;
}

///-----------------------------------------------------------------------------
/// \brief   Search through list for #include statements. If found then
///          call processFile to search for the full pathname and process the
///          file. If it's found it gets added to the output list of include file
///          pathanames. processFile will then call this function (ie recursive)
///          to process the contents of the found file. When we are done
///          "pathnameList" will contain a list of all the include pathnames
///          found.
///-----------------------------------------------------------------------------
void Indexer::findHeadersInText(QStringList *textList)
{
    // go through each line looking for #include statements.
    foreach(QString str, *textList)
    {
        // remove any leading and trailing whitespace
        str = str.trimmed();

        // look for #include statements
        if(str.startsWith("#include"))
        {
            str = str.remove("#include");
            // remove any whitespace between #include and start of filename statement
            str = str.trimmed();

            // #include "filename" scenario
            if(str.startsWith('"'))
            {
                // remove leading "
                str = str.right(str.length()-1);
                // find ending " and trim remaining
                int i = str.indexOf('"');
                if(i != -1)
                {
                    str = str.left(i);
                    str = str.trimmed();
                    // process this file
                    findHeadersInFile(str);
                }
            }
            // #include <filename> scenario
            else if(str.startsWith('<'))
            {
                // remove leading <
                str = str.right(str.length()-1);
                // find ending > and trim remaining
                int i = str.indexOf('>');
                if(i != -1)
                {
                    str = str.left(i);
                    str = str.trimmed();
                    // process this file
                    findHeadersInFile(str);
                }
            }
        }
    }
}

///-----------------------------------------------------------------------------
/// \brief   Create a list of tags from source and header files by running ctags.
///
/// \return  true = success, false = failure.
///-----------------------------------------------------------------------------
bool Indexer::runCtags(QStringList fileList, QString options)
{
    // return false if this indexer is already running.
    if(ctagsProcess != NULL)
    {
        if(ctagsProcess->isOpen())
            return false;
    }
    tagList.clear();

    // write the list of filepaths to a temp input file
    ctagsInputFilename = FileUtility::getUniqueTempFilename();
    if(ctagsInputFilename.isEmpty()) return false;
    QFile listFile(ctagsInputFilename);
    if(!listFile.open(QIODevice::WriteOnly | QIODevice::Text)) return false;
    QTextStream out(&listFile);
    foreach(QString str,fileList)
        out << str << "\n";
    listFile.close();

    // get a unique-name temporary filename for the output
    ctagsOutputFilename = FileUtility::getUniqueTempFilename();
    if(ctagsInputFilename.isEmpty())
    {
        listFile.remove();
        return false;
    }

    // run ctags...
    QString cmd = "\"" + FileUtility::getDirTools() + "/ctags\"";
    QString homeFolder = FileUtility::getDirHome();
    cmd += " " + options + " -f \"" + ctagsOutputFilename + "\" -L \"" + ctagsInputFilename + "\"";

    // console->appendLine(cmd);
    ctagsProcess = new QProcess(this);
    ctagsProcess->setWorkingDirectory(homeFolder);
    connect(ctagsProcess,SIGNAL(finished(int)),this,SLOT(ctagsFinished(int)));
    running = true;
    ctagsProcess->start(cmd);

    return true;
}

///-----------------------------------------------------------------------------
/// \brief  Slot called when ctags command line process finishes.
///-----------------------------------------------------------------------------
void Indexer::ctagsFinished(int exitcode)
{
    Q_UNUSED(exitcode);

    // clean up memory
    ctagsProcess->deleteLater();
    ctagsProcess = NULL;

    // delete temorary file holding filenames to process
    QFile listFile(ctagsInputFilename);
    if(listFile.exists()) listFile.remove();

    // load tags created
    QFile file(ctagsOutputFilename);
    if(!file.exists())
    {
        // do something to indicate the file doesn't exist
        running = false;
        emit indexingComplete();
        return;
    }
    if (file.open(QIODevice::ReadOnly))
    {
        QTextStream in(&file);
        while ( !in.atEnd() )
        {
            QString line = in.readLine();
            // populate tagList with data returned by ctags, strip out comment lines
            if(!line.startsWith("!"))
                tagList.append(line);
        }
        file.close();
    }
    // delete output file
    file.remove();
    // replace temporary filepaths with the actual filepaths in the tags, remove temporary files while we're at it.
    if(!pathReplacementList.isEmpty())
    {
        for(int i=0;i<pathReplacementList.length();)
        {
            QString actualName = pathReplacementList.at(i++);
            QString tempName = pathReplacementList.at(i++);
            replacePathname(tempName,actualName);
            // delete temporary source file
            if(!tempName.isEmpty())
            {
                QFile tempSourceFile(tempName);
                if(tempSourceFile.exists())
                    tempSourceFile.remove();
            }
        }
    }

    // last but not least parse the tags
    parseTags();

    running = false;
    emit indexingComplete();
}
