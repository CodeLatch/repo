#include "ceditor.h"
#include <QtGui>
#include <QDebug>

//!----------------------------------------------------------------------------
//!                     BlockData - class definition
//!----------------------------------------------------------------------------

class BlockData: public QTextBlockUserData
{
public:
    QList<int> bracketPositions;
    QList<int> parenthesisPositions;
    bool breakpoint;
};

//!----------------------------------------------------------------------------
//!
//!                     Highlighter - class defintion
//!
//!----------------------------------------------------------------------------
class Highlighter : public QSyntaxHighlighter
{
public:
    Highlighter(QTextDocument *parent = 0);
    void setColor(CodeEditor::ColorComponent component, const QColor &color);

    QStringList getKeywords() const;
    void setKeywords(const QStringList &getKeywords);
    int blockState();

protected:
    void highlightBlock(const QString &text);

private:
    QSet<QString> keywordSet;
    QSet<QString> knownIdSet;
    QHash<CodeEditor::ColorComponent, QColor> colorHash;
};

//!----------------------------------------------------------------------------
//!
//!                    MarginWidget - class definition
//!
//!----------------------------------------------------------------------------

class MarginWidget : public QWidget
{
public:
    struct BlockInfo
    {
        int position;
        int number;
    };

    MarginWidget(CodeEditor *editor);
    QVector<BlockInfo> lineNumbers;
    QColor backgroundColor;
    QColor lineNumberColor;
    QColor indicatorColor;
    QFont font;
    int debugMarkerWidth;
    QPixmap rightArrowIcon;
    QPixmap downArrowIcon;
    QImage debugMarkerImage;
protected:
    void mousePressEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);
};


//!----------------------------------------------------------------------------
//!
//!                    Highlighter - class implementation
//!
//!----------------------------------------------------------------------------

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Highlighter::Highlighter(QTextDocument *parent)
    : QSyntaxHighlighter(parent)
{
    // default color scheme
    /*    colorHash[CodeEditor::Normal]     = QColor("#000000");
    colorHash[CodeEditor::Comment]    = QColor("#808080");
    colorHash[CodeEditor::Number]     = QColor("#008000");
    colorHash[CodeEditor::String]     = QColor("#800000");
    colorHash[CodeEditor::Operator]   = QColor("#808000");
    colorHash[CodeEditor::Identifier] = QColor("#000020");
    colorHash[CodeEditor::Keyword]    = QColor("#000080");
    colorHash[CodeEditor::BuiltIn]    = QColor("#008080");
    colorHash[CodeEditor::Marker]     = QColor("#ffff00");
*/
    colorHash[CodeEditor::Background]    = QColor("#ffffff"); // paper
    colorHash[CodeEditor::Normal]        = QColor("#000000"); // plain text
    colorHash[CodeEditor::Comment]       = QColor("#108010"); // comment
    colorHash[CodeEditor::Number]        = QColor("#FF7F00"); // number
    colorHash[CodeEditor::String]        = QColor("#a03030"); // string
    colorHash[CodeEditor::Operator]      = QColor("#1111FF"); // {}[]()+-#.*=/;:
    colorHash[CodeEditor::Identifier]    = QColor("#00FFFF"); // anything that starts with alpha or _ that's not a string, keyword, or knownid
    colorHash[CodeEditor::Keyword]       = QColor("#6A5ACD"); // m_keywords list
    colorHash[CodeEditor::BuiltIn]       = QColor("#1874CD"); // m_knownIds list
    colorHash[CodeEditor::Cursor]        = QColor("#FFFFC0"); // current line highlight color
    colorHash[CodeEditor::Marker]        = QColor("#DBF76C"); // word marker highlight color
    colorHash[CodeEditor::BracketMatch]  = QColor("#AFFF9C"); // matching brackets highlight color
    colorHash[CodeEditor::BracketError]  = QColor("#FFA3A3"); // unmatched bracket highlight color


    // c++ keywords ref http://en.cppreference.com/w/cpp/keyword
    keywordSet << "alignas"     << "alignof"        << "and"        << "and_eq"     << "asm";
    keywordSet << "auto"        << "bitand"         << "bitor"      << "bool"       << "break";
    keywordSet << "case"        << "catch"          << "char"       << "char16_t"   << "char32_t";
    keywordSet << "class"       << "compl"          << "const"      << "constexpr"  << "const_cast";
    keywordSet << "continue"    << "decltype"       << "default"    << "delete"     << "do";
    keywordSet << "double"      << "dynamic_cast"   << "else"       << "enum"       << "explicit";
    keywordSet << "export"      << "extern"         << "false"      << "float"      << "for";
    keywordSet << "friend"      << "goto"           << "if"         << "inline"     << "int";
    keywordSet << "long"        << "mutable"        << "namespace"  << "new"        << "noexcept";
    keywordSet << "not"         << "not_eq"         << "nullptr"    << "operator"   << "or";
    keywordSet << "or_eq"       << "private"        << "protected"  << "public"     << "register";
    keywordSet << "reinterpret_cast" << "return"     << "short"      << "signed"     << "sizeof";
    keywordSet << "static"      << "static_assert"  << "static_cast" << "struct"     << "switch";
    keywordSet << "template"    << "this"           << "thread_local" << "throw"     << "true";
    keywordSet << "try"         << "typedef"        << "typeid"     << "typename"   << "union";
    keywordSet << "unsigned"    << "using"          << "virtual"    << "void"       << "volatile";
    keywordSet << "wchar_t"     << "while"          << "xor"        << "xor_eq"     << "override";
    keywordSet << "final";

    // know id's are words that are indexed or known special words
    knownIdSet << "include"     << "define"         << "INT_MIN"    << "INT_MAX"    << "MAX_RAND";
    knownIdSet << "main"        << "NULL"           << "ifdef"      << "ifndef"     << "endif";
    knownIdSet << "elseif";
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Highlighter::setColor(CodeEditor::ColorComponent component, const QColor &color)
{
    colorHash[component] = color;
    rehighlight();
}

//!----------------------------------------------------------------------------
//! \brief Does the work of highlighting a block of text.
//!
//! When a document is first loaded highlightBlock will be called for every
//! block (ie line) in the document. This initial update will allow us to
//! highlight the entire document and determine the state at the end of each
//! block, which we store using setCurrentBlockState(state).
//!
//! After the initial update the QSyntaxHighlighter class will determine what
//! blocks need to be processed as editing occurs. Because we can access the
//! previous blocks ending state we can process the given block correctly.
//!----------------------------------------------------------------------------
void Highlighter::highlightBlock(const QString &text)
{
    // the state we are in determines the color we will apply
    enum
    {
        Start = 0,
        Number = 1,
        Identifier = 2,
        String = 3,
        Comment = 4
    };

    QList<int> bracketPositions;
    QList<int> parenthesisPositions;

    // get the block state of the block just prior to this block in the doc, -1 if no state is set.
    int blockState = previousBlockState();
    // blockState = (bracketLevel << 4) | (state & 0xf);
    int bracketLevel = blockState >> 4;
    int state = blockState & 0x0f;
    if (blockState < 0)
    {
        bracketLevel = 0;
        state = Start;
    }

    int start = 0;
    int i = 0;
    while (i <= text.length())
    {
        QChar ch = (i < text.length()) ? text.at(i) : QChar();
        QChar next = (i < text.length() - 1) ? text.at(i + 1) : QChar();

        switch (state)
        {

        case Start:
            start = i;
            if (ch.isSpace())
                i++;
            else if (ch.isDigit())
            {
                i++;
                state = Number;
            }
            else if (ch.isLetter() || ch == '_')
            {
                i++;
                state = Identifier;
            }
            else if (ch == '\'' || ch == '\"')
            {
                i++;
                state = String;
            }
            else if (ch == '/' && next == '*')
            {
                i+=2;
                state = Comment;
            }
            else if (ch == '/' && next == '/')
            {
                i = text.length();
                setFormat(start, text.length(), colorHash[CodeEditor::Comment]);
            }
            else
            {
                if (!QString("(){}[]").contains(ch))
                    setFormat(start, 1, colorHash[CodeEditor::Operator]);
                if (ch == '{' || ch == '}')
                {
                    bracketPositions += i;
                    if (ch == '{')
                        bracketLevel++;
                    else
                        bracketLevel--;
                }
                else if (ch == '(' || ch == ')')
                    parenthesisPositions += i;

                i++;
                state = Start;
            }
            break;

        case Number:
            if (ch.isSpace() || !ch.isDigit())
            {
                QChar lc = ch.toLower();
                QString hextest("abcdefx");
                if(hextest.contains(lc))
                    i++;
                else
                {
                    setFormat(start, i - start, colorHash[CodeEditor::Number]);
                    state = Start;
                }
            }
            else
                i++;

            break;

        case Identifier:
            if (ch.isSpace() || !(ch.isDigit() || ch.isLetter() || ch == '_'))
            {
                QString token = text.mid(start, i - start).trimmed();
                if (keywordSet.contains(token))
                    setFormat(start, i - start, colorHash[CodeEditor::Keyword]);
                else if (knownIdSet.contains(token))
                    setFormat(start, i - start, colorHash[CodeEditor::BuiltIn]);
                state = Start;
            }
            else
                i++;
            break;

        case String:
            if (ch == text.at(start))
            {
                QChar prev = (i > 0) ? text.at(i - 1) : QChar();
                if (prev != '\\')
                {
                    i++;
                    setFormat(start, i - start, colorHash[CodeEditor::String]);
                    state = Start;
                }
                else
                    i++;
            }
            else
                i++;
            break;

        case Comment:
            // we are in a multi-line comment, check for the end of the comment.
            if (ch == '*' && next == '/')
            {
                i += 2;
                setFormat(start, i - start, colorHash[CodeEditor::Comment]);
                state = Start;
            }
            else
                i++;
            break;

        default:
            state = Start;
            break;
        }
    }

    // if we never reached the end of the comment then colorize from the start to the end of the line.
    // the comment state will carry forward into the next block, otherwise set state to Start.
    if (state == Comment)
        setFormat(start, text.length(), colorHash[CodeEditor::Comment]);
    else
        state = Start;

    // From QTextBlock documentation for setUserData()
    // QTextBlockUserData can be used to store custom settings. The ownership is passed to the underlying
    // text document, i.e. the provided QTextBlockUserData object will be deleted if the corresponding text
    // block gets deleted. The user data object is not stored in the undo history, so it will not be available
    // after undoing the deletion of a text block.
    BlockData *blockData = reinterpret_cast<BlockData*>(currentBlock().userData());
    if (!bracketPositions.isEmpty() || !parenthesisPositions.isEmpty())
    {
        if (!blockData)
        {
            blockData = new BlockData; // see above note about deletion
            blockData->breakpoint = false;
            currentBlock().setUserData(blockData);
        }
        blockData->bracketPositions = bracketPositions;
        blockData->parenthesisPositions = parenthesisPositions;
    }
    else
    {
        if (blockData)
        {
            blockData->bracketPositions.clear();
            blockData->parenthesisPositions.clear();
        }
    }

    // state gets stored in lower four bits, bracketLevel in upper remaining bits
    blockState = (state & 0x0f) | (bracketLevel << 4);
    setCurrentBlockState(blockState);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QStringList Highlighter::getKeywords() const
{
    return keywordSet.toList();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Highlighter::setKeywords(const QStringList &keywords)
{
    keywordSet = QSet<QString>::fromList(keywords);
    rehighlight();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int Highlighter::blockState()
{
    int blockState = previousBlockState();
    return blockState;
}

//!----------------------------------------------------------------------------
//!
//!                    MarginWidget - class implementation
//!
//!----------------------------------------------------------------------------

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
MarginWidget::MarginWidget(CodeEditor *editor)
    : QWidget(editor)
{
    backgroundColor = Qt::lightGray;
    lineNumberColor = Qt::black;
    indicatorColor = Qt::white;

    debugMarkerWidth = -1;
    if (debugMarkerImage.load(":/icons/icons/reddot.png"))
        debugMarkerWidth = debugMarkerImage.width();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MarginWidget::mousePressEvent(QMouseEvent *event)
{
    // check for margin press
    if (debugMarkerWidth > 0)
    {
        int xofs = width();
        int fh = fontMetrics().lineSpacing();
        int ys = event->pos().y();
        if (event->pos().x() < xofs)
        {
            for (int i = 0; i < lineNumbers.size(); i++)
            {
                BlockInfo ln = lineNumbers.at(i);
                if ((ln.position < ys) && ((ln.position + fh) > ys))
                {
                    CodeEditor *editor = qobject_cast<CodeEditor*>(parent());

                    if (editor)
                    {
                        int x = event->pos().x();
                        lineNumbers.replace(i,ln);
                        editor->marginPressEvent(ln.number, x);
                        update();
                    }
                    break;
                }
            }
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MarginWidget::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    p.fillRect(event->rect(), backgroundColor);
    p.setPen(lineNumberColor);
    p.setFont(font);
    int fh = QFontMetrics(font).height();

    // draw line numbers and breakpoints
    CodeEditor *editor = qobject_cast<CodeEditor*>(parent());
    foreach(BlockInfo ln, lineNumbers)
    {
        // draw line number
        p.drawText(0, ln.position, width() - 4, fh, Qt::AlignRight, QString::number(ln.number));
        // draw breakpoint
        if (editor)
        {
            if (editor->isBreakpointAt(ln.number))
                p.drawImage(0, ln.position, debugMarkerImage);
        }
    }
}

//!----------------------------------------------------------------------------
//!
//!                    CodeEditor - class implementation
//!
//!----------------------------------------------------------------------------

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
CodeEditor::CodeEditor(QWidget *parent) :
    QPlainTextEdit(parent)
{
    highlighter = new Highlighter(document());
    sidebar = new MarginWidget(this);
    showLineNumbers = true;
    highlightBrackets = true;
    cursorColor = QColor(255, 255, 192);
    bracketMatchColor = QColor(180, 238, 180);
    bracketErrorColor = QColor(224, 128, 128);

    connect(this, SIGNAL(cursorPositionChanged()), this, SLOT(updateCursor()));
    connect(this, SIGNAL(blockCountChanged(int)), this, SLOT(slotBlockCountChanged(int)));
    connect(this, SIGNAL(updateRequest(QRect, int)), this, SLOT(updateSidebar(QRect, int)));

    // set font
    QFont font = this->font();

#if defined Q_OS_MAC
    font.setPointSize(12);
    font.setFamily("Monaco");
#elif defined Q_OS_WIN
    font.setPointSize(10);
#elif defined Q_OS_UNIX
    font.setPointSize(10);
#endif

    setFont(font);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::slotBlockCountChanged(int cnt)
{
    Q_UNUSED(cnt);

    updateSidebar();
    emit updateBreakpoints();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int CodeEditor::getMarginWidgetWidth()
{
    return sidebar->width();
}

void CodeEditor::updateHighlighter()
{
    highlighter->rehighlight();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::setColor(ColorComponent component, const QColor &color)
{
    if (component == Background)
    {
        qDebug() << "color:" << color;
        QPalette pal = palette();
        pal.setColor(QPalette::Base, color);
        setPalette(pal);
        sidebar->indicatorColor = color;
        updateSidebar();

        highlighter->setColor(component, color);
        updateCursor();
    }
    else if (component == Normal)
    {
        QPalette pal = palette();
        pal.setColor(QPalette::Text, color);
        setPalette(pal);
    }
    else if (component == Sidebar)
    {
        sidebar->backgroundColor = color;
        updateSidebar();
    }
    else if (component == LineNumber)
    {
        sidebar->lineNumberColor = color;
        updateSidebar();
    }
    else if (component == Cursor)
    {
        cursorColor = color;
        updateCursor();
    }
    else if (component == BracketMatch)
    {
        bracketMatchColor = color;
        updateCursor();
    }
    else if (component == BracketError)
    {
        bracketErrorColor = color;
        updateCursor();
    }
    else
    {
        highlighter->setColor(component, color);
        updateCursor();
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QStringList CodeEditor::getKeywords() const
{
    return highlighter->getKeywords();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::setKeywords(const QStringList &keywords)
{
    highlighter->setKeywords(keywords);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::setLineNumbersVisible(bool visible)
{
    showLineNumbers = visible;
    updateSidebar();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::setBracketsMatchingEnabled(bool enable)
{
    highlightBrackets = enable;
    updateCursor();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QList<int> CodeEditor::getBreakpoints()
{
    QList<int> breakpointList;

    int n = document()->blockCount();
    for(int line=1;line<=n;line++)
    {
        QTextBlock block = document()->findBlockByLineNumber(line);
        BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
        if(blockData != NULL)
        {
            if(blockData->breakpoint)
                breakpointList.append(line);
        }
    }
    return breakpointList;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::setBreakpoints(const QList<int> &list)
{
    // remove breakpoints
    int n = document()->blockCount();
    for(int line=1;line<=n;line++)
    {
        QTextBlock block = document()->findBlockByLineNumber(line);
        BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
        if(blockData != NULL)
        {
            blockData->breakpoint = false;
            block.setUserData(blockData);
        }
    }

    // set breakpoints
    foreach(int line, list)
    {
        if(line > document()->blockCount()) continue;
        QTextBlock block = document()->findBlockByLineNumber(line);
        BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
        if(blockData == NULL)
        {
            blockData = new BlockData;
            blockData->bracketPositions.clear();
            blockData->parenthesisPositions.clear();
        }
        blockData->breakpoint = true;
        block.setUserData(blockData);
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::marginPressEvent(int line, int x)
{
    emit marginClicked(line,x);
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool CodeEditor::isBreakpointAt(int line)
{
    QTextBlock block = document()->findBlockByLineNumber(line);
    BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
    if(blockData == NULL) return false;

    return blockData->breakpoint;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::resizeEvent(QResizeEvent *e)
{
    QPlainTextEdit::resizeEvent(e);
    updateSidebar();
}

//!----------------------------------------------------------------------------
//! \brief Called anytime the cursor position is changed.
//!----------------------------------------------------------------------------
void CodeEditor::updateCursor()
{
    if (isReadOnly())
        setExtraSelections(QList<QTextEdit::ExtraSelection>());
    else
    {
        bracketMatchPositions.clear();
        bracketErrorPositions.clear();
        parenMatchPositions.clear();
        parenErrorPositions.clear();

        if (highlightBrackets && textCursor().block().userData())
        {
            QTextCursor cursor = textCursor();
            int cursorPosition = cursor.position();

            // opening bracket
            if (document()->characterAt(cursorPosition) == '{')
            {
                int matchPos = findClosingBracket(document(), cursorPosition);
                if (matchPos < 0)
                    bracketErrorPositions += cursorPosition;
                else
                {
                    bracketMatchPositions += cursorPosition;
                    bracketMatchPositions += matchPos;
                }
            }
            // closing bracket
            if (document()->characterAt(cursorPosition - 1) == '}')
            {
                int matchPos = findOpeningBracket(document(), cursorPosition);
                if (matchPos < 0)
                    bracketErrorPositions += cursorPosition - 1;
                else
                {
                    bracketMatchPositions += cursorPosition - 1;
                    bracketMatchPositions += matchPos;
                }
            }
            // opening parenthesis
            if (document()->characterAt(cursorPosition) == '(')
            {
                int matchPos = findClosingParen(document(), cursorPosition);
                if (matchPos < 0)
                    parenErrorPositions += cursorPosition;
                else
                {
                    parenMatchPositions += cursorPosition;
                    parenMatchPositions += matchPos;
                }
            }
            // closing parenthesis
            if (document()->characterAt(cursorPosition - 1) == ')')
            {
                int matchPos = findOpeningParen(document(), cursorPosition);
                if (matchPos < 0)
                    parenErrorPositions += cursorPosition - 1;
                else
                {
                    parenMatchPositions += cursorPosition - 1;
                    parenMatchPositions += matchPos;
                }
            }
        }

        // highlight current line
        QTextEdit::ExtraSelection highlight;
        highlight.format.setBackground(cursorColor);
        highlight.format.setProperty(QTextFormat::FullWidthSelection, true);
        highlight.cursor = textCursor();
        highlight.cursor.clearSelection();

        QList<QTextEdit::ExtraSelection> extraSelections;
        extraSelections.append(highlight);

        // highlight bracket matches
        for (int i = 0; i < bracketMatchPositions.count(); ++i)
        {
            int pos = bracketMatchPositions.at(i);
            QTextEdit::ExtraSelection matchHighlight;
            matchHighlight.format.setBackground(bracketMatchColor);
            matchHighlight.cursor = textCursor();
            matchHighlight.cursor.setPosition(pos);
            matchHighlight.cursor.setPosition(pos + 1, QTextCursor::KeepAnchor);
            extraSelections.append(matchHighlight);
        }
        // highlight bracket mismatches
        for (int i = 0; i < bracketErrorPositions.count(); ++i)
        {
            int pos = bracketErrorPositions.at(i);
            QTextEdit::ExtraSelection errorHighlight;
            errorHighlight.format.setBackground(bracketErrorColor);
            errorHighlight.cursor = textCursor();
            errorHighlight.cursor.setPosition(pos);
            errorHighlight.cursor.setPosition(pos + 1, QTextCursor::KeepAnchor);
            extraSelections.append(errorHighlight);
        }
        // highlight parenthesis matches
        for (int i = 0; i < parenMatchPositions.count(); ++i)
        {
            int pos = parenMatchPositions.at(i);
            QTextEdit::ExtraSelection matchHighlight;
            matchHighlight.format.setBackground(bracketMatchColor);
            matchHighlight.cursor = textCursor();
            matchHighlight.cursor.setPosition(pos);
            matchHighlight.cursor.setPosition(pos + 1, QTextCursor::KeepAnchor);
            extraSelections.append(matchHighlight);
        }
        // highlight parenthesis mismatches
        for (int i = 0; i < parenErrorPositions.count(); ++i)
        {
            int pos = parenErrorPositions.at(i);
            QTextEdit::ExtraSelection errorHighlight;
            errorHighlight.format.setBackground(bracketErrorColor);
            errorHighlight.cursor = textCursor();
            errorHighlight.cursor.setPosition(pos);
            errorHighlight.cursor.setPosition(pos + 1, QTextCursor::KeepAnchor);
            extraSelections.append(errorHighlight);
        }

        setExtraSelections(extraSelections);
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::updateSidebar(const QRect &rect, int dy)
{
    Q_UNUSED(rect)
    if (dy != 0) // dy carries the amount of pixels the viewport was scrolled
        updateSidebar();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void CodeEditor::updateSidebar()
{
    if (!showLineNumbers)
    {
        sidebar->hide();
        setViewportMargins(0, 0, 0, 0);
        //        sidebar->setGeometry(3, 0, 0, height());
        return;
    }

    sidebar->font = font();
    sidebar->show();

    // determine width of sidebar
    int sw = 0;

    // add width for line numbers
    if (showLineNumbers)
    {
        int digits = 2;
        int maxLines = blockCount();
        for (int number = 10; number < maxLines; number *= 10)
            ++digits;
        sw += fontMetrics().width('w') * digits;
    }

    // add width for debug markers
    if (sidebar->debugMarkerWidth > 0)
        sw += sidebar->debugMarkerWidth;

    // update
    setViewportMargins(sw, 0, 0, 0);
    sidebar->setGeometry(0, 0, sw, height());
    QRectF sidebarRect(0, 0, sw, height());

    // start at first visible block and process the remaining blocks
    QTextBlock block = firstVisibleBlock();
    int index = 0;
    while (block.isValid())
    {
        if (block.isVisible())
        {
            QRectF rect = blockBoundingGeometry(block).translated(contentOffset());
            if (sidebarRect.intersects(rect))
            {
                if (sidebar->lineNumbers.count() >= index)
                    sidebar->lineNumbers.resize(index + 1);
                sidebar->lineNumbers[index].position = rect.top();
                sidebar->lineNumbers[index].number = block.blockNumber() + 1;
                ++index;
            }
            if (rect.top() > sidebarRect.bottom())
                break;
        }
        block = block.next();
    }
    sidebar->lineNumbers.resize(index);
    sidebar->update();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int CodeEditor::blockState()
{
    return highlighter->blockState();
}

//!----------------------------------------------------------------------------
//! \brief Search down from the cursorPosition to find the matching closing
//! bracket.
//!----------------------------------------------------------------------------
int CodeEditor::findClosingBracket(const QTextDocument *doc, int cursorPosition)
{
    // search down from cursorPosition to find the matching closing bracket
    QTextBlock block = doc->findBlock(cursorPosition);
    BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
    if (!blockData->bracketPositions.isEmpty())
    {
        int depth = 1;
        while (block.isValid())
        {
            blockData = reinterpret_cast<BlockData*>(block.userData());
            if (blockData && !blockData->bracketPositions.isEmpty())
            {
                for (int c = 0; c < blockData->bracketPositions.count(); ++c)
                {
                    int absPos = block.position() + blockData->bracketPositions.at(c);
                    if (absPos <= cursorPosition)
                        continue;
                    if (doc->characterAt(absPos) == '{')
                        depth++;
                    else
                        depth--;
                    if (depth == 0)
                        return absPos;
                }
            }
            block = block.next();
        }
    }
    return -1;
}

//!----------------------------------------------------------------------------
//! \brief  Search up from the cursorPosition to find the matching opening
//! bracket.
//!----------------------------------------------------------------------------
int CodeEditor::findOpeningBracket(const QTextDocument *doc, int cursorPosition)
{
    QTextBlock block = doc->findBlock(cursorPosition);
    BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
    if (!blockData->bracketPositions.isEmpty())
    {
        int depth = 1;
        while (block.isValid())
        {
            blockData = reinterpret_cast<BlockData*>(block.userData());
            if (blockData && !blockData->bracketPositions.isEmpty())
            {
                for (int c = blockData->bracketPositions.count() - 1; c >= 0; --c)
                {
                    int absPos = block.position() + blockData->bracketPositions.at(c);
                    if (absPos >= cursorPosition - 1)
                        continue;
                    if (doc->characterAt(absPos) == '}')
                        depth++;
                    else
                        depth--;
                    if (depth == 0)
                        return absPos;
                }
            }
            block = block.previous();
        }
    }
    return -1;
}

//!----------------------------------------------------------------------------
//! \brief Search down from cursorPosition to find the matching closing
//! parenthesis.
//!----------------------------------------------------------------------------
int CodeEditor::findClosingParen(const QTextDocument *doc, int cursorPosition)
{
    // search down from cursorPosition to find the matching closing bracket
    QTextBlock block = doc->findBlock(cursorPosition);
    BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
    if (!blockData->parenthesisPositions.isEmpty())
    {
        int depth = 1;
        while (block.isValid())
        {
            blockData = reinterpret_cast<BlockData*>(block.userData());
            if (blockData && !blockData->parenthesisPositions.isEmpty())
            {
                for (int c = 0; c < blockData->parenthesisPositions.count(); ++c)
                {
                    int absPos = block.position() + blockData->parenthesisPositions.at(c);
                    if (absPos <= cursorPosition)
                        continue;
                    if (doc->characterAt(absPos) == '(')
                        depth++;
                    else
                        depth--;
                    if (depth == 0)
                        return absPos;
                }
            }
            block = block.next();
        }
    }
    return -1;
}

//!----------------------------------------------------------------------------
//! \brief  Search up from the cursorPosition to find the matching opening
//! parenthesis.
//!----------------------------------------------------------------------------
int CodeEditor::findOpeningParen(const QTextDocument *doc, int cursorPosition)
{
    QTextBlock block = doc->findBlock(cursorPosition);
    BlockData *blockData = reinterpret_cast<BlockData*>(block.userData());
    if (!blockData->parenthesisPositions.isEmpty())
    {
        int depth = 1;
        while (block.isValid())
        {
            blockData = reinterpret_cast<BlockData*>(block.userData());
            if (blockData && !blockData->parenthesisPositions.isEmpty())
            {
                for (int c = blockData->parenthesisPositions.count() - 1; c >= 0; --c)
                {
                    int absPos = block.position() + blockData->parenthesisPositions.at(c);
                    if (absPos >= cursorPosition - 1)
                        continue;
                    if (doc->characterAt(absPos) == ')')
                        depth++;
                    else
                        depth--;
                    if (depth == 0)
                        return absPos;
                }
            }
            block = block.previous();
        }
    }
    return -1;
}
