CodeLatch Installation Notes.

Run the following commands from a terminal window.

    $ sudo cp 99-codelatch.rules /etc/udev/rules.d
    $ sudo apt-get install libqt4

    For 64bit systems run the following command to allow the 32bit arm compiler to run…
    $ sudo apt-get install lib32z1 lib32ncurses5 lib32bz2-1.0

Note: You may need to edit the 99-codelatch.rules file and adjust the “busnum” parameter. This specifies what bus number your computers usb ports are operating on.