//*****************************************************************************
//
//                                  STUBS
//
//*****************************************************************************

#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <sys/unistd.h>

#undef errno
extern int errno;

extern "C" caddr_t _sbrk(int incr);
//unsigned long __my_get_MSP(void) __attribute__( ( naked ) );
extern "C" pid_t _getpid();
extern "C" int _kill(int pid, int sig);
//extern "C" caddr_t _sbrk(int incr);
extern "C" unsigned long __get_MSP(void);
extern "C" void _exit(int status);
//unsigned long __my_get_MSP(void) __attribute__( ( naked ) );

extern "C" int _write(int file, char *ptr, int len);
extern "C" int _close(int file);
extern "C" int _execve(char *name, char **argv, char **env);
extern "C" int _fork();
extern "C" int _fstat(int file, struct stat *st);
extern "C" int _isatty(int file);
extern "C" int _read(int file, char *ptr, int len);
extern "C" int _lseek(int file, int ptr, int dir);


/*
 environ
 A pointer to a list of environment variables and their values.
 For a minimal environment, this empty list is adequate:
 */
char *__env[1] = { 0 };
char **environ = __env;

void *operator new(size_t size);
void operator delete(void *ptr);
void *operator new[](size_t size);
void operator delete[](void *ptr);

void* operator new(size_t size) {
    void *ptr = malloc(size);
    return ptr;
}
void* operator new[](size_t size) {
    void *ptr = malloc(size);
    return ptr;
}

void operator delete(void *ptr) {
   free(ptr);
}
void operator delete[](void *ptr) {
   free(ptr);
}


//#include <stdlib.h> // for malloc and free
//void* operator new(size_t size) { return malloc(size); }
//void operator delete(void* ptr) { if(ptr) free(ptr); }

void _exit(int status) {
//    _write(1, "exit", 4);
	while (1) {
		;
	}
}

int _close(int file) {
	return -1;
}
/*
 execve
 Transfer control to a new process. Minimal implementation (for a system without processes):
 */
int _execve(char *name, char **argv, char **env) {
	errno = ENOMEM;
	return -1;
}
/*
 fork
 Create a new process. Minimal implementation (for a system without processes):
 */

int _fork() {
	errno = EAGAIN;
	return -1;
}
/*
 fstat
 Status of an open file. For consistency with other minimal implementations in these examples,
 all files are regarded as character special devices.
 The `sys/stat.h' header file required is distributed in the `include' subdirectory for this C library.
 */
int _fstat(int file, struct stat *st) {
	st->st_mode = S_IFCHR;
	return 0;
}

/*
 getpid
 Process-ID; this is sometimes used to generate strings unlikely to conflict with other processes. Minimal implementation, for a system without processes:
 */

int _getpid() {
	return 1;
}

/*
 isatty
 Query whether output stream is a terminal. For consistency with the other minimal implementations,
 */
int _isatty(int file) {
	switch (file) {
	case STDOUT_FILENO:
	case STDERR_FILENO:
	case STDIN_FILENO:
		return 1;
	default:
		//errno = ENOTTY;
		errno = EBADF;
		return 0;
	}
}

/*
 kill
 Send a signal. Minimal implementation:
 */
int _kill(int pid, int sig) {
	errno = EINVAL;
	return (-1);
}

/*
 link
 Establish a new name for an existing file. Minimal implementation:
 */

int _link(char *old, char *newname) {
	errno = EMLINK;
	return -1;
}

/*
 lseek
 Set position in a file. Minimal implementation:
 */
int _lseek(int file, int ptr, int dir) {
	return 0;
}

/*
 read
 Read a character to a file. `libc' subroutines will use this system routine for input from all files, including stdin
 Returns -1 on error or blocks until the number of characters have been read.
 */

int _read(int file, char *ptr, int len) {
	int n;
	int num = 0;
	switch (file) {
	case STDIN_FILENO:
		for (n = 0; n < len; n++) {
//            *ptr++ = c;
			num++;
		}
		break;
	default:
		errno = EBADF;
		return -1;
	}
	return num;
}

/*
 stat
 Status of a file (by name). Minimal implementation:
 int    _EXFUN(stat,( const char *__path, struct stat *__sbuf ));
 */

int _stat(const char *filepath, struct stat *st) {
	st->st_mode = S_IFCHR;
	return 0;
}

/*
 times
 Timing information for current process. Minimal implementation:
 */

clock_t _times(struct tms *buf) {
	return -1;
}

/*
 unlink
 Remove a file's directory entry. Minimal implementation:
 */
int _unlink(char *name) {
	errno = ENOENT;
	return -1;
}

/*
 wait
 Wait for a child process. Minimal implementation:
 */
int _wait(int *status) {
	errno = ECHILD;
	return -1;
}

/*
 write
 Write a character to a file. `libc' subroutines will use this system routine for output to all files, including stdout
 Returns -1 on error or number of bytes sent
 */
int _write(int file, char *ptr, int len) {
	int n;
	switch (file) {
	case STDOUT_FILENO: /*stdout*/
		for (n = 0; n < len; n++) {
		}
		break;
	case STDERR_FILENO: /* stderr */
		for (n = 0; n < len; n++) {
		}
		break;
	default:
		errno = EBADF;
		return -1;
	}
	return len;
}
/*
 sbrk
 Increase program data space.
 Malloc and related functions depend on this
 */

caddr_t _sbrk (int size)
{
/*
   extern char __cs3_heap_start;
   extern char __cs3_heap_end ;
   static char *current_heap_end = &__cs3_heap_start;
   char *previous_heap_end;

   previous_heap_end = current_heap_end;

   if ((current_heap_end + size) > &__cs3_heap_end )
   {
      errno = ENOMEM;
      return (caddr_t) -1;
   }

   current_heap_end += size;

   return (caddr_t) previous_heap_end;
*/
   extern char __heap_start__;
   extern char __heap_end__ ;
   static char *current_heap_end = &__heap_start__;
   char *previous_heap_end;

   previous_heap_end = current_heap_end;

   if ((current_heap_end + size) > &__heap_end__ )
   {
      errno = ENOMEM;
      return (caddr_t) -1;
   }

   current_heap_end += size;

   return (caddr_t) previous_heap_end;

}
