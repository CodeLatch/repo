#ifndef _CTERMINAL_HPP_
#define _CTERMINAL_HPP_

#include "types.h"
#include "print.h"
#include "fifo.h"

typedef void (*TerminalRxCallbackType)(void);

#define TERMINAL_RX_BUF_SIZE 128
#define TERMINAL_TX_BUF_SIZE 128

void HID_LoadTxData(u8 data[], u32 numBytes);
void HID_LoadRxData(u8 data[], u32 numBytes);

// CTerminal class - usb hid terminal functionality.
//		note: we inherit all the members of CPrint and must override CPrint::write()
class CTerminal : public CPrint {

protected:

	u8 txTimeout;
	u8 txbuf[TERMINAL_RX_BUF_SIZE];
	u8 rxbuf[TERMINAL_TX_BUF_SIZE];
	void write(u8 val); // override to get CPrint functionality.

public:

	Fifo rxFifo;
	Fifo txFifo;
	TerminalRxCallbackType rxCallback;

public:

	CTerminal(void);
	~CTerminal(void);

	// Start the terminal service, default is to wait up to 10ms for tx buffer to free up.
	// The default terminal hid packet interrupt is 8ms.
	void start(u8 timeout_ms = 10);

	// Returns the number of bytes in the receive fifo available for reading.
	u16 available(void);

	// Read a number of bytes from the receive fifo.
	// return: number of bytes read.
	u16 read(void *dest,u16 numbytes);

	// Get a null terminated string from the receive fifo.
	// return: number of characters read.
	u16 gets(char* str, u16 maxlen);

	// Sets the function to call when data is received from the host pc.
	void setRxCallback(TerminalRxCallbackType cb);

	// Sets the timeout period in milliseconds to wait for free space
	// to become available in the transmit fifo.
	// timeout_ms = 0..255
	void setTxTimeout(u8 timeout_ms);
};

// we instantiate Terminal in terminal.cpp
extern CTerminal Terminal;

#endif
