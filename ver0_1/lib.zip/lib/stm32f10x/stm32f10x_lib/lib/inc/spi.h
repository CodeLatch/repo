#ifndef _SPI_CLASS_H_
#define _SPI_CLASS_H_

#include "stm32f10x_spi.h"

enum SPI_CLK_SPEED
{
    PCLK_Div2 = SPI_BaudRatePrescaler_2,
    PCLK_Div4 = SPI_BaudRatePrescaler_4,
    PCLK_Div8 = SPI_BaudRatePrescaler_8,
    PCLK_Div16 = SPI_BaudRatePrescaler_16,
    PCLK_Div32 = SPI_BaudRatePrescaler_32,
    PCLK_Div64 = SPI_BaudRatePrescaler_64,
    PCLK_Div128 = SPI_BaudRatePrescaler_128,
    PCLK_Div256 = SPI_BaudRatePrescaler_256
};

enum SPI_CPOL
{
    CPOL_0 = SPI_CPOL_Low,
    CPOL_1 = SPI_CPOL_High
};

enum SPI_CPHA
{
    CPHA_0 = SPI_CPHA_1Edge,
    CPHA_1 = SPI_CPHA_2Edge
};

enum SPI_ENDIAN
{
    LSB_FIRST = SPI_FirstBit_LSB,
    MSB_FIRST = SPI_FirstBit_MSB
};

class CSPI
{
	public:
		CSPI();

		void begin(SPI_CLK_SPEED speed = PCLK_Div2, SPI_CPOL cpol = CPOL_1,
		           SPI_CPHA cpha = CPHA_1, SPI_ENDIAN endian = LSB_FIRST);

		u8 transfer(u8 data);
		u8 transfer(u8 csPin, u8 data);
};

extern CSPI SPI;

#endif
