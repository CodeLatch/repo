#ifndef _CSERIAL_H_
#define _CSERIAL_H_

#include "types.h"
#include "print.h"
#include "fifo.h"
#include "stm32f10x.h"

typedef void (*SerialRxCallbackType)(void);

#define SERIAL_RX_BUF_SIZE 64

class CSerial : public CPrint {

protected:

	USART_TypeDef *uart;
	u8 rxbuf[SERIAL_RX_BUF_SIZE];
	void write(u8 val); // override to get CPrint functionality.

public:

	Fifo rxFifo;
	SerialRxCallbackType rxCallback;
	bool termRxOnLF;
	bool b_ignoreUnprintable;
	
public:

	CSerial(USART_TypeDef *uart);

	void start(uint32_t baud = 115200);

	// Returns the number of bytes in the receive fifo available for reading.
	u16 available(void);

	// Read a number of bytes from the receive fifo.
	// return: number of bytes read.
	u16 read(void *dest,u16 numbytes);

	// Get a null terminated string from the receive fifo.
	// return: number of characters read.
	u16 gets(char* str, u16 maxlen);

	// Sets the function to call when data is received from the host pc.
	void setRxCallback(SerialRxCallbackType cb);
	
	void terminateRxOnLF(bool enable);
	
	void ignoreUnprintable(bool enable) {b_ignoreUnprintable = enable;}
};

// we instantiate Terminal in terminal.cpp
extern CSerial Serial;
extern CSerial Serial2;
extern CSerial Serial3;
#ifdef STM32F10X_HD
extern CSerial Serial4;
extern CSerial Serial5;
#endif
/*
STM32F103X 

INTERFACE	RX		TX
-------------------------
USART1		PA10		PA9		or PB7,PB6
USART2		PA3		PA2
USART3		PB11		PB10
UART4		PC11		PC10
USART5		PD2		PC12
*/
#endif
