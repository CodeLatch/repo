#ifndef _SERVO_HPP_
#define _SERVO_HPP_

#include "types.hpp"

class Servo {

private:
	s32 angle;
	u8 pin;

public:

	Servo(void);
	~Servo(void);

	// Initialize a servo control signal pin.
	// Available pins: 4, 17, 27, 28, 29, 30, 34, 35, 39, 46, 47.
	void attach(u8 pin);
	// set servo position in degrees (0 to 180).
	void write(u32 angle);
	// set servo position in microseconds (typically 1000 to 2000).
	void writeMicroseconds(u32 microseconds);
	// read servo angle setting.
	s32 read();
};

#endif
