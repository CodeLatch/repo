/*
 * fifo.hpp
 *
 *  Created on: Jun 11, 2011
 *      Author: John
 */

#ifndef _FIFO_H_
#define _FIFO_H_

#include "types.h"

#define FIFO_HOLDING_DATA			0x01	// flag can be used to determine if data is ready to be taken out.
#define FIFO_WAITING_FOR_KEY		0x02	// flag used to prohibit receive fifo from accepting data until the first byte is a key character.
#define FIFO_FULL					0x04

class Fifo {
private:
	volatile u16		flags;
			 u16		size;
			 u16    len;
			 u16    bufSize;
	volatile u16		head;
	volatile u16 	tail;
	volatile u8		*buf;

public:
	Fifo(void);
	Fifo(void *buf, u16 item_size, u16 num_items);
	~Fifo(void);

	void initialize(void *buf, u16 item_size, u16 num_items);
	u16 put(void *source);
	u16 put(void *source,u16 numbytes);
	u16 get(void *dest);
	u16 get(void *dest,u16 numbytes);
	u16 peek(void *dest,u16 numbytes);
	u16  available();
	u16	 free();
	BOOL isEmpty();
	void flush();
};

#endif /* SERIAL_FIFO_H_ */
