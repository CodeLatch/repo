#ifndef _PWM_HPP_
#define _PWM_HPP_

#include "types.hpp"

class PWM {

public:
	PWM(void);
	~PWM(void);

	void init(u8 pin, u32 prescaler, u32 period);
	void setPeriod(u8 pin, u32 period);
	void setDutyCycle(u8 pin, u32 dutycycle);

};

extern PWM Pwm;

#endif
