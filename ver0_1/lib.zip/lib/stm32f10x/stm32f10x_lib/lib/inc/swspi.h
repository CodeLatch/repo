#ifndef _SWSPI_H_
#define _SWSPI_H_

//#include "pin.hpp"
#include "types.h"

class CSWSPI {
public:
	CSWSPI(void);
	~CSWSPI(void);

	/*	typedef struct IO_PINDEF {
	 int pin;
	 int function;
	 } IO_PINDEF;

	 typedef struct SPIINTERFACE {
	 IO_PINDEF CSn;
	 IO_PINDEF SCK;
	 IO_PINDEF MISO;
	 IO_PINDEF MOSI;
	 IO_PINDEF SRn;
	 } SPIINTERFACE;
	 */
	typedef struct SPIINTERFACE {
		u8 CSn;
		u8 SCK;
		u8 MISO;
		u8 MOSI;
		u8 SRn;
	} SPIINTERFACE;

	void initMaster(volatile unsigned long cpuFreqHz, unsigned long baudRate,
			CSWSPI::SPIINTERFACE *pin);
	void write(unsigned char data, CSWSPI::SPIINTERFACE *pin);
	unsigned char read(CSWSPI::SPIINTERFACE *pin);
	void selectDevice(int pin);
	void unselectDevice(int pin);
};

#endif // _SWSPI_H_
