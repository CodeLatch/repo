#ifndef _UTILITY_HPP_
#define _UTILITY_HPP_

#include "string_s.h"
#include "stdarg.h"

// itoa.cpp
//
int itoa_s(s8 num, char * bf, u8 maxlen, unsigned int base, int uc);
int itoa_s(u8 num, char * bf, u8 maxlen, unsigned int base, int uc);

int itoa_s(s16 num, char * bf, u8 maxlen, unsigned int base, int uc);
int itoa_s(u16 num, char * bf, u8 maxlen, unsigned int base, int uc);

int itoa_s(s32 num, char * bf, u8 maxlen, unsigned int base, int uc);
int itoa_s(u32 num, char * bf, u8 maxlen, unsigned int base, int uc);

// itoa_64.cpp
//
int itoa_s(s64 num, char * bf, u8 maxlen, unsigned int base, int uc);
int itoa_s(u64 num, char * bf, u8 maxlen, unsigned int base, int uc);

int ftoa_s(double val, u8 precision, char* buf, int maxlen);

int sprintf(char* buf, int bufSize, const char* fmt, ...);
int format_s(char* output, int maxlen, char* fmt, va_list va);

long map(long x, long in_min, long in_max, long out_min, long out_max);

#endif
