#ifndef _CONVERT_H_
#define _CONVERT_H_

int atoi_s(char *s, int maxstrlen);
double atof_s(char *s, int maxstrlen);

#endif