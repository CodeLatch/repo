#ifndef _TIMER_HPP_
#define _TIMER_HPP_

#include "types.h"
#include "stm32f10x_it.h"

void delayMicroseconds(u32 microseconds);
void intializeMicrosecondTimer();

void timerEnableInterrupt(TIM_TypeDef* TIMx, u8 priority, u8 subPriority);
void timerInit(TIM_TypeDef* TIMx, u32 timerClkHz, u32 timerPeriodCnt);

//extern volatile u32 systicks;

#endif // _TIMER_HPP_
