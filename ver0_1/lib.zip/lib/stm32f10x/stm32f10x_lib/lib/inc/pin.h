#ifndef _PIN_HPP_
#define _PIN_HPP_

#include "target-pins.h"
#include "types.h"

#define OUTPUT		0x01
#define INPUT		0x02
#define PULLUP		0x04
#define PULLDOWN		0x08
#define OPENDRAIN	0x10
#define NORMAL		0x20
#define HYSTERESIS	0x40
#define ADC			0x80
#define ALT			0x100
#define PWM			0x200

#define EDGE			0
#define LEVEL		1
#define FALLING		0
#define RISING		1
#define BOTH			2
#define LOW			0
#define HIGH			1

// used to configure I2C SDA and SCL pins
#define I2C_STANDARD     0
#define I2C_NOFILTER     1
#define I2C_HIGH_CURRENT 2

// special pins for external interrupt control
#define PVD_EVENT       38 // b16
#define RTC_EVENT       39 // b17
#define USB_EVENT       40 // b18
#define ENET_EVENT      41 // b19

typedef void (*PinInterruptCallbackType)(void);
/*
#define GPIO_PIN_MAP_LEN 42
#define GPIO_PORT_MAP_LEN 42
#define TABLE_pinTimer_LEN 15
*/
class CPin {

protected:

	// IOCONN ADDRESS = 0x40044000 + LPC_IOCON_TABLE[phy_pin]
//	static const long LPC_PIN_PORT[];
//	static const long LPC_PIN_BIT[];
//	static const u32 LPC_IOCON_TABLE[];
//	static LPC_GPIO_TypeDef (* const LPC_GPIO[]);

	PinInterruptCallbackType callbackFuncPtr;

public:
	CPin(void);
	~CPin(void);

	// Sets the pin operating mode.
	//  pin = physical pin number (1-48)
	//  mode = operating mode:
	//        INPUT, OUTPUT,
	//        OPENDRAIN, PULLUP, PULLDOWN, HYSTERESIS,
	//        NORMAL, ADC
	//
	// Mode functions can be or'ed together
	// Example: Pin.mode(35,INPUT|PULLUP);
	void mode(u8 pin, int mode);

	// Set a digital output high.
	// Example: Pin.set(35);
	void set(u8 pin);

	// Set a digital output low.
	// Example: Pin.clr(35);
	void clr(u8 pin);

	void pwm(u8 pin, u16 value);


	// Changes a digital outputs state
	// from low to high or from high to low.
	// Example: Pin.toggle(35);
	void toggle(u8 pin);

	// Reads a digital input pins state.
	//  returns 0 or 1
	// Example: state = Pin.read(35);
	u8 read(u8 pin);

	// Reads an analog pin.
	//  returns 0..4096
	u32 readAnalog(u8 pin);
	
	// Configures a pin to generate an interrupt.
	//  pin = physical pin number.
	//  type = EDGE or LEVEL
	//  polarity = RISING, FALLING, or BOTH for type = EDGE
	//             HIGH or LOW for type = LEVEL
	//
	// Example: Pin.configureInterrupt(35,EDGE,RISING);
	int configureInterrupt(u8 pin, u32 type, u32 polarity);

	// Enables interrupts on a pin.
	//  pin = physical pin number.
	// Example: Pin.enableInterrupt(35);
	void enableInterrupt(u8 pin);

	// Disables interrupts on a pin.
	//  pin = physical pin number.
	// Example: Pin.disableInterrupt(35);
	void disableInterrupt(u8 pin);

	u32 getInterruptStatus(u8 pin);
	u32 getEventStatus(u8 pin);
	void clearInterruptStatus(u8 pin);
	void setInterruptCallback(PinInterruptCallbackType funcPtr);
//	void setFunction(u8 pin, int function);

	inline void invokeCallback(u32 port) {if(callbackFuncPtr) callbackFuncPtr();}

	//-----------------------------------------------------------------------
	// Set I2C SCL Pin Mode
	//
	// mode
	//  I2C_STANDARD  : Standard open drain, glitch filter enabled
	//  I2C_NO_FILTER : Standard open drain, glitch filter disabled
	//  I2C_HIGH_SINK : High sink current open drain, glitch filter enabled
	//-----------------------------------------------------------------------
//	void setI2C_SCLMode(int mode);
//	void setI2C_SDAMode(int mode);

	/**
	 * Initialize gpio domain clock and enable pin interrupts.
	 *
	 * @return none.
	 */
//	void init(void);
	
private:
	void configureTimerPWM(TIM_TypeDef* timerX, u8 channel, u32 timerClkHz, u32 timerPeriodCnt);
//	TIM_TypeDef* getTimerPtr(u8 timer);


};

extern CPin Pin;


#endif
