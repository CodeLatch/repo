#ifndef __CPRINT_HPP_
#define __CPRINT_HPP_

#include "types.h"
#include "stdarg.h"

enum parseVariableType {ASCII = 1, BIN = 2, OCT = 8, DEC = 10, HEX = 16};

class CPrint
{

	public:
		CPrint(void);

		// binary
		virtual void write(u8 val);	// ** this function must be overridden by parent.
		void write(char val);
		virtual void print(const char* str);
		virtual void println(const char* str);
		// formatted print
		virtual int printf(const char* fmt, ...);
};

#endif
