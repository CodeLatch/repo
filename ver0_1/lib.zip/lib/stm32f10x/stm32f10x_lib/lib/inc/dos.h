#ifndef __JEMDOS_H__
#define __JEMDOS_H__

#include "mmc.h"
#include "types.h"

#define DOS_READONLY			0x01
#define DOS_HIDDEN			0x02
#define DOS_SYSTEM			0x04
#define DOS_VOLUME_ID		0x08
#define DOS_DIRECTORY		0x10
#define DOS_ARCHIVE			0x20

#define DOS_FAIL				0x00
#define DOS_SUCCESS			0x01
#define DOS_EOF				0x03
#define DOS_READSECTORERROR	0x04
#define DOS_SEEKERROR		0x05
#define DOS_FILECLOSED		0x06
#define DOS_ZEROBYTES		0x07
#define DOS_NOBOOTSECTOR		0x08
#define DOS_NOMATCH			0x09

#define DOS_FAT16			0x00
#define DOS_FAT32			0x01

struct MMCFILE
{
	u8 status;				// file status
	u32 firstcluster;		// cluster the beginning of the file is at
	u32 cluster;			// current cluster
	u32 sector;				// current sector
	u32 byteptr;			// current file position byte pointer
	u16 byteoffset;			// byte offset inside current sector to get to byteptr location (0..511)
	u32 size;				// file size in bytes
	u8 sectoroffset;		// sector offset within a cluster
	u32 dirsector;
	u16 dirsectoroffset;
};

struct DIRENTRY
{
	char name[13];			// filename
	u16 attribute;			// type of entry
	u16 time;				// Time  (b15-b11=hour, b10-b5=minute, b4-b0=second/2)
	u16 date;				// Date  (b15-b9=year-1980, b8-b5=month, b4-b0=day)
	u32 cluster;			// starting data cluster
	u32 size;				// size of file
};

class CDos
{
public:
	CDos(void);

	// DOS Services

	u8 initialize(u32 CPU_FREQ_HZ, CSWSPI::SPIINTERFACE *pinDef);

	//----------------------------------------------------------------------------
	// FUNCTION: open
	//
	// Description:
	//   Open a file for reading or writting. The function will update the passed
	//   file structure (f).
	//
	// Parameters:
	// struct MMCFILE *f	-- file structure
	// char *filename		-- filename
	// char mode			-- 'r'=read, 'w'=write, 'a'=append, 'd'=subdirectory
	//
	// Return: 0 = fail, 1 = success
	//---------------------------------------------------------------------------
	u8 open(struct MMCFILE *f, const char *_filename, char mode);
	void close(struct MMCFILE *f);
	u8 seek(struct MMCFILE *f, u32 pos);
	u16 readBuf(void *buffer, u8 size, u16 count, u16 *countRead, struct MMCFILE *f);
	u32 writeBuf(const void *buffer, u8 size, u16 count, struct MMCFILE *f);
	u8 getStr(char *str, u8 maxbytes, struct MMCFILE *f);
	u8 putStr(const char *str, struct MMCFILE *f);
	u8 chdir(const char *_dirname);
	u8 mkdir(const char *_dirname);

	//	int fprintf(struct MMCFILE *f,const char *fmt, ...);

	u8 findfile(struct MMCFILE *f, const char *_filename, u8 filetype);
	u8 rewind(struct MMCFILE *f);
	u8 DeleteFile(const char* _filename);

	bool isopen(struct MMCFILE *f);
	bool isInitialized(void);
	bool isEOF(struct MMCFILE *f);

	void debugShowBootInfo(void);
	int dbgListFiles(void);
	int InitDirectorySearch(struct MMCFILE *dir, int startAtRoot);
	int GetNextDirEntry(struct MMCFILE* dir, struct DIRENTRY* entry, u8 filetype);
	void SoftResetMMC(void);
	int fprintf(struct MMCFILE *f, const char *fmt, ...);

	CMMC mmc;

protected:
	//	void safe_putchw(struct MMCFILE *f,int *maxlen,int fmtWidth, char leadZeros, char *source);
	//	int format_s(struct MMCFILE *f,int maxlen,char *fmt, va_list va);
	u32 SectorFromCluster(u32 cluster);
	u32 ClusterFromSector(u32 sector);
	u8 readbootinfo(void);
	u32 getfreecluster(u32 currentcluster);
	u8 createdirentry(struct MMCFILE* f, const char* _filename, u32 cluster, u8 type);

	u8 initcluster(u32 cluster);
	bool formatname(char *dest, const char *source);
	void ToUpper(const char *input, char *output, uint8_t maxlen);
	bool isfile(u8 *buffer, u8 type);
	
	// notes: 1) there are always 512 bytes per sector
	//        2) sub directories are treated like files in the fat and directory, they contain directory entries
	//           in their assigned data clusters.
	//
	u8  buf[512];
	u16	m_bytesPerSector;			// number of bytes per sector, always 512
	u8	m_sectorsPerCluster;		// number of sectors per cluster
	u16	m_reservedSectors;			// number of reserved sectors
	u8	m_numFATs;					// number of copies of the FAT
	u16	m_maxRootDirEntries;		// maximum number of root directory entries
	u16	m_sectorsPerFAT;			// number of sectors per FAT
	u32 m_firstFATSector;			// sector number where the first FAT starts
	u32 m_firstRootDirSector;		// sector number where the root directory starts
	u32 m_firstDataSector;			// sector number where the data area starts

	u32 m_currentDirSector;			// sector number where the current directory starts
	u32 m_currentDirCluster;		// cluster number where the current directory starts

	bool m_initSuccess;
	u8 m_fatType;					// FAT16 or FAT32
};

#endif

