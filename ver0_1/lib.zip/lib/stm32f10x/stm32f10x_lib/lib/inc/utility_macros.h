#ifndef _UTILITY_MACROS_HPP_
#define _UTILITY_MACROS_HPP_

#include "LPC13xx.hpp"

// these will set and clear pins at 10MHz with -O0, and 72MHz with -O2 optimization.

#define pinSet_36() 	LPC_GPIO3->MASKED_ACCESS[(1<<0)] = (1<<0);
#define pinClr_36() 	LPC_GPIO3->MASKED_ACCESS[(1<<0)] = 0;
#define pinToggle_36() 	LPC_GPIO3->MASKED_ACCESS[(1<<0)] ^= (1<<0);

#define pinSet_1() 		LPC_GPIO2->MASKED_ACCESS[(1<<6)] = (1<<6);
#define pinClr_1() 		LPC_GPIO2->MASKED_ACCESS[(1<<6)] = 0;
#define pinToggle_1() 	LPC_GPIO2->MASKED_ACCESS[(1<<6)] ^= (1<<6);

#define setPin35() 		LPC_GPIO1->MASKED_ACCESS[(1<<2)] = (1<<2);
#define clrPin35() 		LPC_GPIO1->MASKED_ACCESS[(1<<2)] = 0;
#define togglePin35() 	LPC_GPIO1->MASKED_ACCESS[(1<<2)] ^= (1<<2);

#define setPin37() 		LPC_GPIO3->MASKED_ACCESS[(1<<1)] = (1<<1);
#define clrPin37() 		LPC_GPIO3->MASKED_ACCESS[(1<<1)] = 0;
#define togglePin37() 	LPC_GPIO3->MASKED_ACCESS[(1<<1)] ^= (1<<1);

/*
#define pinSet() 		LPC_GPIO->MASKED_ACCESS[1<<] = (1<<);
#define pinClr() 		LPC_GPIO->MASKED_ACCESS[1<<] = 0;
#define pinToggle() 	LPC_GPIO->MASKED_ACCESS[1<<] ^= (1<<);

#define pinSet() 		LPC_GPIO->MASKED_ACCESS[] = (1<<);
#define pinClr() 		LPC_GPIO->MASKED_ACCESS[] = 0;
#define pinToggle() 	LPC_GPIO->MASKED_ACCESS[] ^= (1<<);

#define pinSet() 		LPC_GPIO->MASKED_ACCESS[] = (1<<);
#define pinClr() 		LPC_GPIO->MASKED_ACCESS[] = 0;
#define pinToggle() 	LPC_GPIO->MASKED_ACCESS[] ^= (1<<);


(const u32*)&LPC_IOCON->PIO2_6,				// 1
		(const u32*)&LPC_IOCON->PIO2_0,				// 2
		(const u32*)&LPC_IOCON->RESET_PIO0_0,		// 3
		(const u32*)&LPC_IOCON->PIO0_1,				// 4
		0,											// 5
		0,											// 6
		0,											// 7
		0,											// 8
		(const u32*)&LPC_IOCON->PIO1_8,				// 9
		(const u32*)&LPC_IOCON->PIO0_2,				// 10
		(const u32*)&LPC_IOCON->PIO2_7,				// 11
		(const u32*)&LPC_IOCON->PIO2_8,				// 12
		(const u32*)&LPC_IOCON->PIO2_1,				// 13
		(const u32*)&LPC_IOCON->PIO0_3,				// 14
		(const u32*)&LPC_IOCON->PIO0_4,				// 15
		(const u32*)&LPC_IOCON->PIO0_5,				// 16
		(const u32*)&LPC_IOCON->PIO1_9,				// 17
		(const u32*)&LPC_IOCON->PIO2_4,				// 18
		0,											// 19
		0,											// 20
		(const u32*)&LPC_IOCON->PIO2_5,				// 21
		(const u32*)&LPC_IOCON->PIO0_6,				// 22
		(const u32*)&LPC_IOCON->PIO0_7,				// 23
		(const u32*)&LPC_IOCON->PIO2_9,				// 24
		(const u32*)&LPC_IOCON->PIO2_10,			// 25
		(const u32*)&LPC_IOCON->PIO2_2,				// 26
		(const u32*)&LPC_IOCON->PIO0_8,				// 27
		(const u32*)&LPC_IOCON->PIO0_9,				// 28
		(const u32*)&LPC_IOCON->JTAG_TCK_PIO0_10,	// 29
		(const u32*)&LPC_IOCON->PIO1_10,			// 30
		(const u32*)&LPC_IOCON->PIO2_11,			// 31
		(const u32*)&LPC_IOCON->JTAG_TDI_PIO0_11,	// 32
		(const u32*)&LPC_IOCON->JTAG_TMS_PIO1_0,	// 33
		(const u32*)&LPC_IOCON->JTAG_TDO_PIO1_1,	// 34
		(const u32*)&LPC_IOCON->JTAG_nTRST_PIO1_2,	// 35
		(const u32*)&LPC_IOCON->PIO3_0,				// 36
		(const u32*)&LPC_IOCON->PIO3_1,				// 37
		(const u32*)&LPC_IOCON->PIO2_3,				// 38
		(const u32*)&LPC_IOCON->ARM_SWDIO_PIO1_3,	// 39
		(const u32*)&LPC_IOCON->PIO1_4,				// 40
		0,											// 41
		(const u32*)&LPC_IOCON->PIO1_11,			// 42
		(const u32*)&LPC_IOCON->PIO3_2,				// 43
		0,											// 44
		(const u32*)&LPC_IOCON->PIO1_5,				// 45
		(const u32*)&LPC_IOCON->PIO1_6,				// 46
		(const u32*)&LPC_IOCON->PIO1_7,				// 47
		(const u32*)&LPC_IOCON->PIO3_3				// 48
*/
#endif
