//
// STM32F103X TQFP 64 Header
//
// These need to be defined by the target code.

#ifndef TARGET_PINS_H
#define TARGET_PINS_H

#include "types.h"
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"

extern const uint16_t GPIO_PIN_MAP[];
extern const u8 GPIO_PORT_MAP[];
extern const u8 TABLE_pinTimer[];
extern const u8 TABLE_pinTimerChannel[];
extern const u8 TABLE_ADCChannel[];

extern GPIO_TypeDef* GPIO_PORTS[];
extern TIM_TypeDef* TABLE_Timer[];

#endif
