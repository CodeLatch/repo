#ifndef _STRING_HPP_
#define _STRING_HPP_

#include "types.h"
#include "string.h"

u32 strlen_s(const char *string, u32 maxstrlen);
u32 strlen_s(const char *string);
u32 strcat_s(char *dest,u32 destsize,const char *source);
u32 strcpy_s(char *dest,u32 destsize,const char *source);
s8 strcmp_s(const char *str,const char *cmpstr, u32 numchars);
s8 strcmp_s(const char *str,const char *cmpstr);

#endif // _STRING_HPP_
