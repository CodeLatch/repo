#ifndef _ARDUINO_PIN_H_
#define _ARDUINO_PIN_H_

#include "types.h"

#ifndef HIGH
#define HIGH 1
#endif

#ifndef LOW
#define LOW 0
#endif

#define INPUT_PULLUP 		0x04
#define INPUT_PULLDOWN		0x08
#define OUTPUT_OPENDRAIN		0x10

// extra
void pinSet(u8 pin);
void pinClr(u8 pin);
void pinToggle(u8 pin);
u8 pinRead(u8 pin);

// standard
void digitalWrite(u8 pin, u8 state);
u8 digitalRead(u8 pin);
void pinMode(u8 pin, int mode);
u32 analogRead(u8 pin);


#endif // _ARDUINO_PIN_H_