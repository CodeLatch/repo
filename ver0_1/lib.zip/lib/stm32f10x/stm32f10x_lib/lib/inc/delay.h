#ifndef _DELAY_H_
#define _DELAY_H_

#include "types.h"

// Start a timer based on 1 millisecond system timer.
// a = u32 timer variable, b = timeout period in milliseconds.
#define timerStart(a,b) a = systicks + b
// Check if a timer has expired.
#define timerExpired(a) (systicks >= a)
#define millis() (systicks)
	
void delay(u32 milliseconds);

#endif // _DELAY_H_