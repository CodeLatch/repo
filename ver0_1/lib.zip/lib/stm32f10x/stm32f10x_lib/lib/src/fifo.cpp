#include "fifo.h"

Fifo::Fifo(void)
{
}

Fifo::~Fifo(void)
{
}

void Fifo::initialize(void *data_buf, u16 item_size, u16 num_items)
{
	size = item_size;
	len = num_items;
	bufSize = size * len;
	head = 0;
	tail = 0;
	flags = 0;
	buf = (u8*)data_buf;
}

void Fifo::flush()
{
	head = 0;
	tail = 0;
}

u16 Fifo::put(void *source)
{
	return put(source, size);
}

u16 Fifo::put(void *source, u16 numbytes)
{
	u16 next;
	u16 i;
	u8 *ptr = (u8*) source;

	for (i = 0; i < numbytes; i++)
	{
		// check if FIFO has room
		next = (head + 1) % bufSize;
		if (next == tail)
			return i;

		buf[head] = ptr[i];
		head = next;
	}

	return i;
}

u16 Fifo::get(void *dest)
{
	return get(dest, size);
}

// get up to numbytes out of fifo into dest
u16 Fifo::get(void *dest, u16 numbytes)
{
	u8 *ptr = (u8*) dest;
	u16 next;
	u16 i;

	for (i = 0; i < numbytes; i++)
	{
		// if fifo is out of data return the number of bytes transferred
		if (head == tail)
			return i;

		next = (tail + 1) % bufSize;
		ptr[i] = buf[tail];
		tail = next;
	}

	return i;
}

// get data without removing it from the fifo
u16 Fifo::peek(void *dest, u16 numbytes)
{
	u8 *ptr = (u8*) dest;
	u16 tTail;
	u16 next;
	u16 i;

	tTail = tail;

	for (i = 0; i < numbytes; i++)
	{
		// if fifo is out of data return the number of bytes transferred
		if (head == tTail)
			break;

		next = (tTail + 1) % bufSize;
		ptr[i] = buf[tTail];
		tTail = next;
	}

	return i;
}

u16 Fifo::available()
{
	u16 val = (bufSize + head - tail) % bufSize;
	val = val / size;
	return val;
}

u16 Fifo::free()
{
	u16 val = (bufSize - 1 - available());
	val = val / size;
	return val;
}

BOOL Fifo::isEmpty()
{
	if (available() == 0)
		return TRUE;
	else
		return FALSE;
}
