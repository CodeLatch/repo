#include "print.h"
#include "utility.h"

//--------------------------------------------------------------------
// printf
//--------------------------------------------------------------------
int CPrint::printf(const char* fmt, ...)
{
	int len;
	char tmp[128];
	va_list va;
	va_start(va, fmt);
	len = format_s(tmp, sizeof(tmp), (char*) fmt, va);
	va_end(va);
	print(tmp);
	return len;
}