#include "print.h"
#include "utility.h"

CPrint::CPrint(void)
{
}


void CPrint::write(u8 val)
{
	// This is a virtual function that must be overridden by
	// the inheriting class for the CPrint class to do anything useful.
	//
	// This is the routine that ultimately does all the work.
	// All other print routines eventually rely on this one.
}


void CPrint::write(char val)
{
	write((u8) val);
}

void CPrint::print(const char* str)
{
	int i = 0;
	while ((*str != '\0') && (i++ < 500))
	{
		write((u8) *str);
		str++;
	}
}

void CPrint::println(const char* str)
{
	print(str);
	write('\n');
}