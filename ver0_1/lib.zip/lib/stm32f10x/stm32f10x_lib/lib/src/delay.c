#include "delay.h"
#include "stm32f10x_it.h"

void delay(u32 milliseconds) 
{	u32 timer;
	timerStart(timer,milliseconds);
	while(!timerExpired(timer));
}
