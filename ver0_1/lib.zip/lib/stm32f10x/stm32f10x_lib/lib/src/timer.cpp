#include "timer.h"
#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_tim.h"
#include "misc.h"


void timerEnableInterrupt(TIM_TypeDef* TIMx, u8 priority, u8 subPriority)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	
	if (TIMx == TIM2)
		NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	else if(TIMx == TIM3)
		NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
#if defined(STM32F10X_MD) || defined(STM32F10X_MD_VL) 
	else if(TIMx == TIM4)
		NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
#endif	
#if defined(STM32F10X_HD) || defined(STM32F10X_HD_VL) || defined(STM32F10X_XL) || defined(STM32F10X_CL) 
	else if(TIMx == TIM5)
		NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
	else if(TIMx == TIM6)
		NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;
	else if(TIMx == TIM7)
		NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;
#endif
	else
		return;
	
	// enable timer irq
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = priority & 0xf;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = subPriority & 0xf;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void timerInit(TIM_TypeDef* TIMx, u32 timerClkHz, u32 timerPeriodCnt)
{
	if (TIMx == TIM1)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	else if (TIMx == TIM2)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	else if(TIMx == TIM3)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	else if(TIMx == TIM4)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	else if(TIMx == TIM5)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
	else if(TIMx == TIM6)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	else if(TIMx == TIM7)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
	else if(TIMx == TIM8)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);
	else
		return;

	// it's the users responsiblity to make sure this is < 65536
	uint16_t prescaler = (uint16_t)(SystemCoreClock / timerClkHz) - 1;

	// configure structure
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_TimeBaseStructure.TIM_Period = timerPeriodCnt - 1;
	TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; // TIM_CKD_DIV1, 2, or 4
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIMx, &TIM_TimeBaseStructure);
	TIM_ITConfig(TIMx, TIM_IT_Update, ENABLE);
	TIM_Cmd(TIMx, ENABLE);
}

