// MMC / SD Card services

#include "mmc.h"
#include "pin.h"

//#include <AVR32_SPI.h"
//#include <AVR32_UART.h>

//extern CAVR32_SPI spi;
//extern CSWSPI spi;
//extern CAVR32_UART uart1;


CMMC::CMMC(void) {
//	CSWSPI::SPIINTERFACE sp = {{5,2},{2,2},{3,2},{2,2}};

}

CMMC::~CMMC(void) {
	// make sure sd card is not selected when we dump this class
	spi.unselectDevice(pin.CSn);
}

void CMMC::send_command(u8 command, u16 px, u16 py) {
	spi.selectDevice(pin.CSn);

	spi.write(0xff, &pin); // dummy byte

	spi.write(command | 0x40, &pin);

	spi.write((u8) ((px >> 8) & 0xff), &pin); // high byte of param x
	spi.write((u8) (px & 0xff), &pin); // low byte of param x

	spi.write((u8) ((py >> 8) & 0xff), &pin); // high byte of param y
	spi.write((u8) (py & 0xff), &pin); // low byte of param y

	spi.write(0x95, &pin); // correct CRC for first command in SPI
	// after that CRC is ignored, so no problem with
	// always sending 0x95
	spi.write(0xff, &pin); // ignore return byte

}

u8 CMMC::get(void) {
	u16 i = 0xffff;
	u8 b = 0xff;

	while ((b == 0xff) && (i != 0)) {
		b = spi.read(&pin);
		i--;
	}
	return b;

}

u16 CMMC::waitforbyte(u8 val) {
	u16 i = 0xffff;
	u8 r = spi.read(&pin);

	while ((r != val) && (i != 0)) {
		r = spi.read(&pin);
		i--;
	}

	if (r == val)
		return i;

	return 0;
}

u8 CMMC::datatoken(void) {
	u16 i = 0xffff;
	u8 b = 0xff;

	while ((b != 0xfe) && (i != 0)) {
		b = spi.read(&pin);
		i--;
	}
	return b;
}

void CMMC::clock_and_release(void) {
	u32 i;

	// SD cards require at least 8 final clocks
	for (i = 0; i < 10; i++)
		spi.write(0xff, &pin);

	spi.unselectDevice(pin.CSn);
}

int CMMC::readsector(u32 sector, u8 buffer[]) {
	u16 i;

	sector += sectorOffset;

	// send cmd, convert sector address to physical address (sectors are 512 bytes long)
	send_command(MMC_READ_SINGLE_BLOCK, (sector >> 7) & 0xffff, (sector << 9) & 0xffff);

	if (datatoken() != 0xfe) // if no valid token
			{
		clock_and_release(); // cleanup and
		return 0; // return error code
	}

	for (i = 0; i < 512; i++) // read sector data
		buffer[i] = spi.read(&pin);

	spi.write(0xff, &pin); // dummy checksum
	spi.write(0xff, &pin); // dummy checksum

	if (!waitforbyte(0xff)) // wait for ready
			{
		return 0;
	}
	clock_and_release(); // cleanup

	return 1; // return success
}

int CMMC::writesector(u32 sector, u8 *buffer) {
	u16 i;

	sector += sectorOffset;

	// send cmd, convert sector address to physical address (sectors are 512 bytes long)
	send_command(MMC_WRITE_BLOCK, (sector >> 7) & 0xffff, (sector << 9) & 0xffff);

	spi.write(0xff, &pin); // send start of block write
	spi.write(0xfe, &pin);

	for (i = 0; i < 512; i++) // write sector data
		spi.write(buffer[i], &pin);

	spi.write(0xff, &pin); // dummy checksum
	spi.write(0xff, &pin);

	if (!waitforbyte(0xff)) // wait for ready
			{
		return 0;
	}

	clock_and_release(); // cleanup

	// writing a sector is slow, to avoid problems delay here for a short time.
	//	delay_mS(100);

	return 1; // return success
}

u8 CMMC::erasesector(u32 sector) {
	sector += sectorOffset;

	// send cmd, convert sector address to physical address (sectors are 512 bytes long)
	send_command(MMC_TAG_SECTOR_START, (sector >> 7) & 0xffff,
			(sector << 9) & 0xffff);
	if (!waitforbyte(0xff)) // wait for ready
		return 0;

	send_command(MMC_TAG_SECTOR_END, (sector >> 7) & 0xffff,
			(sector << 9) & 0xffff);
	if (!waitforbyte(0xff)) // wait for ready
		return 0;

	send_command(MMC_ERASE, 0, 0);
	if (!waitforbyte(0xff)) // wait for ready
		return 0;

	clock_and_release(); // cleanup

	return 1; // return success
}

u8 CMMC::init(u32 CPU_FREQ_HZ, CSWSPI::SPIINTERFACE *pinDef) {
	int i;

	pin.CSn = pinDef->CSn;
	pin.MISO = pinDef->MISO;
	pin.MOSI = pinDef->MOSI;
	pin.SCK = pinDef->SCK;
	pin.SRn = pinDef->SRn;

	spi.initMaster(CPU_FREQ_HZ, 12000000, &pin);
	sectorOffset = 0;

	for (i = 0; i < 50; i++) // send clocks while card power stabilizes
		spi.write(0xff, &pin);

	send_command(MMC_GO_IDLE_STATE, 0, 0); // send CMD0 - reset card

	if (get() != 1) // if no valid response code
			{
		clock_and_release();
		return 10; // card cannot be detected
	}

	//
	// send CMD1 until we get a 0 back, indicating card is done initializing
	//
	i = 0xffff; // max timeout
	while ((spi.read(&pin) != 0) && (i != 0)) // wait for it
	{
		send_command(1, 0, 0); // send CMD1 - activate card init
		i--;
	}

	clock_and_release(); // clean up

	if (i == 0) // if we timed out above
			{
		return 20; // return failure code
	}
	return 0;
}

