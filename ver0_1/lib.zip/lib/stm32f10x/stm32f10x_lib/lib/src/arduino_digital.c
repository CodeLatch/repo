#include "arduino.h"
#include "pin.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "misc.h"

#ifndef NULL
#define NULL (void*)0
#endif


//	callbackFuncPtr = (PinInterruptCallbackType)NULL;

//--------------------------------------------------------------------
//
//--------------------------------------------------------------------
void digitalWrite(u8 pin, u8 state)
{
	if (state == 0)
		pinClr(pin);
	else
		pinSet(pin);
}

//--------------------------------------------------------------------
//
//--------------------------------------------------------------------
void pinSet(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return;
		GPIO_PORTS[port]->BSRR = GPIO_PIN_MAP[pin];
	}
}

//--------------------------------------------------------------------
//
//--------------------------------------------------------------------
void pinClr(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return;
		GPIO_PORTS[port]->BRR = GPIO_PIN_MAP[pin];
	}
}

//--------------------------------------------------------------------
//
//--------------------------------------------------------------------
void pinToggle(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return;
		GPIO_PORTS[port]->ODR ^= GPIO_PIN_MAP[pin];
	}
}

//--------------------------------------------------------------------
//
//--------------------------------------------------------------------
u8 pinRead(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return 0;
		if (GPIO_PORTS[port]->IDR & GPIO_PIN_MAP[pin])
			return 1;
		else
			return 0;
	}
	return 0;
}

u8 digitalRead(u8 pin)
{
	return pinRead(pin);
}

//--------------------------------------------------------------------
// Configure a physical pin.
//
// INPUT
// OUTPUT
// INPUT_PULLUP
// INPUT_PULLDOWN
// OUTPUT_OPENDRAIN
//--------------------------------------------------------------------
void pinMode(u8 pin, int mode)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_TypeDef* port;

	if ((pin <= 0) || (pin >= GPIO_PIN_MAP[0]))
		return;
	u8 portnum = GPIO_PORT_MAP[pin];
	if (portnum == 255) return;

	port = GPIO_PORTS[portnum];

	// enable peripheral clock for given port
	if (port == GPIOA)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	else if (port == GPIOB)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	else if (port == GPIOC)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	else if (port == GPIOD)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	else
		return;
/*
	// to enable us to use PB3,PB4,and PA15 as gpio's (default as jtag pins)
	if((pin == PB3) || (pin == PB4) || (pin == PA15))
	{
		RCC_APB2PeriphClockCmd (RCC_APB2Periph_AFIO, ENABLE);
		GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	}
*/
	GPIO_InitStructure.GPIO_Pin = GPIO_PIN_MAP[pin];
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	if (mode & INPUT)
	{
		if (mode & PULLUP)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		else if (mode & PULLDOWN)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		else
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		GPIO_Init(port, &GPIO_InitStructure);
		return;
	}
	else if (mode & OUTPUT)
	{
		if (mode & OPENDRAIN)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
		else
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_Init(port, &GPIO_InitStructure);
		return;
	}
	else if (mode & ALT)
	{
		if (mode & OPENDRAIN)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
		else
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_Init(port, &GPIO_InitStructure);
		return;
	}
}
