#include "convert.h"

//--------------------------------------------------------------------
// atoi_s
//
// converts a string to an int
//--------------------------------------------------------------------
int atoi_s(char *s, int maxstrlen)
{
	int r;
	int sign = 1;
	int i = 0;

	r = 0;

	// get past any whitespace
	while (((s[i] == ' ') || (s[i] == '\t')) && (i < maxstrlen))
		i++;
	if(i >= maxstrlen)
		return 0;

	// handle +/- sign
	if (s[i] == '+')
		i++;
	else if (s[i] == '-')
	{
		sign = -1;
		i++;
	}

	// handle integer part
	while (((s[i] >= '0') && (s[i] <= '9')) && (i < maxstrlen))
	{
		r = r * 10.0;
		r = r + (s[i] - '0');
		i++;
	}
	if(i > maxstrlen)
		return 0;

	// apply sign
	if (sign == -1)
		r = -r;

	return r;
}

//--------------------------------------------------------------------
// atof_s
//
// converts a string to a double
//--------------------------------------------------------------------
double atof_s(char *s, int maxstrlen)
{
	double r,d;
	int sign = 1;
	int i = 0;

	r = 0.0;

	// get past any whitespace
	while (((s[i] == ' ') || (s[i] == '\t')) && (i < maxstrlen))
		i++;
	if(i >= maxstrlen)
		return 0;

	// handle +/- sign
	if (s[i] == '+')
		i++;
	else if (s[i] == '-')
	{
		sign = -1;
		i++;
	}

	// handle integer part
	while (((s[i] >= '0') && (s[i] <= '9')) && (i < maxstrlen))
	{
		r = r * 10.0;
		r = r + (s[i] - '0');
		i++;
	}
	if(i >= maxstrlen)
		return 0;

	// handle fraction part
	if (s[i] == '.')
	{
		d = 0.1;
		i++;
		while (((s[i] >= '0') && (s[i] <= '9')) && (i < maxstrlen))
		{
			r = r + (d * (s[i] - '0'));
			d = d * 0.1;
			i++;
		}
	}

	// apply sign
	if (sign == -1)
		r = -r;

	return r;
}
