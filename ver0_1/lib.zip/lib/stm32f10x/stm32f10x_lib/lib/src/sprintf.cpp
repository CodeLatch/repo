#include "print.h"
#include "utility.h"

#define FORMATTED_NUMBER_MAX_LEN  32

//--------------------------------------------------------------------
// sprintf
//--------------------------------------------------------------------
int sprintf(char* buf, int bufSize, const char* fmt, ...)
{
	int len;
	va_list va;
	va_start(va, fmt);
	len = format_s(buf, bufSize, (char*) fmt, va);
	va_end(va);
	return len;
}

//--------------------------------------------------------------------
// format_s
//--------------------------------------------------------------------
int format_s(char* output, int maxlen, char* fmt, va_list va)
{
	char tmp[FORMATTED_NUMBER_MAX_LEN];
	char ch;
	int n;
	char* ptr = output;

	memset(output, 0, maxlen);

	// loop until *fmt == 0 (end of str) or maxlen is exceeded
	while ((ch = *fmt) && (maxlen > 0))
	{
		fmt++;
		// print characters until we get to a %
		if (ch != '%')
		{
			//print(ch);
			*ptr = ch;
			ptr++;
			maxlen--;
		}
		else
		{
			// process string following a %
			char leadingChar = ' ';
			bool longInt = false;
			int leadingCharCnt = 0;
			int precision = 7; // default floating point precision is 7

			// get next character
			ch = *(fmt);
			fmt++;
			// a 0 would indicate we want leading zeros in front of the number
			if (ch == '0')
			{
				ch = *(fmt);
				fmt++;
				leadingChar = '0';
			}
			// a digit 0..9 indicates the number of leading zeros or spaces
			if (ch >= '0' && ch <= '9')
			{
				leadingCharCnt = ch - '0';
				ch = *(fmt);
				fmt++;
			}
			// a second digit 0..9 means we want double digit leading zeros or spaces
			if (ch >= '0' && ch <= '9')
			{
				leadingCharCnt *= 10;
				leadingCharCnt += ch - '0';
				ch = *(fmt);
				fmt++;
			}
			// a . indicates we are going to specify the precision of a double
			if (ch == '.')
			{
				ch = *(fmt);
				fmt++;
				if (ch >= '0' && ch <= '9')
				{
					precision = ch - '0';
					ch = *(fmt);
					fmt++;
				}
			}
			if (ch == 'l')
			{
				ch = *(fmt);
				fmt++;
				longInt = true;
			}

			// process characters
			switch (ch)
			{
				case 0: // just in case, but shouldn't normally happen
					return (int)(ptr - output);
				case 'u':
				case 'd':
				case 'x':
				case 'X':
					if (ch == 'u')
						n = itoa_s((u32)va_arg(va, unsigned int), tmp, sizeof(tmp), 10, 1);
					else if (ch == 'd')
						n = itoa_s((s32)va_arg(va, int), tmp, sizeof(tmp), 10, 1);
					else // ((ch == 'x') || (ch == 'X'))
						n = itoa_s((u32) va_arg(va, unsigned int), tmp, sizeof(tmp), 16, (ch == 'X'));
					leadingCharCnt -= n;
					maxlen -= n;
					if (leadingCharCnt > maxlen)
						leadingCharCnt = maxlen;
					if ((leadingCharCnt > 0) && (maxlen > 0))
					{
						memset(ptr, leadingChar, leadingCharCnt);
						ptr += leadingCharCnt;
						maxlen -= leadingCharCnt;
					}
					memcpy(ptr, tmp, n);
					ptr += n;
					break;
				case 'f':
					n = ftoa_s((double) va_arg(va, double), precision, ptr, maxlen);
					maxlen -= n;
					ptr += n;
					break;
				case 'e':
					// currently unsupported
					break;
				case 'c':
					ch = (char) va_arg(va, int);
					*ptr = ch;
					ptr++;
					maxlen--;
					break;
				case 's':
				{
					char* str = (char*)va_arg(va, char*);
					n = strcpy_s(ptr, maxlen, str);
					maxlen -= n;
					ptr += n;
				}
				break;
				case '%':
					*ptr = ch;
					ptr++;
					maxlen--;
					break;
				default:
					break;
			}
		}
	}

	return (int)(ptr - output);
}



