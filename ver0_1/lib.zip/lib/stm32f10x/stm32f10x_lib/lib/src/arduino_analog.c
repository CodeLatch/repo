#include "arduino.h"
#include "pin.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "misc.h"
#include "stm32f10x_adc.h"

void init_ADC1()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); 	// turn on adc1
	RCC_ADCCLKConfig(RCC_PCLK2_Div6); 						// set adc1 clock prescaler

	ADC1->CR1 &= 0xFFF0FEFF;
	ADC1->CR1 |= ADC_Mode_Independent;
	ADC1->CR2 &= 0xFFF1F7FD;
	ADC1->CR2 |= (ADC_DataAlign_Right | ADC_ExternalTrigConv_None);
	ADC1->SQR1 &= 0xFF0FFFFF;
	ADC1->SQR1 = 0;
	ADC1->CR2 |= 0x00000001;

	// Enable ADC1 reset calibration register
	ADC1->CR2 |= 0x00000008;
	// Check the end of ADC1 reset calibration register
	while (ADC1->CR2 & 0x00000008);

	// Start ADC1 calibration
	ADC1->CR2 |= 0x00000004;
	// Check the end of ADC1 calibration
	while (ADC1->CR2 & 0x00000004);
}

void init_ADC_pin(u8 pin)
{
	if ((pin <= 0) || (pin >= GPIO_PIN_MAP[0]))
		return;

	u8 portnum = GPIO_PORT_MAP[pin];
	if (portnum == 255) return;
	GPIO_TypeDef* port = GPIO_PORTS[portnum];

	// enable peripheral clock for the port for this pin
	if (port == GPIOA)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	else if (port == GPIOB)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	else if (port == GPIOC)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	else if (port == GPIOD)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	else
		return;

	// setup pin configuration
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_PIN_MAP[pin];
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(port, &GPIO_InitStructure);
}

u32 analogRead(u8 pin)
{
	if ((pin == 0) || (pin >= TABLE_ADCChannel[0]))
		return 0;
	u8 channel = TABLE_ADCChannel[pin];
	if (channel == 255)
		return 0;

	// check if adc1 has been initialized...
	if ((RCC->APB2ENR & RCC_APB2Periph_ADC1) == 0)
		init_ADC1();

	// check if this pin has been initialized
	// get GPIO_PORT->CRH, check if analog_in
	init_ADC_pin(pin);

	// configure adc
	ADC_RegularChannelConfig(ADC1, channel, 1, ADC_SampleTime_55Cycles5);
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
	// wait for End Of Conversion
	while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET)
		;
	// return the value
	return ADC_GetConversionValue(ADC1);
}