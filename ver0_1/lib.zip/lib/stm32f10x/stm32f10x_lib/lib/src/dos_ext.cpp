#include "dos.h"
#include "stdio.h"
#include "string_s.h"
#include "stdlib.h"
#include "utility.h"

//-----------------------------------------------------------------------------
// debugShowBootInfo
//-----------------------------------------------------------------------------
void CDos::debugShowBootInfo(void)
{
	/*	msg.printf("m_fatType             %u\n", m_fatType);
		msg.printf("m_bytesPerSector      %u\n", m_bytesPerSector);
		msg.printf("m_sectorsPerCluster   %u\n", m_sectorsPerCluster);
		msg.printf("m_reservedSectors     %u\n", m_reservedSectors);
		msg.printf("m_numFATs             %u\n", m_numFATs);
		msg.printf("m_maxRootDirEntries   %u\n", m_maxRootDirEntries);
		msg.printf("m_sectorsPerFAT       %u\n", m_sectorsPerFAT);
		msg.printf("m_firstRootDirSector  %lu\n", m_firstRootDirSector);
		msg.printf("m_firstFATSector      %lu\n", m_firstFATSector);
		msg.printf("m_firstDataSector     %lu\n", m_firstDataSector);
		msg.printf("m_currentDirSector    %lu\n", m_currentDirSector);
		msg.printf("m_currentDirCluster   %lu\n", m_currentDirCluster);
	*/
}

//-----------------------------------------------------------------------------
// FUNCTION: dbgListFiles
//-----------------------------------------------------------------------------
int CDos::dbgListFiles(void)
{
	u16 i, max, numbytes;
	int n;
	char fname[13];
	struct MMCFILE dir;
	u8 tmp[32];

	// read boot sector info
	//	if(!readbootinfo())
	if (!m_initSuccess)
		return DOS_FAIL;

	// use a file structure to search the directory
	dir.status = 1;
	dir.firstcluster = m_currentDirCluster;
	dir.cluster = m_currentDirCluster;
	dir.sector = m_currentDirSector;
	dir.sectoroffset = 0;
	dir.byteptr = 0;
	dir.byteoffset = 0;
	dir.size = 32;
	dir.dirsector = 0; // this will indicate to the write not to try and update this directory size
	dir.dirsectoroffset = 0;

	// max 512 entries in root directory
	// I'm setting an arbitrary limit on the number of files in a subdirectory of 5000.
	if (m_currentDirSector < m_firstDataSector)
		max = 512;
	else
		max = 5000;

	n = 0;
	// look for the files
	for (i = 0; i < max; i++)
	{
		// read in file directory entry at the location pointed to by dir
		readBuf(tmp, 1, 32, &numbytes, &dir);
		if (numbytes != 32)
			return DOS_FAIL;
		dir.size += 32;

		// check for end of directory indicator
		if (tmp[0] == 0x00)
			return DOS_SUCCESS;

		// check for valid directory entry, 0x3f = any file or directory type is ok
		if (isfile(tmp, 0x3f))
		{
			n++;
			// print the name
			memcpy(fname, tmp, 11);
			fname[11] = 0;
			//			msg.printf("%s\r\n", fname);
		}
	}
	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// InitDirectorySearch
//
// if startAtRoot = 1 we will start at the root directory, otherwise
// we will start at the current directory.
//-----------------------------------------------------------------------------
int CDos::InitDirectorySearch(struct MMCFILE* dir, int startAtRoot)
{
	// read boot sector info
	//	if(!readbootinfo())
	if (!m_initSuccess)
		return DOS_FAIL;

	if (startAtRoot != 0)
	{
		m_currentDirSector = m_firstRootDirSector;
		m_currentDirCluster = ClusterFromSector(m_currentDirSector);
		dir->size = m_maxRootDirEntries * 32;
	}
	else
	{
		dir->size = 32;
	}

	// use a file structure to search the directory
	dir->status = 1;
	dir->firstcluster = m_currentDirCluster;
	dir->cluster = m_currentDirCluster;
	dir->sector = m_currentDirSector;
	dir->sectoroffset = 0;
	dir->byteptr = 0;
	dir->byteoffset = 0;
	dir->dirsector = 0; // this will indicate to the write not to try and update this directory size
	dir->dirsectoroffset = 0;

	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// GetNextDirEntry
//
// return: 0 = end of directory
//         1 = matching filetype entry type found
//         2 = non-matching filetype entry
//-----------------------------------------------------------------------------
int CDos::GetNextDirEntry(struct MMCFILE* dir, struct DIRENTRY* entry, u8 filetype)
{
	u16 numbytes, ret;
	u8 buffer[32];

	// read in file directory entry at the location pointed to by dir
	ret = readBuf(buffer, 1, 32, &numbytes, dir);

	if (numbytes != 32)
		return DOS_FAIL;
	dir->size += 32;

	// check for end of directory indicator
	if (buffer[0] == 0x00)
		return DOS_FAIL;

	// check if this is a subdirectory name entry
	if ((buffer[11] & 0x02) != 0)
		return DOS_NOMATCH;

	// check for matching entry attribute
	if (isfile(buffer, filetype))
	{
		memset(entry->name, 0, 13);
		memcpy(entry->name, buffer, 11);

		entry->attribute = buffer[11];

		entry->time = buffer[23];
		entry->time <<= 8;
		entry->time |= buffer[22];

		entry->date = buffer[25];
		entry->date <<= 8;
		entry->date |= buffer[24];

		if (m_fatType == DOS_FAT16)
		{
			entry->cluster = buffer[27];
			entry->cluster <<= 8;
			entry->cluster |= buffer[26];
		}
		else   // fat32
		{
			entry->cluster = buffer[21];
			entry->cluster <<= 8;
			entry->cluster |= buffer[20];
			entry->cluster <<= 8;
			entry->cluster = buffer[27];
			entry->cluster <<= 8;
			entry->cluster |= buffer[26];
		}

		entry->size = buffer[31];
		entry->size <<= 8;
		entry->size |= buffer[30];
		entry->size <<= 8;
		entry->size |= buffer[29];
		entry->size <<= 8;
		entry->size |= buffer[28];

		return DOS_SUCCESS;
	}
	return DOS_NOMATCH;
}

//-----------------------------------------------------------------------------
// FUNCTION: mkdir
//
// Description:
//   make directory.
//
// Parameters:
// char *dirname		-- name of directory
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::mkdir(const char* _dirname)
{
	u32 cluster, currentcluster;
	struct MMCFILE f;
	char dirname[13];

	ToUpper(_dirname, dirname, strlen_s(_dirname));

	// if a file with this filename already exists, return fail
	if (findfile(&f, dirname, DOS_ARCHIVE | DOS_DIRECTORY))
		return DOS_FAIL;
	currentcluster = m_currentDirCluster;
	if (currentcluster == ClusterFromSector(m_firstRootDirSector))
		currentcluster = 0;

	// find an open cluster in the fat that will be the start of a new chain
	cluster = getfreecluster(0);
	if (cluster == 0)
		return DOS_FAIL;
	// init variables
	f.firstcluster = cluster;
	f.cluster = cluster;
	f.sector = SectorFromCluster(cluster);
	f.sectoroffset = 0;
	f.byteptr = 0;
	f.byteoffset = 0;
	f.size = 0;

	// create a new entry in the directory structure
	if (!createdirentry(&f, dirname, cluster, DOS_DIRECTORY))
		return DOS_FAIL;
	if (!chdir(dirname))
		return DOS_FAIL;
	if (!createdirentry(&f, (char*) ".", cluster, DOS_DIRECTORY))
		return DOS_FAIL;
	if (!createdirentry(&f, (char*) "..", currentcluster, DOS_DIRECTORY))
		return DOS_FAIL;
	if (!chdir((char*) ".."))
		return DOS_FAIL;
	// flag file as open and ready
	f.status = 1;
	return DOS_SUCCESS;
}
