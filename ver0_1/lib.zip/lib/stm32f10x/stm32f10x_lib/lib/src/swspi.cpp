//-----------------------------------------------------------------------------
// Software implementation of SPI.
// equivalant sequencing of CPOL = 0, CPHA = 0
//
// CS/        ------____________________________________________________--------
// SCLK       __________---___---___---___---___---___---___---___---___________
// MISO                  R     R     R     R     R     R     R     R
// MOSI                W     W     W     W     W     W     W     W
//
// Notes: 1) MISO is read by the micro xns after rising edge of SCLK.
//        2) MOSI is written by the micro xns before the rising edge of SCLK.
//        3) During reads MOSI is high.
// 	      4) The falling edge of CS/ to the rising edge of SCLK is xns.
// 	      5) The falling edge of SCLK to rising edge of CS/ is xns.
// 	      6) During a  read cycle SCLK high time is xns, low time is xns, bit rate is xbps.
// 	      7) During a write cycle SCLK high time is xns, low time is xns, bit rate is xbps.
//-----------------------------------------------------------------------------

// OLIMEXINO STM32 SD CARD
//
// MOSI		D34		PB15	SPI2_MOSI
// MISO		D33		PB14	SPI2_MISO
// SCK		D32		PB13	SPI2_CLK
// CS		D25		PD2
//

#define CLK_LOW 		GPIOB->BRR = GPIO_Pin_13
#define CLK_HIGH		GPIOB->BSRR = GPIO_Pin_13
#define MOSI_LOW 		GPIOB->BRR = GPIO_Pin_15
#define MOSI_HIGH		GPIOB->BSRR = GPIO_Pin_15
#define CS_LOW 			GPIOD->BRR = GPIO_Pin_2
#define CS_HIGH			GPIOD->BSRR = GPIO_Pin_2


#include "swspi.h"
#include "pin.h"
#include "stm32f10x_spi.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"

//#include <cycle_counter.h>

//#define SWSPI_USE_SPI

CSWSPI::CSWSPI(void) {
}

CSWSPI::~CSWSPI(void) {
}
//-----------------------------------------------------------------------------
//
//
// if config = 0, clk is normally low
// if config = 1, clk is normally high
//-----------------------------------------------------------------------------
#ifndef SWSPI_USE_SPI
void CSWSPI::initMaster(volatile unsigned long cpuFreqHz,
		unsigned long baudRate, CSWSPI::SPIINTERFACE *pin) {

	Pin.mode(pin->CSn, OUTPUT);
	Pin.mode(pin->SCK, OUTPUT);
	Pin.mode(pin->MOSI, OUTPUT);
	Pin.mode(pin->MISO, INPUT | PULLUP);

//	Pin.set(pin->CSn);
//	Pin.clr(pin->MOSI);
//	Pin.clr(pin->SCK);
	CS_HIGH;
	MOSI_LOW;
	CLK_LOW;
}

//-----------------------------------------------------------------------------
// write
//-----------------------------------------------------------------------------
void CSWSPI::write(unsigned char data, CSWSPI::SPIINTERFACE *pin) {
	unsigned char i;

	for (i = 0; i < 8; i++) {
//		Pin.clr(pin->SCK); // send clk low
		CLK_LOW;

		if (data & 0x80)
//			Pin.set(pin->MOSI); // write mosi, msb first
			MOSI_HIGH;

		else
//			Pin.clr(pin->MOSI);
			MOSI_LOW;

//		Pin.set(pin->SCK); // send clk high
		CLK_HIGH;

		data <<= 1; // point to next data bit
	}

	__asm("nop");
	// make clk pulse a little longer for some devices
	__asm("nop");
	// make clk pulse a little longer for some devices
	__asm("nop");
	// make clk pulse a little longer for some devices
	__asm("nop");
	// make clk pulse a little longer for some devices

//	Pin.clr(pin->SCK); // send clk low
	CLK_LOW;
}

//-----------------------------------------------------------------------------
// read
//
// this is the same as xferByte(0xff,&pin);
//-----------------------------------------------------------------------------
unsigned char CSWSPI::read(CSWSPI::SPIINTERFACE *pin) {
	unsigned char data = 0;
	unsigned char i;

	// effectivly send 0xff on the write cycle
	MOSI_HIGH;

	for (i = 0; i < 8; i++) {
		CLK_LOW; // send clk low
		data <<= 1;
		__asm("nop");
		// make clk pulse a little longer for some devices
		CLK_HIGH; // send clk high
		if(GPIOB->IDR & GPIO_Pin_14)
			data |= 1;
//		data |= Pin.read(pin->MISO); // read miso, msb first
	}
	__asm("nop");
	// make clk pulse a little longer for some devices
	CLK_LOW; // send clk low

	return data;
}

void CSWSPI::selectDevice(int pin) {
	CS_LOW;;
}

void CSWSPI::unselectDevice(int pin) {
	if (pin != 100)
		CS_HIGH;
}

#else

void CSWSPI::initMaster(volatile unsigned long cpuFreqHz,
		unsigned long baudRate, CSWSPI::SPIINTERFACE *pin) {

	u16 tmpreg = 0;
	tmpreg = SPI2->CR1;
	tmpreg &= 0x3040;
	tmpreg |= (u16) ((uint32_t) SPI_InitStructure.SPI_Direction
			| SPI_InitStructure.SPI_Mode | SPI_InitStructure.SPI_DataSize
			| SPI_InitStructure.SPI_CPOL | SPI_InitStructure.SPI_CPHA
			| SPI_InitStructure.SPI_NSS
			| SPI_InitStructure.SPI_BaudRatePrescaler
			| SPI_InitStructure.SPI_FirstBit);
	SPI2->CR1 = tmpreg;
	SPI2->I2SCFGR &= 0xF7FF;
	SPI2->CRCPR = SPI_InitStructure.SPI_CRCPolynomial;
	SPI2->CR1 |= 0x0040;
}

//-----------------------------------------------------------------------------
// write
//-----------------------------------------------------------------------------
void CSWSPI::write(unsigned char data, CSWSPI::SPIINTERFACE *pin) {

	while ((SPI2->SR & SPI_I2S_FLAG_TXE) == 0)
		;
	SPI2->DR = data;
	while ((SPI2->SR & SPI_I2S_FLAG_TXE) == 0)
		;
}

//-----------------------------------------------------------------------------
// read
//
// this is the same as xferByte(0xff,&pin);
//-----------------------------------------------------------------------------
unsigned char CSWSPI::read(CSWSPI::SPIINTERFACE *pin) {
	unsigned char data;

	// effectively send 0xff on the write cycle
//	write(0xff,pin);
//	while ((SPI2->SR & SPI_I2S_FLAG_RXNE) == 0)
//		;
	while ((SPI2->SR & SPI_I2S_FLAG_TXE) == 0)
		;
	SPI2->DR = 0xff;
	while ((SPI2->SR & SPI_I2S_FLAG_TXE) == 0)
		;

	while ((SPI2->SR & SPI_I2S_FLAG_RXNE) == 0)
		;

	data = SPI2->DR;
	return data;
}


void CSWSPI::selectDevice(int pin) {
	Pin.clr(pin);
}

void CSWSPI::unselectDevice(int pin) {
	if (pin != 100)
		Pin.set(pin);
}

#endif
