

#include "serial.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "string.h"
#include "misc.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

CSerial Serial(USART1);
CSerial Serial2(USART2);

//------------------------------------------------------------------------------
// USART1 interrupt handler. Called when we receive a character on USART1.
//------------------------------------------------------------------------------
void USART1_IRQHandler(void)
{
	// if we received a character process it
	if ((USART1->SR & USART_FLAG_RXNE) != (u16)RESET)
	{
		// get the character
		char c = (char) USART_ReceiveData(USART1);
		if (Serial.b_ignoreUnprintable && ((c < ' ') || (c > '~')) && (c != '\n'))
			return;
		// add data to receive fifo
		Serial.rxFifo.put(&c, 1);
		if (Serial.rxCallback)
		{
			if (Serial.termRxOnLF)
			{
				if ((c == '\n') || (Serial.rxFifo.free() == 0))
					Serial.rxCallback();
			}
			else
				Serial.rxCallback();
		}
	}
}

//------------------------------------------------------------------------------
// USART2 interrupt handler. Called when we receive a character on USART1.
//------------------------------------------------------------------------------
void USART2_IRQHandler(void)
{
	// if we received a character process it
	if ((USART2->SR & USART_FLAG_RXNE) != (u16)RESET)
	{
		// get the character
		char c = (char) USART_ReceiveData(USART2);
		if (Serial2.b_ignoreUnprintable && ((c < ' ') || (c > '~')) && (c != '\n'))
			return;
		// add data to receive fifo
		Serial2.rxFifo.put(&c, 1);
		if (Serial2.rxCallback)
		{
			if (Serial2.termRxOnLF)
			{
				if ((c == '\n') || (Serial2.rxFifo.free() == 0))
					Serial2.rxCallback();
			}
			else
				Serial2.rxCallback();
		}
	}
}

//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
CSerial::CSerial(USART_TypeDef *uart)
{
	this->uart = uart;
	termRxOnLF = false;
	b_ignoreUnprintable = false;
	rxCallback = (SerialRxCallbackType) NULL;
}

//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
void CSerial::terminateRxOnLF(bool enable)
{
	termRxOnLF = enable;
}

//------------------------------------------------------------------------------
// Initialize the USART1 and use PA9 for Tx, PA10 for RX.
//------------------------------------------------------------------------------
void CSerial::start(uint32_t baud)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;

	rxFifo.initialize(rxbuf, 1, SERIAL_RX_BUF_SIZE);

	// enable USART and GPIO clocks
	if (uart == USART1)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);
		NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	}
	else if (uart == USART2)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 | RCC_APB2Periph_GPIOA, ENABLE);
		NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	}
	else if (uart == USART3)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3 | RCC_APB2Periph_GPIOB, ENABLE);
		NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	}
#ifdef STM32F10X_HD
	else if (uart == UART4)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4  | RCC_APB2Periph_GPIOC, ENABLE);
		NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
	}
	else if (uart == UART5)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5  | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);
		NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
	}
#endif
	else
		return;

	// configure USART
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = baud;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(uart, &USART_InitStructure);

	// enable USART
	USART_Cmd(uart, ENABLE);

	// enable USART receive interrupt
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	USART_ITConfig(uart, USART_IT_RXNE, ENABLE);

	if (uart == USART1)
	{
		// configure gpio pins for uart operation
		// USART1 Tx on PA9
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		// USART1 Rx on PA10
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
	}
	else if (uart == USART2)
	{
		// configure gpio pins for uart operation
		// USART2 Tx on PA2
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		// USART1 Rx on PA3
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
	}
}

//!----------------------------------------------------------------------------
//! \brief  Routine to send data to the pc. Overrides CPrint::write().
//! Attempts to place a byte into the transmit fifo, will wait up to txTimeout before
//! bailing out.
//!----------------------------------------------------------------------------
void CSerial::write(u8 val)
{
	// wait for pending usart tx to finish
	while (USART_GetFlagStatus(uart, USART_FLAG_TC) == RESET)	{}
	USART_SendData(uart, (uint16_t) val);
}

//!----------------------------------------------------------------------------
//! \brief	Routine to read data out of the receive fifo.
//!----------------------------------------------------------------------------
u16 CSerial::read(void *dest, u16 numbytes)
{
	return rxFifo.get(dest, numbytes);
}

//!----------------------------------------------------------------------------
//! \brief	Routine to read a character string out of the receive fifo.
//! Returns the length of the string read.
//!----------------------------------------------------------------------------
u16 CSerial::gets(char* str, u16 maxlen)
{
	u16 n = 0;

	// if no data is available return
	if (rxFifo.available() == 0)
	{
		str[0] = '\0';
		return 0;
	}

	memset(str, 0, maxlen);
	rxFifo.peek(str, maxlen);
	// determine string length
	for (n = 0; n < maxlen; n++)
		if (str[n] == '\0')
			break;
	// include terminating null if present
	if (n < maxlen)
		n++;
	// get the string
	n = rxFifo.get(str, n);
	return n;
}

//!----------------------------------------------------------------------------
//! \brief	Returns the number of bytes available in the receive fifo.
//!----------------------------------------------------------------------------
u16 CSerial::available(void)
{
	return rxFifo.available();
}

//!----------------------------------------------------------------------------
//! \brief	Sets a callback function that will be called when we receive data
//! from the pc.
//!
//! example:
//! 		void hidRxCallback(void) { do something} // our callback FunctionalState
//!		...
//!		Terminal.setRxCallback(hidRxCallback);
//!		Terminal.start();
//!----------------------------------------------------------------------------
void CSerial::setRxCallback(SerialRxCallbackType cb)
{
	rxCallback = cb;
}


