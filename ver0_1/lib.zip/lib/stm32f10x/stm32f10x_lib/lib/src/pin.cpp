#include "pin.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_tim.h"

CPin Pin;

#ifndef NULL
#define NULL (void*)0
#endif


// constructor
CPin::CPin(void)
{
	callbackFuncPtr = (PinInterruptCallbackType)NULL;
}

// destructor
CPin::~CPin(void)
{
}

// set - sets pin output high.
// pin is the physical pin number
void CPin::set(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return;
		GPIO_PORTS[port]->BSRR = GPIO_PIN_MAP[pin];
	}
}

// clr - sets pin output low.
void CPin::clr(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return;
		GPIO_PORTS[port]->BRR = GPIO_PIN_MAP[pin];
	}
}

// toggle - toggles state of pin.
void CPin::toggle(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return;
		GPIO_PORTS[port]->ODR ^= GPIO_PIN_MAP[pin];
	}
}

// read - returns 0 or 1 based on state of pin.
u8 CPin::read(u8 pin)
{
	if ((pin > 0) && (pin < GPIO_PIN_MAP[0]))
	{
		u8 port = GPIO_PORT_MAP[pin];
		if (port == 255) return 0;
		if (GPIO_PORTS[port]->IDR & GPIO_PIN_MAP[pin])
			return 1;
		else
			return 0;
	}
	return 0;
}

/******************************************************************************
 * Configure a physical pin.
 *
 * pin: 0-37
 *
 * mode: logical or'ed combination of the following options...
 *
 * INPUT
 * OUTPUT
 * PULLUP
 * PULLDOWN
 * OPENDRAIN
 * NORMAL
 * ADC
 * ALT_OD
 * ALT_PP
 *
 *****************************************************************************/
void CPin::mode(u8 pin, int mode)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_TypeDef* port;

	if ((pin <= 0) || (pin >= GPIO_PIN_MAP[0]))
		return;
	u8 portnum = GPIO_PORT_MAP[pin];
	if (portnum == 255) return;

	port = GPIO_PORTS[portnum];

	// enable peripheral clock for given port
	if (port == GPIOA)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	else if (port == GPIOB)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	else if (port == GPIOC)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	else if (port == GPIOD)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	else
		return;

	GPIO_InitStructure.GPIO_Pin = GPIO_PIN_MAP[pin];
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	if (mode & INPUT)
	{
		if (mode & PULLUP)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		else if (mode & PULLDOWN)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		else
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		GPIO_Init(port, &GPIO_InitStructure);
		return;
	}
	else if (mode & OUTPUT)
	{
		if (mode & OPENDRAIN)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
		else
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_Init(port, &GPIO_InitStructure);
		return;
	}
	else if (mode & ALT)
	{
		if (mode & OPENDRAIN)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
		else
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_Init(port, &GPIO_InitStructure);
		return;
	}
	else if (mode & ADC)
	{
		RCC_ADCCLKConfig(RCC_PCLK2_Div6); // set adc clock
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); // turn on adc 1 clocks.
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
		GPIO_Init(port, &GPIO_InitStructure);

		ADC1->CR1 &= 0xFFF0FEFF;
		ADC1->CR1 |= ADC_Mode_Independent;
		ADC1->CR2 &= 0xFFF1F7FD;
		ADC1->CR2 |= (ADC_DataAlign_Right | ADC_ExternalTrigConv_None);
		ADC1->SQR1 &= 0xFF0FFFFF;
		ADC1->SQR1 = 0;
		ADC1->CR2 |= 0x00000001;

		// Enable ADC1 reset calibration register
		ADC1->CR2 |= 0x00000008;
		// Check the end of ADC1 reset calibration register
		while (ADC1->CR2 & 0x00000008)
			;

		// Start ADC1 calibration
		ADC1->CR2 |= 0x00000004;
		// Check the end of ADC1 calibration
		while (ADC1->CR2 & 0x00000004)
			;

		return;
	}
	else if (mode & PWM)
	{
		if (mode & OPENDRAIN)
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
		else
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_Init(port, &GPIO_InitStructure);

		if (pin > TABLE_pinTimer[0]) // first entry in table is the number of entries
			return;
		u8 timer = TABLE_pinTimer[pin];
		u8 channel = TABLE_pinTimerChannel[pin];
		//TIM_TypeDef* timerPtr = getTimerPtr(timer);
		TIM_TypeDef* timerPtr = TABLE_Timer[timer];
		if (timerPtr == NULL)
			return;
		// 12MHz clock, 2000 max count = 12MHz / 2000 = 6khz =
		// TIM_Prescaler = (timer_clk_source_hz / target_timer_clk_hz) - 1
		// timer_frequency = (timer_clk_source_hz / (TIM_Prescaler + 1)) / (TIM_Period + 1)

		configureTimerPWM(timerPtr, channel, 24000000, 1000);    // ptr, channel, freq, max count
	}

}

//!----------------------------------------------------------------------------
//! \brief  Configure a timer to produce a pwm signal. You also need to call
//! Pin.mode(x,PWM); to set the pin in the correct mode.
//!----------------------------------------------------------------------------
void CPin::configureTimerPWM(TIM_TypeDef* timerX, u8 channel, u32 timerClkHz, u32 timerPeriodCnt)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	uint16_t prescaler = 0;

	if ((timerClkHz == 0) || (timerPeriodCnt == 0))
		return;

	// enable clock for timer
	if (timerX == TIM2)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	else if (timerX == TIM3)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	else if (timerX == TIM4)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	else if (timerX == TIM5)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
	else
		return;

	// maybe only need this for alternate mapping????
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

	// TIM_Prescaler = (timer_clk_source_hz / target_timer_clk_hz) - 1
	// timer_frequency = (timer_clk_source_hz / (TIM_Prescaler + 1)) / (TIM_Period + 1)
	// timer_duty_cycle = (TIMx->CCRx / TIM_Period);
	prescaler = (uint16_t)(SystemCoreClock / timerClkHz) - 1;

	// configure structures
	TIM_TimeBaseStructure.TIM_Period = timerPeriodCnt - 1;
	TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(timerX, &TIM_TimeBaseStructure);

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;

	if (channel == 1)
	{
		TIM_OC1Init(timerX, &TIM_OCInitStructure);
		TIM_OC1PreloadConfig(timerX, TIM_OCPreload_Enable);
	}
	else if (channel == 2)
	{
		TIM_OC2Init(timerX, &TIM_OCInitStructure);
		TIM_OC2PreloadConfig(timerX, TIM_OCPreload_Enable);
	}
	else if (channel == 3)
	{
		TIM_OC3Init(timerX, &TIM_OCInitStructure);
		TIM_OC3PreloadConfig(timerX, TIM_OCPreload_Enable);
	}
	else if (channel == 4)
	{
		TIM_OC4Init(timerX, &TIM_OCInitStructure);
		TIM_OC4PreloadConfig(timerX, TIM_OCPreload_Enable);
	}

	TIM_ARRPreloadConfig(timerX, ENABLE);
	TIM_Cmd(timerX, ENABLE);
}

void CPin::pwm(u8 pin, u16 value)
{
	if (pin > TABLE_pinTimer[0])
		return;

	u8 timer = TABLE_pinTimer[pin];
	u8 channel = TABLE_pinTimerChannel[pin];
	if (timer == 0)
		return;

	//	TIM_TypeDef* timerPtr = getTimerPtr(timer);
	TIM_TypeDef* timerPtr = TABLE_Timer[timer];
	if (timerPtr == 0)
		return;

	if (channel == 1)
		timerPtr->CCR1 = value;
	else if (channel == 2)
		timerPtr->CCR2 = value;
	else if (channel == 3)
		timerPtr->CCR3 = value;
	else if (channel == 4)
		timerPtr->CCR4 = value;
}


u32 CPin::readAnalog(u8 pin)
{
	if (pin >= TABLE_ADCChannel[0])
		return 0;

	// note: adc clock is set in mode() as main clock / 6

	// ADC_SampleTime_1Cycles5: Sample time equal to 1.5 cycles
	// ADC_SampleTime_7Cycles5: Sample time equal to 7.5 cycles
	// ADC_SampleTime_13Cycles5: Sample time equal to 13.5 cycles
	// ADC_SampleTime_28Cycles5: Sample time equal to 28.5 cycles
	// ADC_SampleTime_41Cycles5: Sample time equal to 41.5 cycles
	// ADC_SampleTime_55Cycles5: Sample time equal to 55.5 cycles
	// ADC_SampleTime_71Cycles5: Sample time equal to 71.5 cycles
	// ADC_SampleTime_239Cycles5: Sample time equal to 239.5 cycles

	// configure adc
	u8 sampleTime = ADC_SampleTime_55Cycles5;
	u8 sequencerRank = 1;

	s8 channel = TABLE_ADCChannel[pin];
	if (channel == -1) return 0;

	ADC_RegularChannelConfig(ADC1, channel, sequencerRank, sampleTime);
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
	// wait for End Of Conversion
	while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET)
		;
	// return the value
	return ADC_GetConversionValue(ADC1);
}

