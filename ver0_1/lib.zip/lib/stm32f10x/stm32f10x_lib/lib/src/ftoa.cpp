#include "utility.h"
/*
//!-----------------------------------------------------------------------------
//! \brief Convert a floating point number to a character string. uses float to
//! u64 conversion instead of log or divide technique. So the biggest number we can handle
//! is a +/- 2^64 which is basically 19 full digits.
//!
//! val = number to convert
//! precision = number of digits to follow decimal point
//! minlength = minimum total length of string (ie pad front with spaces)
//! maxlength = maxiumum size of string
//!
//! Returns the length of the string.
//!-----------------------------------------------------------------------------
int ftoa(double val, char* str, u8 strlength, u8 minlength, u8 precision)
{
	int length = 0;
	int padlength = 0;

	if(strlength < 2)
	{
		*str = 0;
		return 0;
	}

	// negative sign
	if (val < 0.0)
	{
		*str = '-';
		str++;
		val = -val;
		length++;
	}
	if(precision > 0)
		length += precision + 1; // precision + decimal point

	// round
	double rounding = 0.5;
	for (uint8_t i = 0; i < precision; ++i)
		rounding /= 10.0;
	val += rounding;

	// Extract the integer part of the number and print it
	u64 int_part = (u64) val;
	double remainder = val - (double) int_part;

	char tmpstr[32];
	int ni = itoa_s(int_part, tmpstr, sizeof(tmpstr), 10, 0);
	length += ni;

	// if the number is going to produce too long of a string, return
	if(length >= strlength)
	{
		str[0] = 'E';
		str[1] = 0;
		return 0;
	}

	// pad front
	if((length < minlength) && (minlength < (strlength-1)))
		padlength = minlength - length;
	memset(str,' ',padlength);
	str+=padlength;

	// append integer part
	memcpy(str,tmpstr,ni);
	str += ni;
	
	// Print the decimal point, but only if there are digits beyond
	if (precision > 0)
	{
		*str = '.';
		str++;
	}
	
	for(int i=0; i<precision; i++)
	{
		remainder *= 10.0;
		u8 rval = (u8) remainder;
		*str = rval + '0';
		str++;
		remainder = remainder - rval;
	}		
	
	return length;
}
*/

int ftoa_s(double val, u8 precision, char* buf, int maxlen)
{
	char* ptr = buf;

	memset(buf,0,sizeof(buf));

	// negative sign
	if ((val < 0.0) && (maxlen > 0))
	{
		*ptr = '-';
		ptr++;
		maxlen--;
		val = -val;
	}

	// round
	double rounding = 0.5;
	for (uint8_t i = 0; i < precision; ++i)
		rounding /= 10.0;
	val += rounding;

	// Extract the integer part of the number
	u32 int_part = (u32) val;
	double remainder = val - (double) int_part;
	int n = itoa_s(int_part, ptr, sizeof(buf), 10, 1);
	ptr += n;
	maxlen -= n;

	// add the decimal point, but only if there are digits beyond
	if ((precision > 0) && (maxlen > 0))
	{
		*ptr = '.';
		ptr++;
		maxlen--;
	}
	// Extract digits from the remainder one at a time
	while ((precision-- > 0) && (maxlen > 0))
	{
		remainder *= 10.0;
		u32 toPrint = (u32) remainder;
		n = itoa_s(toPrint, ptr, maxlen, 10, 1);
		remainder -= toPrint;
		ptr+=n;
		maxlen-=n;
	}
	return (int) (ptr-buf);
}