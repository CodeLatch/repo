#include "spi.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "misc.h"
#include "arduino.h"

CSPI SPI;

CSPI::CSPI()
{
}

//------------------------------------------------------------------------------
// Initialize SPI1 as master.
//------------------------------------------------------------------------------
void CSPI::begin(SPI_CLK_SPEED speed, SPI_CPOL cpol, SPI_CPHA cpha, SPI_ENDIAN endian)
{
	// enable interfaces
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_SPI1, ENABLE);

	// configure SPI1 pins SCK (PA5), MISO (PA6), MOSI (PA7)
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// general SPI configuration
	SPI_InitTypeDef SPI_InitStructure;
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;	// full duplex
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;					// 8 bit data size
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;							// software controlled chip select
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_InitStructure.SPI_BaudRatePrescaler = speed;

	SPI_InitStructure.SPI_CPOL = cpol;
	SPI_InitStructure.SPI_CPHA = cpha;
	SPI_InitStructure.SPI_FirstBit = endian;	

	// SPI1 as master
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_Init(SPI1, &SPI_InitStructure);

	// Enable SPI1
	SPI_Cmd(SPI1, ENABLE);
}

//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
u8 CSPI::transfer(u8 csPin, u8 data)
{
	digitalWrite(csPin, LOW);
	u8 ret = transfer(data);
	digitalWrite(csPin, HIGH);
	return ret;
}

//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
u8 CSPI::transfer(u8 data)
{
	// Wait for SPI1 Tx buffer empty
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);

	// Send SPI1 data. Load and clock out SPI1 data.
	SPI_I2S_SendData(SPI1, data);

	// Wait for SPI1 data reception
	u32 timeout = 0xfff;
	while ((SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET) && (timeout != 0))
		timeout--;

	// Read SPI1 received data
	u8 ret = SPI_I2S_ReceiveData(SPI1);

	return ret;
}