#include "pin.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_tim.h"

#ifndef NULL
#define NULL (void*)0
#endif


// interrupt handlers
void EXTI0_IRQHandler(void)
{
	Pin.invokeCallback(0);
}
void EXTI1_IRQHandler(void)
{
	Pin.invokeCallback(1);
}
void EXTI2_IRQHandler(void)
{
	Pin.invokeCallback(2);
}
void EXTI3_IRQHandler(void)
{
	Pin.invokeCallback(3);
}
void EXTI4_IRQHandler(void)
{
	Pin.invokeCallback(4);
}
void EXTI9_5_IRQHandler(void)
{
	Pin.invokeCallback(5);
}

void EXTI15_10_IRQHandler(void)
{
	Pin.invokeCallback(6);
}


/*****************************************************************************
*	pin:		physical pin number.
*	type:		EDGE triggered.
*	polarity:	FALLING, RISING, or BOTH edge triggered.
*
*	stm32f10x External Interrupts:
*
*		There are 20 external interrupt source lines...
*		- lines 0..15: can be attached to the corresponding bits 0..15 of a
*		    gpio port. A line can only be assigned to one port. So you can't
*		    have PA0 and PB0 both connected to interrupts, you have to pick one b0 source.
*		- line 16: PVD output:
*		- line 17: RTC alarm event:
*		- line 18: USB wakeup event:
*		- line 19: Ethernet wakeup event:
*
*		There are six registers that control external interrupts. Each register
*		operates over 20 bits where b0 corresponds to line 0 and so on.
*
*		EXTI_IMR - Interrupt mask register. 0=masked,1=not masked.
*		EXTI_EMR - Event mask register. 0=masked,1=not masked.
*		EXTI_RTSR - Rising trigger selection. 0=disabled, 1=enabled.
*		EXTI_FTSR - Falling trigger selection. 0=disabled, 1=enabled.
*		EXTI_SWIER - Software trigger event. 0=no action, 1=spoof h/w interrupt.
*		EXTI_PR - pending trigger register. 0=no event, 1=event occurred.
*				  Bit is cleared by writing a 1 to bit where event occurred.
*
* parameters:			pin , type, single, polarity
* Returned value:		None
*
*****************************************************************************/
int CPin::configureInterrupt(u8 pin, u32 type, u32 polarity)
{
	GPIO_TypeDef *port;
	u16 pin_source = 999;
	u16 tmp, pval;
	u8 port_source, i;

	if ((pin == 0) || (pin >= GPIO_PIN_MAP[0]))
		return 0;

	int portIndex = GPIO_PORT_MAP[pin];
	if(portIndex == 255)
		return 0;
		
	// need to enable AFIO for all pins to work
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);	

	port = (GPIO_TypeDef*)GPIO_PORTS[portIndex];
	tmp = pval = GPIO_PIN_MAP[pin];
	// go from bit offset to number
	for (i = 0; i < 16; i++)
	{
		if (tmp == 1)
		{
			pin_source = i;
			break;
		}
		tmp >>= 1;
	}
	if (pin_source > 15)
		return 0;

	// enable the peripheral clock for the given port
	if (port == GPIOA)
		port_source = GPIO_PortSourceGPIOA;
	else if (port == GPIOB)
		port_source = GPIO_PortSourceGPIOB;
	else if (port == GPIOC)
		port_source = GPIO_PortSourceGPIOC;
	else if (port == GPIOD)
		port_source = GPIO_PortSourceGPIOD;
	else
		return 0;

	// set mux to select gpio pin as exti line input.
	// note: only one port allowed for a given line
	GPIO_EXTILineConfig(port_source, pin_source);

	// disable interrupts and events on this line
	// the user must enable this interrupt after config is done.
	EXTI->IMR &= ~pval;
	EXTI->EMR &= ~pval;
	// disable rising and falling edge selection
	// so we get a clean update.
	EXTI->RTSR &= ~pval;
	EXTI->FTSR &= ~pval;
	// enable rising and or falling edge selections
	if ((polarity == FALLING) || (polarity == BOTH))
		EXTI->FTSR |= pval;
	if ((polarity == RISING) || (polarity == BOTH))
		EXTI->RTSR |= pval;
	// clear interrupt flag for this line
	EXTI->PR |= pval;

	// set up nvic for this line or line group
	NVIC_InitTypeDef NVIC_InitStructure;
	// EXTI0..4_IRQn individual, EXTI9_5_IRQn group, EXTI15_10_IRQn group
	if (pin_source == 0)
		NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	else if (pin_source == 1)
		NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
	else if (pin_source == 2)
		NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
	else if (pin_source == 3)
		NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
	else if (pin_source == 4)
		NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	else if ((pin_source > 4) && (pin_source < 10))
		NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	else if ((pin_source > 9) && (pin_source < 16))
		NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	else
		return 0;
	// set nvic priority
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; // lowest priority = 0x0f, highest = 0.
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0; // lowest priority = 0x0f, highest = 0.
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	return 1;
}

// setInterruptCallback - sets function to call when external interrupt occurs.
void CPin::setInterruptCallback(PinInterruptCallbackType funcPtr)
{
	callbackFuncPtr = funcPtr;
}

// getInterruptStatus - determines if an interrupt occured on a given pin.
u32 CPin::getInterruptStatus(u8 pin)
{
	if ((pin == 0) || (pin >= GPIO_PIN_MAP[0]))
		return 0;
		
	u32 pin_v = GPIO_PIN_MAP[pin];
	if (EXTI_GetITStatus(pin_v) != RESET)
		return 1;
	return 0;
}

u32 CPin::getEventStatus(u8 pin)
{
	return 0;
}

// clearInterruptStatus - clears interrupt flag on a given pin.
void CPin::clearInterruptStatus(u8 pin)
{
	if ((pin == 0) || (pin >= GPIO_PIN_MAP[0]))
		return;
		
	u32 pin_v = GPIO_PIN_MAP[pin];
	if (EXTI_GetITStatus(pin_v) != RESET)
		EXTI_ClearITPendingBit(pin_v);
}

// enableInterrupt - enables interrupt on a given pin.
void CPin::enableInterrupt(u8 pin)
{
	u32 pval;

	if ((pin == 0) || (pin >= GPIO_PIN_MAP[0]))
		return;

	pval = GPIO_PIN_MAP[pin];
	EXTI->IMR |= pval;
}

// disableInterrupt - disables interrupt on a given pin.
void CPin::disableInterrupt(u8 pin)
{
	u32 pval;

	if ((pin == 0) || (pin >= GPIO_PIN_MAP[0]))
		return;

	pval = GPIO_PIN_MAP[pin];
	EXTI->IMR &= ~pval;
}
