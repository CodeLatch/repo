
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "string_s.h"                                     // memcpy support
#include "terminal.h"
#include "pin.h"
#include "timer.h"
#include "delay.h"
#include "usb_lib.h"
#include "usb_istr.h"

// General Notes:
// SampleInterval will control our throughput, it can
// range from 1 to 32, which is the number of milliseconds
// between packets (and HID_LoadTxData calls). Each packet is 64 bytes.
//
// SampleInterval	Equivalent UART baud rate
// ------------------------------------------
//      32			20kbps
//		16			40kpbs
//		8			80kpbs
//		5			128kbps
//		1			640kbps
//
// To moderate the microcontroller and computer load we are going to
// default to a SampleInterval setting of 8. This should
// give us nice uart equivalent throughput without taxing
// the microcontroller or computer.
// this parameter is set in usb_desc.c by the byte bInterval in CustomHID_ConfigDescriptor.

CTerminal Terminal;

//---------------------------------
// Constant Defines
//---------------------------------
#define EN_TIMER32_1            (1 << 10)
#define EN_IOCON                (1 << 16)
#define EN_USBREG               (1 << 14)

#define USB_VENDOR_ID           0x0925  // USB HID Vendor ID
#define USB_PROD_ID             0x7002  // USB HID Product ID
#define USB_DEVICE              0x0100  // USB HID Device ID
#define HID_TX_DATA_LENGTH      64              // set tx (in)  transfer size to maximum (64 bytes is max for hid class)
#define HID_RX_DATA_LENGTH      64              // set rx (out) transfer size to maximum (64 bytes is max for hid class)



//!----------------------------------------------------------------------------
//! \brief	Routine called by the usb isr to provide data for micro -> PC transfer.
//! 
//! Take up to HID_TX_DATA_LENGTH bytes of data out of our transmit fifo and put it
//! into the hid tx data buffer to be sent to the host pc. This gets called
//! every x milliseconds as specified in usb_desc.c by the byte bInterval in
//! CustomHID_ConfigDescriptor. Default for terminal is 8ms.
//!----------------------------------------------------------------------------
void HID_LoadTxData(u8 data[], u32 numBytes)
{
	if (numBytes != HID_TX_DATA_LENGTH)
		return;

	// set buffer to all zeros
	memset(data, 0, numBytes);
	// get up to HID_TX_DATA_LENGTH bytes of data from the fifo into transmit buffer
	Terminal.txFifo.get(data, numBytes);
}

//!----------------------------------------------------------------------------
//! \brief	Routine called by the usb isr when the host pc sends data to the
//! microcontroller.
//!
//! Places data in the receive fifo up to the point that the
//! fifo is full. If a callback function has been set by setRxCallback() it
//! will be called.
//!----------------------------------------------------------------------------
void HID_LoadRxData(u8 data[], u32 numBytes)
{
	u32 n;
	// determine string length
	for (n = 0; n < numBytes; n++)
		if (data[n] == '\0')
			break;
	// include the terminating null if present
	if (n < numBytes)
		n++;

	// add data to receive fifo
	Terminal.rxFifo.put(data, n);
	if (Terminal.rxCallback)
		Terminal.rxCallback();
}

//!----------------------------------------------------------------------------
//! \brief	Constructor.
//!----------------------------------------------------------------------------
CTerminal::CTerminal(void)
{
	rxCallback = (TerminalRxCallbackType)NULL;
	txTimeout = 0;
}

//!----------------------------------------------------------------------------
//! \brief	Destructor.
//!----------------------------------------------------------------------------
CTerminal::~CTerminal(void)
{
}

//!----------------------------------------------------------------------------
//! \brief  Start the Terminal process. This must be called to initialize
//! the usb to operate as a hid. The parameter timout_ms sets the amount
//! of time the write() routine will wait for free fifo space before returning.
//! It is defaulted to 10ms, since the default hid implementation has an 8ms
//! interrupt we shouldn't drop transmit packets.
//!----------------------------------------------------------------------------
void CTerminal::start(u8 timeout_ms)
{
	// set up fifos
	rxFifo.initialize(rxbuf, 1, TERMINAL_RX_BUF_SIZE);
	txFifo.initialize(txbuf, 1, TERMINAL_TX_BUF_SIZE);

	setTxTimeout(timeout_ms);
	// stm32 specific init
	Set_System();
	USB_Interrupts_Config();
	Set_USBClock();
	USB_Init();
}

//!----------------------------------------------------------------------------
//! \brief	Set tx timeout period in ms.
//!----------------------------------------------------------------------------
void CTerminal::setTxTimeout(u8 timeout_ms)
{
	txTimeout = timeout_ms;
}

//!----------------------------------------------------------------------------
//! \brief  Routine to send data to the pc. Overrides CPrint::write().
//! Attempts to place a byte into the transmit fifo, will wait up to txTimeout before
//! bailing out. 
//!----------------------------------------------------------------------------
void CTerminal::write(u8 val)
{
	u16 ret = txFifo.put(&val);
	// if the fifo didn't accept the data and txTimeout is non-zero
	// then wait up to txTimeout and try again.
	if ((txTimeout != 0) && (ret != 1))
	{
		u32 timer;
		timerStart(timer, txTimeout);
		while ((ret != 1) && !timerExpired(timer))
		{
			// need some dummy statements that won't be optimized out
			// to keep the processor from not allowing usb interrupts to run.
			__asm("nop");
			__asm("nop");
			ret = txFifo.put(&val);
		}
	}
}

//!----------------------------------------------------------------------------
//! \brief	Routine to read data out of the receive fifo.
//!----------------------------------------------------------------------------
u16 CTerminal::read(void *dest, u16 numbytes)
{
	return rxFifo.get(dest, numbytes);
}

//!----------------------------------------------------------------------------
//! \brief	Routine to read a character string out of the receive fifo.
//! Returns the length of the string read.
//!----------------------------------------------------------------------------
u16 CTerminal::gets(char* str, u16 maxlen)
{
	u16 n = 0;

	// if no data is available return
	if (rxFifo.available() == 0)
	{
		str[0] = '\0';
		return 0;
	}

	memset(str, 0, maxlen);
	rxFifo.peek(str, maxlen);
	// determine string length
	for (n = 0; n < maxlen; n++)
		if (str[n] == '\0')
			break;
	// include terminating null if present
	if (n < maxlen)
		n++;
	// get the string
	n = rxFifo.get(str, n);
	return n;
}

//!----------------------------------------------------------------------------
//! \brief	Returns the number of bytes available in the receive fifo.
//!----------------------------------------------------------------------------
u16 CTerminal::available(void)
{
	return rxFifo.available();
}

//!----------------------------------------------------------------------------
//! \brief	Sets a callback function that will be called when we receive data
//! from the pc.
//!
//! example:
//! 		void hidRxCallback(void) { do something} // our callback FunctionalState
//!		...
//!		Terminal.setRxCallback(hidRxCallback);
//!		Terminal.start();
//!----------------------------------------------------------------------------
void CTerminal::setRxCallback(TerminalRxCallbackType cb)
{
	rxCallback = cb;
}


