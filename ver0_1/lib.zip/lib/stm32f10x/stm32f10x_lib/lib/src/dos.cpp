///////////////////////////////////////////////////////////////////////////////////////////////////
// DOS Services
//
// NOTES: 1) Implemented using byte reading/writing so you don't have to worry about endianess.
//        2) Could improve several routines by keeping track of what data is currently in the buf to save time.
//        3) Currently I update the file size by writing to the directory every time you call writeBuf.
//           Could improve performance by only writing when a file is closed. but this also adds risk of corruption.
//        4) Some SD cards have a master boot record at sector 0, some do not. If there is no master boot record
//			 the first FAT is at sector 0.
///////////////////////////////////////////////////////////////////////////////////////////////////

/*-----------------------------------------------------------------------------
You must first browse through the partition table (which starts at the absolute offset 0x1BE, from the start
of the disk) and find the start of the partition. When jumping to the partition, you will then stumble upon
a boot record containing a Disk Parameter Block. Then you can proceed to locate and decode the FAT and the root
directory, keeping in mind that all offsets in this Disk Parameter Block are relative to the start of the partition.

The table below shows the lay-out of a single record in the partition table. Each such record is 16 bytes in size,
and the partition table contains 4 records. That is, the second entry in the partition table starts at offset 0x1CE,
the third at 0x1DE and the fourth at 0x1EE.

Partition table records are at 0x1be, 0x1ce, 0x1de, 0x1ee
Look at 0x1c6, 0x1d6, 0x1e6, 0x1f6 for a 4byte word detailing the boot sector

Offset	Description												Size
0x00	 	0x80 if active (bootable), 0 otherwise	 				1
0x01	 	start of the partition in CHS-addressing	 				3
0x04	 	type of the partition, see below	 						1
0x05	 	end of the partition in CHS-addressing	 				3
0x08	 	relative offset to the partition in sectors (LBA)	 	4
0x0C	 	size of the partition in sectors	 						4


 **** FAT16 DRIVE LAYOUT ****
 Description			Sector
 ---------------------------------------------------------------------
 Boot Sector			0
 Fat Table			0 + m_reservedSectors
 Fat Table (copy)	0 + m_reservedSectors + m_sectorsPerFAT (if it exists, ie m_numFATs = 2)
 Root Directory		0 + m_reservedSectors + (m_sectorsPerFAT * m_numFATs)
 Data Area			0 + m_reservedSectors + (m_sectorsPerFAT * m_numFATs) + ((m_maxRootDirEntries * 32)/m_bytesPerSector).

 **** FAT32 DRIVE LAYOUT ****
 Description			Sector
 ---------------------------------------------------------------------
 Boot Sector			0
 Fat Table			0 + m_reservedSectors
 Fat Table (copy)	0 + m_reservedSectors + m_sectorsPerFAT (if it exists)
 Data Area			0 + m_reservedSectors + (m_sectorsPerFAT * m_numFATs)

 **** FAT16/32 BOOT SECTOR - This information is located at sector 0 of every partition. ****
 Offset	Description											Size
 0		Jump Code + NOP										3 Bytes
 3		OEM Name												8 Bytes
 11		Bytes Per Sector										1 Word
 13		Sectors Per Cluster									1 Byte
 14		Reserved Sectors										1 Word
 16		Number of Copies of FAT								1 Byte
 17		Maximum Root Directory Entries						1 Word
 19		Number of Sectors in Partition Smaller than 32MB		1 Word
 21		Media Descriptor (F8h for Hard Disks)				1 Byte
 22		Sectors Per FAT										1 Word
 24		Sectors Per Track									1 Word
 26		Number of Heads										1 Word
 28		Number of Hidden Sectors in Partition				1 Double Word
 32		Number of Sectors in Partition						1 Double Word
 36		Logical Drive Number of Partition					1 Word
 38		Extended Signature (29h)								1 Byte
 39		Serial Number of Partition							1 Double Word
 43		Volume Name of Partition								11 Bytes
 54		FAT Name (FAT16)										8 Bytes
 62		Executable Code										448 Bytes
 510		Executable Marker (55h AAh)							2 Bytes

 **** FAT32 BOOT SECTOR ENTRIES ****
 Offset	Description												Size
 0x24   Sectors per FAT											4 Bytes
 0x2c   Cluster number of root directory start					4 Bytes
 0x30	Sector number of FS information sector					2 Bytes
 0x32	Sector number of copy of this boot sector (0 if none)	2 Bytes
 0x52   FAT Name "FAT32"											8 Bytes

 **** FAT32 FS INFORMATION SECTOR ****
 Offset	Description															Size
 0x00 	FS information sector signature (0x52 0x52 0x61 0x41 / "RRaA")		4 Bytes
 0x04 	Reserved (byte values are 0x00)										480 Bytes
 0x1e4 	FS information sector signature (0x72 0x72 0x41 0x61 / "rrAa")		4 Bytes
 0x1e8 	Number of free clusters on the drive, or -1 if unknown				4 Bytes
 0x1ec 	Number of the most recently allocated cluster						4 Bytes
 0x1f0 	Reserved (byte values are 0x00)										14 Bytes
 0x1fe  FS information sector signature (0x55 0xAA)							2 Bytes

 **** FAT ENTRIES ****
 FAT12 		 FAT16 			FAT32 					Description
 ----------------------------------------------------------------------------------------------
 0x000 		 0x0000 			0x00000000 				Free Cluster
 0x001 		 0x0001 			0x00000001 				Reserved value; do not use
 0x002?0xFEF 0x0002?0xFFEF 	0x00000002?0x0FFFFFEF 	Used cluster; value points to next cluster
 0xFF0?0xFF6 0xFFF0?0xFFF6 	0x0FFFFFF0?0x0FFFFFF6 	Reserved values; do not use[30].
 0xFF7 		 0xFFF7 			0x0FFFFFF7 				Bad sector in cluster or reserved cluster
 0xFF8?0xFFF 0xFFF8?0xFFFF 	0x0FFFFFF8?0x0FFFFFFF 	Last cluster in file

 **** DIRECTORY ENTIRES ****
 Offset  Length			Value
 0		8 bytes			Name
 8		3 bytes			Extension
 11		byte			Attribute (00ARSHDV)
					 	0: unused bit
 						A: archive bit,
 						R: read-only bit
 						S: system bit
 						D: directory bit
 						V: volume bit
 12		byte			NT (Reserved for WindowsNT;  always 0)
 13		byte			Created time; millisecond portion
 14		word			Created time; hour and minute  (b15-b11=hour, b10-b5=minute, b4-b0=second/2)
 16		word			Created date  (b15-b9=year-1980, b8-b5=month, b4-b0=day)
 18		word			Last accessed date  (b15-b9=year-1980, b8-b5=month, b4-b0=day)
 20		word			FAT16 always 0, FAT32 high 2 bytes of first cluster
 22		word			Time  (b15-b11=hour, b10-b5=minute, b4-b0=second/2)
 24		word			Date  (b15-b9=year-1980, b8-b5=month, b4-b0=day)
 26		word			FAT16 First cluster, FAT32 low 2 bytes of first cluster
 28		dword		File Size

 -----------------------------------------------------------------------------*/

#include "dos.h"
#include "stdio.h"
#include "string_s.h"
#include "stdlib.h"
#include "utility.h"

CDos::CDos(void)
{
}


//-----------------------------------------------------------------------------
// FUNCTION: init
//
// Description:
//   Find boot sector and init some variables.
//
// Parameters:
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::initialize(u32 CPU_FREQ_HZ, CSWSPI::SPIINTERFACE* pinDef)
{
	u32 sector;

	m_initSuccess = false;

	u8 ret = mmc.init(CPU_FREQ_HZ, pinDef);
	if (ret != 0)
		return ret; // mmc init failed

	// init m_currentDirSector to 0 so readbootinfo will init it on the first pass
	m_currentDirSector = 0;
	mmc.sectorOffset = 0;

	// search for the boot sector
	sector = 0;
	while (sector < 1024)
	{
		mmc.readsector(sector, buf);
		if (((memcmp(buf + 0x36, "FAT16", 5) == 0)
		        || (memcmp(buf + 0x52, "FAT32", 5) == 0))
		        && (buf[0x1fe] == 0x55) && (buf[0x1ff] == 0xaa))
		{
			// found boot sector, update mmc.sectorOffset so that all
			// sector reads are relative to this sector.
			mmc.sectorOffset = sector;
			if (readbootinfo() == DOS_SUCCESS)
			{
				m_initSuccess = true;
				return DOS_SUCCESS;
			}
		}
		sector++;
	}
	//	msg.print("mmc didn't find boot sector\n");
	return DOS_NOBOOTSECTOR;
}

//-----------------------------------------------------------------------------
// FUNCTION: isInitialized
//-----------------------------------------------------------------------------
bool CDos::isInitialized(void)
{
	return m_initSuccess;
}

//-----------------------------------------------------------------------------
// FUNCTION: readbootinfo
//
// Description:
//   Read the required boot sector parameters for further dos operations.
//
//   You MUST !!!!! succeed at init before calling this.
//
// Parameters:
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::readbootinfo(void)
{
	// read the boot sector, the boot sector is at sector 0 from our perspective now because we offset
	// the sector by mmc.sectorOffset in the mmc routines.
	if (!mmc.readsector(0, buf))
		return DOS_FAIL;

	// determine if this is FAT16 or FAT32
	if (memcmp(buf + 0x36, "FAT16", 5) == 0)
		m_fatType = DOS_FAT16;
	else if (memcmp(buf + 0x52, "FAT32", 5) == 0)
		m_fatType = DOS_FAT32;
	else
		return DOS_FAIL;

	m_bytesPerSector = buf[0x0c];
	m_bytesPerSector <<= 8;
	m_bytesPerSector += buf[0x0b];

	m_sectorsPerCluster = buf[0x0d];

	m_reservedSectors = buf[0x0f];
	m_reservedSectors <<= 8;
	m_reservedSectors += buf[0x0e];

	m_numFATs = buf[0x10];

	if (m_fatType == DOS_FAT16)
	{
		m_maxRootDirEntries = buf[0x12];
		m_maxRootDirEntries <<= 8;
		m_maxRootDirEntries += buf[0x11];

		m_sectorsPerFAT = buf[0x17];
		m_sectorsPerFAT <<= 8;
		m_sectorsPerFAT += buf[0x16];
	}
	else   // FAT32
	{
		m_maxRootDirEntries = 5000; // arbitrary number to prevent runaway code with a bad sd card

		m_sectorsPerFAT = buf[0x27];
		m_sectorsPerFAT <<= 8;
		m_sectorsPerFAT += buf[0x26];
		m_sectorsPerFAT <<= 8;
		m_sectorsPerFAT += buf[0x25];
		m_sectorsPerFAT <<= 8;
		m_sectorsPerFAT += buf[0x24];
	}

	m_firstRootDirSector = m_reservedSectors + (m_numFATs * m_sectorsPerFAT);
	m_firstFATSector = m_reservedSectors;

	if (m_fatType == DOS_FAT16)
		m_firstDataSector = m_firstRootDirSector
		                    + (m_maxRootDirEntries * 32) / m_bytesPerSector;
	else
		// FAT32
		m_firstDataSector = m_firstRootDirSector;

	// current directory info, if m_currentDirSector is 0 then it has never been initialized so initialize it, otherwise
	// leave m_currentDirSector and m_currentDirCluster alone.
	if (m_currentDirSector == 0)
	{
		m_currentDirSector = m_firstRootDirSector;
		m_currentDirCluster = ClusterFromSector(m_currentDirSector);
	}

	return DOS_SUCCESS;
}


//-----------------------------------------------------------------------------
// formatname
//
// takes a filename in the form of "MYFILE.TXT" and formats it as a
// directory entry in the form of  "MYFILE  TXT"
// note: dest and source must be at least char[13]
//-----------------------------------------------------------------------------
bool CDos::formatname(char* dest, const char* source)
{
	u8 i, j;

	dest[11] = 0;
	// special cases
	if (strcmp_s(source, ".."))
	{
		strcpy_s(dest, 12, "..         ");
		return true;
	}
	if (strcmp_s(source, "."))
	{
		strcpy_s(dest, 12, ".          ");
		return true;
	}
	// format the filename to match the directory format
	// all spaces to start
	memset(dest, ' ', 11);
	// bail out if the filename is too long
	if (strlen_s(source, 13) > 12)
		return false;
	// copy filename
	for (i = 0; ((i < 8) && (source[i] != '.') && (source[i] != 0)); i++)
		dest[i] = source[i];
	// copy the extension
	for (i = 0; ((i < 9) && (source[i] != '.') && (source[i] != 0)); i++)
		;
	j = 8;
	if ((i < 9) && (source[i] != 0))
	{
		i++;
		for (; ((i < 12) && (source[i] != 0)); i++)
			dest[j++] = source[i];
	}
	return true;
}

//-----------------------------------------------------------------------------
// SoftResetMMC
//
// special function for dual access cards, sends go idle command to card.
//
//-----------------------------------------------------------------------------
void CDos::SoftResetMMC(void)
{
	mmc.send_command(0, 0, 0); // send CMD0 - reset card
	mmc.clock_and_release();
}


//-----------------------------------------------------------------------------
// FUNCTION: findfile
//
// Description:
//   Look in the current directory for a file. If it's there load it's parameters.
//
// Parameters:
// struct MMCFILE *f	-- file structure
// char *filename		-- filename
//
// Return: DOS_FAIL, DOS_SUCCESS
//-----------------------------------------------------------------------------
u8 CDos::findfile(struct MMCFILE* f, const char* _filename, u8 filetype)
{
	u16 i, max, numbytes;
	char fname[12];
	struct MMCFILE dir;
	u8 buffer[32];
	char filename[13];

	ToUpper(_filename, filename, strlen_s(_filename));

	// read boot sector info
	//	if(!readbootinfo())
	if (!m_initSuccess)
		return DOS_FAIL;

	// use a file structure to search the directory
	dir.status = 1;
	dir.firstcluster = m_currentDirCluster;
	dir.cluster = m_currentDirCluster;
	dir.sector = m_currentDirSector;
	dir.sectoroffset = 0;
	dir.byteptr = 0;
	dir.byteoffset = 0;
	dir.size = 32;
	dir.dirsector = 0; // this will indicate to the write not to try and update this directory size
	dir.dirsectoroffset = 0;

	if (!formatname(fname, filename))
		return DOS_FAIL;

	// max 512 entries in root directory
	// I'm setting an arbitrary limit on the number of files in a subdirectory of 5000.
	if ((m_currentDirSector == m_firstRootDirSector)
	        && (m_fatType == DOS_FAT16))
		max = 512;
	else
		max = 5000;
	// look for the filename
	for (i = 0; i < max; i++)
	{
		if (readBuf(buffer, 1, 32, &numbytes, &dir) != DOS_SUCCESS)
			return DOS_FAIL;
		dir.size += 32;
		// check for end of directory indicator
		if (buffer[0] == 0x00)
			return DOS_FAIL;

		// check for valid directory entry
		if (isfile(buffer, filetype))
		{
			// see if the names match
			if (memcmp(fname, buffer, 11) == 0)
			{
				// get back to where the matching entry is
				if (!seek(&dir, dir.byteptr - 32))
					return DOS_FAIL;
				// found filename
				f->dirsector = dir.sector;
				f->dirsectoroffset = dir.byteoffset;
				// remember where the first data cluster is
				//				f->cluster = (* ((u16 *) (buf+26)));
				// words are stored in little endian format, re least significant byte first
				if (m_fatType == DOS_FAT16)
				{
					f->cluster = buffer[27];
					f->cluster <<= 8;
					f->cluster |= buffer[26];
				}
				else   // fat32
				{
					f->cluster = buffer[21];
					f->cluster <<= 8;
					f->cluster |= buffer[20];
					f->cluster <<= 8;
					f->cluster = buffer[27];
					f->cluster <<= 8;
					f->cluster |= buffer[26];
				}

				f->firstcluster = f->cluster;
				// determine the first data sector
				f->sector = SectorFromCluster(f->cluster);
				f->sectoroffset = 0;
				// get the file size
				f->size = buffer[31];
				f->size <<= 8;
				f->size |= buffer[30];
				f->size <<= 8;
				f->size |= buffer[29];
				f->size <<= 8;
				f->size |= buffer[28];

				// init byte ptr
				f->byteptr = 0;
				f->byteoffset = 0;
				return DOS_SUCCESS;
			}
		}
	}
	return DOS_FAIL;
}

/**----------------------------------------------------------------------------
// FUNCTION: open
//
// Description:
//   Open a file for reading or writting. The function will update the passed
//   file structure (f).
//
// Parameters:
// struct MMCFILE *f	-- file structure
// char *filename		-- filename
// char mode			-- 'r'=read, 'w'=write, 'a'=append, 'd'=subdirectory
//
// Return: 0 = fail, 1 = success
//---------------------------------------------------------------------------*/
u8 CDos::open(struct MMCFILE* f, const char* _filename, char mode)
{
	u32 cluster;
	u16 readbytes;
	char c;
	char filename[13];

	f->status = 0; // init as not open
	ToUpper(_filename, filename, strlen_s(_filename));

	if (mode == 'r')
	{
		// if we don't find the file return fail
		if (!findfile(f, filename, DOS_ARCHIVE))
			return DOS_FAIL;
		// set status to indicate we found the file
		f->status = 1;
		return DOS_SUCCESS;
	}

	if (mode == 'w')
	{
		//		msg.print("starting open w\n");
		// if a file with this filename already exists, delete it
		if (findfile(f, filename, DOS_ARCHIVE | DOS_DIRECTORY))
		{
			//			msg.print("found duplicate file, deleting\n");
			if (DeleteFile(filename) == 0)
			{
				//				msg.print("failed to delete file\n");
				return DOS_FAIL;
			}
		}
		// allocate a new cluster because the file is a brand new file
		cluster = getfreecluster(0);
		if (cluster == 0)
			return DOS_FAIL;
		f->firstcluster = cluster;
		f->cluster = cluster;
		f->sector = SectorFromCluster(cluster);
		f->sectoroffset = 0;
		f->byteptr = 0;
		f->byteoffset = 0;
		f->size = 0;

		//msg.printf("creating directory entry for %s\n",filename);
		// create a new entry in the directory structure
		if (!createdirentry(f, filename, cluster, DOS_ARCHIVE))
			return DOS_FAIL;
		// flag file as open and ready
		f->status = 1;
		//msg.print("done file open\n");
		return DOS_SUCCESS;
	}

	if (mode == 'a')
	{
		// if we dont' find the file start a new one
		if (!findfile(f, filename, DOS_ARCHIVE))
		{
			// allocate a new cluster because the file is a brand new file
			cluster = getfreecluster(0);
			if (cluster == 0)
				return DOS_FAIL;
			f->firstcluster = cluster;
			f->cluster = cluster;
			f->sector = SectorFromCluster(cluster);
			f->sectoroffset = 0;
			f->byteptr = 0;
			f->byteoffset = 0;
			f->size = 0;
			// create a new entry in the directory structure
			if (!createdirentry(f, filename, cluster, DOS_ARCHIVE))
				return DOS_FAIL;
			// flag file as open and ready
			f->status = 1;
			return DOS_SUCCESS;
		}
		// flag file as open
		f->status = 1;

		// go the the end of the file
		if (f->size > 0)
		{
			if (!seek(f, f->size - 1))
				return DOS_FAIL;

			// read the last byte in the file so we can then write it back to force a new space for appending
			if (readBuf(&c, 1, 1, &readbytes, f) != DOS_SUCCESS)
				return DOS_FAIL;

			if (!seek(f, f->size - 1))
				return DOS_FAIL;

			u32 ret = writeBuf(&c, 1, 1, f);
			if (ret != DOS_SUCCESS)
				return DOS_FAIL;
			//			if (writeBuf(&c, 1, 1, f) != DOS_SUCCESS)
			//				return DOS_FAIL;
		}
		return DOS_SUCCESS;
	}

	return DOS_FAIL;
}


//-----------------------------------------------------------------------------
//
//
//
//-----------------------------------------------------------------------------
u8 CDos::DeleteFile(const char* _filename)
{
	u16 offset;
	u32 cluster, sector, endflag;
	u8* ptr;
	struct MMCFILE f;
	char filename[13];

	ToUpper(_filename, filename, strlen_s(_filename));

	if (!findfile(&f, filename, DOS_ARCHIVE))
		return DOS_FAIL;

	// write 0xe5 to first byte of filename in directory entry to free up this directory entry
	if (!mmc.readsector(f.dirsector, buf))
		return DOS_FAIL;
	ptr = buf + f.dirsectoroffset;
	ptr[0] = 0xe5;
	if (!mmc.writesector(f.dirsector, buf))
		return DOS_FAIL;

	// follow cluster chain and free up each entry
	if (m_fatType == DOS_FAT16)
		endflag = 0xFFF8;
	else
		// fat32
		endflag = 0x0FFFFFF8;

	cluster = f.firstcluster;
	do
	{
		// determine the sector offset in the fat
		if (m_fatType == DOS_FAT16)
		{
			sector = (cluster << 1) >> 9; // FAT16 2 bytes per cluster, 512 bytes per sector
			offset = (cluster & 0xff) << 1; // determine the offset the cluster is at in the sector
		}
		else   // fat32
		{
			sector = (cluster << 2) >> 9; // FAT32 4 bytes per cluster, 512 bytes per sector
			offset = (cluster & 0x7f) << 2; // determine the offset the cluster is at in the sector
		}
		// read fat
		if (!mmc.readsector(sector + m_reservedSectors, buf))
			return DOS_FAIL;

		// get the next cluster in the chain from the fat entry for this cluster
		if (m_fatType == DOS_FAT16)
		{
			cluster = buf[offset + 1];
			cluster <<= 8;
			cluster += buf[offset + 0];
			// free the cluster
			memset(buf + offset, 0, 2);
		}
		else   // fat32
		{
			cluster = buf[offset + 3];
			cluster <<= 8;
			cluster += buf[offset + 2];
			cluster <<= 8;
			cluster += buf[offset + 1];
			cluster <<= 8;
			cluster += buf[offset + 0];
			// free the cluster
			memset(buf + offset, 0, 4);
		}
		// update fat
		if (!mmc.writesector(sector + m_reservedSectors, buf))
			return DOS_FAIL;
		// update copy of fat if it exists
		if (m_numFATs == 2)
		{
			if (!mmc.writesector(sector + m_reservedSectors + m_sectorsPerFAT,
			                     buf))
				return DOS_FAIL;
		}
	}
	while (cluster < endflag);

	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// FUNCTION: close
//
// Description:
//-----------------------------------------------------------------------------
void CDos::close(struct MMCFILE* f)
{
	f->status = 0; // set as not open
}

//-----------------------------------------------------------------------------
// FUNCTION: createdirentry
//
// Description:
//   Create a directory entry based on the filename and starting cluster. The
//   filesize will be set to 0.
//
// Parameters:
// struct MMCFILE *f		-- file structure
// char *filename			-- filename
// u32 cluster			-- starting cluster
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::createdirentry(struct MMCFILE* f, const char* _filename, u32 cluster, u8 type)
{
	u16 max, readbytes;
	u16 i;
	char fname[13];
	char filename[13];
	u8 buffer[32];
	//	u16 timedate;
	struct MMCFILE dir;
	//msg.print("in createdirectory\n");
	// read boot sector info
	//	if(!readbootinfo())
	if (!m_initSuccess)
		return DOS_FAIL;
	//debugShowBootInfo();
	//msg.printf("calling toupper %s\n",filename);
	ToUpper(_filename, filename, strlen_s(_filename));
	//msg.printf("calling formatname %s\n",filename);
	if (!formatname(fname, filename))
		return DOS_FAIL;
	//msg.printf("filename: %s\n",fname);
	// max 512 entries in root directory
	// I'm setting an arbitrary limit on the number of files in a subdirectory of 5000.
	if (m_currentDirSector == m_firstRootDirSector)
		max = 512;
	else
		max = 5000;

	// use a file structure to search the directory
	dir.status = 1;
	dir.firstcluster = m_currentDirCluster;
	dir.cluster = m_currentDirCluster;
	dir.sector = m_currentDirSector;
	dir.sectoroffset = 0;
	dir.byteptr = 0;
	dir.byteoffset = 0;
	dir.size = 32;
	dir.dirsector = 0; // this will indicate to the write not to try and update this directory size
	dir.dirsectoroffset = 0;

	// look for a free place in the directory
	for (i = 0; i < max; i++)
	{
		//msg.printf("i = %d\n",i);
		if (readBuf(buffer, 1, 32, &readbytes, &dir) != DOS_SUCCESS)
		{
			//			msg.print("readBuf failed\n");
			return DOS_FAIL;
		}
		dir.size += 32;
		//msg.printf("post readBuf %d\n",readbytes);

		// check for unused entry by looking at the first byte of the 32 byte sequence
		if ((buffer[0] == 0xe5) || (buffer[0] == 0x00))
		{
			// get back to where the matching entry is
			if (!seek(&dir, dir.byteptr - 32))
				return DOS_FAIL;
			//			msg.printf(
			//					"found free directory entry at offset %lu of sector %lu sector offset %u\n",
			//					dir.byteptr, dir.sector, dir.byteoffset); // we found a free spot

			// remember, words are stored lsb first
			// copy some info
			f->dirsector = dir.sector;
			f->dirsectoroffset = dir.byteoffset;
			// fill in name
			memcpy(buffer, fname, 11);
			// set attribute
			memset(buffer + 11, type, 1);
			// filed for windows NT set to 0
			memset(buffer + 12, 0, 1);
			// set creation time count tenths of seconds
			memset(buffer + 13, 0, 1);
			// set creation time (b15-b11=hour, b10-b5=minute, b4-b0=second/2)
			//			timedate = Swap16(0x4800); // 9am
			buffer[14] = 0x00; // 9am
			buffer[15] = 0x48;
			//			memcpy(buffer+14,&timedate,2);
			// set creation date (b15-b9=year-1980, b8-b5=month, b4-b0=day)
			//			timedate = Swap16(0x36c9); // 6/9/2007
			//			memcpy(buffer+16,&timedate,2);
			buffer[16] = 0xc9; // 6/9/2007
			buffer[17] = 0x36;
			// set last access date (b15-b9=year-1980, b8-b5=month, b4-b0=day)
			//			timedate = Swap16(0x36c9); // 6/9/2007
			//			memcpy(buffer+18,&timedate,2);
			buffer[18] = 0xc9; // 6/9/2007
			buffer[19] = 0x36;
			// set first data cluster high word, 0 for FAT16
			memset(buffer + 20, 0, 2);
			// set time of last write (b15-b11=hour, b10-b5=minute, b4-b0=second/2)
			//			timedate = Swap16(0x4800); // 9am
			//			memcpy(buffer+22,&timedate,2);
			buffer[22] = 0x00; // 9am
			buffer[23] = 0x48;
			// set date of last write (b15-b9=year-1980, b8-b5=month, b4-b0=day)
			//			timedate = Swap16(0x36c9); // 6/9/2007
			//			memcpy(buffer+24,&timedate,2);
			buffer[24] = 0xc9; // 6/9/2007
			buffer[25] = 0x36;
			// set first data cluster, high two bytes(21,20) should be 0 for FAT16, low two bytes are (27,26)
			buffer[26] = cluster & 0xff;
			buffer[27] = (cluster >> 8) & 0xff;
			if (m_fatType == DOS_FAT16)
			{
				buffer[20] = 0;
				buffer[21] = 0;
			}
			else   // fat32
			{
				buffer[20] = (cluster >> 16) & 0xff;
				buffer[21] = (cluster >> 24) & 0xff;
			}
			// set filesize, 0 to start with
			memset(buffer + 28, 0, 4);

			// write the data back to disk
			if (writeBuf(buffer, 1, 32, &dir) != DOS_SUCCESS)
				return DOS_FAIL;
			return DOS_SUCCESS;
		}
	}
	return DOS_FAIL;
}

//-----------------------------------------------------------------------------
// FUNCTION: getfreecluster
//
// Description:
//   Look through the FAT and find an available cluster. Mark it as used
//   and return the cluster number. If this is part of a chain, then update the chain.
//
// Parameters:
// u32 currentcluster	-- the cluster we are currently at in order to link a
//								a cluster chain,  or 0 if we want to start a new chain.
//
// Return: 0 = fail, assigned cluster otherwise
//-----------------------------------------------------------------------------
u32 CDos::getfreecluster(u32 currentcluster)
{
	u16 i, offset;
	u32 cluster, sector;
	u32 cursector;
	u32 zero = 0;

	// read boot sector info
	//	if(!readbootinfo())
	if (!m_initSuccess)
		return 0;
	// if there is no current cluster assigned
	if (currentcluster == 0)
	{
		//msg.printf("currentcluster = %lu\r\n",currentcluster);
		sector = 0;
		i = 0;
		while (sector < m_sectorsPerFAT)
		{
			if (!mmc.readsector(sector + m_reservedSectors, buf))
				return 0;
			while (i < m_bytesPerSector)
			{
				// if the fat entry is all zeros this is a free cluster
				if (m_fatType == DOS_FAT16)
				{
					if (memcmp(buf + i, &zero, 2) == 0)
						break;
					i += 2;
				}
				else   // fat32
				{
					if (memcmp(buf + i, &zero, 4) == 0)
						break;
					i += 4;
				}
			}
			if (i != 512)
				break;
			sector++;
			i = 0;
		}
		if (i == 512)
			return 0;

		//msg.printf("sector = %lu i = %lu\r\n",sector,i);

		// we found a free cluster
		// we already have the fat sector in buf, update it and write it back
		// i is the byte offset in this sector where the cluster is at
		buf[i] = 0xff; // indicates allocated and end of cluster chain lsb
		buf[i + 1] = 0xff; // indicates allocated and end of cluster chain msb
		if (m_fatType == DOS_FAT32) // for fat32 0x0fffffff indicates allocated and last cluster in chain
		{
			buf[i + 2] = 0xff;
			buf[i + 3] = 0x0f;
		}
		if (!mmc.writesector(sector + m_reservedSectors, buf))
			return 0;
		// do the same thing for the next fat entry
		if (m_numFATs == 2)
		{
			if (!mmc.writesector(sector + m_reservedSectors + m_sectorsPerFAT,
			                     buf))
				return 0;
		}
		// return the newly allocated cluster number
		// fat16: 512 bytes per sector, 2 bytes per cluster entry -> 256 cluster entries per sector + entry # / 2
		// fat32: 512 bytes per sector, 4 bytes per cluster entry -> 128 cluster entries per sector + entry # / 4
		if (m_fatType == DOS_FAT16)
			cluster = (sector << 8) + (i >> 1);
		else
			// fat32
			cluster = (sector << 7) + (i >> 2);
		// set cluster contents to 0's
		//		initcluster(cluster);
		//msg.printf("new clusterA = %lu\r\n",cluster);
		return cluster;
	}
	else   // a previous cluster was assigned, find the next free cluster and update the fat
	{
		//msg.printf("currentcluster = %lu\r\n",currentcluster);
		// determine what sector offset in the fat the previously assigned cluster was in
		if (m_fatType == DOS_FAT16)
			sector = (currentcluster << 1) >> 9; // FAT16 2 bytes per cluster, 512 bytes per sector
		else
			// fat32
			sector = (currentcluster << 2) >> 9; // FAT32 4 bytes per cluster, 512 bytes per sector
		cursector = sector;
		// determine what byte offset the currentcluster is at in the fat sector
		// find the next free cluster, try the next contiguous cluster first,
		if (m_fatType == DOS_FAT16)
		{
			offset = (currentcluster & 0xff) << 1; // offset = byte index of currentcluster in this fat sector
			i = offset + 2; // index of next contiguous cluster
		}
		else   // fat32
		{
			offset = (currentcluster & 0x7f) << 2; // offset = byte index of currentcluster in this fat sector
			i = offset + 4; // index of next contiguous cluster
		}
		// see if this pushes us into the next sector
		if (i >= m_bytesPerSector)
		{
			i = 0;
			sector++;
		}
		//msg.printf("starting sector = %lu i = %lu\r\n",sector,i);
		// look for free cluster
		while (sector < m_sectorsPerFAT)
		{
			if (!mmc.readsector(sector + m_reservedSectors, buf))
				return 0;
			while (i < m_bytesPerSector)
			{
				// if the fat entry is all zeros this is a free cluster
				if (m_fatType == DOS_FAT16)
				{
					if (memcmp(buf + i, &zero, 2) == 0)
						break;
					i += 2;
				}
				else   // fat32
				{
					if (memcmp(buf + i, &zero, 4) == 0)
						break;
					i += 4;
				}
			}
			// if we got here because of a break then break out of this while loop as well
			if (i < m_bytesPerSector)
				break;
			sector++;
			i = 0;
		}
		// if we get here and i is 512 we didn't find a free cluster.
		if (i == m_bytesPerSector)
			return 0;

		//msg.printf("free sector = %lu i = %lu\r\n",sector,i);

		// we have identified an unused cluster which is at sector offset "sector" byte index "i" in the fat table.
		// the actual cluster number is...
		// for fat16 cluster = (sector<<8) + (i>>1);
		// for fat32 cluster = (sector<<7) + (i>>2);

		// mark the new cluster as used
		// i is the offset where the cluster is at
		buf[i] = 0xff; // indicates allocated and end of cluster chain lsb
		buf[i + 1] = 0xff; // indicates allocated and end of cluster chain msb
		if (m_fatType == DOS_FAT32) // for fat32 0x0fffffff indicates allocated and last cluster in chain
		{
			buf[i + 2] = 0xff;
			buf[i + 3] = 0x0f;
		}
		if (cursector != sector) // save a little time if the sectors match because we have to write again just ahead
		{
			if (!mmc.writesector(sector + m_reservedSectors, buf))
				return 0;
			// do the same thing for the next fat entry
			if (m_numFATs == 2)
			{
				if (!mmc.writesector(
				            sector + m_reservedSectors + m_sectorsPerFAT, buf))
					return 0;
			}
			if (!mmc.readsector(cursector + m_reservedSectors, buf))
				return 0;
		}
		// now, update the fats previous cluster in the chain to point to the new cluster
		// fat16: 512 bytes per sector, 2 bytes per cluster entry -> 256 cluster entries per sector + entry # / 2
		// fat32: 512 bytes per sector, 4 bytes per cluster entry -> 128 cluster entries per sector + entry # / 4

		// newly allocated cluster number
		if (m_fatType == DOS_FAT16)
			cluster = (sector << 8) + (i >> 1);
		else
			// fat32
			cluster = (sector << 7) + (i >> 2);

		// update last cluster location in fat so it points to the new cluster number
		if (m_fatType == DOS_FAT16)
		{
			buf[offset] = cluster & 0xff;
			buf[offset + 1] = (cluster >> 8) & 0xff;
		}
		else   // fat32
		{
			buf[offset] = cluster & 0xff;
			buf[offset + 1] = (cluster >> 8) & 0xff;
			buf[offset + 2] = (cluster >> 16) & 0xff;
			buf[offset + 3] = (cluster >> 24) & 0xff;
		}

		if (!mmc.writesector(cursector + m_reservedSectors, buf))
			return 0;
		// do the same thing for the next fat entry
		if (m_numFATs == 2)
		{
			if (!mmc.writesector(
			            cursector + m_reservedSectors + m_sectorsPerFAT, buf))
				return 0;
		}
		// set cluster contents to 0's
		//		initcluster(cluster);
		//msg.printf("new cluster = %lu\r\n\r\n",cluster);
		return cluster;
	}

	return 0;
}

//-----------------------------------------------------------------------------
// FUNCTION: initcluster
//
// Description:
//   set each byte in a cluster to 0.
//
// Parameters:
// u32 cluster		-- cluster number
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::initcluster(u32 cluster)
{
	u32 sector;
	u8 i;

	sector = SectorFromCluster(cluster);
	for (i = 0; i < m_sectorsPerCluster; i++)
	{
		if (!mmc.erasesector(sector))
			return DOS_FAIL;
		sector++;
	}
	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// FUNCTION: rewind
//
// Description:
//   This function will update the file structure (f) so it's pointing to the
//   begining of the file.
//
// Parameters:
// struct MMCFILE *f	-- file structure
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::rewind(struct MMCFILE* f)
{
	if (!isopen(f))
		return DOS_FAIL;
	f->cluster = f->firstcluster;
	f->sector = SectorFromCluster(f->cluster);
	f->sectoroffset = 0;
	f->byteptr = 0;
	f->byteoffset = 0;

	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// FUNCTION: isopen
//
// Description:
//   This function will check to see if a file is open.
//
// Parameters:
// struct MMCFILE *f	-- file structure
//
// Return: ture = open, false = not open
//-----------------------------------------------------------------------------
bool CDos::isopen(struct MMCFILE* f)
{
	if (f->status != 1)
		return false;
	return true;
}

//-----------------------------------------------------------------------------
// FUNCTION: isEOF
//
// Description:
//   This function will update the passed file structure (f) so that it's
//   pointing to passed file position (pos).
//
// Parameters:
// struct MMCFILE *f	-- file structure
// u32 pos			-- file position in bytes to seek
//
// Return: false = not at eof, true = at eof
//-----------------------------------------------------------------------------
bool CDos::isEOF(struct MMCFILE* f)
{
	if (f->byteptr >= f->size)
		return true;
	return false;
}

//-----------------------------------------------------------------------------
// FUNCTION: seek
//
// Description:
//   Update the passed file structure (f) so that it's pointing to the passed
//   file position (pos). Runs through the FAT cluster index if neccesary to find
//   the correct cluster, sector, and byteoffset.
//
// Parameters:
// struct MMCFILE *f	-- file structure
// u32 pos				-- file position in bytes to seek
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::seek(struct MMCFILE* f, u32 pos)
{
	u32 fsec, fatSector, fatSectorOffset, sectorOffset, cluster;
	u16 i, j, clusterOffset;

	// make sure the file is open
	if (!isopen(f))
		return DOS_FAIL;
	// make sure we are not trying to seek beyond the end of the file
	if (pos >= f->size)
		return DOS_FAIL;

	// the root directory in FAT16 is a special case because there are no fat entries for it, handle it seperately
	if ((m_fatType == DOS_FAT16) && (f->sector < m_firstDataSector))
	{
		// if we are trying to seek beyond the end of the root directory return fail
		if ((pos / 32) >= m_maxRootDirEntries)
			return DOS_FAIL;
		// the root directory is not handled by the fat, so we don't need to deal with cluster chains
		// determine what sector in the root directory we are looking for, there is only one cluster
		f->sectoroffset = pos / m_bytesPerSector;
		f->sector = m_firstRootDirSector + f->sectoroffset;
		f->byteoffset = pos - (f->sectoroffset * m_bytesPerSector);
		f->byteptr = pos;
	}

	// if we're not in the root directory or we're using fat32 we're in the data area, so use the fat
	else
	{
		// every file/directory starts at the begining of a cluster
		// calculate the sector offset and cluster offset based on file position
		sectorOffset = pos / m_bytesPerSector;
		clusterOffset = sectorOffset / m_sectorsPerCluster;
		// we don't need to walk through the fat if we're just in the first cluster
		if (clusterOffset == 0)
		{
			// update file pointer info
			f->cluster = f->firstcluster;
			f->sectoroffset = sectorOffset;
			f->sector = SectorFromCluster(f->cluster) + f->sectoroffset;
			f->byteptr = pos;
			f->byteoffset = pos - (f->sectoroffset * m_bytesPerSector);
		}
		// we need to walk through the fat to find the cluster we want
		else
		{
			cluster = f->firstcluster;
			fsec = 0;
			for (i = 0; i < clusterOffset; i++)
			{
				// determine what sector in the fat the cluster index is at
				// FAT16 has two bytes per cluster index (re << 1), 512 bytes per sector (re >> 9)
				// FAT32 has four bytes per cluster index (re << 2), 512 bytes per sector (re >> 9)
				if (m_fatType == DOS_FAT16)
					fatSectorOffset = (cluster << 1) >> 9;
				else
					fatSectorOffset = (cluster << 2) >> 9;
				fatSector = m_firstFATSector + fatSectorOffset;
				// read the fat sector if necessary
				if ((fsec != fatSector) || (i == 0))
				{
					if (!mmc.readsector(fatSector, buf))
						return DOS_FAIL;
					fsec = fatSector;
				}
				// determine the byte offset in this sector where the cluster data is
				// get the next cluster in the chain from the fat entry for this cluster
				if (m_fatType == DOS_FAT16)
				{
					j = (cluster & 0xff) << 1; // determine the byte offset in this sector where the cluster data is
					cluster = buf[j + 1];
					cluster <<= 8;
					cluster += buf[j + 0];
				}
				else   // fat32
				{
					j = (cluster & 0x7f) << 2; // determine the byte offset in this sector where the cluster data is
					cluster = buf[j + 3];
					cluster <<= 8;
					cluster += buf[j + 2];
					cluster <<= 8;
					cluster += buf[j + 1];
					cluster <<= 8;
					cluster += buf[j + 0];
				}

				// if we get the next cluster number and it indicates there are no more clusters
				// in this chain we shouldn't have been trying to find the next cluster in the chain
				// because we should have realized the seek point was beyond the end of the file.
				if ((m_fatType == DOS_FAT16) && (cluster >= 0xFFF8))
					return DOS_FAIL;
				else if (cluster >= 0x0FFFFFF8)
					return DOS_FAIL;
			}
			// update file pointer info
			f->cluster = cluster;
			f->sectoroffset = sectorOffset
			                  - (clusterOffset * m_sectorsPerCluster);
			f->sector = SectorFromCluster(cluster) + f->sectoroffset;
			f->byteptr = pos;
			f->byteoffset = pos
			                - (f->sectoroffset + (clusterOffset * m_sectorsPerCluster))
			                * m_bytesPerSector;
		} // end: we need to walk through the fat to find the cluster we want
	} // end: handle files/directories in the data area

	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// FUNCTION: readBuf
//
// Description:
//   Reads in count of size into buffer from the current file position of file f.
//
// Parameters:
// struct MMCFILE *f	-- file structure
// u8 size			-- size of items to read in (re 1 for uint8, 2 for uint 16, 4 for uint32)
// u16 count		-- number of items of to read
// u16 *countRead   -- number of items actually read
// void *buffer			-- pointer to array containing the data
//
// Return: number of items (of size bytes) read
//-----------------------------------------------------------------------------
u16 CDos::readBuf(void* buffer, u8 size, u16 count, u16* countRead,
                  struct MMCFILE* f)
{
	int bytecnt, j, k, i, n;
	u8* ptr;

	*countRead = 0;
	n = 0;

	// make sure the file is open
	if (!isopen(f))
		return DOS_FILECLOSED;
	// make sure we are not at the eof
	if (isEOF(f))
		return DOS_EOF;
	// a little error protection
	if (size == 0)
		return DOS_ZEROBYTES;
	if (count == 0)
		return DOS_ZEROBYTES;

	ptr = (u8*) buffer;

	// determine how many items we can actually read in before we get to the eof
	bytecnt = size * count;
	if (f->size < (f->byteptr + bytecnt))
	{
		count = (u16)((f->size - f->byteptr) / size);
		bytecnt = size * count;
	}

	// read in data
	if (!mmc.readsector(f->sector, buf))
		return DOS_READSECTORERROR;
	j = 0;

	while (bytecnt > 0)
	{
		// determine how many bytes we can read from buf
		k = 512 - f->byteoffset;
		// if there are no more new bytes left in this sector then read in the next sector
		if (k <= 0)
		{
			if (!seek(f, f->byteptr))
				return DOS_SEEKERROR;
			if (!mmc.readsector(f->sector, buf))
				return DOS_READSECTORERROR;
			k = 512 - f->byteoffset;
		}

		// determine how many we want to take
		if (k > bytecnt)
			k = bytecnt;
		// copy bytes
		for (i = 0; i < k; i++)
		{
			ptr[j] = buf[f->byteoffset];
			f->byteptr++;
			f->byteoffset++;
			j++;
			bytecnt--;
			n++;
			*countRead = n;
		}
	}

	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// FUNCTION: getStr
//
// Description:
//
// Parameters:
// struct MMCFILE *f	-- file structure
// char *str			-- pointer to char string to receive read characters
// u8 maxbytes			-- maximum number of characters+1(for null) to fill into *str
//
// Return: number of characters copied
//-----------------------------------------------------------------------------
u8 CDos::getStr(char* str, u8 maxbytes, struct MMCFILE* f)
{
	char ctmp;
	u16 r, ret;
	u8 getout;
	u8 i;

	i = 0;
	getout = 0;
	do
	{
		ret = readBuf(&ctmp, 1, 1, &r, f);
		if (ret != DOS_SUCCESS)
			getout = 1;
		if (r == 0)
			getout = 1;
		if (ctmp == 10)
			getout = 1;
		if (ctmp == 0)
			getout = 1;
		if (getout == 0)
		{
			// don't copy CR or LF character
			if ((ctmp != '\r') && (ctmp != '\n'))
			{
				str[i] = ctmp;
				i++;
			}
		}
		if (i >= (maxbytes - 1))
			getout = 1;
	}
	while (getout == 0);
	// add null character
	str[i] = 0;
	return i;
}

//-----------------------------------------------------------------------------
// FUNCTION: writeBuf
//
// Description:
//   Writes to file size*count bytes from buffer.
//
// Parameters:
// struct MMCFILE *f	-- file structure
// u8 size				-- size of items to write (re 1 for uint8, 2 for uint 16, 4 for uint32)
// u16 count			-- number of items to read
// void *buffer			-- pointer to array containing the data
//
// Return: number of items (of size bytes) written
//-----------------------------------------------------------------------------
u32 CDos::writeBuf(const void* buffer, u8 size, u16 count, struct MMCFILE* f)
{
	u16 bytecnt, k, n, maxcnt;
	u32 cluster;
	u8* ptr;

	// make sure the file is open
	if (!isopen(f))
		return 2;
	// a little error protection
	if (size == 0)
		return 3;
	if (count == 0)
		return 4;

	k = 0;
	ptr = (u8*) buffer;
	bytecnt = size * count;

	// see if we need to allocate a new cluster because the file is a brand new file
	if ((f->cluster == 0) && (f->sector == 0))
	{
		cluster = getfreecluster(0);
		if (cluster == 0)
			return 5;
		f->cluster = cluster;
		f->sectoroffset = 0;
		f->sector = SectorFromCluster(cluster);
		// update directory entry to reflect this newly assigned first cluster
		// read directory entry sector into buf
		if (!mmc.readsector(f->dirsector, buf))
			return 6;
		// update cluster entry for this file
		buf[f->dirsectoroffset + 26] = cluster & 0xff;
		buf[f->dirsectoroffset + 27] = (cluster >> 8) & 0xff;
		if (m_fatType == DOS_FAT16)
		{
			buf[f->dirsectoroffset + 20] = 0;
			buf[f->dirsectoroffset + 21] = 0;
		}
		else   // fat32
		{
			buf[f->dirsectoroffset + 20] = (cluster >> 16) & 0xff;
			buf[f->dirsectoroffset + 21] = (cluster >> 24) & 0xff;
		}
		if (!mmc.writesector(f->dirsector, buf))
			return 7;
	}

	// stay in this loop until all the bytes have been written
	while (bytecnt > 0)
	{
		// see if we need to move to the next sector
		if (f->byteoffset > 511)
		{
			f->byteoffset = 0;
			f->sectoroffset++;
			f->sector++;
			// see if we need to get a new cluster
			if (f->sectoroffset >= m_sectorsPerCluster)
			{
				cluster = getfreecluster(f->cluster);
				if (cluster == 0)
					return 8;
				f->cluster = cluster;
				f->sectoroffset = 0;
				f->sector = SectorFromCluster(cluster);
			}
		}

		// how many bytes can we write to the sector we are on
		maxcnt = 512 - f->byteoffset;
		// how many bytes we are going to write on this pass
		if (bytecnt > maxcnt)
			n = maxcnt;
		else
			n = bytecnt;
		// read in data from the target sector into the dos buffer
		if (!mmc.readsector(f->sector, buf))
			return 9;
		// copy the new data into the dos buffer at the correct location
		memcpy(buf + (f->byteoffset), ptr + k, n);
		// write the dos buffer back to the target sector
		if (!mmc.writesector(f->sector, buf))
			return 10;
		// update pointers/counters
		k += n;
		bytecnt -= n;
		f->byteptr += n;
		f->byteoffset += n;
	}

	// if the filesize increased we need to update the directory structure
	if (f->byteptr >= f->size)
	{
		// update file size count
		f->size = f->byteptr;
		// update the directory filesize if this is a real file
		if (f->dirsector != 0)
		{
			if (!mmc.readsector(f->dirsector, buf))
				return 11;
			ptr = buf + f->dirsectoroffset;
			// store in buffer as little endian
			ptr[28] = f->size & 0xff;
			ptr[29] = (f->size >> 8) & 0xff;
			ptr[30] = (f->size >> 16) & 0xff;
			ptr[31] = (f->size >> 24) & 0xff;

			if (!mmc.writesector(f->dirsector, buf))
				return 12;
		}
	}

	return DOS_SUCCESS;
	//	return (size * count);
}

//-----------------------------------------------------------------------------
// FUNCTION: fputs
//
// Description:
//   Writes string str to file f.
//
// Parameters:
// char *str			-- character string to write to file
// struct MMCFILE *f	-- file structure
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::putStr(const char* str, struct MMCFILE* f)
{
	u16 len;

	len = strlen_s((char*)str, 500);
	if (!writeBuf(str, 1, len, f))
		return DOS_FAIL;
	return DOS_SUCCESS;
}

//-----------------------------------------------------------------------------
// FUNCTION: isfile
//
// Description:
//   Checks a directory entry to see if its a valid file entry.
//
// Parameters:
// u8 *buffer		-- pointer to array containing the directory entry bytes
//
// Return: 0 = not a valid entry, 1 = valid entry
//-----------------------------------------------------------------------------
bool CDos::isfile(u8* buffer, u8 type)
{
	// check for end of directory
	if (buffer[0] == 0x00)
		return false;

	// check for invalid entry
	if (buffer[0] == 0xE5)
		return false;

	// check for invalid first character or long filename counter (there are more that I didn't include here)
	if (buffer[0] < 0x21)
		return false;

	// check for long filename entry (attribute field set to 0x0f)
	if (buffer[11] == 0x0f)
		return false;

	// check if the attribute matches the type we are looking for
	if ((buffer[11] & 0x3f) & type)
		return true;

	return false;
}

//-----------------------------------------------------------------------------
// FUNCTION: SectorFromCluster
//
// Description:
//   Returns the sector where the passed cluster begins.
//
// Parameters:
// u32 cluster		-- cluster number
//
// Return: sector where cluster begins
//-----------------------------------------------------------------------------
u32 CDos::SectorFromCluster(u32 cluster)
{
	return (((cluster - 2) * m_sectorsPerCluster) + m_firstDataSector);
}

//-----------------------------------------------------------------------------
// FUNCTION: ClusterFromSector
//
// Description:
//   Returns the cluster that the passed sector is in. Note cluster 0 does not start
//   at sector 0, so only sectors that are at or above cluster 0 are valid to pass.
//   For example, if the DOS_FirstDataSector = 519 and m_sectorsPerCluster is 32 then
//   the first valid sector number that can be used with this function is sector=455 which
//   would then return cluster=0.
//
// Parameters:
// u32 sector		-- cluster number
//
// Return: cluster where sector is
//-----------------------------------------------------------------------------
u32 CDos::ClusterFromSector(u32 sector)
{
	if (sector < m_firstDataSector)
	{
		return 0;
	}
	else
		return (u32)(((sector - m_firstDataSector) / m_sectorsPerCluster) + 2);
}

//-----------------------------------------------------------------------------
// FUNCTION: chdir
//
// Description:
//   change directory.
//
// Parameters:
// char *dirname		-- name of directory
//
// Return: 0 = fail, 1 = success
//-----------------------------------------------------------------------------
u8 CDos::chdir(const char* _dirname)
{
	struct MMCFILE dir;
	char dirname[13];

	ToUpper(_dirname, dirname, strlen_s(_dirname));

	if (!findfile(&dir, dirname, DOS_DIRECTORY))
		return DOS_FAIL;

	// check if we are moving back to the root directory
	if (dir.cluster == 0)
	{
		m_currentDirSector = m_firstRootDirSector;
		m_currentDirCluster = ClusterFromSector(m_currentDirSector);
	}
	else
	{
		m_currentDirSector = dir.sector;
		m_currentDirCluster = dir.cluster;
	}
	return DOS_SUCCESS;
}



//-----------------------------------------------------------------------------
// ToUpper
//
//
//-----------------------------------------------------------------------------
void CDos::ToUpper(const char* input, char* output, uint8_t maxlen)
{
	uint8_t i;

	if (maxlen > 12)
		maxlen = 12;

	for (i = 0; i < maxlen; i++)
	{
		if (input[i] > 96)
			output[i] = input[i] - 32;
		else
			output[i] = input[i];
	}
}

//--------------------------------------------------------------------
// fprintf
//--------------------------------------------------------------------
int CDos::fprintf(struct MMCFILE* f, const char* fmt, ...)
{
	int len;
	char tmp[128];
	va_list va;
	va_start(va, fmt);
	len = format_s(tmp,sizeof(tmp), (char*) fmt, va);
	va_end(va);
	putStr(tmp,f);
	return len;
}

