#include "types.h"
#include "string.h"

//--------------------------------------------------------------------
// strlen_s
//--------------------------------------------------------------------
u32 strlen_s(const char *string, u32 maxstrlen)
{
	u32 len = 0;
	const char *ptr = string;

	while((*ptr != '\0') && (len < maxstrlen))
	{
		ptr++;
		len++;
	}

	return len;
}

//--------------------------------------------------------------------
// strlen_s const
//--------------------------------------------------------------------
u32 strlen_s(const char *string)
{
	return strlen_s(string,500);
}

//--------------------------------------------------------------------
// strcat_s
//--------------------------------------------------------------------
u32 strcat_s(char *dest,u32 destsize,const char *source)
{
	u32 maxsize = destsize;
	const char *sptr = source;
	char *dptr = dest;

	if(destsize == 0)
		return 0;

	// find end of string in destination
	while((destsize > 0) && (*dptr != '\0'))
	{
		dptr++;
		destsize--;
	}
	if(destsize == 0)
	{
		dest[maxsize-1] = '\0';
		return maxsize;
	}

	// copy source to destination
	while((destsize > 0) && (*sptr != '\0'))
	{
		*dptr = *sptr;
		dptr++;
		sptr++;
		destsize--;
	}

	if(destsize == 0)
		dest[maxsize-1] = '\0';
	else
		*dptr = '\0';

	return (maxsize - destsize);
}

//--------------------------------------------------------------------
// strcpy_s const
//--------------------------------------------------------------------
u32 strcpy_s(char *dest,u32 destsize,const char *source)
{
	u32 len = 0;
	const char *sptr = source;
	char *dptr = dest;

	if(destsize == 0)
		return 0;

	destsize--; // leave room for terminating character

	while((len < destsize) && (*sptr != '\0'))
	{
		*dptr = *sptr;
		dptr++;
		sptr++;
		len++;
	}
	*dptr = '\0';

	return len;
}

//--------------------------------------------------------------------
// strcmp_s
//--------------------------------------------------------------------
s8 strcmp_s(const char *str,const char *cmpstr, u32 numchars)
{
	while(numchars > 0)
	{
		if(*str != *cmpstr)
		{
			if(*str > *cmpstr)
				return 1;
			return -1;
		}
		str++;
		cmpstr++;
		numchars--;
	}

	return 0;
}
//--------------------------------------------------------------------
// strcmp_s
//--------------------------------------------------------------------
s8 strcmp_s(const char *str,const char *cmpstr)
{
	while(*cmpstr != 0)
	{
		if(*str != *cmpstr)
		{
			if(*str > *cmpstr)
				return 1;
			return -1;
		}
		cmpstr++;
		str++;
	}
	return 0;
}

