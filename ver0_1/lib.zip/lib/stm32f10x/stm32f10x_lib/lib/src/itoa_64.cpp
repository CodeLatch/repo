/*
 * 64 bit itoa support.
 */

#include "types.h"
#include "utility.h"


//--------------------------------------------------------------------
// Convert integer to string.
//   num = integer
//   bf  = string buffer
//   maxlen = maximum length of bf
//   base   = conversion base (eg 10 for decimal, 16 for hexidecimal)
//   uc = 0=lower case output, 1=upper case output
//--------------------------------------------------------------------
int itoa_s(s64 num, char * bf, u8 maxlen, unsigned int base, int uc)
{
	int n;
	u64 unum;

	if(maxlen < 2)
		return 0;

	if(num < 0)
	{
		unum = -num;
		*bf = '-';
		bf++;
		maxlen--;
	}
	else
		unum = num;

	n = itoa_s(unum, bf, maxlen,base,uc);
	return n;
}

//--------------------------------------------------------------------
// Convert unsigned integer to string.
//   num = unsigned integer
//   bf  = string buffer
//   maxlen = maximum length of bf
//   base   = conversion base (eg 10 for decimal, 16 for hexidecimal)
//   uc = 0=lower case output, 1=upper case output
//--------------------------------------------------------------------
int itoa_s(u64 num, char * bf, u8 maxlen, unsigned int base, int uc)
{
	int n=0;
	u64 d=1;

	if(maxlen < 2)
		return 0;

	while (num/d >= base)
		d*=base;
	while((d!=0) && (maxlen > 1))
	{
		u64 dgt = num / d;
		num%=d;
		d/=base;
		if (n || (dgt>0) || (d==0))
		{
			*bf++ = dgt+(dgt<10 ? '0' : (uc ? 'A' : 'a')-10);
			++n;
			maxlen--;
		}
	}
	if(maxlen > 0)
		*bf=0;
	else
	{
		bf[0] = 'E';
		bf[1] = 0;
	}

	return n;
}
