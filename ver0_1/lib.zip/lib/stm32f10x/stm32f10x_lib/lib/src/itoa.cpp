#include "types.h"
#include "utility.h"

int itoa_s(s8 num, char* bf, u8 maxlen, unsigned int base, int uc)
{
	return itoa_s((s32)num, bf, maxlen, base, uc);
}
int itoa_s(u8 num, char* bf, u8 maxlen, unsigned int base, int uc)
{
	return itoa_s((u32)num, bf, maxlen, base, uc);
}
int itoa_s(s16 num, char* bf, u8 maxlen, unsigned int base, int uc)
{
	return itoa_s((s32)num, bf, maxlen, base, uc);
}
int itoa_s(u16 num, char* bf, u8 maxlen, unsigned int base, int uc)
{
	return itoa_s((u32)num, bf, maxlen, base, uc);
}

//--------------------------------------------------------------------
// Convert integer to string.
//   num = integer
//   bf  = string buffer
//   maxlen = maximum length of bf
//   base   = conversion base (eg 10 for decimal, 16 for hexidecimal)
//   uc = 0=lower case output, 1=upper case output
//--------------------------------------------------------------------
int itoa_s(s32 num, char* bf, u8 maxlen, unsigned int base, int uc)
{
	int n;
	u32 unum;
	
	// check that the base is valid and maxlen is long enough to hold a character and null
	if ((base < 2) || (base > 16) || (maxlen < 2))
	{
		bf[0] = '\0';
		return 0;
	}
	if (num < 0)
	{
		unum = -num;
		*bf = '-';
		bf++;
		maxlen--;
	}
	else
		unum = num;

	n = itoa_s(unum, bf, maxlen, base, uc);
	if(num < 0) n++;
	
	return n;
}

//--------------------------------------------------------------------
// Convert unsigned integer to string.
//   num = unsigned integer
//   bf  = string buffer
//   maxlen = maximum length of bf
//   base   = conversion base (eg 10 for decimal, 16 for hexidecimal)
//   uc = 0=lower case output, 1=upper case output
//--------------------------------------------------------------------
int itoa_s(u32 num, char* bf, u8 maxlen, unsigned int base, int uc)
//	char* itoa(int value, char* result, int base) {
{
	// check that the base if valid
	if ((base < 2) || (base > 16) || (maxlen < 2))
	{
		bf[0] = '\0';
		return 0;
	}

	char* ptr = bf, *ptr1 = bf, tmp_char;
	u32 tmp_value;
	u32 n = 0;

	do
	{
		tmp_value = num;
		num /= base;
		if(uc)
			*ptr++ = "fedcba9876543210123456789abcdef" [15 + (tmp_value - num * base)];
		else
			*ptr++ = "FEDCBA9876543210123456789ABCDEF" [15 + (tmp_value - num * base)];
		n++;
	}
	while ((num != 0) && (n < (maxlen - 1)));

	if (n == maxlen)
	{
		bf[0] = '\0';
		return 0;
	}

	// reverse
	*ptr-- = '\0';
	while (ptr1 < ptr)
	{
		tmp_char = *ptr;
		*ptr-- = *ptr1;
		*ptr1++ = tmp_char;
	}
	return n;
}
