#ifndef _TYPES_H_
#define _TYPES_H_

//#include "lpc_types.hpp"
#include <stdint.h>

/**
 * @brief Boolean Type definition
 */

#ifndef FALSE
typedef enum {FALSE = 0, TRUE = !FALSE} Bool;
#else
typedef uint8_t Bool;
#endif

/** SMA type for character type */
typedef char CHAR;

/** SMA type for 8 bit unsigned value */
typedef uint8_t UNS_8;

/** SMA type for 8 bit signed value */
typedef int8_t INT_8;

/** SMA type for 16 bit unsigned value */
typedef	uint16_t UNS_16;

/** SMA type for 16 bit signed value */
typedef	int16_t INT_16;

/** SMA type for 32 bit unsigned value */
typedef	uint32_t UNS_32;

/** SMA type for 32 bit signed value */
typedef	int32_t INT_32;

/** SMA type for 64 bit signed value */
typedef int64_t INT_64;

/** SMA type for 64 bit unsigned value */
typedef uint64_t UNS_64;

/** 32 bit boolean type */
typedef Bool BOOL_32;

/** 16 bit boolean type */
typedef Bool BOOL_16;

/** 8 bit boolean type */
typedef Bool BOOL_8;

#ifndef u8
typedef uint8_t u8;
#endif
#ifndef u16
typedef uint16_t u16;
#endif
#ifndef u32
typedef uint32_t u32;
#endif
#ifndef u64
typedef uint64_t u64;
#endif
#ifndef s8
typedef int8_t s8;
#endif
#ifndef s16
typedef int16_t s16;
#endif
#ifndef s32
typedef int32_t s32;
#endif
#ifndef s64
typedef int64_t s64;
#endif
#ifndef BOOL
typedef uint8_t BOOL;
#endif

#ifndef byte
typedef u8 byte;
#endif

#ifndef boolean
typedef u8 boolean;
#endif

#ifndef uint32
typedef u32 uint32;
typedef u16 uint16;
typedef u8 uint8;
#endif


#endif
