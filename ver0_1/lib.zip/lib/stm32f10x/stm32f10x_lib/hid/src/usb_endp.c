/**
 ******************************************************************************
 * @file    usb_endp.c
 * @author  MCD Application Team
 * @version V3.4.0
 * @date    29-June-2012
 * @brief   Endpoint routines
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
 *
 * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *        http://www.st.com/software_license_agreement_liberty_v2
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "hw_config.h"
#include "usb_lib.h"
#include "usb_istr.h"

extern void HID_LoadTxData(u8 data[], u32 numBytes);
extern void HID_LoadRxData(u8 data[], u32 numBytes);

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
//uint8_t Receive_Buffer[128];
//extern __IO uint8_t PrevXferComplete;
//extern __IO uint8_t hidTxDataWaiting;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
 * Function Name  : EP1_OUT_Callback.
 * Description    : EP1 OUT Callback Routine.
 * Input          : None.
 * Output         : None.
 * Return         : None.
 *******************************************************************************/
void EP1_OUT_Callback(void) {
	u8 buf[64];
	u32 numbytes = USB_SIL_Read(EP1_OUT, buf);

	if (numbytes == 64) {
		HID_LoadRxData(buf,numbytes);
//		if(strcmp((char*)buf,"led on") == 0) Pin.set(13);
//		if(strcmp((char*)buf,"led off") == 0) Pin.clr(13);
	}
#ifndef STM32F10X_CL   
	SetEPRxStatus(ENDP1, EP_RX_VALID);
#endif /* STM32F10X_CL */

}

/*******************************************************************************
 * Function Name  : EP1_IN_Callback.
 * Description    : EP1 IN Callback Routine.
 * Input          : None.
 * Output         : None.
 * Return         : None.
 *******************************************************************************/
void EP1_IN_Callback(void) {
	// this gets called after the data was sent, update flag indicating we sent the data.
	//PrevXferComplete = 1;

}

void CTR_Callback(void) {
	// usb ctr callback saying we are ready to send data to pc

	u8 buf[64];
	HID_LoadTxData(buf,64);
	USB_SIL_Write(EP1_IN, buf, 64);
	SetEPTxValid(ENDP1);
}

void ERR_Callback(void) {
	// usb error callback
}

// usb low priority (and CAN1 RX0) interrupt handler
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  USB_Istr();
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

