#ifndef _TARGETLIB_INC_H
#define _TARGETLIB_INC_H

#include "types.h"
#include "stm32f10x.h"
//#include "lpc_types.h"

#include "pin.h"
//#include "uart.h"
#include "string.h"
//#include "pwm.h"
//#include "servo.h"
#include "timer.h"
#include "stm32f10x_it.h"
//#include "adc.h"
//#include "utility_macros.h"
#include "utility.h"
#include "terminal.h"
#include "string_s.h"
#include "dos.h"
#include "mmc.h"
#include "swspi.h"
#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_dma.h"
#include "stm32f10x_tim.h"

#include "target-pins.h"

#include "stdlib.h"


#endif
