//
// STM32F01X TQFP64 GPIO PIN MACROS
//

#ifndef PIN_MACROS_H
#define PIN_MACROS_H

// fast pin specific set, clr, toggle macros
#define setPin2()		GPIOC->BSRR = GPIO_Pin_13
#define clrPin2()		GPIOC->BRR  = GPIO_Pin_13
#define togglePin2()		GPIOC->ODR ^= GPIO_Pin_13

#define setPin3()		GPIOC->BSRR = GPIO_Pin_14
#define clrPin3()		GPIOC->BRR  = GPIO_Pin_14
#define togglePin3()		GPIOC->ODR ^= GPIO_Pin_14

#define setPin4()		GPIOC->BSRR = GPIO_Pin_15
#define clrPin4()		GPIOC->BRR  = GPIO_Pin_15
#define togglePin4()		GPIOC->ODR ^= GPIO_Pin_15

#define setPin5()		GPIOD->BSRR = GPIO_Pin_0
#define clrPin5()		GPIOD->BRR  = GPIO_Pin_0
#define togglePin5()		GPIOD->ODR ^= GPIO_Pin_0

#define setPin6()		GPIOD->BSRR = GPIO_Pin_1
#define clrPin6()		GPIOD->BRR  = GPIO_Pin_1
#define togglePin6()		GPIOD->ODR ^= GPIO_Pin_1

#define setPin8()		GPIOC->BSRR = GPIO_Pin_0
#define clrPin8()		GPIOC->BRR  = GPIO_Pin_0
#define togglePin8()		GPIOC->ODR ^= GPIO_Pin_0

#define setPin9()		GPIOC->BSRR = GPIO_Pin_1
#define clrPin9()		GPIOC->BRR  = GPIO_Pin_1
#define togglePin9()		GPIOC->ODR ^= GPIO_Pin_1

#define setPin10()		GPIOC->BSRR = GPIO_Pin_2
#define clrPin10()		GPIOC->BRR  = GPIO_Pin_2
#define togglePin10()	GPIOC->ODR ^= GPIO_Pin_2

#define setPin11()		GPIOC->BSRR = GPIO_Pin_3
#define clrPin11()		GPIOC->BRR  = GPIO_Pin_3
#define togglePin11()	GPIOC->ODR ^= GPIO_Pin_3

#define setPin14()		GPIOA->BSRR = GPIO_Pin_0
#define clrPin14()		GPIOA->BRR  = GPIO_Pin_0
#define togglePin14()	GPIOA->ODR ^= GPIO_Pin_0

#define setPin15()		GPIOA->BSRR = GPIO_Pin_1
#define clrPin15	()		GPIOA->BRR  = GPIO_Pin_1
#define togglePin15()	GPIOA->ODR ^= GPIO_Pin_1

#define setPin16()		GPIOA->BSRR = GPIO_Pin_2
#define clrPin16()		GPIOA->BRR  = GPIO_Pin_2
#define togglePin16()	GPIOA->ODR ^= GPIO_Pin_2

#define setPin17()		GPIOA->BSRR = GPIO_Pin_3
#define clrPin17()		GPIOA->BRR  = GPIO_Pin_3
#define togglePin17()	GPIOA->ODR ^= GPIO_Pin_3

#define setPin20()		GPIOA->BSRR = GPIO_Pin_4
#define clrPin20()		GPIOA->BRR  = GPIO_Pin_4
#define togglePin20()	GPIOA->ODR ^= GPIO_Pin_4

#define setPin21()		GPIOA->BSRR = GPIO_Pin_5
#define clrPin21()		GPIOA->BRR  = GPIO_Pin_5
#define togglePin21()	GPIOA->ODR ^= GPIO_Pin_5

#define setPin22()		GPIOA->BSRR = GPIO_Pin_6
#define clrPin22()		GPIOA->BRR  = GPIO_Pin_6
#define togglePin22()	GPIOA->ODR ^= GPIO_Pin_6

#define setPin23()		GPIOA->BSRR = GPIO_Pin_7
#define clrPin23()		GPIOA->BRR  = GPIO_Pin_7
#define togglePin23()	GPIOA->ODR ^= GPIO_Pin_7

#define setPin24()		GPIOC->BSRR = GPIO_Pin_4
#define clrPin24()		GPIOC->BRR  = GPIO_Pin_4
#define togglePin24()	GPIOC->ODR ^= GPIO_Pin_4

#define setPin25()		GPIOC->BSRR = GPIO_Pin_5
#define clrPin25()		GPIOC->BRR  = GPIO_Pin_5
#define togglePin25()	GPIOC->ODR ^= GPIO_Pin_5

#define setPin26()		GPIOB->BSRR = GPIO_Pin_0
#define clrPin26()		GPIOB->BRR  = GPIO_Pin_0
#define togglePin26()	GPIOB->ODR ^= GPIO_Pin_0

#define setPin27()		GPIOB->BSRR = GPIO_Pin_1
#define clrPin27()		GPIOB->BRR  = GPIO_Pin_1
#define togglePin27()	GPIOB->ODR ^= GPIO_Pin_1

#define setPin28()		GPIOB->BSRR = GPIO_Pin_2
#define clrPin28()		GPIOB->BRR  = GPIO_Pin_2
#define togglePin28()	GPIOB->ODR ^= GPIO_Pin_2

#define setPin29()		GPIOB->BSRR = GPIO_Pin_10
#define clrPin29()		GPIOB->BRR  = GPIO_Pin_10
#define togglePin29()	GPIOB->ODR ^= GPIO_Pin_10

#define setPin30()		GPIOB->BSRR = GPIO_Pin_11
#define clrPin30()		GPIOB->BRR  = GPIO_Pin_11
#define togglePin30()	GPIOB->ODR ^= GPIO_Pin_11

#define setPin33()		GPIOB->BSRR = GPIO_Pin_12
#define clrPin33()		GPIOB->BRR  = GPIO_Pin_12
#define togglePin33()	GPIOB->ODR ^= GPIO_Pin_12

#define setPin34()		GPIOB->BSRR = GPIO_Pin_13
#define clrPin34()		GPIOB->BRR  = GPIO_Pin_13
#define togglePin34()	GPIOB->ODR ^= GPIO_Pin_13

#define setPin35()		GPIOB->BSRR = GPIO_Pin_14
#define clrPin35()		GPIOB->BRR  = GPIO_Pin_14
#define togglePin35()	GPIOB->ODR ^= GPIO_Pin_14

#define setPin36()		GPIOB->BSRR = GPIO_Pin_15
#define clrPin36()		GPIOB->BRR  = GPIO_Pin_15
#define togglePin36()	GPIOB->ODR ^= GPIO_Pin_15

#define setPin37()		GPIOC->BSRR = GPIO_Pin_6
#define clrPin37()		GPIOC->BRR  = GPIO_Pin_6
#define togglePin37()	GPIOC->ODR ^= GPIO_Pin_6

#define setPin38()		GPIOC->BSRR = GPIO_Pin_7
#define clrPin38()		GPIOC->BRR  = GPIO_Pin_7
#define togglePin38()	GPIOC->ODR ^= GPIO_Pin_7

#define setPin39()		GPIOC->BSRR = GPIO_Pin_8
#define clrPin39()		GPIOC->BRR  = GPIO_Pin_8
#define togglePin39()	GPIOC->ODR ^= GPIO_Pin_8

#define setPin40()		GPIOC->BSRR = GPIO_Pin_9
#define clrPin40()		GPIOC->BRR  = GPIO_Pin_9
#define togglePin40()	GPIOC->ODR ^= GPIO_Pin_9

#define setPin41()		GPIOA->BSRR = GPIO_Pin_8
#define clrPin41()		GPIOA->BRR  = GPIO_Pin_8
#define togglePin41()	GPIOA->ODR ^= GPIO_Pin_8

#define setPin42()		GPIOA->BSRR = GPIO_Pin_9
#define clrPin42()		GPIOA->BRR  = GPIO_Pin_9
#define togglePin42()	GPIOA->ODR ^= GPIO_Pin_9

#define setPin43()		GPIOA->BSRR = GPIO_Pin_10
#define clrPin43()		GPIOA->BRR  = GPIO_Pin_10
#define togglePin43()	GPIOA->ODR ^= GPIO_Pin_10

#define setPin44()		GPIOA->BSRR = GPIO_Pin_11
#define clrPin44()		GPIOA->BRR  = GPIO_Pin_11
#define togglePin44()	GPIOA->ODR ^= GPIO_Pin_11

#define setPin45()		GPIOA->BSRR = GPIO_Pin_12
#define clrPin45()		GPIOA->BRR  = GPIO_Pin_12
#define togglePin45()	GPIOA->ODR ^= GPIO_Pin_12

#define setPin46()		GPIOA->BSRR = GPIO_Pin_13
#define clrPin46()		GPIOA->BRR  = GPIO_Pin_13
#define togglePin46()	GPIOA->ODR ^= GPIO_Pin_13

#define setPin49()		GPIOA->BSRR = GPIO_Pin_14
#define clrPin49()		GPIOA->BRR  = GPIO_Pin_14
#define togglePin49()	GPIOA->ODR ^= GPIO_Pin_14

#define setPin50()		GPIOA->BSRR = GPIO_Pin_15
#define clrPin50()		GPIOA->BRR  = GPIO_Pin_15
#define togglePin50()	GPIOA->ODR ^= GPIO_Pin_15

#define setPin51()		GPIOC->BSRR = GPIO_Pin_10
#define clrPin51()		GPIOC->BRR  = GPIO_Pin_10
#define togglePin51()	GPIOC->ODR ^= GPIO_Pin_10

#define setPin52()		GPIOC->BSRR = GPIO_Pin_11
#define clrPin52()		GPIOC->BRR  = GPIO_Pin_11
#define togglePin52()	GPIOC->ODR ^= GPIO_Pin_11

#define setPin53()		GPIOC->BSRR = GPIO_Pin_12
#define clrPin53()		GPIOC->BRR  = GPIO_Pin_12
#define togglePin53()	GPIOC->ODR ^= GPIO_Pin_12

#define setPin54()		GPIOD->BSRR = GPIO_Pin_2
#define clrPin54()		GPIOD->BRR  = GPIO_Pin_2
#define togglePin54()	GPIOD->ODR ^= GPIO_Pin_2

#define setPin55()		GPIOB->BSRR = GPIO_Pin_3
#define clrPin55()		GPIOB->BRR  = GPIO_Pin_3
#define togglePin55()	GPIOB->ODR ^= GPIO_Pin_3

#define setPin56()		GPIOB->BSRR = GPIO_Pin_4
#define clrPin56()		GPIOB->BRR  = GPIO_Pin_4
#define togglePin56()	GPIOB->ODR ^= GPIO_Pin_4

#define setPin57()		GPIOB->BSRR = GPIO_Pin_5
#define clrPin57()		GPIOB->BRR  = GPIO_Pin_5
#define togglePin57()	GPIOB->ODR ^= GPIO_Pin_5

#define setPin58()		GPIOB->BSRR = GPIO_Pin_6
#define clrPin58()		GPIOB->BRR  = GPIO_Pin_6
#define togglePin58()	GPIOB->ODR ^= GPIO_Pin_6

#define setPin59()		GPIOB->BSRR = GPIO_Pin_7
#define clrPin59()		GPIOB->BRR  = GPIO_Pin_7
#define togglePin59()	GPIOB->ODR ^= GPIO_Pin_7

#define setPin61()		GPIOB->BSRR = GPIO_Pin_8
#define clrPin61()		GPIOB->BRR  = GPIO_Pin_8
#define togglePin61()	GPIOB->ODR ^= GPIO_Pin_8

#define setPin62()		GPIOB->BSRR = GPIO_Pin_9
#define clrPin62()		GPIOB->BRR  = GPIO_Pin_9
#define togglePin62()	GPIOB->ODR ^= GPIO_Pin_9

#endif
