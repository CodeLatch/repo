#ifndef _TARGETLIB_INC_H
#define _TARGETLIB_INC_H

#include "types.h"
//#include "lpc_types.h"

// STM32F10X CMSIS
#include "stm32f10x.h"
#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_dma.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_can.h"
#include "stm32f10x_it.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_i2c.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_rtc.h"
#include "stm32f10x_bkp.h"
#include "stm32f10x_spi.h"
#include "stm32f10x_flash.h"

#include "arduino.h"
#include "serial.h"
#include "spi.h"

#include "pin.h"
//#include "uart.h"
#include "string.h"
//#include "pwm.h"
//#include "servo.h"
#include "timer.h"
#include "delay.h"
//#include "adc.h"
//#include "utility_macros.h"
#include "utility.h"
#include "terminal.h"
#include "string_s.h"
#include "dos.h"
#include "mmc.h"
#include "swspi.h"
#include "convert.h"
#include "eeprom.h"


#include "olimex.h"
#include "pin-macros.h"
#include "target-pins.h"

#include "stdlib.h"


#endif
