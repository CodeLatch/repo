//
// OLIMEXINO-STM32 Header
//

#ifndef OLIMEX_INCLUDE_H
#define OLIMEX_INCLUDE_H

// PORT TO PIN MAPPING
#define PA0		10
#define PA1		11
#define PA2		12
#define PA3		13
#define PA4		14
#define PA5		15
#define PA6		16
#define PA7		17
#define PA8		29
#define PA9		30
#define PA10		31
#define PA11		32
#define PA12		33
#define PA13		34
#define PA14		37
#define PA15		38

#define PB0		18
#define PB1		19
#define PB2		20
#define PB3		39
#define PB4		40
#define PB5		41
#define PB6		42
#define PB7		43
#define PB8		45
#define PB9		46
#define PB10		21
#define PB11		22
#define PB12		25
#define PB13		26
#define PB14		27
#define PB15		28

#define PC13		2
#define PC14		3
#define PC15		4

#define PD0		5
#define PD1		6

/*
D2	14	PA0, WKUP, USART2_CTS, ADC123_0, TIM2_CH1_ETR, TIM5_CH1, TIM8_ETR
D3	15	PA1, USART2_RTS, ADC123_1, TIM5_CH2, TIM2_CH2
D1	16	PA2 ,USART2_TX, TIM5_CH3, ADC123_2, TIM2_CH3
D0	17	PA3, USART2_RX, TIM5_CH4, ADC123_3, TIM2_CH4
D10	20	PA4, SPI1_NSS, USART2_CK, DAC_OUT1, ADC12_4
D13	21	PA5, SPI1_SCK, DAC_OUT2, ADC12_5
D12	22	PA6, SPI1_MISO, TIM8_BKIN, ADC12_6, TIM3_CH1
D11	23	PA7, SPI_MOSI, TIM8_CH1N, ADC12_7, TIM3_CH2
D6	41	PA8, USART1_CK, TIM1_CH1, MCO
D7	42	PA9, USART1_TX, TIM1_CH2
D8	43	PA10, USART1_RX, TIM1_CH3
	44	PA11, USART1_CTS, USBDM, CAN_RX, TIM1_CH4
	45	PA12, USART1_RTS, USBDP, CAN_TX, TIM1_ETR
	46	PA13, JTMS_SWDIO
	49	PA14, JTCK_SWCLK
	50	PA15, JTDI, SPI3_NSS, I2S3_WS, TIM2_CH1_ETR, SPI1_NSS

D27	26	PB0, ADC12_8, TIM3_CH3, TIM8_CH2N
D28	27	PB1, ADC12_9, TIM3_CH4, TIM1_CH3N
	28	PB2, BOOT1
	55	PB3, JTDO, SPI3_SCK, I2S3_CK, TRACESWO, TIM2_CH2, SPI1_SCK
	56	PB4, NJTRST, SPI3_MISO, TIM3_CH1, SPI1_MISO
D4	57	PB5, I2C1_SMBA, SPI3_MOSI, I2S3_SD, TIM3_CH2, SPI1_MOSI
D5	58	PB6, I2C1_SCL, TIM4_CH1, USART1_TX
D9	59	PB7, I2C1_SDA, FSMC_NADV, TIM4_CH2, USART1_RX
D14	61	PB8, TIM4_CH3, SDIO_D4, I2C1_SCL, CAN_RX
D24	62	PB9, TIM4_CH4, SDIO_D5, I2C1_SDA, CAN_TX
D29	29	PB10, I2C2_SCL, USART3_TX, TIM2_CH3
D30	30	PB11, I2C2_SDA, USART3_RX, TIM2_CH4
D31	33	PB12, SPI2_NSS, I2S2_WS, I2C2_SMBA, USART3_CK, TIM1_BKN
D32	34	PB13, SPI2_SCK, I2S2_CK, USART3_CTS, TIM1_CH1N
D33	35	PB14, SPI2_MISO, TIM1_CH2N, USART3_RTS
D34	36	PB15, SPI2_MOSI, I2S2_SD, TIM1_CH3N


A0	8	PC0, ADC123_10
A1	9	PC1, ADC123_11
A2	10	PC2, ADC123_12
A3	11	PC3, ADC123_13
A4	24	PC4, ADC12_14
A5	25	PC5, ADC12_15
D35	37	PC6, I2S2_MCK, TIM3_CH1, SDIO_D6, TIM3_CH1
D36	38	PC7, I2S3_MCK, TIM8_CH2, SDIO_D7, TIM3_CH2
D37	39	PC8, TIM8_CH3, SDIO_D0, TIM3_CH3
	40	PC9, TIM8_CH4, SDIO_D1, TIM3_CH4
D26	51	PC10, UART4_TX, SDIO_D2, USART3_TX
	52	PC11, UART4_RX, SDIO_D3, USART3_RX
	53	PC12, UART5_TX, SDIO_CK, USART3_CKD21
	2	PC13, TAMPER, RTC
D22	3	PC14, OSC32_IN
D23	4	PC15, OSC32_OUT

	5	PD0, OSC_IN
	6	PD1, OSC_OUT
D25	54	PD2, TIM3_ETR, UART5_RX, SDIO_CMD





STM32F103xx 64 pin TQFP

------------------------FULL PIN MAP---------------------------------
Ref Pin Description	
---------------------------------------------------------------------
	1	VBAT
D21	2	PC13, TAMPER, RTC
D22	3	PC14, OSC32_IN
D23	4	PC15, OSC32_OUT
	5	PD0, OSC_IN
	6	PD1, OSC_OUT
	7	NRST
A0	8	PC0, ADC123_10
A1	9	PC1, ADC123_11
A2	10	PC2, ADC123_12
A3	11	PC3, ADC123_13
	12	VSSA
	13	VDDA
D2	14	PA0, WKUP, USART2_CTS, ADC123_0, TIM2_CH1_ETR, TIM5_CH1, TIM8_ETR
D3	15	PA1, USART2_RTS, ADC123_1, TIM5_CH2, TIM2_CH2
D1	16	PA2 ,USART2_TX, TIM5_CH3, ADC123_2, TIM2_CH3
D0	17	PA3, USART2_RX, TIM5_CH4, ADC123_3, TIM2_CH4
	18	VSS
	19	VDD
D10	20	PA4, SPI1_NSS, USART2_CK, DAC_OUT1, ADC12_4
D13	21	PA5, SPI1_SCK, DAC_OUT2, ADC12_5
D12	22	PA6, SPI1_MISO, TIM8_BKIN, ADC12_6, TIM3_CH1
D11	23	PA7, SPI_MOSI, TIM8_CH1N, ADC12_7, TIM3_CH2
A4	24	PC4, ADC12_14
A5	25	PC5, ADC12_15
D27	26	PB0, ADC12_8, TIM3_CH3, TIM8_CH2N
D28	27	PB1, ADC12_9, TIM3_CH4, TIM1_CH3N
	28	PB2, BOOT1
D29	29	PB10, I2C2_SCL, USART3_TX, TIM2_CH3
D30	30	PB11, I2C2_SDA, USART3_RX, TIM2_CH4
	31	VSS
	32	VDD
D31	33	PB12, SPI2_NSS, I2S2_WS, I2C2_SMBA, USART3_CK, TIM1_BKN
D32	34	PB13, SPI2_SCK, I2S2_CK, USART3_CTS, TIM1_CH1N
D33	35	PB14, SPI2_MISO, TIM1_CH2N, USART3_RTS
D34	36	PB15, SPI2_MOSI, I2S2_SD, TIM1_CH3N
D35	37	PC6, I2S2_MCK, TIM3_CH1, SDIO_D6, TIM3_CH1
D36	38	PC7, I2S3_MCK, TIM8_CH2, SDIO_D7, TIM3_CH2
D37	39	PC8, TIM8_CH3, SDIO_D0, TIM3_CH3
	40	PC9, TIM8_CH4, SDIO_D1, TIM3_CH4
D6	41	PA8, USART1_CK, TIM1_CH1, MCO
D7	42	PA9, USART1_TX, TIM1_CH2
D8	43	PA10, USART1_RX, TIM1_CH3
	44	PA11, USART1_CTS, USBDM, CAN_RX, TIM1_CH4
	45	PA12, USART1_RTS, USBDP, CAN_TX, TIM1_ETR
	46	PA13, JTMS_SWDIO
	47	VSS
	48	VDD
	49	PA14, JTCK_SWCLK
	50	PA15, JTDI, SPI3_NSS, I2S3_WS, TIM2_CH1_ETR, SPI1_NSS
D26	51	PC10, UART4_TX, SDIO_D2, USART3_TX
	52	PC11, UART4_RX, SDIO_D3, USART3_RX
	53	PC12, UART5_TX, SDIO_CK, USART3_CK
D25	54	PD2, TIM3_ETR, UART5_RX, SDIO_CMD
	55	PB3, JTDO, SPI3_SCK, I2S3_CK, TRACESWO, TIM2_CH2, SPI1_SCK
	56	PB4, NJTRST, SPI3_MISO, TIM3_CH1, SPI1_MISO
D4	57	PB5, I2C1_SMBA, SPI3_MOSI, I2S3_SD, TIM3_CH2, SPI1_MOSI
D5	58	PB6, I2C1_SCL, TIM4_CH1, USART1_TX
D9	59	PB7, I2C1_SDA, FSMC_NADV, TIM4_CH2, USART1_RX
	60	BOOT0
D14	61	PB8, TIM4_CH3, SDIO_D4, I2C1_SCL, CAN_RX
D24	62	PB9, TIM4_CH4, SDIO_D5, I2C1_SDA, CAN_TX
	63	VSS
	64	VDD

------------------------ANALOG PIN MAP-------------------------------
Def		OlimexRef 	Pin Description	
---------------------------------------------------------------------
A0		A0			8	ADC123_10
A1		A1			9	ADC123_11
A2		A2			10	ADC123_12
A3		A3			11	ADC123_13
A4		A4			24	ADC12_14
A5		A5			25	ADC12_15
A7		D0			17	ADC123_3
A7		D1			16	ADC123_2
A8		D2			14	ADC123_0
A9		D3			15	ADC123_1
A10		D10			20	DAC_OUT1, ADC12_4
A11		D11			23	ADC12_7
A12		D12			22	ADC12_6
A13		D13			21	DAC_OUT2, ADC12_5
A14		D27			26	ADC12_8
A15		D28			27	ADC12_9

*/
/*
// map digital pins to physical pin numbers
#define D0		17
#define D1		16
#define D2		14
#define D3		15		// led
#define D4		57
#define D5		58
#define D6		41
#define D7		42
#define D8		43
#define D9		59
#define D10		20
#define D11		23
#define D12		22
#define D13		21		// led
#define D14		61
#define D15		8
#define D16		9
#define D17		10
#define D18		11
#define D19		24
#define D20		25
#define D21		2
#define D22		3		// D22 and D23 are connected to the 32KHz osc, we don't want them used
#define D23		4
#define D24		62
#define D25		54
#define D26		51
#define D27		26
#define D28		27
#define D29		29
#define D30		30
#define D31		33
#define D32		34
#define D33		35
#define D34		36
#define D35		37
#define D36		38
#define D37		39

// map analog pins to physical pin numbers
#define A0		D15		// ADC1 0
#define A1		D16		// ADC1 1
#define A2		D17		// ADC1 2
#define A3		D18		// ADC1 3
#define A4		D19		// ADC1 4
#define A5		D20		// ADC1 5

// note: these aren't labeled on the board but are still available for use
#define A6		D0		// ADC3
#define A7		D1		// ADC2
#define A8		D2		// ADC0
#define A9		D3		// ADC1
#define A10		D10		// ADC4
#define A11		D11		// ADC7
#define A12		D12		// ADC6
#define A13		D13		// ADC5
#define A14		D27		// ADC8
#define A15		D28		// ADC9


// map EXT (Extension) header
#define EXT_1		D23
#define EXT_2		D24
#define EXT_3		D25		
#define EXT_4		D26		
#define EXT_5		D27		
#define EXT_6		D28		
#define EXT_7		D29		
#define EXT_8		D30		
#define EXT_9		D31		
#define EXT_10		D32		
#define EXT_11		D33		
#define EXT_12		D34		
#define EXT_13		D35		
#define EXT_14		D36		
#define EXT_15		D37		

// map UEXT header
#define UEXT_3                  D7
#define UEXT_4                  D8
#define UEXT_5                  D29
#define UEXT_6                  D30
#define UEXT_7                  D12
#define UEXT_8                  D11
#define UEXT_9                  D13
#define UEXT_10                 D4  // note this can be modified to be D10 by selection trace
#define UEXT_10_ALT             D10
*/

// map LED's
#define LED1                    PA1
#define LED2                    PA0
/*
// map sdcard
#define SD_MISO		D33 		// PB14, SPI2_MISO, TIM1_CH2N, USART3_RTS
#define SD_MOSI		D34 		// PB15, SPI2_MOSI, I2S2_SD, TIM1_CH3N
#define SD_SCK		D32 		// SPI2_SCK, I2S2_CK, USART3_CTS, TIM1_CH1N
#define SD_CS		D25 		// PD2, TIM3_ETR, UART5_RX, SDIO_CMD

// map can
#define CAN_CTRL		D21
#define CAN_TX		D24
#define CAN_RX		D14

// map fast pin set, clr, toggle macros
#define setD0()		setPin17()
#define clrD0()		clrPin17()
#define toggleD0()	togglePin17()

#define setD1()		setPin16()
#define clrD1()		clrPin16()
#define toggleD1()	togglePin16()

#define setD2()		setPin14()
#define clrD2()		clrPin14()
#define toggleD2()	togglePin14()

#define setD3()		setPin15()
#define clrD3()		clrPin15()
#define toggleD3()	togglePin15()

#define setD4()		setPin57()
#define clrD4()		clrPin57()
#define toggleD4()	togglePin57()

#define setD5()		setPin58()
#define clrD5()		clrPin58()
#define toggleD5()	togglePin58()

#define setD6()		setPin41()
#define clrD6()		clrPin41()
#define toggleD6()	togglePin41()

#define setD7()		setPin42()
#define clrD7()		clrPin42()
#define toggleD7()	togglePin42()

#define setD8()		setPin43()
#define clrD8()		clrPin43()
#define toggleD8()	togglePin43()

#define setD9()		setPin59()
#define clrD9()		clrPin59()
#define toggleD9()	togglePin59()

#define setD10()		setPin20()
#define clrD10()		clrPin20()
#define toggleD10()	togglePin20()

#define setD11()		setPin23()
#define clrD11()		clrPin23()
#define toggleD11()	togglePin23()

#define setD12()		setPin22()
#define clrD12()		clrPin22()
#define toggleD12()	togglePin22()

#define setD13()		setPin21()
#define clrD13()		clrPin21()
#define toggleD13()	togglePin21()

#define setD14()		setPin61()
#define clrD14()		clrPin61()
#define toggleD14()	togglePin61()

#define setD15()		setPin8()
#define clrD15()		clrPin8()
#define toggleD15()	togglePin8()

#define setD16()		setPin9()
#define clrD16()		clrPin9()
#define toggleD16()	togglePin9()

#define setD17()		setPin10()
#define clrD17()		clrPin10()
#define toggleD17()	togglePin10()

#define setD18()		setPin11()
#define clrD18()		clrPin11()
#define toggleD18()	togglePin11()

#define setD19()		setPin24()
#define clrD19()		clrPin24()
#define toggleD19()	togglePin24()

#define setD21()		setPin2()
#define clrD21()		clrPin2()
#define toggleD21()	togglePin2()

#define setD24()		setPin62()
#define clrD24()		clrPin62()
#define toggleD24()	togglePin62()

#define setD25()		setPin54()
#define clrD25()		clrPin54()
#define toggleD25()	togglePin54()

#define setD26()		setPin51()
#define clrD26()		clrPin51()
#define toggleD26()	togglePin51()

#define setD27()		setPin26()
#define clrD27()		clrPin26()
#define toggleD27()	togglePin26()

#define setD28()		setPin27()
#define clrD28()		clrPin27()
#define toggleD28()	togglePin27()

#define setD29()		setPin29()
#define clrD29()		clrPin29()
#define toggleD29()	togglePin29()

#define setD30()		setPin30()
#define clrD30()		clrPin30()
#define toggleD30()	togglePin30()

#define setD31()		setPin33()
#define clrD31()		clrPin33()
#define toggleD31()	togglePin33()

#define setD32()		setPin34()
#define clrD32()		clrPin34()
#define toggleD32()	togglePin34()

#define setD33()		setPin35()
#define clrD33()		clrPin35()
#define toggleD33()	togglePin35()

#define setD34()		setPin36()
#define clrD34()		clrPin36()
#define toggleD34()	togglePin36()

#define setD35()		setPin37()
#define clrD35()		clrPin37()
#define toggleD35()	togglePin37()

#define setD36()		setPin38()
#define clrD36()		clrPin38()
#define toggleD36()	togglePin38()

#define setD37()		setPin39()
#define clrD37()		clrPin39()
#define toggleD37()	togglePin39()

#define setLED1()	setD3()
#define clrLED1()	clrD3()
#define toggleLED1()	toggleD3()

#define setLED2()	setD13()
#define clrLED2()	clrD13()
#define toggleLED2()	toggleD13()
*/
#endif
