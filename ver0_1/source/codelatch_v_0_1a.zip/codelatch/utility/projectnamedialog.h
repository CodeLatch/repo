#ifndef PROJECTNAMEDIALOG_H
#define PROJECTNAMEDIALOG_H

#include <QWidget>
#include <QDialog>

namespace Ui {
class ProjectNameDialog;
}

class ProjectNameDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit ProjectNameDialog(QWidget *parent = 0);
    ~ProjectNameDialog();
    
    void setTitle(QString title);
    void setMessage(QString msg);
    void setInitialDirectory(QString dir);
    void setInitialName(QString name);
    QString getProjectName();
    QString getProjectFolder();

private slots:

    void on_toolButton_clicked();

    void on_projectName_returnPressed();

    void on_projectName_textChanged(const QString &arg1);

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    bool checkCharacters(QString str);

    Ui::ProjectNameDialog *ui;
    QString projectName;
    QString projectFolder;
    QString parentFolder;
    QString message;
};

#endif // PROJECTNAMEDIALOG_H
