#include "projectarchiver.h"
#include "ui_projectarchiver.h"
#include <QFile>
#include <QFileInfo>
#include <QTemporaryDir>
#include <QDir>
#include <QDateTime>
#include <QInputDialog>
#include <QMessageBox>
#include "zip.h"
#include "utility/fileutility.h"
#include "utility/textinputdialog.h"


ProjectArchiver::ProjectArchiver(Project *prj, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProjectArchiver)
{
    ui->setupUi(this);
    setWindowTitle("Project Archiver");

    ui->pbAdd->setEnabled(false);
    ui->pbDelete->setEnabled(false);
    ui->pbRestore->setEnabled(false);

    project = prj;
    if(project != NULL)
    {
        ui->projectLabel->setText(project->getName());
        ui->pbAdd->setEnabled(true);
    }
    populateList();
}

ProjectArchiver::~ProjectArchiver()
{
    delete ui;
}

void ProjectArchiver::populateList()
{
    ui->listWidget->clear();
    // get list of archives
    if(project == NULL) return;

    QString archiveFolder = project->getProjectFolder() + "/archive";
    QDir dir(archiveFolder);
    QFileInfoList list = dir.entryInfoList();

    foreach(QFileInfo info,list)
    {
        if(info.fileName().startsWith('.')) continue;
        if(info.absoluteFilePath().contains("__MACOSX/")) continue;
        if(info.isHidden()) continue;
        if(info.isSymLink()) continue;

        QString name = info.fileName();
        ui->listWidget->addItem(name);
    }

    if(ui->listWidget->count() > 0)
    {
        ui->listWidget->setCurrentRow(0);
        ui->pbDelete->setEnabled(true);
        ui->pbRestore->setEnabled(true);
    }
    else
    {
        ui->pbDelete->setEnabled(false);
        ui->pbRestore->setEnabled(false);
    }
}

QStringList ProjectArchiver::buildFileList(const QString &folder)
{
    QStringList fileList;
    // get a list of all the files in this folder excluding the bulid and archive folders
    QDir dir(folder);
    QFileInfoList list = dir.entryInfoList();
    foreach(QFileInfo info,list)
    {
        if(info.fileName().startsWith('.')) continue;
        if(info.absoluteFilePath().contains("__MACOSX/")) continue;
        if(info.isHidden()) continue;
        if(info.fileName().toLower() == "build") continue;
        if(info.fileName().toLower() == "archive") continue;
        if(info.isDir())
            buildFileList(info.absoluteFilePath());
        else
            fileList.append(info.absoluteFilePath());
    }
    return fileList;
}

void ProjectArchiver::on_pbAdd_clicked()
{
    if(project == NULL) return;

    // get a comment
    TextInputDialog dlg(this);
    QString dateTime = QDateTime::currentDateTime().toString();
    QString comment = project->getName() + " " + dateTime;
    dlg.setText(comment);
    dlg.setWindowTitle("Archive");
    if(!dlg.exec())
        return;
    comment = dlg.text();

    // find a filename with count that works
    QString destFolder = project->getProjectFolder() + "/archive";
    bool loop = true;
    int cnt = 1;
    QString destPath = destFolder + "/" + project->getName() + " (";
    do {
        QString testPath = destPath + QString::number(cnt++) + ").zip";
        QFile testFile(testPath);
        if(!testFile.exists())
        {
            destPath = testPath;
            loop = false;
        }
    } while(loop);

    // create a temp dir to hold files
    QTemporaryDir tempDir;
    tempDir.setAutoRemove(true);
    QString tempDirFolder = tempDir.path();
    if(tempDirFolder.isEmpty())
    {
        QMessageBox::critical(this,"Error","Error creating temporary directory.");
        return;
    }

    // create "temp" folder to hold project files
//    tempDirFolder += "/"+project->getName();
    tempDirFolder += "/temp";
    QDir dir;
    if(!dir.mkdir(tempDirFolder))
    {
        QMessageBox::critical(this,"Error","Error creating temporary directory.");
        return;
    }

    // copy project files over
    QStringList fileList = buildFileList(project->getProjectFolder());
    if(!copyFiles(fileList,tempDirFolder))
    {
        QMessageBox::critical(this,"Error","Error copying files.");
        return;
    }

    // zip up temp dir
    Zip zip;
    zip.setComment(comment);
    if(!zip.zip(tempDirFolder))
    {
        QMessageBox::critical(this,"Error","Error creating zip file.");
        return;
    }

    // copy zip to destPath
    QFile file(destFolder);
    if(!file.exists())
    {
        QDir destDir;
        if(!destDir.mkdir(destFolder))
        {
            QMessageBox::critical(this,"Error","Error creating archive directory.");
            return;
        }
    }

    QString zipFilePath = tempDirFolder + ".zip";
    QFile zipFile(zipFilePath);
    if(!zipFile.copy(destPath))
    {
        QMessageBox::critical(this,"Error","Error copying zip file.");
        return;
    }

    populateList();
    emit updateProjectTree(project);
}

bool ProjectArchiver::copyFiles(const QStringList &filePathList, const QString &destFolder)
{
    QString prjFolder = project->getProjectFolder();

    // copy files
    foreach(QString srcFilePath,filePathList)
    {
        QString destFilePath = destFolder + srcFilePath.right(srcFilePath.length()-prjFolder.length());

        qDebug() << "src :" << srcFilePath;
        qDebug() << "dest:" << destFilePath;
        // make folder if needed
        QFileInfo info(destFilePath);
        QString destFolderPath = info.absolutePath();
        QDir destDir(destFolderPath);
        if(!destDir.exists())
            destDir.mkpath(destFolderPath);

        QFile srcFile(srcFilePath);
        if(!srcFile.copy(destFilePath))
            return false;
    }
    return true;
}

void ProjectArchiver::on_pbRestore_clicked()
{
    // get zip filepath
    if(project == NULL) return;
    QString archiveFileName = ui->listWidget->currentItem()->text();
    QString archiveFilePath = project->getProjectFolder() + "/archive/" + archiveFileName;
    QFile file(archiveFilePath);
    if(!file.exists())
    {
        QMessageBox::critical(this,"Error","Archive file doesn't exist.");
        emit updateProjectTree(project);
        return;
    }

    // create temp directory to hold the unzipped files
    QTemporaryDir tempDir;
    tempDir.setAutoRemove(true);
    QString tempDirFolder = tempDir.path();
    if(tempDirFolder.isEmpty())
    {
        QMessageBox::critical(this,"Error","Error creating temporary directory.");
        return;
    }

    // copy zip file to temp dir
    QString destFilePath = tempDirFolder+"/temp.zip";
    if(!file.copy(destFilePath))
    {
        QMessageBox::critical(this,"Error","Error copying archive file.");
        return;
    }

    // unzip files in temp directory
    Zip zip;
    zip.unzip(destFilePath);

    QString srcFolder = tempDirFolder + "/temp";
    // create a list of files in the temp directory
    QStringList fileList = buildFileList(srcFolder);
    if(fileList.size() == 0)
    {
        QMessageBox::information(this,"Info","The archive file didn't produce any files.");
        return;
    }

    // signal the tabManager to close all tabs related to this project
    emit closeTabs(project);

    // ask if the user wants to erase all current project files
    QMessageBox::StandardButton reply = QMessageBox::question(this,"Restore","Erase all existing project files before restoring?",
                                                              QMessageBox::Yes|QMessageBox::No);
    if(reply == QMessageBox::Yes)
    {
        // erase current project directory excluding archive folder
        QDir dir(project->getProjectFolder());
        QFileInfoList infoList = dir.entryInfoList();
        foreach(QFileInfo info,infoList)
        {
            if(info.fileName().startsWith('.')) continue;
            if(info.absoluteFilePath().contains("__MACOSX")) continue;
            if(info.isHidden()) continue;
            if(info.fileName() == "archive") continue;
            QDir rmDir;
            if(info.isDir())
                FileUtility::eraseDir(info.absoluteFilePath());
            else
                rmDir.remove(info.absoluteFilePath());
        }
    }

    // copy files from unzip folder to project folder
    QString destPath = project->getProjectFolder();
    bool yesToAll = false;
    foreach(QString srcPath,fileList)
    {
        QString srcSubPathName = srcPath.right(srcPath.length()-(1+srcFolder.length()));
        QString destPathName = destPath + "/" + srcSubPathName;
        QFile srcFile(srcPath);
        if(!srcFile.exists()) continue;
        QFile destFile(destPathName);
        QFileInfo destFileInfo(destPathName);
        if(!destFile.exists())
            srcFile.copy(destPathName);
        else if(!yesToAll)
        {
            // message box Overwrite <filename>? Yes, Yes to All, No
            QString msg = "Replace " + destFileInfo.fileName() + "?";
            reply = QMessageBox::question(this,"Restore",msg,QMessageBox::Yes|QMessageBox::YesToAll|QMessageBox::No);
            if(reply == QMessageBox::YesToAll)
                yesToAll = true;
            if(reply != QMessageBox::No)
            {
                destFile.remove();
                srcFile.copy(destPathName);
            }
        }
        else
        {
            destFile.remove();
            srcFile.copy(destPathName);
        }
    }
    emit updateProjectTree(project);
}

void ProjectArchiver::on_pbDelete_clicked()
{
    if(project == NULL) return;
    QString archiveFileName = ui->listWidget->currentItem()->text();
    QString msg = "Permanently delete " + archiveFileName;
    // get confirmation
    QMessageBox::StandardButton reply = QMessageBox::question(this,"Delete Archive",msg,QMessageBox::Yes|QMessageBox::No);
    if(reply != QMessageBox::Yes) return;

    QString archiveFilePath = project->getProjectFolder() + "/archive/" + archiveFileName;
    QFile file(archiveFilePath);
    file.remove();
    emit updateProjectTree(project);
    populateList();
}

void ProjectArchiver::on_listWidget_itemSelectionChanged()
{
    if(project == NULL) return;
    QString archiveFileName = ui->listWidget->currentItem()->text();
    QString archiveFilePath = project->getProjectFolder() + "/archive/" + archiveFileName;
    Zip zip;
    QString comment = zip.readComment(archiveFilePath);
    qDebug() << "comment:" << comment;
    ui->plainTextEdit->setPlainText(comment);
}
