//!----------------------------------------------------------------------------
//! file: projectnamedialog.cpp
//!
//! Implements dialog to get a project name from the user.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "projectnamedialog.h"
#include "ui_projectnamedialog.h"
#include <QFileDialog>
#include <QFileInfo>
#include <QPushButton>
#include "utility/fileutility.h"

ProjectNameDialog::ProjectNameDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProjectNameDialog)
{
    ui->setupUi(this);
}

ProjectNameDialog::~ProjectNameDialog()
{
    delete ui;
}

void ProjectNameDialog::on_toolButton_clicked()
{
    // select parent folder
    QFileDialog dlg;
    QString initDir = FileUtility::getDirProjects();

    if(!projectFolder.isEmpty())
    {
        QFileInfo info = QFileInfo(projectFolder);
        if(info.exists())
            initDir = info.path();
    }
    dlg.setDirectory(initDir);

    dlg.setOption(QFileDialog::ShowDirsOnly,true);
    if(!dlg.exec())
        return;
    QStringList list = dlg.selectedFiles();
    QString dir = list.at(0);
    parentFolder = dir;
    projectFolder = parentFolder + "/" + projectName;
    projectFolder.replace("\\","/");
    projectFolder.replace("//","/");

    dir = FileUtility::replacePathWithKey(NULL,dir);
    ui->parentFolder->setText(dir);
}

void ProjectNameDialog::on_projectName_returnPressed()
{
    on_buttonBox_accepted();
}

void ProjectNameDialog::on_projectName_textChanged(const QString &arg1)
{
    // validate
    //    projectName = ui->projectName->text();
    projectName = arg1;
    parentFolder = ui->parentFolder->text();
    projectFolder = parentFolder + "/" + projectName;
    projectFolder.replace("\\","/");
    projectFolder.replace("//","/");

    projectFolder = FileUtility::replaceKeyWithPath(NULL,projectFolder);
    QFileInfo info(projectFolder);
    QPushButton *okButton = ui->buttonBox->button(QDialogButtonBox::Ok);

    if(info.exists())
    {
        ui->message->setText("Folder already exits!");
        okButton->setEnabled(false);
    }
    else if(!checkCharacters(projectFolder))
    {
        ui->message->setText("Invalid name!");
        okButton->setEnabled(false);
    }
    else
    {
        ui->message->setText("OK to save.");
        okButton->setEnabled(true);
    }
}

bool ProjectNameDialog::checkCharacters(QString str)
{
    if(str.contains('?')) return false;
    if(str.contains('<')) return false;
    if(str.contains('>')) return false;
    if(str.contains('\\')) return false;
#ifdef Q_OS_WIN
    // windows can have something like c:/, so that colon is ok, but no others.
    if(str.length() > 2)
        if(str.right(str.length()-2).contains(':')) return false;
    if(str.at(0) == ':') return false;
#else
    if(str.contains(':')) return false;
#endif
    if(str.contains('*')) return false;
    if(str.contains('|')) return false;
    if(str.contains('"')) return false;
    if(str.contains(',')) return false;
    if(str.contains(';')) return false;
    if(str.contains('`')) return false;
    if(str.contains('^')) return false;
    return true;
}

void ProjectNameDialog::on_buttonBox_accepted()
{
    projectName = ui->projectName->text();
    parentFolder = ui->parentFolder->text();
    parentFolder = FileUtility::replaceKeyWithPath(NULL,parentFolder);
    projectFolder = FileUtility::replaceKeyWithPath(NULL,projectFolder);
    projectFolder = parentFolder + "/" + projectName;
    projectFolder.replace("\\","/");
    projectFolder.replace("//","/");

    accept();
}

void ProjectNameDialog::on_buttonBox_rejected()
{
    projectName = "";
    projectFolder = "";
    reject();
}

void ProjectNameDialog::setTitle(QString title)
{
    setWindowTitle(title);
}

void ProjectNameDialog::setMessage(QString msg)
{
    message = msg;
    ui->message->setText(msg);
}

void ProjectNameDialog::setInitialDirectory(QString dir)
{
    dir = FileUtility::replacePathWithKey(NULL,dir);
    parentFolder = dir;
    ui->parentFolder->setText(parentFolder);
}

void ProjectNameDialog::setInitialName(QString name)
{
    projectName = name;
    ui->projectName->setText(projectName);
}

QString ProjectNameDialog::getProjectName()
{
    return projectName;
}

QString ProjectNameDialog::getProjectFolder()
{
    return projectFolder;
}


