#include "newfilenamedialog.h"

NewFileNameDialog::NewFileNameDialog(QWidget *parent) :
    QWidget(parent)
{
}
