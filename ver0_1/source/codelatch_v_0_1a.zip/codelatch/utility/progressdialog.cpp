#include "progressdialog.h"

ProgressDialog::ProgressDialog(QWidget *parent) :
    QWidget(parent)
{
    dlg = new QProgressDialog(this);
    dlg->setWindowModality(Qt::WindowModal);
    connect(dlg,SIGNAL(canceled()),this,SIGNAL(canceled()));
}

void ProgressDialog::set(QString text, int val, int max)
{
    if(text.size() > 40)
        text = QString("...") + text.right(40);
    dlg->setLabelText(text);
    dlg->setRange(0,max);
    dlg->setValue(val);
}
