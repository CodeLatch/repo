#ifndef HEXINPUT_H
#define HEXINPUT_H

#include <QDialog>

namespace Ui {
class HexInput;
}

class HexInput : public QDialog
{
    Q_OBJECT
    
public:
    explicit HexInput(QWidget *parent = 0);
    ~HexInput();
    
private slots:
    void on_lineEdit_returnPressed();

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::HexInput *ui;
};

#endif // HEXINPUT_H
