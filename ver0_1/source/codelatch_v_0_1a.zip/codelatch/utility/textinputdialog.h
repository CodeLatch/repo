#ifndef TEXTINPUTDIALOG_H
#define TEXTINPUTDIALOG_H

#include <QDialog>

namespace Ui {
class TextInputDialog;
}

class TextInputDialog : public QDialog
{
    Q_OBJECT

public:
    explicit TextInputDialog(QWidget *parent = 0);
    ~TextInputDialog();
    QString text() {return _text;}
    void setText(QString text);

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::TextInputDialog *ui;
    QString _text;
};

#endif // TEXTINPUTDIALOG_H
