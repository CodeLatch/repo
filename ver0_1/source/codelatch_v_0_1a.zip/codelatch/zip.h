#ifndef ZIP_H
#define ZIP_H

#include <QtGlobal>
#include <QObject>
#include <QFile>
#include <inttypes.h>

//! file organization
//!
//! n x LocalFileRecord's
//! m x CentralDirectoryRecord's
//! EndCentralDirectoryRecord
//!
//! LocalFileRecord
//!   header
//!   filename
//!   extra field (present if bit 3 is set in header.flag)
//!   compressed data
//!   data descriptor
//!

struct LocalFileHeader
{
     // 30 bytes long
    uint32_t signature; // 0x04034b50
    uint16_t version;
    uint16_t flag;
    uint16_t compressionMethod;
    uint16_t lastModifiedTime;
    uint16_t lastModifiedDate;
    uint32_t crc32;
    uint32_t compressedSize;
    uint32_t uncompressedSize;
    uint16_t filenameLength;
    uint16_t extraFieldLength;
};

struct LocalFileDataDescriptor
{
     // 16 bytes long
    uint32_t signature; // optional 0x08074b50
    uint32_t crc32;
    uint32_t compressedSize;
    uint32_t uncompressedSize;
};

struct CentralDirectoryHeader
{
    // 46 bytes
    uint32_t signature;  // 0x02014b50
    uint16_t version;
    uint16_t minVersion;
    uint16_t flag;
    uint16_t compressionMethod;
    uint16_t lastModifiedTime;
    uint16_t lastModifiedDate;
    uint32_t crc32;
    uint32_t compressedSize;
    uint32_t uncompressedSize;
    uint16_t filenameLength;
    uint16_t extraFieldLength;
    uint16_t fileCommentLength;
    uint16_t diskNumber;
    uint16_t internalFileAttributes;
    uint32_t externalFileAttributes;
    uint32_t relativeOffset;
};

struct EndCentralDirectoryHeader
{
    // 22 bytes
    uint32_t signature; // 0x06054b50
    uint16_t diskNumber;
    uint16_t diskStartNumber;
    uint16_t numDirRecordsOnDisk;
    uint16_t totalDirRecords;
    uint32_t centralDirectorySize; // in bytes
    uint32_t centralDirecotryOffset;
    uint16_t commentLength;
};


// File.setPermissions(QFile::ReadOwner);
// QFile::ReadOwner - The file is readable by the owner of the file.
// QFile::WriteOwner - The file is writable by the owner of the file.
// QFile::ExeOwner - The file is executable by the owner of the file.
// QFile::ReadUser - The file is readable by the user.
// QFile::WriteUser - The file is writable by the user.
// QFile::ExeUser - The file is executable by the user.
// QFile::ReadGroup - The file is readable by the group.
// QFile::WriteGroup - The file is writable by the group.
// QFile::ExeGroup - The file is executable by the group.
// QFile::ReadOther - The file is readable by anyone.
// QFile::WriteOther - The file is writable by anyone.
// QFile::ExeOther - The file is executable by anyone.

//!
//! External File Attributes
//!
//! TTTT
//! ----
//! 0001 named pipe (fifo)
//! 0010 character special
//! 0100 directory
//! 0110 block special
//! 1000 regular
//! 1010 symbolic link
//! 1100 socket
//!
//! sst
//! ---
//! 001 sticky bit - only owner or root user can delete or rename the file
//! 010 set group id on execution
//! 100 set user id on execution
//!
//! rwx rwx rwx - read write execution permissions for owner, group, and other
//!
//! ADVSHR
//! 1       Archive
//!  1      Directory
//!   1     Volume
//!    1    System
//!     1   Hidden
//!      1  Read-only
//!
//! TTTT sstr wxrw xrwx 0000 0000 00AD VSHR
//! ^^^^ ___________________________________ file type as explained above
//!      ^^^________________________________ setuid, setgid, sticky
//!         ^ ^^^^ ^^^^_____________________ permissions
//!                     ^^^^ ^^^^___________
//!                               ^^^^ ^^^^_ DOS attribute bits
//!
//! TTTT sstr wxrw xrwx 0000 0000 00AD VSHR
//! 0100 0001 1110 1101 0100 0000 0000 0000 folder           0x41ed4000
//! 1000 0001 1010 0100 0100 0000 0000 0000 text/data file   0x81a44000
//! 1000 0001 1110 1101 0100 0000 0000 0000 executable file  0x81ed4000

struct LocalFileRecord
{
    LocalFileHeader header;
    QByteArray filename;
    QByteArray extraField;
    QByteArray compressedData;
    LocalFileDataDescriptor optionalDescriptor; // only present if header.flag & 0x08

    uint32_t fileAttributes;
    uint32_t pos;
};

struct CentralDirectoryRecord
{
    CentralDirectoryHeader header;
    QByteArray filename;
    QByteArray extraField;
    QByteArray fileComment;
};

// this is the last entry in the file.
struct EndCentralDirectoryRecord
{
    EndCentralDirectoryHeader header;
    QByteArray comment;
};

struct ZipFileStruct
{
    QList<LocalFileRecord*> fileList;
    QList<CentralDirectoryRecord*> directoryList;
    EndCentralDirectoryRecord endRecord;
};

class Zip : public QObject
{
    Q_OBJECT
public:
    explicit Zip(QObject *parent = 0);
    ~Zip();

    bool unzip(QString zipFilePath, bool overwrite = false, QString destFolder = "");
    bool zip(QString sourceFilePath, bool overwrite = false, QString destFilePath = "");

    void setComment(QString comment);
    QString readComment(QString zipFilePath);

private:
    bool unzipReadZipFile(QString filepath);
    uint32_t crc32(uint32_t crc, const QByteArray &data);
    uint32_t crc32(uint32_t crc, void *buf, uint32_t size);
    uint32_t adler32(uint32_t adler, const QByteArray &data);

    void printLocalFileRecord(LocalFileRecord *record);
    void printCentralDirRecord(CentralDirectoryRecord *record);
    void printEndRecord(EndCentralDirectoryRecord record);

    uint32_t unzipReadLocalFileRecord(void *buf, LocalFileRecord *record, uint32_t nextOffset);
    uint32_t unzipReadCentralDirectoryRecord(void *buf, CentralDirectoryRecord *record);
    void unzipReadEndingRecord(void *buf);
    bool unzipPopulateRecords(const QByteArray &data);
    uint32_t getNextRecordOffset(CentralDirectoryRecord r);
    void freeMemory();
    bool unzipCreateFile(LocalFileRecord *record, const uint8_t *data, uint32_t numbytes, const QString &destFolder, bool overwrite);
    bool unzipUpdateFoldersDateTime(QString destFolder);
    void unzipSetFilePermissions(const QString &filePath, LocalFileRecord *record);
    void unzipSetFileDateTime(const QString &filePath, LocalFileRecord *record);

    void zipCreateLocalFileRecords(const QString &sourceFilePath, const QString &rootFolder);
    void zipCreateCentralDirectoryRecords();
    void zipCreateEndDirectoryRecord();

    void zipAppendFileRecord(const QString &sourceFilePath, const QString &rootFolder);

    uint32_t zipWriteFileRecord(QFile &file, LocalFileRecord *record);
    uint32_t zipWriteCentralDirectoryRecord(QFile &file, CentralDirectoryRecord *record);
    uint32_t zipWriteEndRecord(QFile &file);

    QByteArray zipReadArray;
    ZipFileStruct records;
    int fileCount,totalFiles;

signals:
    void progress(QString message, qint64 value, qint64 total);

public slots:

};

#endif // ZIP_H
