#include "target.h"
#include <QFile>
#include <QFileInfo>
#include <QVariant>
#include <QDir>
#include <QStringList>
#include "utility/fileutility.h"

#define STR_INCLUDE_FOLDERS          "includeFolders"
#define STR_OBJECT_FILES             "objectFiles"
#define STR_LIBRARY_FILES            "libraryFiles"
#define STR_STD_LIBRARIES            "standardLibs"
#define STR_STARTUP_FILE             "startupFile"
#define STR_STUBS_FILE               "stubsFile"
#define STR_LINKER_SCRIPT            "linkerScriptFile"
#define STR_RESERVED_MEM             "reservedMemory"
#define STR_TARGET_NAME               "targetName"
#define STR_DESCRIPTION              "description"
#define STR_GDB_STARTUP_CMDS         "gdbStartupCmds"
#define STR_COMPILER_TOOL            "compilerTool"
#define STR_FLASHPROG_TOOL           "flashProgTool"
#define STR_FLASHPROG_ARGS           "flashProgArgs"
#define STR_GDBSERVER_TOOL           "gdbServerTool"
#define STR_GDBSERVER_ARGS           "gdbServerArgs"
#define STR_MAX_HW_BREAKPOINTS       "maxhwbreakpoints"
#define STR_UPDATE_LPC_USER_CODE     "updatelpcusercode"

// default constructor
Target::Target(QObject *parent) : QObject(parent)
{
}

// copy constructor
Target::Target(const Target &other, QObject *parent) : QObject(parent)
{
    libraryFiles = other.libraryFiles;
    standardLibs = other.standardLibs;
    objectFiles = other.objectFiles;
    externalIncludeFolders = other.externalIncludeFolders;
    startObjFile = other.startObjFile;
    stubsObjFile = other.stubsObjFile;
    linkerScriptFile = other.linkerScriptFile;
    targetName = other.targetName;
    pathname = other.pathname;
    description = other.description;
    gdbStartupCmds = other.gdbStartupCmds;
    compilerToolPrefix = other.compilerToolPrefix;
    flashProgramTool = other.flashProgramTool;
    flashProgramArgs = other.flashProgramArgs;
    gdbServerArgs = other.gdbServerArgs;
    gdbServerTool = other.gdbServerTool;
    maxHWBreakpoints = other.maxHWBreakpoints;
    updateLPCUserCode = other.updateLPCUserCode;
}

// target map constructor
Target::Target(QMap<QString, QVariant> &map, QObject *parent) : QObject(parent)
{
    loadFromMap(map);
}

// target name constructor
Target::Target(const QString name, QObject *parent) : QObject(parent)
{
    load(name);
}

//!----------------------------------------------------------------------------
//! \brief  Load target map from disk
//!----------------------------------------------------------------------------
bool Target::load(QString name)
{    
    if (name.isEmpty())
        return false;
    if(!name.endsWith(".tgt"))
        name += ".tgt";

    QString filepath = FileUtility::getDirTargets() + "/" + name;

    QFile file(filepath);
    QFileInfo fileInfo(file);

    if(!fileInfo.exists())
        return false;

    if (!file.open(QIODevice::ReadOnly))
        return false;

    // read target settings
    // everything is stored in a map, each item identified by a key string.
    QMap<QString, QVariant> map;
    QDataStream in(&file);
    in.setVersion(QDataStream::Qt_4_3);
    in >> map;
    file.close();

    loadFromMap(map);

    pathname = filepath;
    targetName = fileInfo.fileName();
    if(targetName.endsWith(".tgt"))
        targetName = targetName.left(targetName.length()-4);

    return true;
}

//!----------------------------------------------------------------------------
//! \brief  Save target map to disk
//!----------------------------------------------------------------------------
bool Target::save()
{
    if (pathname.isEmpty())
        return false;

    QFile file(pathname);
    QFileInfo fileInfo(file);

    if(fileInfo.exists())
        if(!fileInfo.isWritable())
            return false;

    targetName = fileInfo.fileName();
    if(targetName.endsWith(".tgt"))
        targetName = targetName.left(targetName.length()-4);

    QMap<QString, QVariant> map = getMap();

    // save data
    if (!file.open(QIODevice::WriteOnly))
        return false;

    QDataStream out(&file);
    out.setVersion(QDataStream::Qt_4_3);
    out << map;
    file.close();

    return true;
}

//!----------------------------------------------------------------------------
//! \brief  Loads class variables from a map, paths keys are mapped to paths.
//!----------------------------------------------------------------------------
void Target::loadFromMap(QMap<QString,QVariant> &map)
{
    // read data from map
    objectFiles = map.value(STR_OBJECT_FILES,QVariant()).toStringList();
    externalIncludeFolders = map.value(STR_INCLUDE_FOLDERS,QVariant()).toStringList();
    libraryFiles = map.value(STR_LIBRARY_FILES,QVariant()).toStringList();
    standardLibs = map.value(STR_STD_LIBRARIES,QVariant()).toStringList();
    startObjFile = map.value(STR_STARTUP_FILE,QVariant()).toString();
    stubsObjFile = map.value(STR_STUBS_FILE,QVariant()).toString();
    linkerScriptFile = map.value(STR_LINKER_SCRIPT,QVariant()).toString();
    targetName = map.value(STR_TARGET_NAME,QVariant()).toString();
    description = map.value(STR_DESCRIPTION,QVariant()).toString();
    gdbStartupCmds = map.value(STR_GDB_STARTUP_CMDS,QVariant()).toStringList();
    compilerToolPrefix = map.value(STR_COMPILER_TOOL,QVariant()).toString();
    flashProgramTool = map.value(STR_FLASHPROG_TOOL,QVariant()).toString();
    flashProgramArgs = map.value(STR_FLASHPROG_ARGS,QVariant()).toString();
    gdbServerTool = map.value(STR_GDBSERVER_TOOL,QVariant()).toString();
    gdbServerArgs = map.value(STR_GDBSERVER_ARGS,QVariant()).toString();
    maxHWBreakpoints = map.value(STR_MAX_HW_BREAKPOINTS,QVariant()).toInt();
    updateLPCUserCode = map.value(STR_UPDATE_LPC_USER_CODE,QVariant()).toBool();

    // replace path shortcuts with actual paths
    for(int i=0;i<objectFiles.size();i++)
        objectFiles.replace(i,FileUtility::replaceKeyWithPath(NULL,objectFiles.at(i)));
    for(int i=0;i<externalIncludeFolders.size();i++)
        externalIncludeFolders.replace(i,FileUtility::replaceKeyWithPath(NULL,externalIncludeFolders.at(i)));
    for(int i=0;i<libraryFiles.size();i++)
        libraryFiles.replace(i,FileUtility::replaceKeyWithPath(NULL,libraryFiles.at(i)));

    startObjFile = FileUtility::replaceKeyWithPath(NULL,startObjFile);
    stubsObjFile = FileUtility::replaceKeyWithPath(NULL,stubsObjFile);
    linkerScriptFile = FileUtility::replaceKeyWithPath(NULL,linkerScriptFile);
    compilerToolPrefix = FileUtility::replaceKeyWithPath(NULL,compilerToolPrefix);
    flashProgramTool = FileUtility::replaceKeyWithPath(NULL,flashProgramTool);
    flashProgramArgs = FileUtility::replaceKeyWithPath(NULL,flashProgramArgs);
    gdbServerTool = FileUtility::replaceKeyWithPath(NULL,gdbServerTool);
    gdbServerArgs = FileUtility::replaceKeyWithPath(NULL,gdbServerArgs);

    pathname = FileUtility::getDirTargets() + "/" + targetName;

}

//!----------------------------------------------------------------------------
//! \brief  Returns the class variables in a map. Paths are mapped to path keys.
//!----------------------------------------------------------------------------
QMap<QString, QVariant> Target::getMap()
{
    QStringList tmpObjectFiles;
    QStringList tmpExternalIncludeFolders;
    QStringList tmpLibraryFiles;

    // when we store info replace actual paths with path shortcuts
    for(int i=0;i<objectFiles.size();i++)
        tmpObjectFiles.append(FileUtility::replacePathWithKey(NULL,objectFiles.at(i)));
    for(int i=0;i<externalIncludeFolders.size();i++)
        tmpExternalIncludeFolders.append(FileUtility::replacePathWithKey(NULL,externalIncludeFolders.at(i)));
    for(int i=0;i<libraryFiles.size();i++)
        tmpLibraryFiles.append(FileUtility::replacePathWithKey(NULL,libraryFiles.at(i)));

    QString tmpStartObjFile = FileUtility::replacePathWithKey(NULL,startObjFile);
    QString tmpStubsObjFile = FileUtility::replacePathWithKey(NULL,stubsObjFile);
    QString tmpLinkerScriptFile = FileUtility::replacePathWithKey(NULL,linkerScriptFile);
    QString tmpCompilerToolPrefix = FileUtility::replacePathWithKey(NULL,compilerToolPrefix);
    QString tmpFlashProgTool = FileUtility::replacePathWithKey(NULL,flashProgramTool);
    QString tmpFlashProgArgs = FileUtility::replacePathWithKey(NULL,flashProgramArgs);
    QString tmpGdbServerTool = FileUtility::replacePathWithKey(NULL,gdbServerTool);
    QString tmpGdbServerArgs = FileUtility::replacePathWithKey(NULL,gdbServerArgs);

    // write data into map
    QMap<QString, QVariant> map;
    map.insert(STR_OBJECT_FILES,tmpObjectFiles);
    map.insert(STR_INCLUDE_FOLDERS,tmpExternalIncludeFolders);
    map.insert(STR_LIBRARY_FILES,tmpLibraryFiles);
    map.insert(STR_STD_LIBRARIES,standardLibs);
    map.insert(STR_STARTUP_FILE,tmpStartObjFile);
    map.insert(STR_STUBS_FILE,tmpStubsObjFile);
    map.insert(STR_LINKER_SCRIPT,tmpLinkerScriptFile);
    map.insert(STR_TARGET_NAME,targetName);
    map.insert(STR_DESCRIPTION,description);
    map.insert(STR_GDB_STARTUP_CMDS,gdbStartupCmds);
    map.insert(STR_COMPILER_TOOL,tmpCompilerToolPrefix);
    map.insert(STR_FLASHPROG_TOOL,tmpFlashProgTool);
    map.insert(STR_FLASHPROG_ARGS,tmpFlashProgArgs);
    map.insert(STR_GDBSERVER_TOOL,tmpGdbServerTool);
    map.insert(STR_GDBSERVER_ARGS,tmpGdbServerArgs);
    map.insert(STR_MAX_HW_BREAKPOINTS,maxHWBreakpoints);
    map.insert(STR_UPDATE_LPC_USER_CODE,updateLPCUserCode);

    return map;
}

//!----------------------------------------------------------------------------
//! \brief
//!
//! \return true if success, false if fail.
//!----------------------------------------------------------------------------
bool Target::saveAs(QString newName)
{
    if(newName.isEmpty()) return false;
    if(!newName.endsWith(".tgt"))
        newName += ".tgt";

    QString folder = FileUtility::getDirTargets();
    QString newPathname = folder + "/" + newName;
    QFileInfo nInfo(newPathname);
    if(nInfo.exists())
    {
        return false;
    }
    pathname = newPathname;
    targetName = newName;
    if(!save()) return false;
    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Target::erase()
{
    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Target::rename(QString newName)
{
    QFile file(pathname);
    if(!file.exists()) return false;
    if(!newName.endsWith(".tgt"))
        newName += ".tgt";
    QString newPathname = FileUtility::getDirTargets() + "/" + newName;
    QFileInfo info(newPathname);
    if(info.exists()) return false;

    if(file.rename(newPathname))
    {
        pathname = newPathname;
        targetName = info.fileName();
        return true;
    }
    return false;
}

//!----------------------------------------------------------------------------
//! \brief  Returns a list of all the target names available.
//!----------------------------------------------------------------------------
QStringList Target::getTargetNames()
{
    QString targetsFolder = FileUtility::getDirTargets();
    QDir dir(targetsFolder);
    QStringList filter;
    filter << "*.tgt";
    dir.setNameFilters(filter);
    QStringList names = dir.entryList(filter,QDir::Files,QDir::Name);
    for(int i=0;i<names.size();i++)
    {
        QString name = names.at(i);
        if(name.endsWith(".tgt"))
        {
            name = name.left(name.length()-4);
            names.replace(i,name);
        }
    }
    return names;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString Target::getDescription(QString targetName)
{
    Target target;
    if(!target.load(targetName)) return QString();
    return target.description;
}
