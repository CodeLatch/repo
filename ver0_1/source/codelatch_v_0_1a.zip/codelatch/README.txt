RELEASE VER 0.1  -- note: make sure this matches STR_PROGRAM_VER in mainwindow.h
RELEASE NOTES:
    First release 2/25/2015. Not perfect, but a stake in the ground.



-------------------------------------------------------------------------------
Readme file for CodeLatch IDE. This program is a free cross platform lightweight
software development environment intended for microcontroller firmware development.

Written by: J.Maloney
Copyright (C) 2013

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

-------------------------------------------------------------------------------
TOOLS & CREDITS

    The main ide application was developed using Qt.
    http://qt-project.org

    The windows version of code uses the MINGW compiler.
    http://www.mingw.org

    The mac version of code uses the XCODE compiler.
    https://developer.apple.com/xcode/

    The hid interface uses HIDAPI code written by Alan Ott.
    http://www.signal11.us/oss/hidapi/

    The code formatter uses Artistic Style code written by Jim Pattee and Tal Davidson.
    http://astyle.sourceforge.net

    The indexer uses Exuberant Ctags code.
    http://ctags.sourceforge.net

    The compiler for ARM CORTEX devices can be downloaded from:
    https://launchpad.net/gcc-arm-embedded

    Some icons were created using Pixelmator and some were downloaded under free/lgpl license from:
    https://www.iconarchive.com

-------------------------------------------------------------------------------
PROGRAM NOTES

    A minimum version of Qt 5.2 should be used for building the program.

    Minor modifications were made to the HIDAPI and AStyle code to reduce the compiler
    warnings produced by Qt.

    There is one code base for all platforms. However, additional steps are
    required for creating the final application package for each platform.
    See PLATFORM NOTES below.

    Additionally, the final application relies on a target microcontroller compiler
    and various project directories and files. These can be downloaded using the
    applicaiton.

    To build the project you need to install MINGW on Windows, XCODE on the mac,
    and gnu build tools on Linux. Next install Qt. Once the project is loaded in
    Qt select menu "Build->Run qmake", then build the project.

-------------------------------------------------------------------------------
PLATFORM NOTES

Windows:
    As of this date the easiest set up is to download Qt 5.4 with MINGW32. If
    you install this package Qt will setup the MINGW32 compiler and everything
    should work.

    1) To deploy the application you need to add a group of dll's to the target application directory.
    For version 5.4 MINGW the dll's are found in...
    c:\Qt\Qt5.4.0\5.4\mingw491_32\bin

    The required files are...

    icudt53.dll
    icuin53.dll
    icuuc53.dll
    libgcc_s_dw2-1.dll
    libstdc++-6.dll
    libwinpthread-1.dll
    Qt5Concurrent.dll
    Qt5Core.dll
    Qt5Gui.dll
    Qt5Network.dll
    Qt5PrintSupport.dll
    Qt5Widgets.dll

    2) In target app directory create a subdirectory named "platforms" and include
    the following files from the directory c:\Qt\Qt5.4.0\5.4\mingw491_32\plugins\platforms...

    qminimal.dll
    qoffscreen.dll
    qwindows.dll

    3) In your app directory create a file named "qt.conf" with the following text content...

    [PATHS]
    Libraries=./platforms


Mac:
    Install XCODE, then install Qt 5.4.

    Once the project is built you need to run macdeployqt which is found in the Qt binary install path.
    The easiest way to do this is to add macdeployqt as an external tool in Qt Creator with the following
    settings (if it's not already there)...

    Description: Mac Deployment
    Executable: %{CurrentProject:QT_HOST_BINS}/macdeployqt
    Arguments: *.app
    Working Directory: %{CurrentProject:BuildPath}
    Output and Error output: Show in Pane

Linux:
    Download Linux iso (13.10 32bit or 64bit), burn to dvd, install on computer.
    Don't do any upgrades or updates.
    Boot into linux, open Terminal window and install dev tools...
    $ sudo apt-get install build-essential
    $ sudo apt-get install libqt4-dev
    $ sudo apt-get install libusb-1.0-0-dev libudev-dev

    For 64bit systems also run...
    $ sudo apt-get install lib32z1 lib32ncurses5 lib32bz2-1.0

    Download Qt5.4 offline installer. Change permission to executable and run to install.
    Download CodeLatch source.
    In Qt open CodeLatch project, run qmake, and build..
    Place target binary in desired target folder.

    To set the app icon you need to...
    cp codelatchlogo.png ~/.local/share/icons/hicolor/128x128/apps

    To get the usb hid working you need to...
    sudo cp 99-codelatch.rules /etc/udev/rules.d

    The file 99-codelatch.rules file and codelatchlogo.png file are stored
    in the tools directory for linux.

    I've had instances where certain usb ports don't respond to the hid
    and you have to edit the busnum parameter in the rules file.

-------------------------------------------------------------------------------
