#ifndef INFOVIEW_H
#define INFOVIEW_H

#include <QWidget>
#include "Views/findreplacewidget.h"

class QTabWidget;
class BreakpointsWidget;
class QHBoxLayout;

class InfoView : public QWidget
{
    Q_OBJECT
public:
    explicit InfoView(QWidget *parent = 0);
    void finderSearchForText(const QString &text, int scope = -1);
    void initToolbar(QHBoxLayout *tbLayout);

    BreakpointsWidget *breakpointsWidget;

private:
    QTabWidget *tabWidget;
    FindReplaceWidget *findReplaceWidget;

signals:
    void activateFile(QString pathname, int line);

public slots:
    void clearConsole();
    void showConsole();
    void showFinder();
    void slotSetBreakpoints(Project *prj);
    void updateBreakpointView(Project *prj);

    void addBreakpoint(QString pathname, int line);
    void removeBreakpoint(QString pathname, int line);
    void navItemChanged(Project *prj,QString pathname);
};

#endif // INFOVIEW_H
