//!----------------------------------------------------------------------------
//! file: consoleprocess.cpp
//!
//! Implements ConsoleProcess which launches a process and pipes the output to
//! the console view. Deletes the process when finished and emits finished
//! signal.
//!
//! usage:
//! ConsoleProcess *myProcess = new ConsoleProcess(this);
//! connect(myProcess,SIGNAL(finished()),this,SLOT(myProcessFinished()));
//! QString cmd = "build";
//! QStringList args;
//! args << "print" << "hello";
//! myProcess->start(cmd,args);
//!
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "consoleprocess.h"
#include "Views/console.h"
#include <QDebug>
#include <QTimer>

//!----------------------------------------------------------------------------
//! \brief default constructor.
//!----------------------------------------------------------------------------
ConsoleProcess::ConsoleProcess(QObject *parent) :
    QObject(parent)
{
    process = NULL;
}

//!----------------------------------------------------------------------------
//! \brief Starts a process with the command cmd and arguments args.
//!----------------------------------------------------------------------------
bool ConsoleProcess::start(QString cmd, QStringList args)
{
    if(process != NULL) return false;
    process = new QProcess(this);
    connect(process,SIGNAL(finished(int)),this,SLOT(processFinished(int)));
//    connect(process,SIGNAL(readyRead()),this,SLOT(readyRead()));
    connect(process,SIGNAL(readyReadStandardError()),this,SLOT(readyRead()));
    connect(process,SIGNAL(readyReadStandardOutput()),this,SLOT(readyRead()));

    process->start(cmd,args);

    // check for an error 0=failed to start, 1=crashed, 2=timeout,
    // 3=read error, 4=write error, 5=unknown(default if no error)
    QProcess::ProcessError error = process->error();
    if(error != QProcess::UnknownError)
    {
        qDebug() << "process startup error:" << error;
        process->deleteLater();
        process = NULL;
        return false;
    }

    if(!process->waitForStarted(500))
    {
//        process->kill();
        qDebug() << "process didn't start.";
        process->deleteLater();
        process = NULL;
        return false;
    }
    return true;
}

//!----------------------------------------------------------------------------
//! \brief Wait for a line of text.
//!----------------------------------------------------------------------------
bool ConsoleProcess::waitForOutput(int timeout_ms)
{
    QTimer timer;
    connect(&timer,SIGNAL(timeout()),this,SLOT(waitLoopTimeout()));
    timer.start(timeout_ms);
    int ret = waitForOutputLoop.exec();
    if(ret == 0) return false;
    return true;
}

void ConsoleProcess::waitLoopTimeout()
{
    if(waitForOutputLoop.isRunning())
        waitForOutputLoop.exit(0);
}

//!----------------------------------------------------------------------------
//! \brief SLOT called when the process is finished. Deletes the process and
//! emits finished signal.
//!----------------------------------------------------------------------------
void ConsoleProcess::processFinished(int exitcode)
{
    Q_UNUSED(exitcode);
    process->deleteLater();
    process = NULL;
    emit finished();
}

//!----------------------------------------------------------------------------
//! \brief SLOT called when read data is available from the launched process.
//! The read data is sent to the console view.
//!----------------------------------------------------------------------------
void ConsoleProcess::readyRead()
{
    if(process == NULL) return;
    QByteArray a = process->readAll();
    QString s(a);
    if(s.length() <= 0) return;
    outputList.append(s);
    if(waitForOutputLoop.isRunning())
        waitForOutputLoop.exit(1);

    QStringList list = s.split('\n');

    if(console == NULL) return;
    foreach(QString line,list)
        console->appendLine(line);
}

bool ConsoleProcess::waitForStarted(int msecs)
{
    if(process == NULL) return false;
    return process->waitForStarted(msecs);
}

bool ConsoleProcess::waitForFinished(int msecs)
{
    if(process == NULL) return false;
    return process->waitForFinished(msecs);
}

