//!----------------------------------------------------------------------------
//! file: breakpointswidget.cpp
//!
//! Implements break points widget.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "breakpointswidget.h"
#include <QListWidget>
#include <QListWidgetItem>
#include <QVBoxLayout>
#include <QFileInfo>
#include "project/project.h"

BreakpointsWidget::BreakpointsWidget(QWidget *parent) :
    QWidget(parent)
{
    // MainWindow needs to be passed as this classes parent so
    // we can get access to the NavTree and TabManager.
    mainWindow = reinterpret_cast<MainWindow*>(parent);

    listWidget = new QListWidget;

    connect(listWidget,SIGNAL(itemClicked(QListWidgetItem*)),this,SLOT(itemClicked(QListWidgetItem*)));

    QFont font;
    font.setFamily("Monaco");
    font.setFixedPitch(true);
    font.setPointSize(10);
    listWidget->setFont(font);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(listWidget);
//    layout->setContentsMargins(0,0,0,0);
    layout->setSpacing(0);
    layout->setMargin(0);
    setLayout(layout);

//    QListWidgetItem *item1 = new QListWidgetItem(QIcon(":/icons/icons/reddot.png"), "BlueHills");
//    listWidget->insertItem(0, item1);
}

QList<S_Breakpoint> BreakpointsWidget::sort(QList<S_Breakpoint> list)
{
    int n = list.size();
    if(n < 2) return list;

    bool swap = true;
    bool exchange;
    while(swap)
    {
        swap = false;
        for(int i=0;i<n-1;i++)
        {
            exchange = false;
            S_Breakpoint a = list.at(i);
            S_Breakpoint b = list.at(i+1);
            if(a.pathname == b.pathname)
            {
                if(a.lineNumber < b.lineNumber)
                    exchange = true;
            }
            else if(a.pathname < b.pathname)
                exchange = true;

            if(exchange)
            {
                list.move(i+1,i);
                swap = true;
            }
        }
    }
    return list;
}

void BreakpointsWidget::setBreakpoints(QList<S_Breakpoint> breakpoints)
{
    listWidget->clear();

    breakpoints = sort(breakpoints);
    breakpointList = breakpoints;

    foreach (S_Breakpoint bp, breakpoints)
    {
        QFileInfo info(bp.pathname);
        QString str = "line: " + QString::number(bp.lineNumber) + ", file: " + info.fileName();
        QListWidgetItem *item = new QListWidgetItem(QIcon(":/icons/icons/reddot.png"), str);
        item->setData(Qt::UserRole,bp.pathname);
        item->setData(Qt::UserRole+1,bp.lineNumber);
        listWidget->insertItem(0, item);
    }
}
void BreakpointsWidget::setBreakpoints(Project *prj)
{
    if(prj == NULL) return;

    QList<S_Breakpoint> breakpoints = prj->getBreakpoints();
    setBreakpoints(breakpoints);
}


void BreakpointsWidget::addBreakpont(QString pathname,int line)
{
    S_Breakpoint bp;
    bp.pathname = pathname;
    bp.lineNumber = line;
    breakpointList.append(bp);
    setBreakpoints(breakpointList);
}

void BreakpointsWidget::removeBreakpont(QString pathname,int line)
{
    for(int i=0;i<breakpointList.size();i++)
    {
        S_Breakpoint bp = breakpointList.at(i);
        if((bp.pathname == pathname) && (bp.lineNumber == line))
            breakpointList.removeAt(i);
    }
    setBreakpoints(breakpointList);
}


void BreakpointsWidget::itemClicked(QListWidgetItem *item)
{
    if(item == NULL) return;
    QString filename = item->data(Qt::UserRole).toString();
    int line = item->data(Qt::UserRole+1).toInt();
    emit breakpointClicked(filename,line);
}
