//!----------------------------------------------------------------------------
//! file: variableview.cpp
//!
//! Implements variable view.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "variableview.h"
#include "gdb/debugcontrol.h"
#include <QVBoxLayout>
#include <QInputDialog>
#include <QMenu>
#include <QMessageBox>
#include <QSplitter>
#include <QFileInfo>
#include <QToolBar>


Variable::Variable()
{
}
Variable::Variable(Variable &v)
{
    parentName = v.parentName;
    name = v.name;
    fullName = v.fullName;
    type = v.type;
    rootType = v.rootType;
    baseType = v.baseType;
    address = v.address;
    value = v.value;
    format = v.format;
}
Variable::Variable(const Variable &v)
{
    parentName = v.parentName;
    name = v.name;
    fullName = v.fullName;
    type = v.type;
    rootType = v.rootType;
    baseType = v.baseType;
    address = v.address;
    value = v.value;
    format = v.format;
}
Variable::~Variable()
{
}


VariableView::VariableView(QWidget *parent) :
    QWidget(parent)
{
    debug = NULL;

    QToolBar *toolbar = new QToolBar;
    toolbar->addAction(QIcon(":/icons/icons/add.png"),"add global",this,SLOT(addGlobalVariable()));
    toolbar->addAction(QIcon(":/icons/icons/remove.png"),"remove global",this,SLOT(removeGlobalVariable()));
    toolbar->setIconSize(QSize(12,12));

    tree = new QTreeWidget;
    tree->setFocusPolicy(Qt::NoFocus);
    QTreeWidgetItem *treeHeader = new QTreeWidgetItem;
    treeHeader->setText(0,QString("Name"));
    treeHeader->setText(1,QString("Type"));
    treeHeader->setText(2,QString("Value"));
    // mem manage note: setHeaderItem makes this class parent of headerItem
    tree->setHeaderItem(treeHeader);
    tree->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(tree,SIGNAL(itemDoubleClicked(QTreeWidgetItem*,int)),this,SLOT(itemDoubleClicked(QTreeWidgetItem*,int)));
    connect(tree,SIGNAL(itemCollapsed(QTreeWidgetItem*)),SLOT(itemCollapsed(QTreeWidgetItem*)));
    connect(tree,SIGNAL(itemExpanded(QTreeWidgetItem*)),SLOT(itemExpanded(QTreeWidgetItem*)));
    connect(tree,SIGNAL(customContextMenuRequested(QPoint)),SLOT(contextMenu(QPoint)));

    stackWidget = new QTreeWidget;
    stackWidget->setFocusPolicy(Qt::NoFocus);
    QTreeWidgetItem *stackHeader = new QTreeWidgetItem;
    stackHeader->setText(0,QString("Frame"));
    stackHeader->setText(1,QString("Function"));
    stackHeader->setText(2,QString("Line"));
//    stackHeader->setText(3,QString("Address"));
    stackHeader->setText(3,QString("Filename"));
    stackWidget->setHeaderItem(stackHeader);
    connect(stackWidget,SIGNAL(itemClicked(QTreeWidgetItem*,int)),this,SLOT(stackItemClicked(QTreeWidgetItem*,int)));

    QSplitter *vSplit = new QSplitter(Qt::Vertical);
    vSplit->addWidget(tree);
    vSplit->addWidget(stackWidget);
    vSplit->setStretchFactor(0, 1);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(toolbar);
    layout->addWidget(vSplit);
    layout->setSpacing(0);
    layout->setMargin(0);
    //    layout->setContentsMargins(0,0,0,0);
    setLayout(layout);
}

///----------------------------------------------------------------------------
/// \brief
///----------------------------------------------------------------------------
void VariableView::addGlobalVariable()
{
    if(debug == NULL) return;
    // show dialog with list of globals
    QStringList globalNames = debug->getGlobalVariableNames();
    if(globalNames.length() == 0)
    {
        QMessageBox::information(this,"Info","There are no global variables.");
        return;
    }
    QInputDialog dlg;
    dlg.setOptions(QInputDialog::UseListViewForComboBoxItems);
    dlg.setComboBoxItems(globalNames);
    dlg.setLabelText("Select a global variable");
    if(!dlg.exec()) return;
    QString name = dlg.textValue();
    if(name.isEmpty()) return;

    if(globalVariableList.contains(name)) return;
    globalVariableList.append(name);
    updateVariableView(0);
}

///----------------------------------------------------------------------------
/// \brief
///----------------------------------------------------------------------------
void VariableView::removeGlobalVariable()
{
    if(debug == NULL) return;

    QTreeWidgetItem *item = tree->currentItem();
    if(item == NULL) return;
    QString name = item->text(0);
    int i = globalVariableList.indexOf(name);
    if(i == -1) return;
    globalVariableList.removeAt(i);
    updateVariableView(0);
}

///----------------------------------------------------------------------------
/// \brief
///----------------------------------------------------------------------------
void VariableView::updateFrameView()
{
    if(debug == NULL) return;
    QList<DebugFrame> frames = debug->getStackFrames();
    // update frame list
    stackWidget->clear();
    foreach(DebugFrame f,frames)
    {
//        QString fn;
//        fn.sprintf("0x%08x",f.address) + " : ";
        QFileInfo info(f.pathName);
        QTreeWidgetItem *child = new QTreeWidgetItem;
        child->setText(0,QString::number(f.frameNumber));
        child->setText(1,f.functionName);
        child->setText(2,QString::number(f.lineNumber));
//        child->setText(3,fn);
        child->setText(3,info.fileName());
        child->setData(0,Qt::UserRole+0,f.frameNumber);
        child->setData(0,Qt::UserRole+1,f.lineNumber);
        child->setData(0,Qt::UserRole+2,f.pathName);
        stackWidget->addTopLevelItem(child);
    }
    for(int i=0;i<stackWidget->columnCount();i++)
        stackWidget->resizeColumnToContents(i);
}

///----------------------------------------------------------------------------
/// \brief
///----------------------------------------------------------------------------
void VariableView::updateVariableView(int frameNumber)
{
    if(debug == NULL) return;

    int threadId = debug->getCurrentThraedNumber();
    if(threadId == -1) return;
    QString vars = debug->getVariables(threadId,frameNumber);
    QString globals = getGlobals();
    tree->clear();
    parseAndUpdateVariables(vars);
    parseAndUpdateVariables(globals);
    updateWidths();
}

///----------------------------------------------------------------------------
/// \brief
///----------------------------------------------------------------------------
QString VariableView::getGlobals()
{
    QString str;
    foreach(QString name,globalVariableList)
    {
        QString ret = debug->evaluateExpression(name);
        str += "{name=\""+name+"\",value=\""+ret+"\"},";
    }
    if(!str.isEmpty())
        str = str.left(str.length()-1); // remove trailing comma
    return str;
}

///----------------------------------------------------------------------------
/// \brief
///----------------------------------------------------------------------------
void VariableView::parseAndUpdateVariables(QString str)
{
    // remove leading and trailing bracket
    str = str.left(str.length()-1);
    str = str.right(str.length()-1);
    // split
    QStringList localList = str.split("},{");

    /*
    name="i",value="0x11940"
    name="myArray",value="\"\\340O\\000\\357\\357\\355\""
    name="myS",value="{c = 0xffbfffde, d = 0xfffffffe}"
    name="myT",value="{r = 0x2, m = 0x800245c, j = {c = 0x2, d = 0xf}}"
    */
    foreach(QString line,localList)
    {
        int i=line.indexOf("\",");
        QString name = line.mid(6,i-6);
        QString value = line.mid(i+9,line.length()-11);
        QString subLine = name + " = " + value;
        parseLine(subLine);
    }
}

///----------------------------------------------------------------------------
/// \brief  Main function called by view manager to update this view.
///----------------------------------------------------------------------------
void VariableView::updateView(Debug *debug)
{
    this->debug = debug;
    if(debug == NULL) return;

    updateFrameView();

    // get currently expanded items
    QStringList list = getExpandedItemsList();
    // get currently selected item
    QTreeWidgetItem *item = tree->currentItem();
    QString selName;
    if(item != NULL)
    {
        QVariant qv = item->data(0,VariableView::VarData);
        Variable *var = (Variable *) qv.data();
        selName = var->fullName;
    }
    tree->setVisible(false);
    updateVariableView(0); // update frame 0
    // restore previously expanded items
    restoreExpandedItems(list);

    // restore previously selected item
    item = findItem(selName);
    if(item != NULL)
        tree->setCurrentItem(item);

    // update column widths to fit items
    updateWidths();

    tree->setVisible(true);
}

///----------------------------------------------------------------------------
/// \brief  Slot to handle right clicking in view, display context menu.
///----------------------------------------------------------------------------
void VariableView::contextMenu(QPoint pt)
{
    QTreeWidgetItem *item = tree->currentItem();
    if(item == NULL) return;

    QVariant qv = item->data(0,VariableView::VarData);
    Variable *var = (Variable *) qv.data();

    QPoint globalPos = mapToGlobal(pt);
    // for QAbstractScrollArea and derived classes you would use:
    // QPoint globalPos = myWidget->viewport()->mapToGlobal(pos);

    QMenu menu;
    QMenu *submenu = menu.addMenu("Format");
    submenu->addAction("Hex");
    submenu->addAction("Decimal");
    submenu->addAction("Ascii");
    submenu->addAction("Octal");
    menu.addAction("Get Address");
    menu.addAction("Show Info");
    menu.addSeparator();
    menu.addAction("Add Global");

    QAction* selectedItem = menu.exec(globalPos);
    if (selectedItem)
    {
        QString sel = selectedItem->text();
        // context menu item selected...
        if(sel == "Show Info")
        {
            QString title("Variable Info");
            QString text;
            text.append("Name: " + var->fullName + "\n");
            text.append("Type: " + var->type + "\n");
            text.append("Address: " + var->address + "\n");
            text.append("Value: " + var->value + "\n");
            QMessageBox::information(this,title,text);
        }
    }
}

///----------------------------------------------------------------------------
/// \brief  Handle edit of variable value.
///----------------------------------------------------------------------------
void VariableView::itemDoubleClicked(QTreeWidgetItem* item,int col)
{
    (void) col; // unused
    if(item == NULL) return;

    QVariant qv = item->data(0,VariableView::VarData);
    Variable *var = (Variable*) qv.data();

    QString containerName = var->fullName;
    QString baseType = var->baseType;
    QString name = var->name;
    QString type = var->type;
    QString value = var->value;

    // don't allow editing of entries that are contants, empty, or containers.
    if(baseType.startsWith("const ")) return;
    if(value.isEmpty() || name.isEmpty() || type.isEmpty()) return;
    if(value == "{...}") return;

    // open a dialog to allow the user to edit the value
    bool ok;
    QString newValue = QInputDialog::getText(this, "Modify Variable",
                                             "Value:", QLineEdit::Normal,
                                             value, &ok);
    if(!ok) return;
    if(newValue.isEmpty()) return;
    newValue = newValue.trimmed();

    if((baseType == "double") || (baseType == "float"))
    {
        // if this is a floating point variable and we don't have a decimal point gdb will assume it's hex
        if(!newValue.contains('.'))
            newValue = newValue + ".0";
    }
    else
    {
        if(!newValue.startsWith("0x"))
        {
            // if this is a decimal entry that isn't preceeded by 0x then assume
            // the user wants to enter a base 10 value.
            long val = newValue.toInt(&ok);
            if(ok)
                newValue = "0x" + QString::number(val,16);
        }
    }

    if(debug == NULL) return;
    debug->writeVariable(containerName,newValue);
    updateView(debug);
}

///----------------------------------------------------------------------------
/// \brief  Handle item collapsed.
///----------------------------------------------------------------------------
void VariableView::itemCollapsed(QTreeWidgetItem *item)
{
    (void) item; // unused

    updateWidths();
}

///----------------------------------------------------------------------------
/// \brief  Handle item expanded.
///----------------------------------------------------------------------------
void VariableView::itemExpanded(QTreeWidgetItem *item)
{
    (void) item; // unused
    updateWidths();
}

///-----------------------------------------------------------------------------
/// \brief  Checks to see if the same stack frame (ie current function) has
///         changed since the last time this function was called. Uses class
///         variable stackFrameList to store last stack frame list.
///-----------------------------------------------------------------------------
bool VariableView::hasStackFrameChanged()
{
    bool ret = false;

    if(debug == NULL) return false;
    //    QStringList list = debug->sendCommand("info stack\n");
    QStringList list = debug->sendCommand("-stack-info-frame\n");
    // #0  main ()
    //    at /users/johnmaloney/desktop/dev/build-codelatchdebug/projects/stm32_aread_blink/main.cpp:35
    // (gdb)
    // remove line numbers because only care about functions

    //    ^done,frame={level="0",addr="0x080013b6",func="delay",file="/users/johnmaloney/desktop/dev/build-codelatchdebug/lib/stm32f10x/stm32f10x_lib/timer.cpp",fullname="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/lib/stm32f10x/stm32f10x_lib/timer.cpp",line="9"}
    //    (gdb)

    //    ^done,frame={level="0",addr="0x080001da",func="main",file="/users/johnmaloney/desktop/dev/build-codelatchdebug/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/projects/stm32_aread_blink/main.cpp",line="35"}
    //    (gdb)

    if(list.size() < 2) return false;
    QString line = list.first();
    if(!line.startsWith("^done,")) return false;

    int i = line.lastIndexOf(",line=");
    if(i == -1) return false;
    line = line.left(i);

    i = line.indexOf(",addr=");
    if(i == -1) return false;
    int j = line.indexOf(",func=");
    if(j == -1) return false;
    line = line.remove(i,j-i);

    if(line != stackFrameInfo)
        ret = true;
    else
        ret = false;

    stackFrameInfo = line;

    return ret;
}

///-----------------------------------------------------------------------------
/// \brief
///-----------------------------------------------------------------------------
QStringList VariableView::getExpandedItemsList()
{
    // create a list of all tree items that are expanded
    // so we can restore them to expanded after we re-load the tree.
    QStringList list;

    // if the stack frome has changed (ie we are in a different function) return an empty list.
    if(hasStackFrameChanged())
        return list;

    int n = tree->topLevelItemCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *item = tree->topLevelItem(i);
        if(item->isExpanded())
        {
            QVariant qv = item->data(0,VariableView::VarData);
            Variable *var = (Variable *) qv.data();
            list.append(var->fullName);
            if(item->childCount() > 0)
                addExpandedChildrenToList(item,list);
        }
    }
    return list;
}

///-----------------------------------------------------------------------------
/// \brief
///-----------------------------------------------------------------------------
void VariableView::addExpandedChildrenToList(QTreeWidgetItem *item, QStringList &list)
{
    int n = item->childCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *child = item->child(i);
        if(child->isExpanded())
        {
            QVariant qv = child->data(0,VariableView::VarData);
            Variable *var = (Variable *) qv.data();
            list.append(var->fullName);
        }
        if(child->childCount() > 0)
            addExpandedChildrenToList(child,list);
    }
}

///-----------------------------------------------------------------------------
/// \brief
///-----------------------------------------------------------------------------
void VariableView::restoreExpandedItems(QStringList &list)
{
    if(list.isEmpty()) return;

    int n = tree->topLevelItemCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *item = tree->topLevelItem(i);
        QVariant qv = item->data(0,VariableView::VarData);
        Variable *var = (Variable *) qv.data();
        if(list.contains(var->fullName))
        {
            item->setExpanded(true);
            if(item->childCount() > 0)
                expandChildrenInList(item,list);
        }
    }
}

///-----------------------------------------------------------------------------
/// \brief   Expands tree item children that are in a list, if found.
///-----------------------------------------------------------------------------
void VariableView::expandChildrenInList(QTreeWidgetItem *item, QStringList &list)
{
    int n = item->childCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *child = item->child(i);
        QVariant qv = child->data(0,VariableView::VarData);
        Variable *var = (Variable *) qv.data();
        if(list.contains(var->fullName))
        {
            child->setExpanded(true);
            if(child->childCount() > 0)
                expandChildrenInList(child,list);
        }
    }
}


///-----------------------------------------------------------------------------
/// \brief   Finds an item with the associated parent name and variable name.
///-----------------------------------------------------------------------------
QTreeWidgetItem* VariableView::findItem(QString fullName)
{
    if(fullName.isEmpty()) return NULL;

    int n = tree->topLevelItemCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *treeitem = tree->topLevelItem(i);
        QVariant qv = treeitem->data(0,VariableView::VarData);
        Variable *var = (Variable *) qv.data();
        if(var->fullName == fullName) return treeitem;
        if(treeitem->childCount() > 0)
        {
            QTreeWidgetItem *childItem = findItemInChildren(fullName,treeitem);
            if(childItem != NULL) return childItem;
        }
    }
    return NULL;
}

///-----------------------------------------------------------------------------
/// \brief   Finds an item with the associated parent name and variable name.
///-----------------------------------------------------------------------------
QTreeWidgetItem* VariableView::findItemInChildren(QString &fullName, QTreeWidgetItem *item)
{
    if(item == NULL) return NULL;
    int n = item->childCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *child = item->child(i);
        QVariant qv = child->data(0,VariableView::VarData);
        Variable *var = (Variable *) qv.data();
        if(var->fullName == fullName) return child;
        if(child->childCount() > 0)
        {
            QTreeWidgetItem *childItem = findItemInChildren(fullName,child);
            if(childItem != NULL) return childItem;
        }
    }
    return NULL;
}

///----------------------------------------------------------------------------
/// \brief  Returns the root type for a given data type. This is used for
///         determining typedef data types root type.
///----------------------------------------------------------------------------
QString VariableView::getRootType(QString variableType)
{
    // whatis int
    //    &"whatis int\n"
    //    ~"type = int\n"
    //    ^done
    //    (gdb)

    QString ptrStr;
    QString type = variableType.trimmed();
    do {
        variableType = type;
        if(variableType.contains('*'))
        {
            ptrStr += "*";
            variableType = variableType.remove('*').trimmed();
        }
        if(variableType.contains('['))
        {
            //            int n = variableType.count('[');
            //            for(int i=0;i<n;i++) ptrStr += "*";
            variableType = variableType.left(variableType.indexOf('[')).trimmed();
        }
        type = debug->getVariableType(variableType).trimmed();
    } while((type != variableType) && (type != ""));

    if(!ptrStr.isEmpty())
        type = type + " " + ptrStr;
    return type;
}

///----------------------------------------------------------------------------
/// \brief  Returns the name of the variable for the given gdb line.
///----------------------------------------------------------------------------
QString VariableView::getName(QString line)
{
    QString name;
    int i = line.indexOf('=');
    if(i != -1)
        name = line.left(i).trimmed();
    return name;
}

///----------------------------------------------------------------------------
/// \brief  Returns the data of the variable for the given gdb line.
///----------------------------------------------------------------------------
QString VariableView::getData(QString name, QString type)
{
    //    p **d
    //    &"p **d\n"
    //    ~"$5 = 10"
    //    ~"\n"
    //    ^done

    // int i;
    //    -data-evaluate-expression i
    //    ^done,value="-34"
    //    (gdb)

    // int array[10];
    //    -data-evaluate-expression array
    //    done,value="{0x5, 0x6, 0x7, 0xad27, 0x20000000, 0x3, 0x8003384, 0x3, 0xf, 0xfffffffc}"
    //    (gdb)

    //   (gdb) p array
    //   $1 = {5, 6, 7, 44327, 536870912, 3, 134230916, 3, 15, -4}
    //   (gdb)

    QStringList list;
    QString ptr;
    for(int i=0;i<type.count('*');i++)  ptr+="*";
    list = debug->sendCommand("-data-evaluate-expression " + ptr + name + "\n");
    if(list.size() < 2) return QString();
    QString data = list.first();
    if(!data.startsWith("^done,value=")) return QString();

    data = data.right(data.length() - data.indexOf('=') - 1).trimmed();
    data = data.remove('"');
    return data;
}

///----------------------------------------------------------------------------
/// \brief  Returns the value of a given variable in hex format. This is useful
///         to avoid dealing with character strings. However you can't
///         use this output to extract floating point number values.
///----------------------------------------------------------------------------
QString VariableView::getHexData(Variable &var)
{
    //    QStringList list;
    QString data = getData(var.parentName+var.name,var.rootType);
    /*
    if(var.rootType.contains('*'))
        list = debug->sendCommand("p/x *" + var.parentName+var.name + "\n");
    else
        list = debug->sendCommand("p/x " + var.parentName+var.name + "\n");
    if(list.size() < 2) return "";
    QString data = list.at(0);
    if(data.length() < 2) return "";
    data = data.right(data.length() - data.indexOf('=') - 1).trimmed();
*/    return data;
}

///----------------------------------------------------------------------------
/// \brief  Returns the address of a variable.
///----------------------------------------------------------------------------
QString VariableView::getAddress(QString name, QString type)
{
    // get variable address
    //    QStringList list;
    /*    if(type.contains('*'))
        list = debug->sendCommand("p/x " + name + "\n");
    else
        list = debug->sendCommand("p/x &" + name + "\n");
    if(list.size() < 2) return QString();
    if(list.last().trimmed()=="(gdb)")
        list.removeLast();
    QString varAddress = list.at(0);
    if(varAddress.length() < 2) return QString();
    varAddress = varAddress.right(varAddress.length() - varAddress.indexOf('=') - 1).trimmed();
    return varAddress;
*/
    QString amp;
    if(!type.contains('*'))
        amp = "&";
    QString data = getData(amp + name,type);
    return data;
}

///----------------------------------------------------------------------------
/// \brief  Returns the first member in data and removes that member from data.
///----------------------------------------------------------------------------
QString VariableView::getNextContainerMember(QString *data)
{
    QString section;
    int len = data->length();

    // the first item in data should be a variable name followed by an equal sign.
    int i = data->indexOf('=');
    if(i == -1)
    {
        data->clear();
        return QString();
    }
    i++;
    if(data->at(i) != ' ')
    {
        data->clear();
        return QString();
    }
    i++;
    // i should now be the index of the first character in the first varaibles data

    if(data->at(i) == '{')
    {
        // this is a container or array, find the matching closing bracket
        int n = 1; // bracket counter
        i++; // index next character
        while((n != 0) && (i < len))
        {
            QChar c = data->at(i++);
            if(c == '{')
                n++;
            else if(c == '}')
                n--;
        }
        section = data->left(i);
        //        *data = data->right(len - i - 1);
        *data = data->right(len - i);
    }
    else
    {
        // this is a single data item, find ending comma or }
        i = data->indexOf(',',i);
        if(i != -1)
        {
            section = data->left(i);
            *data = data->right(data->length() - i - 1);
        }
        else
        {
            section = *data;
            data->clear();
        }
    }
    return section;
}

///----------------------------------------------------------------------------
/// \brief  Add a container to the tree.
///----------------------------------------------------------------------------
void VariableView::addContainer(QString parentName,QString name,QString *data,QTreeWidgetItem *item)
{
    QString part;
    // remove opening and closing brackets from data
    if((data->at(0) != '{') || (data->at(data->length()-1) != '}'))
        return;
    *data = data->right(data->length()-1);
    *data = data->left(data->length()-1);
    // add members
    part = getNextContainerMember(data);
    while(!part.isEmpty())
    {
        parseLine(part,parentName+name+".",item);
        part = getNextContainerMember(data);
    }
}

///----------------------------------------------------------------------------
/// \brief  Add array to the tree.
///----------------------------------------------------------------------------
void VariableView::addArray(Variable &container,QString varValue,QTreeWidgetItem *item)
{
    // this is an array, can be multi-dimensional
    QList<int> arrayIndicies;
    int arrayDepth = -1;
    QString arraySuffix;
    Variable v = container;
    if(!v.parentName.isEmpty())
        v.parentName += v.name;
    else
        v.parentName = v.name;

    QStringList split2 = varValue.split(',');

    v.type = v.type.left(v.type.indexOf('[')).trimmed();

    // determine dimensions of array
    int arrayDimensions = split2.at(0).count('{');

    // intialize array indicies
    for(int i=0;i<arrayDimensions;i++)
        arrayIndicies.append(0);

    foreach(QString str,split2)
    {
        int n = str.count('{');
        arrayDepth += n;

        QString value = str;
        value = value.remove('{');
        value = value.remove('}');
        value = value.trimmed();

        arraySuffix.clear();
        for(int i=0;i<arrayDimensions;i++)
            arraySuffix += "[" + QString::number(arrayIndicies.at(i)) + "]";
        Variable var;
        var.parentName = v.parentName;
        var.name = arraySuffix;
        var.type = v.type;
        var.baseType = v.type;
        var.value = value;
        insertRow(var,item);
        arrayIndicies.replace(arrayDepth,arrayIndicies.at(arrayDepth)+1);

        int m = str.count('}');
        for(int i=0;i<m;i++)
        {
            arrayIndicies[arrayDepth] = 0;
            arrayDepth--;
            if(arrayDepth >= 0)
                arrayIndicies[arrayDepth] = arrayIndicies[arrayDepth] + 1;
        }
    }
}

///----------------------------------------------------------------------------
/// \brief  Update tree column widths to fit contents.
///----------------------------------------------------------------------------
void VariableView::updateWidths()
{
    for (int column = 0; column < tree->columnCount(); column++)
        tree->resizeColumnToContents(column);
}

///----------------------------------------------------------------------------
/// \brief  Inserts a new row into the tree.
///----------------------------------------------------------------------------
//QTreeWidgetItem* VariableView::insertRow(QString containerName, QString name, QString type, QString baseType, QString value, QTreeWidgetItem *parent)
QTreeWidgetItem* VariableView::insertRow(Variable &var, QTreeWidgetItem *parent)
{
    QTreeWidgetItem *child = new QTreeWidgetItem;
    child->setText(0,var.name);
    child->setText(1,var.type);
    child->setText(2,var.value);

    QString fullname = var.fullName;
    if(var.name.startsWith('['))
    {
        fullname = var.parentName;
        // change array indexes from decimal to hex (needed for gdb)
        QString name = var.name;
        name = name.remove('[').trimmed();
        QStringList list = name.split(']');
        list.takeLast();
        foreach(QString s,list)
        {
            bool ok;
            int val = s.toInt(&ok);
            QString hex = "[0x" + QString::number(val,16) + "]";
            fullname += hex;
        }
    }

    var.fullName = fullname;
    QVariant qv;
    qv.setValue(var);
    child->setData(0,VariableView::VarData,qv);

    if(parent == NULL)
        tree->addTopLevelItem(child);
    else
        parent->addChild(child);

    return child;
}

/*
SEND:-data-evaluate-expression TABLE_pinTimer
^done,value="\"\\020\\001\\001\\001\\001\\002\\003\\000\\000\\000\\003c\\002\\002c\\003\""
(gdb)

SEND:-data-evaluate-expression systicks
^done,value="0x0"
(gdb)

SEND:-data-evaluate-expression Pin
^done,value="{callbackFuncPtr = 0}"
(gdb)

SEND:-stack-list-variables --thread 1 --frame 0 --all-values
^done,variables=[{name="i",value="0x7"},{name="myArray",value="\"?@ ABCD\""}]
(gdb)

SEND:-data-evaluate-expression myArray
^done,value="\"?@ ABCD\""
(gdb)

SEND:-data-evaluate-expression myT
^done,value="{r = 0x2, m = 0x800245c, j = {c = 0x2, d = 0xf}}"
(gdb)

SEND:-stack-list-variables --thread 1 --frame 0 --all-values
^done,variables=[{name="i",value="0x7"},{name="myArray",value="\"?@ ABCD\""},{name="myS",value="{c = 0xff0025ba, d = 0x200011ba}"},{name="myT",value="{r = 0x2, m = 0x800245c, j = {c = 0x2, d = 0xf}}"}]
(gdb)

1 - remove lead ^done,variables=[{ and tail }]
name="i",value="0x7"},{name="myArray",value="\"?@ ABCD\""},{name="myS",value="{c = 0xff0025ba, d = 0x200011ba}"},{name="myT",value="{r = 0x2, m = 0x800245c, j = {c = 0x2, d = 0xf}}"

2 - split on },{
name="i",value="0x7"
name="myArray",value="\"?@ ABCD\""
name="myS",value="{c = 0xff0025ba, d = 0x200011ba}"
name="myT",value="{r = 0x2, m = 0x800245c, j = {c = 0x2, d = 0xf}}"

3 - parse each line, remove leading name=" split on ",value=" remove trailing "
i
0x7
myArray
\"?@ ABCD\"
myS
{c = 0xff0025ba, d = 0x200011ba}
myT
{r = 0x2, m = 0x800245c, j = {c = 0x2, d = 0xf}}

4 - if value contains { this is a container
*/

///----------------------------------------------------------------------------
/// \brief  Parses a line returned by gdb info locals or info args.
///----------------------------------------------------------------------------
bool VariableView::parseLine(QString line, QString parentName, QTreeWidgetItem *parent)
{
    line = line.trimmed();

    // -stack-list-locals 1
    // ^done,locals=[{name="a",value="0x62"},{name="str",value="\"Hello this is John Maloney\""},{name="c",value="0xf"},{name="s",value="{a = 0x4, b = 67.400000000000006}"},{name="adcVal",value="0x0"},{name="b",value="0xc"},{name="d",value="22.32"},{name="mybird",value="{array1d = {0x685aa2c}, a = 0x1e, b = 0x7f059835, s = {a = 0xcca3b70a, b = -2.6472918356657978e-34}, array4d = {0xf0e08fee, 0x7156ffd7, 0xa1208bab, 0x5d75c549}, c = 0x5556add4, d = 0x1ecbdeba}"},{name="myuni",value="{ch = 0xa8, i = 0xe7abfa8, l = 0xe7abfa8, f = 3.09071582e-30, d = 7.3553016434034279e+112}"}]
    // ...breaks down to...
    // {name="a",value="0x62"},
    // {name="str",value="\"Hello this is John Maloney\""},
    // {name="c",value="0xf"},
    // {name="s",value="{a = 0x4, b = 67.400000000000006}"},
    // {name="adcVal",value="0x0"},
    // {name="b",value="0xc"},
    // {name="d",value="22.32"},
    // {name="mybird",value="{array1d = {0x685aa2c}, a = 0x1e, b = 0x7f059835, s = {a = 0xcca3b70a, b = -2.6472918356657978e-34}, array4d = {0xf0e08fee, 0x7156ffd7, 0xa1208bab, 0x5d75c549}, c = 0x5556add4, d = 0x1ecbdeba}"},
    // {name="myuni",value="{ch = 0xa8, i = 0xe7abfa8, l = 0xe7abfa8, f = 3.09071582e-30, d = 7.3553016434034279e+112}"}

    //  s = {a = 0x4, name = \"Hello\\000\\000\\304\\266\", b = 67.400000000000006}

    if(!line.contains('=')) return false;

    Variable var;
    var.parentName = parentName;
    var.name = getName(line);
    var.fullName = var.parentName + var.name;
    var.type = debug->getVariableType(var.fullName).trimmed();
    var.rootType = getRootType(var.type);
    var.address = getAddress(var.fullName,var.rootType);
    var.baseType = var.rootType;
    var.baseType = var.baseType.remove('*').trimmed();
    QString data;

    // request hex formated data for character types, classes ,stuctures, and unions to make processing easier.
    if((var.baseType == "char") || (var.baseType == "const char") ||
            (var.baseType == "unsinged char") || (var.baseType == "const unsigned char") ||
            (line.count('=') > 1))
        data = getHexData(var);
    else
        data = getData(var.fullName,var.rootType);

    if(data.contains('='))
    {
        // this is a container
        var.value = "{...}";
        QTreeWidgetItem *newParent = insertRow(var,parent);
        addContainer(var.parentName,var.name,&data,newParent);
    }
    else if(data.startsWith('{'))
    {
        // this is an array
        var.value = "{...}";
        QTreeWidgetItem *newParent = insertRow(var,parent);
        addArray(var,data,newParent);
    }
    else
    {
        // this is a single variable
        var.value = data;
        if(var.rootType.contains('*'))
            insertRow(var,parent);
        else
            insertRow(var,parent);
    }

    return true;
}

///----------------------------------------------------------------------------
/// \brief
///----------------------------------------------------------------------------
void VariableView::stackItemClicked(QTreeWidgetItem *item,int col)
{
    Q_UNUSED(col);

    int frameNumber = item->data(0,Qt::UserRole+0).toInt();
    int lineNumber = item->data(0,Qt::UserRole+1).toInt();
    QString pathName = item->data(0,Qt::UserRole+2).toString();

    // update variable view to reflect this stack frame
    updateVariableView(frameNumber);

    // goto file & line number
    emit activateFile(pathName,lineNumber);
}

