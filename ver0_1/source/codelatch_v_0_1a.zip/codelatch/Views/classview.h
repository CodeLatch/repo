#ifndef CLASSVIEW_H
#define CLASSVIEW_H

#include <QWidget>
#include <QTreeWidget>
#include "indexer/indexer.h"

class Debug;
class Indexer;
class Project;


class ClassView : public QWidget
{
    Q_OBJECT

public:
    enum CLASS_DATA_ITEMS {
        PathName =          Qt::UserRole + 1,
        Line =              Qt::UserRole + 2,
        PrototypePathName = Qt::UserRole + 3,
        PrototypeLine =     Qt::UserRole + 4,
        Type =              Qt::UserRole + 5,
        EntryType =         Qt::UserRole + 6,
        LastLine =          Qt::UserRole + 7
    };
    enum CLASS_DATA_ENTRY_TYPES {
        Class =     0,
        Structure = 1,
        Union =     2,
        Variable =  3,
        Function =  4,
        Prototype = 5,
        Typedef =   6
    };

public:
    explicit ClassView(QWidget *parent = 0);
    ~ClassView();

    void updateClassView(Indexer *indexer);
    void updateOutlineView(Indexer *indexer, QString pathname);
    void clear() {if(treeView != NULL) treeView->clear();}

private:
    QTreeWidget *treeView;
    // used to restore the selection after re-populating the tree
    QString selectedItemKey;
    QTreeWidgetItem *restoreSelectedItem;

    void saveExpandedState(QStringList &list);
    void addExpandedChildrenToList(QTreeWidgetItem *item, QStringList &list);
    void restoreExpandedState(QStringList &list);
    void expandChildrenInList(QTreeWidgetItem *item, QStringList &list);


public slots:
    void updateWidths();

protected:

public slots:

signals:
    void treeItemClicked(QModelIndex index);
};

#endif // CLASSVIEW_H
