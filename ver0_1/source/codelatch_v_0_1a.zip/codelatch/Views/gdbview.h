#ifndef GDBVIEW_H
#define GDBVIEW_H

#include <QWidget>
#include "gdb/debugcontrol.h"

namespace Ui {
class GdbView;
}

class GdbView : public QWidget
{
    Q_OBJECT
    
public:
    explicit GdbView(QWidget *parent = 0);
    ~GdbView();
    void updateView(Debug *debug);

private slots:
    void on_pushButton_clicked();

    void on_toolButton_clicked();

private:
    Ui::GdbView *ui;

    Debug *debug;
};

#endif // GDBVIEW_H
