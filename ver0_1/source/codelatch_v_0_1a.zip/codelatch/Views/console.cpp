//!----------------------------------------------------------------------------
//! file: console.cpp
//!
//! Implements console view.
//! Signals and slots are utilzed in order to allow code running in threads
//! to make updates to the console (gui).
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "Views/console.h"
#include <QDebug>
#include <QAction>
#include "Views/findreplacewidget.h"
#include "mainwindow/mainwindow.h"
#include <QSplitter>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QToolBar>
#include "tabmanager.h"

// global declaration of the console.
Console *console;


Console::Console(QWidget *parent) :
    QWidget(parent)
{
    browser = new QTextBrowser(this);
    browser->setOpenLinks(false);
    browser->setReadOnly(true);
    browser->setLineWrapMode(QTextBrowser::NoWrap);

    connect(browser,SIGNAL(anchorClicked(QUrl)),this,SLOT(linkClicked(QUrl)));
    connect(this,SIGNAL(signalAppendConsoleText(QString,bool,QString)),this,SLOT(slotAppendConsoleText(QString,bool,QString)));
    connect(this,SIGNAL(signalAppendConsoleLink(QStringList)),this,SLOT(slotAppendConsoleLink(QStringList)));
    connect(this,SIGNAL(signalClear()),this,SLOT(slotClear()));

    QFont font;
    font.setFamily("Monaco");
    font.setFixedPitch(true);
    font.setPointSize(10);
    browser->setFont(font);

    QVBoxLayout *layout = new QVBoxLayout;
    QToolBar *toolbar = new QToolBar;
//    toolbar->setIconSize(QSize(12,12));
    toolbar->addAction(QIcon(":/icons/icons/clear_console.png"),"Clear console",this,SLOT(slotClear()));
    toolbar->setStyleSheet("QToolBar {spacing: 0px;} QToolButton { border-radius: 5px; border: none; }");
    toolbar->setMaximumHeight(16);
    layout->addWidget(toolbar);
    layout->addWidget(browser);
    layout->setSpacing(0);
    layout->setMargin(0);
    setLayout(layout);
}

Console::~Console()
{
    //    browser->deleteLater();
}

// color can be a word like blue, red, black, or a value like #ff0000
void Console::appendText(const QString &text, QString color)
{
    emit showConsole();
    emit signalAppendConsoleText(text,false,color);
}

void Console::appendLine(const QString &text, QString color)
{
    emit showConsole();
    emit signalAppendConsoleText(text,true,color);
}

void Console::appendLink(const QStringList &list)
{
    emit showConsole();
    emit signalAppendConsoleLink(list);
}

void Console::clear()
{
    emit signalClear();
}

void Console::privateAppendText(const QString &text, bool linefeed, QString color)
{
    QTextCursor cursor;
    QString newText(text);
    if(newText.isEmpty()) return;
    newText = newText.replace(QString("\t"),QString("&nbsp;&nbsp;&nbsp;&nbsp;"));
    newText = newText.replace(QString(" "),QString("&nbsp;"));

    cursor = browser->textCursor();
    cursor.movePosition(QTextCursor::End);
    browser->setTextCursor(cursor);
    //{background-color: black; color: white}
    QString startHtml = "<font color=\""+color+"\">";
    QString endHtml = "</font>";
    if(linefeed)
        endHtml += "<br>";
    browser->insertHtml(startHtml+newText+endHtml);

    cursor = browser->textCursor();
    cursor.movePosition(QTextCursor::End);
    browser->setTextCursor(cursor);
}

void Console::privateAppendLink(const QStringList &list)
{
    if(list.size() != 5) return;
    QString text = list.at(0);
    QString filepath = list.at(1);
    QString projectFolder = list.at(2);
    QString projectName = list.at(3);
    QString lineNumber = list.at(4);

    QTextCursor cursor;
    cursor = browser->textCursor();
    cursor.movePosition(QTextCursor::End);
    browser->setTextCursor(cursor);

    QString str("<a href = \""+filepath+"*"+projectFolder+"*"+projectName+"*"+lineNumber+"\">"+text+"</a> ");
    browser->insertHtml(str);

    cursor = browser->textCursor();
    cursor.movePosition(QTextCursor::End);
    browser->setTextCursor(cursor);
}


void Console::slotAppendConsoleText(const QString text, const bool linefeed, const QString color)
{
    privateAppendText(text,linefeed,color);
}
void Console::slotAppendConsoleLink(const QStringList list)
{
    privateAppendLink(list);
}
void Console::slotClear()
{
    browser->clear();
}

void Console::btnClearPressed()
{
    clear();
}

void Console::btnMinimizePressed()
{
    qDebug()<<"button 2";
}

void Console::btnMaximizePressed()
{
    qDebug()<<"button 3";
}

//!----------------------------------------------------------------------------
//! \brief SLOT
//!          Html file link was clicked in Console.
//!----------------------------------------------------------------------------
void Console::linkClicked(QUrl url)
{
    QString str = url.toString();

    // url was formatted like this: pathname*projectFolder*projectName*lineNumber
    QStringList strlist = str.split("*");
    if(strlist.size() != 4) return;

    QString pathname = strlist.at(0);
  //  QString projectFolder = strlist.at(1);
  //  QString projectName = strlist.at(2);
    QString lineNumber = strlist.at(3);
    int line = lineNumber.toInt();

    if(!line) return;

    emit signalOpenEditor(pathname,line);
}

