//!----------------------------------------------------------------------------
//! file: classview.cpp
//!
//! Implements class view. This is the top level project view that shows
//! everything in the project.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "classview.h"
#include <QGridLayout>
#include <QDebug>
#include <QContextMenuEvent>
#include "project/project.h"

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
ClassView::ClassView(QWidget *parent)
{
    Q_UNUSED(parent); // unused param

    treeView = new QTreeWidget(this);

    // initialize tree
    QTreeWidgetItem *headerItem = new QTreeWidgetItem;
    headerItem->setText(0,QString("Class View"));
    // mem manage note: setHeaderItem makes this class parent of headerItem
    treeView->setHeaderItem(headerItem);
    treeView->setHeaderHidden( true );
    treeView->setAnimated( true );

    connect(treeView,SIGNAL(expanded(QModelIndex)),this,SLOT(updateWidths()));
    connect(treeView,SIGNAL(collapsed(QModelIndex)),this,SLOT(updateWidths()));
    connect(treeView,SIGNAL(clicked(QModelIndex)),this,SIGNAL(treeItemClicked(QModelIndex)));

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(treeView);
    layout->setSpacing(0);
    layout->setMargin(0);
    setLayout(layout);

}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
ClassView::~ClassView()
{

}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void ClassView::updateClassView(Indexer *indexer)
{
    QStringList list;

    saveExpandedState(list);

    treeView->clear();
    if(indexer == NULL) return;
    indexer->populateTree(treeView);

    restoreExpandedState(list);
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void ClassView::updateOutlineView(Indexer *indexer, QString pathname)
{
    QStringList list;

    saveExpandedState(list);

    treeView->clear();
    if(indexer == NULL) return;
    indexer->populateTree(treeView,pathname);

    restoreExpandedState(list);
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void ClassView::saveExpandedState(QStringList &list)
{
    // save currently selected item
    QTreeWidgetItem *selectedItem = treeView->currentItem();
    if(selectedItem != NULL)
    {
        QString itemType = selectedItem->data(0,ClassView::EntryType).toString();
        QString itemPath = selectedItem->data(0,ClassView::PathName).toString();
        QString itemName = selectedItem->text(0);
        selectedItemKey = itemType + itemPath + itemName;
    }

    // create a list of pathnames of all tree items that are expanded
    // so we can restore them to expanded after we re-load the tree.
    int n = treeView->topLevelItemCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *item = treeView->topLevelItem(i);
        if(item == NULL) continue;
        if(item->isExpanded())
        {
            QString itemType = item->data(0,ClassView::EntryType).toString();
            QString itemPath = item->data(0,ClassView::PathName).toString();
            QString itemName = item->text(0);
            QString key = itemType + itemPath + itemName;
            list.append(key);
            if(item->childCount() > 0)
                addExpandedChildrenToList(item,list);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void ClassView::addExpandedChildrenToList(QTreeWidgetItem *item, QStringList &list)
{
    if(item == NULL) return;
    int n = item->childCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *child = item->child(i);
        if(child == NULL) continue;
        if(child->isExpanded())
        {
            QString itemType = child->data(0,ClassView::EntryType).toString();
            QString itemPath = child->data(0,ClassView::PathName).toString();
            QString itemName = child->text(0);
            QString key = itemType + itemPath + itemName;
            list.append(key);
            if(child->childCount() > 0)
                addExpandedChildrenToList(child,list);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief  Restores the expanded state of items and the selected item
//!         after re-populating the tree.
//!-----------------------------------------------------------------------------
void ClassView::restoreExpandedState(QStringList &list)
{
    restoreSelectedItem = NULL;
    int n = treeView->topLevelItemCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *item = treeView->topLevelItem(i);
        QString itemType = item->data(0,ClassView::EntryType).toString();
        QString itemPath = item->data(0,ClassView::PathName).toString();
        QString itemName = item->text(0);
        QString key = itemType + itemPath + itemName;
        if((key == selectedItemKey) && !key.isEmpty())
            restoreSelectedItem = item;
        if(list.contains(key))
        {
            item->setExpanded(true);
            if(item->childCount() > 0)
                expandChildrenInList(item,list);
        }
    }
    if(restoreSelectedItem != NULL)
    {
        treeView->setCurrentItem(restoreSelectedItem);
        restoreSelectedItem->setSelected(true);
        treeView->scrollToItem(restoreSelectedItem);
    }
}

//!-----------------------------------------------------------------------------
//! \brief   Expands tree item children that are in a list, if found.
//!-----------------------------------------------------------------------------
void ClassView::expandChildrenInList(QTreeWidgetItem *item, QStringList &list)
{
    int n = item->childCount();
    for(int i=0;i<n;i++)
    {
        QTreeWidgetItem *child = item->child(i);
        QString itemType = child->data(0,ClassView::EntryType).toString();
        QString itemPath = child->data(0,ClassView::PathName).toString();
        QString itemName = child->text(0);
        QString key = itemType + itemPath + itemName;
        if((key == selectedItemKey) && !key.isEmpty())
            restoreSelectedItem = child;
        if(list.contains(key))
        {
            child->setExpanded(true);
            if(child->childCount() > 0)
                expandChildrenInList(child,list);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief
//!-----------------------------------------------------------------------------
void ClassView::updateWidths()
{
    for (int column = 0; column < treeView->model()->columnCount(); ++column)
        treeView->resizeColumnToContents(column);
}

