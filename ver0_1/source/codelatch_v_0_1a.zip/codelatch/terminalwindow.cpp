//!----------------------------------------------------------------------------
//! file: terminalwindow.cpp
//!
//! Hid terminal implementation. Creates a window that allows the user to send
//! and receive text to a hid device operating with a specific pid and vid.
//! Utilizes external command line process hidserver. hidserver is a tcp server
//! interface to a hid device. We always send and receive data to hidserver
//! in 64 byte packets.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "terminalwindow.h"
#include <QtGui>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QComboBox>
#include <QTextEdit>
#include <QPushButton>
#include <QCheckBox>
#include <QLabel>
#include <QPixmap>
#include <QSizePolicy>
#include <QDebug>
#include <QtConcurrent/QtConcurrent>
#include <QFuture>
#include <QStatusBar>
#include <QIcon>
#include <QStatusBar>
#include <devicemonitor.h>
#include <QHostAddress>
#include "utility/fileutility.h"
#include "programconfig.h"

#if defined Q_OS_MAC
#elif defined Q_OS_UNIX
#include <signal.h>
#endif

// default VID and PID
#define VID     0x0925
#define PID     0x7002

//!----------------------------------------------------------------------------
//! \brief  Delay for a given number of milliseconds.
//!----------------------------------------------------------------------------
#ifdef Q_OS_WIN
#include <windows.h> // for Sleep
#endif
void sleep_ms(int ms)
{
    if(ms <= 0) return;

#ifdef Q_OS_WIN
    Sleep(uint(ms));
#else
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000 * 1000 };
    nanosleep(&ts, NULL);
#endif
}

//!----------------------------------------------------------------------------
//! \brief  Constructor. Builds the window, but doesn't make it visible.
//!----------------------------------------------------------------------------
TerminalWindow::TerminalWindow(QWidget *parent) :
    QMainWindow(parent)
{
    QHBoxLayout *layout1 = new QHBoxLayout;
    sendButton = new QPushButton("Send");
    sendLineEdit = new QLineEdit;
    layout1->addWidget(sendButton);
    layout1->addWidget(sendLineEdit);

    QHBoxLayout *layout2 = new QHBoxLayout;
    QPushButton *clearButton = new QPushButton("Clear");
    clearButton->setSizePolicy( QSizePolicy::Fixed, QSizePolicy::Fixed);
    checkBox = new QCheckBox("Scroll to end");
    checkBox->setSizePolicy( QSizePolicy::Fixed, QSizePolicy::Fixed);
    checkBox->setChecked(true);
    QLabel *label = new QLabel("Device ID");
    label->setSizePolicy( QSizePolicy::Fixed, QSizePolicy::Fixed);
    combo = new QComboBox;
    combo->setSizePolicy( QSizePolicy::Fixed, QSizePolicy::Fixed);
    combo->setMinimumContentsLength(20);

    layout2->addWidget(clearButton);
    layout2->addSpacing(10);
    layout2->addWidget(checkBox);
    layout2->addSpacing(20);
    layout2->addWidget(label);
    layout2->addWidget(combo);
    layout2->setAlignment(Qt::AlignLeft);

    QVBoxLayout *layout3 = new QVBoxLayout;
    rxTextEdit = new QTextEdit;
    rxTextEdit->setReadOnly(true);
    layout3->addLayout(layout1);
    layout3->addLayout(layout2);
    layout3->addWidget(rxTextEdit);

    layout3->setContentsMargins(13,13,13,0);

    QWidget *widget = new QWidget;
    widget->setLayout(layout3);
    setCentralWidget(widget);

    setWindowTitle(tr("Terminal"));

    QFont font = statusBar()->font();
    font.setPointSize(10);
    statusBar()->setFont(font);
    statusBar()->showMessage("not connected");

    sendButton->setEnabled(false);
    connected = false;

    scrollToEnd = checkBox->isChecked();

    connect(sendButton,SIGNAL(clicked()),this,SLOT(sendButtonPressed()));
    connect(clearButton,SIGNAL(clicked()),this,SLOT(clearButtonPressed()));
    connect(checkBox,SIGNAL(clicked()),this,SLOT(scrollToEndCheckBoxPressed()));
    connect(combo,SIGNAL(currentIndexChanged(QString)),this,SLOT(comboSelectionChanged(QString)));
    connect(this,SIGNAL(updateRx(QString)),this,SLOT(setRxText(QString)));
    connect(this,SIGNAL(updateStatus(bool)),this,SLOT(setStatus(bool)));

    // keep terminal window always on top
//    Qt::WindowFlags flags = windowFlags();
//    setWindowFlags(flags | Qt::CustomizeWindowHint | Qt::WindowStaysOnTopHint | Qt::Window);

    server = NULL;
    socket = NULL;
    deviceMonitor = new DeviceMonitor(this);
    connect(deviceMonitor,SIGNAL(deviceAttached(QString)),this,SLOT(deviceAttached(QString)));
    connect(deviceMonitor,SIGNAL(deviceRemoved(QString)),this,SLOT(deviceRemoved(QString)));
    deviceMonitor->start(VID,PID);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
TerminalWindow::~TerminalWindow()
{
}

//!----------------------------------------------------------------------------
//! \brief  Slot called when send button is pressed. Sends text to hid.
//!----------------------------------------------------------------------------
void TerminalWindow::sendButtonPressed()
{
#ifdef Q_OS_WIN
    QString str = sendLineEdit->text();
    int n = str.length();
    if(n > 63) n = 63;
    QByteArray text = str.toLocal8Bit();
    char buf[65];
    memset(buf,0,65);
    memcpy(buf+1,text,text.length());
    if(socket)
        socket->write(buf,65);
#else // mac/linux
    QString str = sendLineEdit->text();
    if(str.length() > 63)
        str = str.left(63);
    if(socket)
        socket->write(str.toLocal8Bit(),64);
#endif
}

//!----------------------------------------------------------------------------
//! \brief  Slot called when clear button is pressed. Clears the receive display.
//!----------------------------------------------------------------------------
void TerminalWindow::clearButtonPressed()
{
    rxTextEdit->clear();
}

//!----------------------------------------------------------------------------
//! \brief  Slot called when scroll to end check box is changed.
//!----------------------------------------------------------------------------
void TerminalWindow::scrollToEndCheckBoxPressed()
{
    scrollToEnd = checkBox->isChecked();
}

//!----------------------------------------------------------------------------
//! \brief  Slot called when combo box selection is changed.
//!----------------------------------------------------------------------------
void TerminalWindow::comboSelectionChanged(QString location)
{
    qDebug() << "TerminalWindow::comboSelectionChanged:" << location;

    if(server)
    {
        server->deleteLater();
        server = NULL;
    }
    if(socket)
    {
        socket->deleteLater();
        socket = NULL;
    }

    port = getFreePort();
    qDebug() << "port:" << port;
    server = new QProcess(this);
    connect(server,SIGNAL(readyRead()),this,SLOT(serverReadyRead()));
    connect(server,SIGNAL(finished(int)),this,SLOT(serverFinished(int)));
    QString cmd;
    // modified for win version 10/20/2013
#ifdef Q_OS_WIN
    cmd = FileUtility::getDirTools() + "/hidserver.exe";
    cmd += " " + QString::number(port);
    qDebug() << "terminal cmd:" << cmd;
    server->start(cmd);
#else
    cmd = FileUtility::getDirTools() + "/hidserver";
    QStringList args;
    args << QString::number(port);
    server->start(cmd,args);
#endif

    QProcess::ProcessError error = server->error();
    if(error != QProcess::UnknownError)
    {
        qDebug() << "hidserver startup error:" << error;
        return;
    }

    if(!server->waitForStarted(1000))
    {
        qDebug() << "error starting server";
        server->deleteLater();
        server = NULL;
        return;
    }
    // wait until the process has written a line of text.
    // this will indicate that the server either started or failed to start.
    bool ret = server->waitForReadyRead(1000);
    qDebug() << "waitForReadyRead:"<< ret << ":" << QString(server->readAll());

    socket = new QTcpSocket(this);
    connect(socket, SIGNAL(readyRead()), this, SLOT(packetReceived()));
    socket->connectToHost(QHostAddress::LocalHost,port);

    emit updateStatus(true);
}

void TerminalWindow::serverReadyRead()
{
//    qDebug() << "serverReadyRead:" << QString(server->readAll());
}

//!----------------------------------------------------------------------------
//! \brief  Slot called when QProcess *server closes.
//!----------------------------------------------------------------------------
void TerminalWindow::serverFinished(int retvalue)
{
    qDebug() << "server finished:" << retvalue;
    if(server)
    {
        server->deleteLater();
        server = NULL;
    }
    if(socket)
    {
        socket->deleteLater();
        socket = NULL;
    }
    emit updateStatus(false);
}

//!----------------------------------------------------------------------------
//! \brief  Slot called when updateRx signal is emitted. Adds text to receive
//!         display. Updates scroll position to the bottom if scrollToEnd is set.
//!----------------------------------------------------------------------------
void TerminalWindow::setRxText(QString text)
{
    text = text.remove('\r');
    if(text.isEmpty()) return;
    if(rxTextEdit == NULL) return;

    QTextCursor cursor = rxTextEdit->textCursor();
    cursor.movePosition(QTextCursor::End);
    cursor.insertText(text);

    if(scrollToEnd)
        rxTextEdit->setTextCursor(cursor);
}

//!----------------------------------------------------------------------------
//! \brief  Slot called when to update connected status message.
//!----------------------------------------------------------------------------
void TerminalWindow::setStatus(bool connected)
{
    if(!statusBar()) return;
    if(!sendButton) return;

    if(connected)
    {
        statusBar()->showMessage("connected");
        sendButton->setEnabled(true);
    }
    else
    {
        statusBar()->showMessage("not connected");
        sendButton->setEnabled(false);
    }
    this->connected = connected;
}

//!----------------------------------------------------------------------------
//! \brief  Override called when the user closes the terminal. This doesn't
//! destroy the terminal, it just hides the window. We call deleteLater
//! at the end to force deletion.
//!----------------------------------------------------------------------------
void TerminalWindow::closeEvent(QCloseEvent *event)
{
    QRect rect(geometry());
    ProgramConfig::set(TERMINAL_WINDOW_GEOMETRY,rect);
    ProgramConfig::save();

    if(socket)
    {
        socket->disconnectFromHost();
        socket->deleteLater();
        socket = NULL;
    }
    if(server)
    {
        Q_PID pid = server->pid();
#ifdef Q_OS_WIN
    GenerateConsoleCtrlEvent(CTRL_C_EVENT   ,pid->dwProcessId);
#else
    kill(pid,SIGINT);
#endif
        server->waitForFinished(100);
        // if the server doesn't close it will get deleted
        // anyway when we call this->deleteLater because it's a child.
    }
    emit TerminalClosing();
    event->accept();
    this->deleteLater();
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TerminalWindow::packetReceived()
{
    static int cnt = 0;
    cnt++;

    if(cnt%200 == 0) qDebug() << "rx cnt:" << cnt;

    QString text;
    if(socket)
    {
        QByteArray ba = socket->read(64);
        text = QString(ba);
    }

    if(isVisible() && !text.isEmpty())
    {
        emit updateRx(text);
    }
    else
    {

    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TerminalWindow::deviceAttached(QString location)
{
    // if the device is not in the current device list, add it and update the combo box.
    if(!deviceList.contains(location))
    {
        deviceList.append(location);
        combo->blockSignals(true);
        combo->clear();
        combo->addItems(deviceList);
        combo->blockSignals(false);
    }
    // if the device combo has no current selection select this device,
    // this will cause the device to be opened via combo selection change event.
    QString sel = combo->currentText();
    if(sel.isEmpty())
        combo->setCurrentText(location);
    else
    {
        // if the server is closed and the device attached matches the combo selection then start it.
        if((server==NULL) && (location == sel))
            comboSelectionChanged(location);
    }
    qDebug() << "TerminalWindow::deviceAttached:" << location;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void TerminalWindow::deviceRemoved(QString location)
{
    if(combo->currentText() == location)
    {
        if(server)
        {
            server->deleteLater();
            server = NULL;
        }
        if(socket)
        {
            server->deleteLater();
            server = NULL;
        }
        emit updateStatus(false);
    }

    qDebug() << "TerminalWindow::deviceRemoved:" << location;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int TerminalWindow::getFreePort()
{
    //    QUdpSocket socket = new QUdpSocket(this);
    QTcpSocket s;
    // bind with port=0 causes the socket to select a free port.
    // we can then query for the port number.
    s.bind();
    int portnum = s.localPort();
    s.close();
    return portnum;
}





