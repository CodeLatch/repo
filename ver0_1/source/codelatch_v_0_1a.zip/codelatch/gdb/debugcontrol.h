#ifndef DEBUG_H
#define DEBUG_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QProcess>
#include <QFuture>
#include <QEventLoop>
#include <gdb/gdbcontrol.h>

class Project;
class VariablesView;
class ConsoleProcess;

class Debug : public QObject
{
    Q_OBJECT

public:
    explicit Debug(QObject *parent = 0);
    bool start(Project *project);
    bool close();

    bool run();
    bool pause();
    bool stepInto();
    bool stepOver();
    bool stepReturn();
    bool setStepMode(bool istep);
    bool getStepMode() {return stepMode;}

    bool getSourceInfo(QString *pathname, QString *function, int *lineNumber);

    bool getRegisters(QStringList *names, QStringList *values);
    QString getLocals(void);
    QString getArgs(void);
    QString getVariableType(QString name);
    bool writeVariable(QString name, QString value);
    QStringList getAssembly();
    bool writeRegister(QString name, quint32 val);
    QStringList readMemory(uint32_t start, int numwords);
    bool writeMemory(uint32_t address, uint32_t data);
    uint32_t getVariableAddress(QString name, bool *ok);
    QStringList sendCommand(QString cmd, int timeout_ms = 250);
    QList<DebugFrame> getStackFrames();
    int getCurrentThraedNumber();
    QString getVariables(int threadId, int frameNumber) {return gdb->getVariables(threadId,frameNumber);}
    QStringList getGlobalVariableNames() {return gdb->getGlobalVariableNames();}
    Project *getProject() {return prj;}
    QString evaluateExpression(QString expression) {return gdb->evaluateExpression(expression);}

//private:
    bool startServer(Project *project, int port);

signals:
    void signalGdbAtPrompt();
    void finished();

public slots:
    void slotGdbAtPrompt();
    bool addBreakPoint(QString pathname,int line);
    bool removeBreakPoint(QString pathname, int line);

private slots:
    void serverTerminated(int returncode);
    void serverReadyRead();
    void gdbErrorOccurred();

protected:

    bool stepMode;
    int lastCommand;
    QProcess *server;
//    ConsoleProcess *server;
    GdbControl *gdb;
    Project *prj;

    enum DebugCommands {
        None = 0,
        Resume = 1,
        StepInto = 2,
        StepOver = 3,
        StepReturn = 4,
        Suspend = 5
    };
};

#endif // DEBUG_H
