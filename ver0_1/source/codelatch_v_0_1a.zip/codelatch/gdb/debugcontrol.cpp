//!----------------------------------------------------------------------------
//! file: debugcontrol.cpp
//!
//! Implements the debug interface. This class is what the main ide code interacts with.
//! Calling start(Project*) will launch arm-none-eabi-gdb and gdbserver and
//! initialize each.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------


#include "gdb/debugcontrol.h"
#include "gdb/gdbcontrol.h"
#include "project/project.h"
#include "utility/fileutility.h"
#include <QFileInfo>
#include <QTimer>
#include <QThread>
#include "target.h"
#include <QMessageBox>
#include "signal.h"
#include "terminalwindow.h"
#include "consoleprocess.h"
#ifdef Q_OS_WIN
#include <windows.h>
#include <wincon.h>  // for sending signals
#endif
/*
    arm-none-eabi-gdb -q --interpreter=mi

SEND:-thread-info
^done,threads=[{id="1",target-id="Thread <main>",frame={level="0",addr="0x08000144",func="sub3",args=[{name="a",value="0x2a"}],file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="10"},state="stopped"}],current-thread-id="1"
(gdb)

SEND:-stack-list-variables --thread 1 --frame 3 --all-values
^done,variables=[{name="i",value="0x7"}]
(gdb)

SEND:-stack-list-frames
^done,stack=[frame={level="0",addr="0x08000142",func="main",file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="8"}]
(gdb)

SEND:-stack-list-variables --thread 1 --frame 0 --all-values
^done,variables=[{name="n",value="0x20000158"},{name="a",arg="1",value="0x2a"}]
(gdb)

SEND:-stack-list-frames
^done,stack=[frame={level="0",addr="0x08002084",func="delay",file="lib/stm32f10x/stm32f10x_lib/lib/src/timer.cpp",fullname="/Users/johnmaloney/Desktop/dev/lib/stm32f10x/stm32f10x_lib/lib/src/timer.cpp",line="76"},frame={level="1",addr="0x080001a8",func="main",file="projects/01-basic/blink led/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/projects/01-Basic/Blink Led/main.cpp",line="20"}]
(gdb)

     (gdb)
     -stack-list-variables --thread 1 --frame 0 --all-values
     ^done,variables=[{name="x",value="11"},{name="s",value="{a = 1, b = 2}"}]
     (gdb)

SEND:info variables
&"info variables\n"
~"All defined variables:\n"
~"\nFile "
~"lib/target-headers/olimexino-stm32/target-pins.c:\n"
~"unsigned short GPIO_PIN_MAP[65];\n"
~"GPIO_TypeDef *GPIO_PORTS[4];\n"
~"unsigned char GPIO_PORT_MAP[65];\n"
~"signed char TABLE_ADCChannel[22];\n"
~"TIM_TypeDef *TABLE_Timer[8];\n"
~"unsigned char TABLE_pinTimer[16];\n"
~"unsigned char TABLE_pinTimerChannel[16];\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/lib/src/pin.cpp:\n"
~"CPin Pin;\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/cmsis/src/stm32f10x_rcc.c:\n"
~"static unsigned char ADCPrescTable[4];\n"
~"static unsigned char APBAHBPrescTable[16];\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/cmsis/src/system_stm32f10x.c:\n"
~"unsigned char AHBPrescTable[16];\n"
~"uint32_t SystemCoreClock;\n"
~"\nFile "
~"lib/stm32f10x/stm32f10x_lib/cmsis/src/stm32f10x_it.c:\n"
~"volatile u32 systicks;\n"
~"\nFile "
~"projects/01-basic/blink led/main.cpp:\n"
~"int global1;\n"
~"int global2;\n"
~"\nFile "
~"/users/johnmaloney/desktop/dev/lib/stm32f10x/stm32f10x_startup/startup_stm32f10x.c:\n"
~"static void (*g_pfnVectors[67])(void);\n"
~"\nNon-debugging symbols:\n"
~"0x0800241c  __frame_dummy_init_array_entry\n"
~"0x0800241c  __init_array_start\n"
~"0x0800241c  __preinit_array_end\n"
~"0x0800241c  __preinit_array_start\n"
~"0x08002424  __do_global_dtors_aux_fini_array_entry\n"
~"0x08002424  __init_array_end\n"
~"0x2000003c  APBAHBPrescTable\n"
~"0x2000004c  ADCPrescTable\n"
~"0x20000064  impure_data\n"
~"0x20000154  _impure_ptr\n"
~"0x20000158  __JCR_END__\n"
~"0x20000158  __JCR_LIST__\n"
~"0x2000015c  _sbss\n"
~"0x2000015c  completed.3246\n"
~"0x20000168  _ebss\n"
^done
(gdb)


*/

Debug::Debug(QObject *parent) :
    QObject(parent)
{
    server = NULL;
    gdb = NULL;
    stepMode = false; // machine code stepping off
    lastCommand = Debug::None;
}

void Debug::serverTerminated(int returncode)
{
    //    Q_UNUSED(returncode);

    qDebug() << "**** GDBSERVER TERMINATED *****:" << returncode;
    if(server)
    {
        qDebug() << "server has not been deleted, deleting now.";
        server->deleteLater();
        server = NULL;
    }

    // TODO: need to deal with unexpected termination
    console->appendLine("gdbserver terminated.");
    emit finished();
}

bool Debug::startServer(Project *project, int port)
{
    Q_UNUSED(port);

    if(project == NULL) return false;
    Target target = project->getTarget();

    if(server != NULL)
    {
        if(server->isOpen())
            server->kill();
        server->deleteLater();
    }
    server = new QProcess(this);
    connect(server,SIGNAL(finished(int)),this,SLOT(serverTerminated(int)));
    //    connect(server,SIGNAL(readyRead()),this,SLOT(serverReadyRead()));
    connect(server,SIGNAL(readyReadStandardOutput()),this,SLOT(serverReadyRead()));
    connect(server,SIGNAL(readyReadStandardError()),this,SLOT(serverReadyRead()));

    QString cmd = target.getGdbServerTool();
/*#ifdef Q_OS_WIN
    cmd += ".exe";
#endif
*/
    /*    QString args = target.getGdbServerArgs();
//    int port = TerminalWindow::getFreePort();
    args.replace("${port}",QString::number(port));
    QStringList argList;
    argList << args;

    server->start(cmd,argList);
*/
    //    cmd += " 2525";
//    qDebug() << "starting server cmd:" << cmd;
/*    QStringList args;
    QString portArg = "-p" + QString::number(port);
    args << portArg;
*/    QFileInfo info(cmd);
    if(!info.exists())
        qDebug() << "error: cmd doesn't exist";

    QString serverArg = target.getGdbServerArgs();
    serverArg.replace("${port}",QString::number(port));
    QStringList args;
    args << serverArg;

    server->start(cmd,args);
/*    QProcess::ProcessError error = server->error();
    if(error != QProcess::UnknownError)
    {
        qDebug() << "gdbserver startup error:" << error;
    }
*/    if(!server->waitForStarted(500))
    {
        // server didn't start show error and bail
        QMessageBox::critical(NULL, "Debug","Unable to start gdbserver, check config.");
        return false;
    }
    // the server will end quickly if it can't connect to the debug probe.
    if(server->waitForFinished(200))
    {
        QMessageBox::critical(NULL, "Debug","Unable to connect to target");
        return false;
    }
/*
    if(!server->isOpen())
    {
        qDebug() << "error: server is not open";
        return false;
    }
    if(!server->isReadable())
    {
        qDebug() << "error: server is not readable";
        return false;
    }

    Q_PID pid = server->pid();
    qDebug() << "server pid:" << pid;
*/
    return true;
}

bool Debug::start(Project *project)
{
    if(project == NULL)
    {
        QMessageBox::critical(NULL, "Debug","Project is NULL.");
        return false;
    }

    // int port = 2525;
    int port = TerminalWindow::getFreePort();

    // start server
    if(!startServer(project,port))
        return false;

    Target target = project->getTarget();


    // start gdb
    //    if(gdb != NULL)
    //        gdb->deleteLater();
    gdb = new GdbControl(this);
    connect(gdb,SIGNAL(gdbErrorOccurred()),this,SLOT(gdbErrorOccurred()));

    if(!gdb->start(project))
    {
        QMessageBox::critical(NULL, "Debug","Unable to start gdb.");
        return false;
    }

    // connect to target
    if(!gdb->connectToTarget(port,2000))
    {
        QMessageBox::critical(NULL, "Debug","Unable to connect to target.");
        return false;
    }

    // the server might bail out at this point because it will quit if it
    // can't connect to the probe.
    qDebug() << "post connectToTarget";
    QTimer timer;
    QEventLoop eloop;
    connect(&timer,SIGNAL(timeout()),&eloop,SLOT(quit()));
    timer.start(300);
    eloop.exec();
    if(!server)
    {
        qDebug() << "server has been destroyed, exiting.";
        return false;
    }

    // send startup commands
    QStringList list = target.getGdbStartupCmds();
    foreach(QString s,list)
    {
        s = s.trimmed();
        if(!s.startsWith('#'))
        {
            if(!gdb->send(s+"\n"))
            {
                QMessageBox::critical(NULL, "Debug","Error sending startup command:" + s);
                return false;
            }
        }
    }

    // set breakpoint at main

    // -break-insert main
    // ^done,bkpt={number="1",type="breakpoint",disp="keep",enabled="y",addr="0x080001d8",func="main",file="/users/johnmaloney/desktop/dev/build-codelatchdebug/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/projects/stm32_aread_blink/main.cpp",line="36",times="0",original-location="main"}
    // (gdb)
    if(!gdb->send("-break-insert main\n",1000))
    {
        QMessageBox::critical(NULL, "Debug","Unable to set breakpoint at main().");
        return false;
    }
    // run to first line in main

    // -exec-continue
    // ^running
    // *running,thread-id="all"
    // (gdb)
    // *stopped,reason="breakpoint-hit",disp="keep",bkptno="1",frame={addr="0x080001d8",func="main",args=[],file="/users/johnmaloney/desktop/dev/build-codelatchdebug/projects/stm32_aread_blink/main.cpp",fullname="/Users/johnmaloney/Desktop/dev/build-codelatchDebug/projects/stm32_aread_blink/main.cpp",line="36"},thread-id="1",stopped-threads="all"
    // (gdb)
    //
    // note: the first prompt reached indicates that the command -exec-continue finished, the second
    // prompt reached indicates the program has stopped
    if(!gdb->send("-exec-continue\n",1000))
    {
        QMessageBox::critical(NULL, "Debug","Unable to run. Try rebuilding and downloading. If that doesn't work try an example program.");
        return false;
    }

    if(!gdb->waitForTargetStop(1000))
    {
        QMessageBox::critical(NULL, "Debug","Program didn't reach main within time alotted.");
        return false;
    }

    // we should now be at our breakpoint in the first line in main
    // remove the breakpoint
    if(!gdb->send("-break-delete\n"))
    {
        QMessageBox::critical(NULL, "Debug","Unable to remove main() breakpoint.");
        return false;
    }
    // this connection must be a queued connection.
    connect(gdb,SIGNAL(signalAtPrompt()),this,SIGNAL(signalGdbAtPrompt()),Qt::QueuedConnection);

    qDebug() << "end Debug::start\n";
    prj = project;

    return true;
}

void Debug::serverReadyRead()
{
    if(server == NULL) return;
    //    QByteArray a = server->readAll();
    //    QString s(a);
    //    qDebug() << "gdbserver:" << a;

}

void Debug::gdbErrorOccurred()
{
    //    close();
    //    deleteLater();
}

bool Debug::close()
{
    qDebug() << "Debug::close\n";

    // terminate gdb
    if(gdb != NULL)
    {
        gdb->terminate();
        gdb->deleteLater();
        gdb = NULL;
    }

    // the server should close as a side effect of closing gdb, wait and make sure.
    if(server != NULL)
    {
        if(!server->waitForFinished(500))
        {
            server->kill();
            server->deleteLater();
            server = NULL;
        }
    }

    return true;
}

bool Debug::run()
{
    qDebug()<<"Debug::run\n";
    return gdb->send("-exec-continue\n");
}
bool Debug::pause()
{
    qDebug()<<"Debug::pause\n";

    if(gdb->sendBreak())
    {
        emit signalGdbAtPrompt();
        return true;
    }
    return false;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
bool Debug::stepOver()
{
    qDebug()<<"Debug::stepOver\n";
    bool ret;
    if(stepMode)
        ret = gdb->send("-exec-next-instruction\n");
    else
        ret = gdb->send("-exec-next\n");

    return ret;
}
bool Debug::stepInto()
{
    qDebug()<<"Debug::stepInto\n";
    bool ret;
    if(stepMode)
        ret = gdb->send("-exec-step-instruction\n");
    else
        ret = gdb->send("-exec-step\n");

    return ret;
}
bool Debug::stepReturn()
{
    qDebug()<<"Debug::stepReturn\n";
    // this can cause an error if we are in the main() function and
    // attempt a -exec-finish (re "not meaningful in the outermost frame.")
    // In that case attempt a continue.
    bool ret = gdb->send("-exec-finish\n");
    if(!ret)
        ret = run();
    return ret;
}
bool Debug::setStepMode(bool istep)
{
    stepMode = istep;
    return true;
}

bool Debug::getSourceInfo(QString *pathname, QString *function, int *lineNumber)
{
    qDebug()<<"Debug::getSourceInfo\n";
    bool ret = gdb->getSourceInfo(pathname,function, lineNumber);
    return ret;
}

bool Debug::addBreakPoint(QString pathname,int line)
{
    qDebug()<<"Debug::addBreakPoint\n";
    return gdb->addBreakPoint(pathname,line);
}

bool Debug::removeBreakPoint(QString pathname, int line)
{
    qDebug()<<"Debug::removeBreakPoint\n";
    return gdb->removeBreakPoint(pathname,line);
}

bool Debug::getRegisters(QStringList *names, QStringList *values)
{
    qDebug()<<"Debug::getRegisters\n";
    return gdb->readRegisters(names,values);
}

void Debug::slotGdbAtPrompt()
{
}

QString Debug::getLocals(void)
{
    qDebug()<<"Debug::getLocals";
    return gdb->getLocals();
}

QString Debug::getArgs(void)
{
    qDebug()<<"Debug::getArgs";
    return gdb->getArgs();
}

QString Debug::getVariableType(QString name)
{
    return gdb->getVariableType(name);
}

bool Debug::writeRegister(QString name, quint32 val)
{
    return gdb->writeRegister(name,val);
}

QStringList Debug::getAssembly()
{
    qDebug()<<"Debug::getAssembly";
    return gdb->getAssembly();
}

QStringList Debug::readMemory(uint32_t start, int numwords)
{
    return gdb->readMemory(start,numwords);
}

bool Debug::writeMemory(uint32_t address, uint32_t data)
{
    return gdb->writeMemory(address,data);
}

uint32_t Debug::getVariableAddress(QString name, bool *ok)
{
    return gdb->getVariableAddress(name,ok);
}

bool Debug::writeVariable(QString name, QString value)
{
    return gdb->writeVariable(name,value);
}

QList<DebugFrame> Debug::getStackFrames()
{
    return gdb->getStackFrames();
}

int Debug::getCurrentThraedNumber()
{
    return gdb->getCurrentThraedNumber();
}

QStringList Debug::sendCommand(QString cmd, int timeout_ms)
{
    bool ret = gdb->send(cmd,timeout_ms);
    if(ret == false)
        return QStringList();
    else
        return gdb->getReadList();
}
