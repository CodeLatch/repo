#ifndef SOURCEEDITOR_H
#define SOURCEEDITOR_H

#include <QWidget>
#include <QObject>
#include <QTextEdit>
#include "project/project.h"
#include <QTimer>
#include "ceditor.h"

class Completer;
class QStringListModel;
class QStandardItemModel;
class Indexer;
class Indexer;

//class QFuture<void>;
//class QFutureWatcher<void>;

class SourceEditor : public CodeEditor
//        class SourceEditor : public CppEdit
{
    Q_OBJECT

public:
    enum MarkerTypes {
        DebugMarker = 8
    };

public:
    SourceEditor(QWidget *parent = 0);

    void setCursorPosition(int line, int col);
    void setDocText(QString text);
    void loadColorScheme();

    void setMarginWidth(int margin, QString text);
    int lines();

    void markerAdd(int line, int type);
    bool markersAtLine(int line);
    int markerFindNext(int startLine, int mask);
    void markerDelete(int line, int mask);

    QString text();
    void getCursorPosition(int *row, int *col);
    bool isUndoAvailable();
    bool isRedoAvailable();

    void setFirstVisibleLine(int line);
    int getFirstVisibleLine();

    Indexer *getOutlineIndexer();


    void setPathname(const QString &pathname) {this->pathname = pathname;}
    QString getPathname() {return pathname;}
    void setProject(Project *project) {this->project = project;}
    Project* getProject() {return project;}
    QString getProjectFolder() {if(project == NULL) return QString(); else return project->getProjectFolder();}
    QString getProjectName() {if(project == NULL) return QString(); else return project->getName();}


protected:
    void keyPressEvent(QKeyEvent *event);

public slots:
    void slotDocumentWasModified();
    void slotUndoAvailable(bool);
    void slotRedoAvailable(bool);
    void updateIndexer();
    void completerKeyEvent(QKeyEvent event);
//    void popupItemClicked(QListWidgetItem *item);
//    void popupDestroyed();
    void jumpToCode();
    void formatSelection();
    void formatDocument();
    void slotReplaceAll(QString findString, QRegExp findExpr, bool isExpr, QString replaceString, bool caseSensitively=false, bool wholeWords=false);
    void outlineIndexingComplete();
    void autocompleteIndexingComplete();
    void setAutoFormat(bool state) {autoFormat = state;}

private slots:
    void insertCompletion(const QString &completion);
    void updateAutoComplete();
    void keypressTimeout();
    void formatAfterReturnPress(QKeyEvent *event);
    void slotCursorPositionChanged();
    void slotMarginPressed(int line, int x);
    void slotUpdateBreakpoints();

private:
//    bool format(QString &input, QString &output);
    void createWidgets();
    void createConnections();
//    QString textUnderCursor() const;
    void showAutoCompleteForPrefix(const QString &wordUnderCursor);
    bool handledCompletedAndSelected(QKeyEvent *event);
    void getStates(int pos, int &state, int &braceState, int &parenState, int &arrayState);

    QString getPrefixUnderCursor();
    QStringList getSeparators(const QString &prefix);
    QString updateLineage(QString str, QStringList lineage);
    QString getEntry(const QStringList &prefixList, const QStringList &varList);
    QString getStatementUnderCursor();
    QString getPreviousIndent(QTextCursor cursor);
    QString getPreviousParagraphForAutoformat(QString currentLine, QTextCursor cursor);
    QString getTailText(int splitType, QString paragraph, int n);

    // these functions handle bracket and parenthesis key presses
    // they will auto insert closing characters if it makes sense and
    // skip over key presses if it makes sense.
    void leftBracketPressed();
    void leftParenthesisPressed();
    void rightBracketPressed(QKeyEvent *event);
    void rightParenthesisPressed(QKeyEvent *event);

protected:

signals:
    void outlineIndexingFinished();
    void requestFileOpen(QString pathname,int linenumber,int col);
    void signalAddBreakpoint(QString pathname, int line);
    void signalRemoveBreakpoint(QString pathname, int line);

private:
    int timeToAutocompletePopup;
    bool bUndoAvailable;
    bool bRedoAvailable;
    bool isDirty;
    QTimer *keypressTimer;
    Completer *completer;
    bool autoFormat;
    bool autoIndent;
    int lastKeyPressed;

    // used for indexing
//    Indexer *outlineIndexer;
    Indexer *autoCompleteIndexer;
    QTimer indexingTimer;
    QString pathname;
    Project *project;

};



#endif // SOURCEEDITOR_H
