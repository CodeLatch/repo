#ifndef UPDATEDIALOG_H
#define UPDATEDIALOG_H

#include <QDialog>
#include <QEventLoop>
#include "downloader/filedownload.h"

// online location of the text file that lists where the zip files are stored online.
#define HTTP_CODELATCH_REPO_LIST "http://www.codelatch.com/repo/repolist.txt"

// these are the keys that are in the repolist file that preceed the corresponding online zip location.
#ifdef Q_OS_WIN
#define KEY_COMPILER_ZIP       "win/compiler.zip"
#define KEY_TOOLS_ZIP          "win/tools.zip"

#elif defined Q_OS_OSX
#define KEY_COMPILER_ZIP       "osx/compiler.zip"
#define KEY_TOOLS_ZIP          "osx/tools.zip"

#elif defined Q_OS_UNIX
#define KEY_COMPILER_ZIP       "linux/compiler.zip"
#if __x86_64__
#define KEY_TOOLS_ZIP          "linux64/tools.zip"
#else
#define KEY_TOOLS_ZIP          "linux/tools.zip"
#endif
#endif

#define KEY_DOC_ZIP             "doc.zip"
#define KEY_EXAMPLES_ZIP        "examples.zip"
#define KEY_LIB_ZIP             "lib.zip"
#define KEY_TARGETS_ZIP         "targets.zip"


namespace Ui {
class UpdateDialog;
}

class ComponentDownloadDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ComponentDownloadDialog(QWidget *parent = 0);
    ~ComponentDownloadDialog();

signals:
    void updateMenus();
    void selectHomeFolder();

private:
    Ui::UpdateDialog *ui;
    FileDownload fileDownload;
    QEventLoop eventLoop;

    void scanLocalDirectory();
    void download(const QMap<QString, QString> &map, const QString &key);
    QStringList downloadedFileList;

private slots:

    void slotFileDownloadStarting(QString filepath);
    void slotFileDownloadComplete(QString filepath, FILEDOWNLOAD_RESULT result);
    void slotDownloadsFinished();
    void slotDownloadProgress(QString filepath, qint64 value, qint64 total);

    void on_cbAllComponents_clicked();
    void on_cbCompiler_clicked();
    void on_cbLibraries_clicked();
    void on_cbExamples_clicked();
    void on_buttonStart_clicked();
    void on_buttonCancel_clicked();
    void on_cbTools_clicked();
    void on_cbTargets_clicked();
    void on_cbDocs_clicked();
    void unzipDownloads();
};

#endif // UPDATEDIALOG_H
