//!----------------------------------------------------------------------------
//! file: mainwindow.cpp
//!
//! Implements the main window. This is the central widget and the heart
//! of program control.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

/*
  NOTE: you can use this to monitor a file system for changes.

    QFileSystemModel *model = new QFileSystemModel;

*/


#include <QtGui>
#include "mainwindow.h"
#include "programconfig.h"
#include <QDebug>
#include <QStatusBar>
#include "utility/fileutility.h"
#include "project/project.h"
#include "Views/console.h"
#include "QProcess"
#include "config/targetconfig.h"
#include "gdb/debugcontrol.h"
#include "Views/dataview.h"
#include "Views/classview.h"
#include <QShortcut>
#include <QPalette>
#include <QToolBar>
#include <QMessageBox>
#include <QFileDialog>
#include <QApplication>
#include <QLineEdit>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QInputDialog>
#include <QtConcurrent/QtConcurrent>
#include "indexer/indexer.h"
#include "utility/projectnamedialog.h"
#include <QFutureWatcher>
#include "config/configeditor.h"
#include "infoview.h"
#include <QDesktopWidget>
#include "tabmanager.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include "target.h"
#include "config/projectconfig.h"
#include <QScrollArea>
#include "consoleprocess.h"
#include "terminalwindow.h"
#include "componentdownload.h"
#include <QtPrintSupport>
#include "zip.h"
#include "utility/progressdialog.h"
#include "utility/selecthomefolderdlg.h"
#include "utility/projectarchiver.h"
#include "downloader/readwebpage.h"

extern bool g_logEnabled;

//!----------------------------------------------------------------------------
//! \brief Constructor - initialize main window.
//!----------------------------------------------------------------------------
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    debugRunning = false;
    debug = NULL;

    createWidgets();
    loadMainWindowConfig(); // needs to be done after widgets are created.
    createMenu();
    createToolbar();
    makeConnections();

    setWindowTitle(tr("CodeLatch"));
    setUnifiedTitleAndToolBarOnMac(true);
    statusBar()->showMessage(tr("Ready"));
#if defined Q_OS_WIN
    setWindowIcon(QIcon(":/icons/icons/codelatchlogo3.png"));
#elif defined Q_OS_UNIX
    setWindowIcon(QIcon(":/icons/icons/codelatchlogo3.png"));
#endif

    nav->initializeTree();
    actionInProgress = false;
    terminalWindow = NULL;

    // - new install check -
    // If this is the first time we are running after installing we won't have a "RootLocationFolder" folder specified in
    // our config. If this is the case we need to prompt the user to specify a folder. The user can later change this
    // by menu item Tools->Select Root Folder.
    // If this is the first time we are running and the user selects a RootLocationFolder then move all the libraries, targets, and
    // examples folders to that new folder, and update the config to reflect the move.
    QTimer::singleShot(50, this, SLOT(startupCheck()));

}

//!----------------------------------------------------------------------------
//! \brief Destructor
//!----------------------------------------------------------------------------
MainWindow::~MainWindow()
{
}

//!----------------------------------------------------------------------------
//! \brief  Class override, called when MainWindow wants to close because
//!         the user clicked the close button on the window bar.
//!----------------------------------------------------------------------------
void MainWindow::closeEvent(QCloseEvent *event)
{
    // if a process (like a build) is in progress don't allow the window to close.
    if (actionInProgress)
    {
        event->ignore();
        return;
    }

    if (tabManager->closeAllTabs(true))
    {
        if(debugRunning)
            actionDebugTerminate();
        nav->closeTempProjects();
        saveMainWindowConfig();
        // delete temp directory
        FileUtility::eraseDir(FileUtility::getDirTemp());
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void MainWindow::hideEvent(QHideEvent *event)
{
    Q_UNUSED(event);

    qDebug() << "hide event";
}

void MainWindow::checkForComponents()
{
    // if a directory doesn't exist ask the user if they want to download the component(s).
    // the home directory should contain compiler, examples, doc, tools, lib, and targets folders.
    bool showDialog = false;
    QFileInfo info;
    info.setFile(FileUtility::getDirCompiler());
    if(!info.exists()) showDialog = true;
    info.setFile(FileUtility::getDirExamples());
    if(!info.exists()) showDialog = true;
    info.setFile(FileUtility::getDirDoc());
    if(!info.exists()) showDialog = true;
    info.setFile(FileUtility::getDirTools());
    if(!info.exists()) showDialog = true;
    info.setFile(FileUtility::getDirLibrary());
    if(!info.exists()) showDialog = true;
    info.setFile(FileUtility::getDirTargets());
    if(!info.exists()) showDialog = true;
    if(showDialog)
        showDownloadComponentsDlg();
}

//!----------------------------------------------------------------------------
//!
//!----------------------------------------------------------------------------
void MainWindow::changeRootLocation()
{
    QString homeFolder = ProgramConfig::get(ROOT_STORAGE_FOLDER).toString();
    if(homeFolder.isEmpty())
        homeFolder = FileUtility::getDocumentsPath() + "/CodeLatch";
    SelectHomeFolderDlg dlg(this,homeFolder);
    int ret = dlg.exec();
    if(ret == 0) return;

    QString path = dlg.homeFolder();
    path = path.replace("\\","/");
    path = path.replace("//","/");

    QDir dir(path);
    if(!dir.exists())
    {
        if(!dir.mkpath(path))
        {
            QMessageBox::critical(this,"Error","Error creating path.");
            return;
        }
    }
    ProgramConfig::set(ROOT_STORAGE_FOLDER,path);

    checkForComponents();
    updateDynamicProjectMenu();
    populateTargetSelCombo();
}

//!----------------------------------------------------------------------------
//! \brief Checks if a ROOT_STORAGE_FOLDER is specified in the master config.
//! If not, prompt the user to create one, if success copy all examples,
//! libraries, and targets to the new folder.
//!----------------------------------------------------------------------------
void MainWindow::startupCheck()
{
    QString folder = ProgramConfig::get(ROOT_STORAGE_FOLDER).toString();
    // if the folder specified exists we are good to go. the user can always use the menu to select a new location.
    if(folder.isEmpty())
        changeRootLocation();
    else
    {
        QDir dir(folder);
        if(dir.exists())
        {
            checkForComponents();
            return;
        }
        else
            changeRootLocation();
    }
}

//============================================================================
//
//                              DATA WINDOW SUPPORT
//
// These routines support the data window on the right side of the app window.
//============================================================================

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::dataViewTabSelChanged(int index)
{
    (void) index; // unused
    // update debug view tab based
    if(debugToolBar->isVisible())
        dataView->updateView(debug);
}


//============================================================================
//
//                              NAV WINDOW SUPPORT
//
// These routines support the navigator window on the left side of the app window.
//============================================================================

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::updateIndexViews()
{
    static Project *lastPrj = NULL;
    qDebug() << "MainWindow::updateIndexViews()";

    updateEditMenuState();
    updateToolbarState();

    // get file pathname and project currently selected in the navigator
    QString pathname = nav->getSelectedFilepath();
    Project *prj = nav->getProjectFromFile(pathname);
    // get current editor
    SourceEditor *editor = tabManager->currentEditor();
    Indexer *autoCompleteIndexer = NULL;
    if(editor != NULL)
        autoCompleteIndexer = editor->getOutlineIndexer();
    // update the project view only if the project has changed
    if(prj != lastPrj)
        dataView->updateClassView(prj);
    lastPrj = prj;

    // jem working on slow update issue
    // update outline view
    if(autoCompleteIndexer != NULL)
        dataView->updateOutlineView(autoCompleteIndexer,pathname);
    //    if(prj != NULL)
    //        dataView->updateOutlineView(prj->getIndexer(),pathname);
}

//!-----------------------------------------------------------------------------
//! \brief   Create a new file. Prompt the user for a filename and create the
//!          file in the directory that the navigator is currently pointing to.
//!-----------------------------------------------------------------------------
void MainWindow::newFile()
{
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;
    QString path = nav->getSelectedFilepath();
    QFileInfo info(path);
    if(!info.isDir())
        path = info.path();

    // get filename
    bool ok;
    QString filename = QInputDialog::getText(this,"New File","New File Name:",QLineEdit::Normal,"",&ok);
    if(!ok || filename.isEmpty()) return;
    QString pathname = path + '/' + filename;

    // create file
    QFile file(pathname);
    if(!file.open(QIODevice::ReadWrite))
    {
        QMessageBox::warning(this,"Error","Couldn't create file.");
        return;
    }
    QTextStream stream( &file );
    stream << "";
    stream.flush();
    file.close();

    // update project and navigator
    prj->update();
    nav->updateProjectTree(prj);

    // open in editor
    tabManager->openFileUsingSourceEditor(prj,pathname);
}

//!-----------------------------------------------------------------------------
//! \brief   Create a new folder. Prompt the user for a folder name and create the
//!          folder in the directory that the navigator is currently pointing to.
//!-----------------------------------------------------------------------------
void MainWindow::newFolder()
{
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;
    QString path = nav->getSelectedFilepath();
    QFileInfo info(path);
    if(!info.isDir())
        path = info.path();

    // get filename
    bool ok;
    QString filename = QInputDialog::getText(this,"New Folder","New Folder Name:",QLineEdit::Normal,"",&ok);
    if(!ok || filename.isEmpty()) return;
    QString pathname = path + '/' + filename;

    // create folder
    QDir dir;
    if(!dir.mkpath(pathname))
    {
        QMessageBox::warning(this,"Error","Couldn't create folder.");
        return;
    }

    // update project and navigator
    prj->update();
    nav->updateProjectTree(prj);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::slotRequestFileOpen(QString pathname,int linenumber, int col)
{
    if(!tabManager->activateTab(pathname))
    {
        // get project for this pathname
        Project *prj = nav->getProjectFromFile(pathname);
        // open project if required
        if(prj == NULL)
        {
            QString prjFolder = FileUtility::getProjectFolderFromPathname(pathname);
            if(prjFolder.isEmpty()) return;
            if(nav->addProject(prjFolder) == NULL) return;
            prj = nav->getSelectedProject();
        }
        if(!tabManager->openFileUsingSourceEditor(prj,pathname))
            return;
    }
    // go to linenumber
    SourceEditor *editor = tabManager->currentEditor();
    if(editor == NULL) return;
    editor->setCursorPosition(linenumber-1,col);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::updateToolbarState()
{
    bool enableBuild = false;

    // see if a nav item or tabWidget tab is selected
    QList<QTreeWidgetItem *> list = nav->selectedItems();
    // check if something in the nav is selected
    if(!list.isEmpty())
        enableBuild = true;
    // if nothing in nav is selected check the tabManager
    else
    {
        QString projectFolder = tabManager->getTabProjectFolder(tabManager->currentIndex());
        if(!projectFolder.isEmpty())
        {
            // make sure the project is in the nav
            Project *prj = nav->getProjectFromFolder(projectFolder);
            if(prj != NULL)
                enableBuild = true;
        }
    }

    fileToolBar->setEnabled(enableBuild);
    buildToolBar->setEnabled(enableBuild);

}


//!-----------------------------------------------------------------------------
//! \brief SLOT: mainMenu File->Open
//!-----------------------------------------------------------------------------
void MainWindow::openFile()
{
    QString pathName = QFileDialog::getOpenFileName(this, tr("Open File"), FileUtility::getDirProjects(), "C++ Files (*.cpp *.h *.c *.hpp)");

    // TODO: search nav to see if this file is part of an open project
    // not part of an open project, open an editor with prj = NULL
    tabManager->openFileUsingSourceEditor(NULL,pathName);
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: mainMenu Project->Open
//!-----------------------------------------------------------------------------
void MainWindow::openProject()
{
    QString str = "Project Files (*." + Project::getProjectExtension() + ")";
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Project"), FileUtility::getDirProjects(), str);
    if(!fileName.isEmpty())
    {
        QFileInfo info(fileName);
        if(info.exists())
            nav->addProject(info.path());
    }
}

//!-----------------------------------------------------------------------------
//! \brief Close selected project. Close all open project files, remove from navigator, free memory.
//!-----------------------------------------------------------------------------
void MainWindow::closeProject(Project *prj)
{
    if(prj == NULL)
        prj = nav->getSelectedProject();
    if(prj == NULL) return;

    // close all open editor tabs associated with this project
    if(!tabManager->closeTabs(prj)) return;

    // remove project from navigator
    nav->removeProject(prj);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString MainWindow::getTabWidgetPathname(QWidget *widget)
{
    SourceEditor *editor = qobject_cast<SourceEditor *>(widget);
    if(editor != NULL) return editor->getPathname();
    TargetConfig *config = qobject_cast<TargetConfig *>(widget);
    if(config != NULL) return config->getPathname();
    ProjectConfig *form = qobject_cast<ProjectConfig *>(widget);
    if(form != NULL) return form->getPathname();
    return QString();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString MainWindow::getTabWidgetProjectFolder(QWidget *widget)
{
    SourceEditor *editor = qobject_cast<SourceEditor *>(widget);
    if(editor != NULL) return editor->getProjectFolder();
    TargetConfig *config = qobject_cast<TargetConfig *>(widget);
    if(config != NULL) return config->getProjectFolder();
    ProjectConfig *form = qobject_cast<ProjectConfig *>(widget);
    if(form != NULL) return form->getProjectFolder();
    return QString();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::saveAsProject()
{
    // get active project.
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;

    // get new project name and parent folder from user via dialog.
    ProjectNameDialog dlg;
    QFileInfo info;
    if(prj->getProjectFolder().startsWith(FileUtility::getDirTemp()))
        info.setFile(FileUtility::getDirProjects()+"/"+prj->getName());
    else
        info.setFile(prj->getProjectFolder());
    dlg.setInitialDirectory(info.path());
    dlg.setInitialName(prj->getName());
    dlg.setMessage("Enter new project name.");
    dlg.setTitle("Project SaveAs");
    if(!dlg.exec())
        return;

    QString sourceFolder = prj->getProjectFolder();
    QString destFolder = dlg.getProjectFolder();
    QString destName = dlg.getProjectName();

    destFolder.replace("\\","/");
    destFolder.replace("//","/");
    qDebug() << "saving to:" << destFolder;

    // save project to new directory
    prj->saveAs(destFolder);

    // rename and save associated open editors.
    for(int i=0;i<tabManager->count();i++)
    {
        QString oldpathname = tabManager->getTabPathname(i);
        QString projectFolder = tabManager->getTabProjectFolder(i);
        if(oldpathname.isEmpty() || projectFolder.isEmpty()) continue;
        if(destFolder == projectFolder)
        {
            QString pathname = oldpathname;
            pathname = pathname.replace(sourceFolder,destFolder);
            pathname = pathname.replace("//","/");
            tabManager->setTabPathname(i,pathname);
            tabManager->setTabProject(i,prj);
            tabManager->saveFile(i,false);
            if(i == tabManager->currentIndex())
                setStatusMessage(FileUtility::replacePathWithKey(prj,pathname));
        }
    }
    /*
    // close the project
    closeProject(prj);
    // update dynamic menus to include new project
    updateDynamicProjectMenu();
    updateSaveSaveAll();
    // open the new project
    nav->addProject(destFolder);
    return;
*/
    // update navigator
    int i = nav->findTopLevelItem(sourceFolder);
    if(i == -1)
    {
        QMessageBox::critical(this,"Error","Error 1 updating navigator.");
        return;
    }
    QTreeWidgetItem *item = nav->topLevelItem(i);
    if(item == NULL)
    {
        QMessageBox::critical(this,"Error","Error 2 updating navigator.");
        return;
    }
    nav->setProjectFolder(item,destFolder);
    nav->setPathname(item,destFolder);
    nav->setProjectName(item,destName);
    // re-load project tree, currently we do not rename every nav item so
    // we will not restore the tree expanded states to the current states.
    nav->updateProjectTree(prj);
    prj->runIndexer();

    // update dynamic menus to include new project
    updateDynamicProjectMenu();
    updateSaveSaveAll();
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: mainMenu New Project
//!-----------------------------------------------------------------------------
void MainWindow::newProject()
{
    QString path = FileUtility::getDirExamples() + "/01-basic/empty project";
    nav->addProject(path);
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Delete selected items in navigator tree.
//!-----------------------------------------------------------------------------
void MainWindow::actionDeleteItem()
{
    // determine if the navigator or editor has the focus
    QWidget *wPtr = QApplication::focusWidget();
    if(nav != wPtr)
    {
        QMessageBox::information(this,"Info","Select item(s) in navigator first.");
        return;
    }

    // get selected items
    QList<QTreeWidgetItem*> list = nav->selectedItems();

    // make string list of pathnames and/or projects that are selected
    QStringList pathList;
    QStringList projectList;
    QStringList projectsToUpdate;
    for(int i=0;i<list.size();i++)
    {
        QString pathname = list.at(i)->data(0,NavTree::FilePath).toString();
        QString projectFolder = list.at(i)->data(0,NavTree::ProjectFolder).toString();
        // if the pathname equals the prjFolder this is a top level project item
        if(pathname == projectFolder)
            projectList.append(projectFolder);
        else
        {
            pathList.append(pathname);
            projectsToUpdate.append(projectFolder);
        }
    }
    projectsToUpdate.removeDuplicates();

    // show warning message box
    QMessageBox msgBox;
    if(projectList.size() == 0)
    {
        if(pathList.size() == 0)
            return; // nothing selected to delete
        else if(pathList.size() == 1)
        {
            QString path = pathList.at(0);
            QFileInfo info(path);
            msgBox.setText("Permanently delete "+info.fileName()+" from disk?");
        }
        else
            msgBox.setText("Permanently delete selected files from disk?");
    }
    else if(projectList.size() == 1)
    {
        QString path = projectList.at(0);
        QFileInfo info(path);
        msgBox.setText("Permanently delete "+info.fileName()+" and files from disk?");
    }
    else
        msgBox.setText("Permanently delete selected projects and files from disk?");
    msgBox.setIcon(QMessageBox::Warning);
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
    msgBox.setDefaultButton(QMessageBox::Cancel);
    if(msgBox.exec() == QMessageBox::Cancel)
        return;

    // close all editor tabs that belong to entire projects being deleted
    for(int i=0;i<projectList.size();i++)
    {
        QString prjFolder = projectList.at(i);
        int n = tabManager->count();
        for(int j=0;j<n;)
        {
            if(tabManager->getTabProjectFolder(j) == prjFolder)
                tabManager->closeTab(j);
            else
                j++;
        }
    }

    // close all editor tabs whose pathnames are are in pathList
    for(int i=0;i<pathList.size();i++)
    {
        QString pathname = pathList.at(i);
        int n = tabManager->count();
        for(int j=0;j<n;)
        {
            if(tabManager->getTabPathname(j) == pathname)
                tabManager->closeTab(j);
            else
                j++;
        }
    }

    // remove selected projects from navigator, delete disk contents
    for(int i=0;i<projectList.size();i++)
    {
        nav->removeProject(nav->getProjectFromFolder(projectList.at(i)));
        FileUtility::eraseDir(projectList.at(i));
    }

    // delete selected files
    for(int i=0;i<pathList.size();i++)
    {
        bool ret;
        QString pathname = pathList.at(i);
        QFileInfo fileinfo(pathname);
        if(fileinfo.isDir())
            ret = FileUtility::eraseDir(pathname);
        else
            ret = QFile::remove(pathname);
        if(!ret) console->appendLine("Error removing " + fileinfo.fileName());
    }

    // update navigator projects that we deleted files out of
    for(int i=0;i<projectsToUpdate.size();i++)
        nav->updateProjectTree(nav->getProjectFromFolder(projectsToUpdate.at(i)));

    // update dynamic project menu if entire projects were deleted
    if(projectList.size() > 0)
        updateDynamicProjectMenu();
}

//!-----------------------------------------------------------------------------
//! \brief SLOT : Navigator context menu item "Rename" selected.
//!-----------------------------------------------------------------------------
void MainWindow::navContextMenuRename()
{

    QTreeWidgetItem *item = nav->getContextItem();
    if(item == NULL) return;
    QString projectFolder = nav->getProjectFolder(item);
    QString pathname = nav->getPathname(item);
    Project *prj = nav->getProject(item);
    if(prj == NULL)
        return;

    QFileInfo info(pathname);
    QString filename = info.fileName();
    QDir dir(pathname);

    // don't allow renaming of config file
    if(filename == prj->getConfigFilename())
        return;

    // get new file name
    bool ok;
    QString newname = QInputDialog::getText(NULL, "Rename","New Name", QLineEdit::Normal,filename, &ok);
    if (!ok || newname.isEmpty()) return;
    QString newPathname = info.path() + "/" + newname;

    if(projectFolder == pathname) // rename a project
    {
        QString sourceFolder = projectFolder;
        QString destFolder = newPathname;
        QString destName = newname;

        // get nav item
        int navIndex = nav->findTopLevelItem(sourceFolder);
        if(navIndex == -1)
            return;
        QTreeWidgetItem *navItem = nav->topLevelItem(navIndex);
        if(navItem == NULL)
            return;

        // rename the project (renames directory)
        if(!prj->rename(destName))
        {
            QMessageBox::warning(this,"Error","Rename failed");
            return;
        }

        // update associated open editors to point to new project location.
        for(int i=0;i<tabManager->count();i++)
        {
            if(tabManager->getTabProjectFolder(i) == destFolder)
            {
                QString pathname = tabManager->getTabPathname(i);
                pathname = pathname.replace(sourceFolder,destFolder);
                pathname = pathname.replace("//","/");
                tabManager->setTabPathname(i,pathname);
            }
        }
        // update navigator
        nav->setProjectFolder(navItem,destFolder);
        nav->setPathname(navItem,destFolder);
        nav->setProjectName(navItem,destName);
        prj->update();
        nav->updateProjectTree(prj);

        // force update of status text
        int i = tabManager->currentIndex();
        QString tabPathname = tabManager->getTabPathname(i);
        if(!tabPathname.isEmpty())
            setStatusMessage(FileUtility::replacePathWithKey(prj,tabPathname));
        updateSaveSaveAll();
        updateToolbarState();
        updateIndexViews();
        dataView->updateClassView(prj);
        // select project item
        nav->selectFile(destFolder);
        // update menu
        updateDynamicProjectMenu();
    }
    else // rename a file
    {
        if(!dir.rename(pathname,newPathname))
        {
            QMessageBox::warning(this,"Error","Rename failed");
            return;
        }
        // delete old object file if present
        QString objName = prj->getBuildFolder() + "/obj/" + info.baseName() + ".o";
        if(QFile::exists(objName))
            QFile::remove(objName);
        // update project, nav tree, and select file in nav tree
        prj->update();
        nav->updateProjectTree(prj);
        nav->selectFile(newPathname);

        if(!tabManager->activateTab(pathname)) return;
        int i = tabManager->currentIndex();
        tabManager->setTabPathname(i,newPathname);
        statusBar()->showMessage(FileUtility::replacePathWithKey(prj,newPathname));
    }
}



//=============================================================================
//
//                          MENU SUPPORT
//
//=============================================================================


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::showDownloadComponentsDlg()
{
    QString homeFolder = ProgramConfig::get(ROOT_STORAGE_FOLDER).toString();
    QFileInfo info(homeFolder);
    // if the root storage folder is not specified or doesn't exist put up a message and stop
    if(homeFolder.isEmpty() || !info.exists())
    {
        QString text = "The Home Folder has not been selected. You must select this first.";
        QMessageBox::information(this, "Initialization", text, QMessageBox::Ok);
        return;
    }

    ComponentDownloadDialog dlg;
    dlg.connect(&dlg,SIGNAL(updateMenus()),this,SLOT(updateDynamicProjectMenu()));
    dlg.connect(&dlg,SIGNAL(updateMenus()),this,SLOT(populateTargetSelCombo()));
    dlg.connect(&dlg,SIGNAL(selectHomeFolder()),this,SLOT(changeRootLocation()));
    dlg.exec();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::about()
{
    QMessageBox::about(this,"Version",STR_PROGRAM_VER);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::indexActiveProject()
{
    if(nav == NULL) return;
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;
    runProjectIndexer(prj);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::openEditorConfig()
{
    if(!tabManager->activateTab("Editor Config"))
    {
        ConfigEditor *view = new ConfigEditor(tabManager);
        connect(view,SIGNAL(modified()),tabManager,SLOT(updateEditorSettings()));
        tabManager->insertTab(0,view,"Editor Config");
        tabManager->activateTab("Editor Config");
    }
}

void MainWindow::testReadError()
{
    console->appendLine("testReadError");
    QByteArray ba = debugProcess1->readAllStandardError();
    QString s(ba);
    console->appendLine(s);
}
void MainWindow::testReadStd()
{
    console->appendLine("testReadStd");
    QByteArray ba = debugProcess1->readAllStandardOutput();
    QString s(ba);
    console->appendLine(s);
}
void MainWindow::testReadAll()
{
    console->appendLine("testReadAll");
    QByteArray ba = debugProcess1->readAll();
    QString s(ba);
    console->appendLine(s);
}
void MainWindow::testFinished(int ret,QProcess::ExitStatus status)
{
    QString s;
    s = "testFinished:" + QString::number(ret) + ":" + QString::number(status);
    console->appendLine(s);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::printFile()
{
    SourceEditor *editor = tabManager->currentEditor();
    if(editor == NULL)
        return;

    QPrinter printer;
    QPrintDialog *dialog = new QPrintDialog(&printer);
    dialog->setWindowTitle("Print File");
    if (dialog->exec() != QDialog::Accepted)
        return;

    // set to small font for printing
    QFont stdFont = editor->font();
    QFont printFont = stdFont;
    printFont.setPointSize(8);
    editor->setFont(printFont);
    editor->print(&printer);
    editor->setFont(stdFont);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::openReference()
{
    QString homeDir = FileUtility::getDirHome();
    QString localDocs = "file://" + homeDir + "/doc/reference.html";

    QUrl url(localDocs);
    QDesktopServices::openUrl(url);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::openHomeFolder()
{
    QString path = FileUtility::getDirHome();
    QDesktopServices::openUrl( QUrl::fromLocalFile( path ) );
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::changeMenuItemText(QMenu *menu, QString currentText, QString newText)
{
    QList<QAction*> actionList = menu->actions();
    foreach(QAction *action,actionList)
    {
        if(action->text() == currentText)
        {
            action->setText(newText);
            break;
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QAction* MainWindow::getMenuAction(QMenu *menu, QString menuName)
{
    QList<QAction*> actionList = menu->actions();
    foreach(QAction *action,actionList)
    {
        if(action->text() == menuName)
            return action;
    }
    return NULL;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::enableAction(QMenu *menu, QString menuName)
{
    QAction *action = getMenuAction(menu,menuName);
    if(action == NULL) return;
    action->setEnabled(true);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::disableAction(QMenu *menu, QString menuName)
{
    QAction *action = getMenuAction(menu,menuName);
    if(action == NULL) return;
    action->setEnabled(false);
}

//!-----------------------------------------------------------------------------
//! \brief Slot - enable logging menu item selected.
//!-----------------------------------------------------------------------------
void MainWindow::actionToggleLogging()
{
    QString enable("Enable Logging");
    QString disable("Disable Logging");

    if(g_logEnabled)
    {
        //        changeMenuItemText(configMenu,disable,enable);
        g_logEnabled = false;
    }
    else
    {
        //        changeMenuItemText(configMenu,enable,disable);
        g_logEnabled = true;
    }
}

//!-----------------------------------------------------------------------------
//! \brief Slot - Edit targets menu item selected.
//!-----------------------------------------------------------------------------
void MainWindow::actionEditTarget()
{
    if(!tabManager->activateTab(TargetConfig::getPathname()))
    {
        TargetConfig *config = new TargetConfig;
        int i = tabManager->addTab(config,TargetConfig::getPathname());
        tabManager->setCurrentIndex(i);
        connect(config,SIGNAL(updateTargetList()),this,SLOT(populateTargetSelCombo()));
    }
}

//!-----------------------------------------------------------------------------
//! \brief Add dynamic menu items to Project menu.
//!-----------------------------------------------------------------------------
void MainWindow::addDynamicMenuItems(QMenu *menu)
{
    QString examplesDir = FileUtility::getDirExamples();
    QString projectsDir = FileUtility::getDirProjects();
    QString libsDir = FileUtility::getDirLibrary();

    QList<QAction*> actionList = menu->actions();
    foreach(QAction *action,actionList)
    {
        if(action->text() == STR_FILE_MENU_EXAMPLES)
        {
            QMenu *submenu = action->menu();
            submenu->clear();
            buildDynamicMenu(submenu,examplesDir);
        }
        if(action->text() == STR_FILE_MENU_PROJECTS)
        {
            QMenu *submenu = action->menu();
            submenu->clear();
            buildDynamicMenu(submenu,projectsDir);
        }
        if(action->text() == STR_FILE_MENU_LIBRARIES)
        {
            QMenu *submenu = action->menu();
            submenu->clear();
            buildDynamicMenu(submenu,libsDir);
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief Add dynamic menu items to project menu.
//!-----------------------------------------------------------------------------
void MainWindow::updateDynamicProjectMenu()
{
    addDynamicMenuItems(fileMenu);
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: edit menu "Find / Replace" action.
//!-----------------------------------------------------------------------------
void MainWindow::actionFind()
{
    QString selText;

    SourceEditor *editor = tabManager->currentEditor();
    if(editor != NULL)
    {
        QTextCursor cursor = editor->textCursor();
        selText = cursor.selectedText();
        infoView->finderSearchForText(selText);
    }
    restoreInfoView();
    infoView->showFinder();
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: edit menu "Goto" action.
//!         goto a specified line number in the current file.
//!-----------------------------------------------------------------------------
void MainWindow::actionGoto()
{
    SourceEditor *editor = tabManager->currentEditor();
    if(editor == NULL) return;

    int row,col;
    editor->getCursorPosition(&row,&col);

    bool ok;
    int line = QInputDialog::getInt(this,tr("Goto"),tr("Line Number:"),row,0,500000,1,&ok);
    if (!ok) return;
    editor->setCursorPosition(line-1,0);
}

//!-----------------------------------------------------------------------------
//! \brief This is a helper function to enable/disable file menu
//! selections by checking current conditions. It's called due to...
//! connect(fileMenu,SIGNAL(aboutToShow()),this,SLOT(updateFileMenuState()));
//!-----------------------------------------------------------------------------
void MainWindow::updateFileMenuState()
{
    // new project, open project, close project, save as project
    // new file, open file, save file, save as file
    // dynamic menus
    // print
    SourceEditor *editor = tabManager->currentEditor();
    if(editor != NULL)
    {
        enableAction(fileMenu,STR_FILE_MENU_PRINT);
    }
    else
    {
        disableAction(fileMenu,STR_FILE_MENU_PRINT);
    }
}

//!-----------------------------------------------------------------------------
//! \brief This is a helper function to enable/disable edit menu
//! selections by checking current conditions. It's called due to...
//! connect(editMenu,SIGNAL(aboutToShow()),this,SLOT(updateEditMenuState()));
//!-----------------------------------------------------------------------------
void MainWindow::updateEditMenuState()
{    
    // undo, redo, cut, copy, paste
    // find replace, goto line, jump to code, format document
    QWidget *wPtr = QApplication::focusWidget();
    if(wPtr == NULL)
    {
        disableAction(editMenu,STR_EDIT_MENU_UNDO);
        disableAction(editMenu,STR_EDIT_MENU_REDO);
        disableAction(editMenu,STR_EDIT_MENU_CUT);
        disableAction(editMenu,STR_EDIT_MENU_COPY);
        disableAction(editMenu,STR_EDIT_MENU_PASTE);
        return;
    }

    if(wPtr == tabManager->currentWidget())
    {
        SourceEditor *editor = tabManager->currentEditor();
        if(editor == NULL)
        {
            disableAction(editMenu,STR_EDIT_MENU_UNDO);
            disableAction(editMenu,STR_EDIT_MENU_REDO);
            return;
        }
        // update undo/redo enabled state
        if(editor->isUndoAvailable()) enableAction(editMenu,STR_EDIT_MENU_UNDO);
        else disableAction(editMenu,STR_EDIT_MENU_UNDO);
        if(editor->isRedoAvailable()) enableAction(editMenu,STR_EDIT_MENU_REDO);
        else disableAction(editMenu,STR_EDIT_MENU_REDO);
        // update cut/copy enabled state
        QTextCursor cursor = editor->textCursor();
        if(cursor.hasSelection())
        {
            enableAction(editMenu,STR_EDIT_MENU_CUT);
            enableAction(editMenu,STR_EDIT_MENU_COPY);
        }
        else
        {
            disableAction(editMenu,STR_EDIT_MENU_CUT);
            disableAction(editMenu,STR_EDIT_MENU_COPY);
        }
        // update paste state
        QString clipboardText = QApplication::clipboard()->text();
        if(clipboardText.isEmpty())
            disableAction(editMenu,STR_EDIT_MENU_PASTE);
        else
            enableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
    else if(wPtr == nav)
    {
        if(nav->hasCutSelection())
            enableAction(editMenu,STR_EDIT_MENU_CUT);
        else
            disableAction(editMenu,STR_EDIT_MENU_CUT);
        if(nav->hasCopySelection())
            enableAction(editMenu,STR_EDIT_MENU_COPY);
        else
            disableAction(editMenu,STR_EDIT_MENU_COPY);
        if(nav->hasPasteSource())
            enableAction(editMenu,STR_EDIT_MENU_PASTE);
        else
            disableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
    else if(wPtr->inherits("QPlainTextEdit"))
    {
        QPlainTextEdit *widget = (QPlainTextEdit *) wPtr;
        QTextCursor cursor = widget->textCursor();
        if(cursor.selectedText().length() > 0)
            enableAction(editMenu,STR_EDIT_MENU_COPY);
        else
            disableAction(editMenu,STR_EDIT_MENU_COPY);
        // don't allow cutting or pasting in arbitrary windows
        disableAction(editMenu,STR_EDIT_MENU_CUT);
        disableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
    else
    {
        disableAction(editMenu,STR_EDIT_MENU_UNDO);
        disableAction(editMenu,STR_EDIT_MENU_REDO);
        disableAction(editMenu,STR_EDIT_MENU_CUT);
        disableAction(editMenu,STR_EDIT_MENU_COPY);
        disableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
}

//!-----------------------------------------------------------------------------
//! \brief This is a helper function to enable/disable the Save and SaveAll
//!         selections in the file menu and file tool bar based on the current
//!         tab and other open tabs.
//!-----------------------------------------------------------------------------
void MainWindow::updateSaveSaveAll()
{    
    int i = tabManager->currentIndex();
    QString name = tabManager->tabText(i);
    if(name.endsWith(STR_DIRTY_FILE))
    {
        enableAction(fileToolBar,STR_FILE_MENU_FILE_SAVE);
        enableAction(fileToolBar,STR_FILE_MENU_FILE_SAVE_ALL);
        enableAction(fileMenu,STR_FILE_MENU_FILE_SAVE);
        return;
    }
    else
    {
        disableAction(fileToolBar,STR_FILE_MENU_FILE_SAVE);
        disableAction(fileMenu,STR_FILE_MENU_FILE_SAVE);
    }

    int n = tabManager->count();
    for(i=0;i<n;i++)
    {
        name = tabManager->tabText(i);
        if(name.endsWith(STR_DIRTY_FILE))
        {
            enableAction(fileToolBar,STR_FILE_MENU_FILE_SAVE_ALL);
            return;
        }
    }
    disableAction(fileToolBar,STR_FILE_MENU_FILE_SAVE_ALL);
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: edit menu "Undo" action.
//!-----------------------------------------------------------------------------
void MainWindow::actionUndo()
{
    SourceEditor *editor = tabManager->currentEditor();
    if(editor == NULL) return;
    if(editor->hasFocus())
        editor->undo();
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: edit menu "Redo" action.
//!-----------------------------------------------------------------------------
void MainWindow::actionRedo()
{
    SourceEditor *editor = tabManager->currentEditor();
    if(editor == NULL) return;
    if(editor->hasFocus())
        editor->redo();
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: edit menu "Cut" action.
//!-----------------------------------------------------------------------------
void MainWindow::actionCut()
{
    QWidget *wPtr = QApplication::focusWidget();
    if(wPtr == NULL) return;
    if(wPtr == tabManager->currentWidget())
    {
        SourceEditor *editor = tabManager->currentEditor();
        if(editor == NULL) return;
        if(editor->hasFocus())
        {
            editor->cut();
            enableAction(editMenu,STR_EDIT_MENU_PASTE);
        }
    }
    else if(wPtr == nav)
    {
        nav->actionCut();
        enableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
    else if(wPtr->inherits("QPlainTextEdit"))
    {
        QPlainTextEdit *widget = (QPlainTextEdit *) wPtr;
        widget->cut();
        enableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: edit menu "Copy" action.
//!-----------------------------------------------------------------------------
void MainWindow::actionCopy()
{
    QWidget *wPtr = QApplication::focusWidget();
    if(wPtr == NULL) return;
    if(wPtr == tabManager->currentWidget())
    {
        SourceEditor *editor = tabManager->currentEditor();
        if(editor == NULL) return;
        if(editor->hasFocus())
        {
            editor->copy();
            enableAction(editMenu,STR_EDIT_MENU_PASTE);
        }
    }
    else if(wPtr == nav)
    {
        nav->actionCopy();
        enableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
    else if(wPtr->inherits("QPlainTextEdit"))
    {
        QPlainTextEdit *widget = (QPlainTextEdit *) wPtr;
        widget->copy();
        enableAction(editMenu,STR_EDIT_MENU_PASTE);
    }
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: edit menu "Paste" action.
//!-----------------------------------------------------------------------------
void MainWindow::actionPaste()
{
    QWidget *wPtr = QApplication::focusWidget();
    if(wPtr == NULL) return;
    if(wPtr == tabManager->currentWidget())
    {
        SourceEditor *editor = tabManager->currentEditor();
        if(editor == NULL) return;
        if(editor->hasFocus())
            editor->paste();
    }
    else if(wPtr == nav)
    {
        nav->actionPaste();
    }
    else if(wPtr->inherits("QPlainTextEdit"))
    {
        QPlainTextEdit *widget = (QPlainTextEdit *) wPtr;
        widget->paste();
    }
}

//!-----------------------------------------------------------------------------
//! \brief Support routine for addDynamicMenuItems. Scans folder for projects
//!        and fills menu.
//!-----------------------------------------------------------------------------
void MainWindow::buildDynamicMenu(QMenu *menu, QString folderName)
{
    // scan folder for folders that contain projects and add menu items for discovered projects.
    // if a folder has sub-folders that contain projects recursively call this routine to add them.
    // project folders cannot contain sub-folders with projects.
    QFileInfo info(folderName);
    if(!info.isDir()) return;

    // make a sorted list of folders in this folder
    QDir dir(folderName);
    QFileInfoList list = dir.entryInfoList();
    QStringList dirList;
    foreach(QFileInfo info,list)
    {
        if(info.fileName().startsWith('.')) continue;
        if(info.isHidden()) continue;
        if(info.isSymLink()) continue;
        if(!info.isDir()) continue;
        dirList.append(info.absoluteFilePath());
    }
    dirList.sort();

    foreach(QString dirname,dirList)
    {
        if (isProjectFolder(dirname))
        {
            // add project to menu.
            // the project name is the name of the parent folder.
            QFileInfo prjInfo(dirname);
            QString prjName = prjInfo.fileName();
            // to control menu ordering we can put two digits followed by a dash at the
            // front of the file/folder name, if that's present remove it for the
            // displayed menu name, although it's still included in the actual project path.
            if(prjName.length() > 3)
                if(prjName.at(0).isDigit() && prjName.at(1).isDigit() && prjName.at(2) == '-')
                    prjName = prjName.right(prjName.length()-3);
            QAction *action = new QAction(prjName, menu);
            action->setData(dirname);
            menu->addAction(action);
        }
        // search sub-directories for projects, if we find something
        // add a cascade menu and then proceed recursively
        else if (subsContainProjects(dirname))
        {
            // add cascade menu
            QFileInfo subinfo(dirname);
            QString name = subinfo.fileName();
            if(name.length() > 3)
                if(name.at(0).isDigit() && name.at(1).isDigit() && name.at(2) == '-')
                    name = name.right(name.length()-3);
            QMenu *subMenu = new QMenu(name,menu);
            // recurse into this directory
            buildDynamicMenu(subMenu, dirname);
            menu->addMenu(subMenu);
        }
        else if(dirname.endsWith("seperator"))
        {
            menu->addSeparator();
        }
    }
}

//!-----------------------------------------------------------------------------
//! \brief Support routine for buildDynamicMenu, determines if a given folder
//!         is a project folder.
//!-----------------------------------------------------------------------------
bool MainWindow::isProjectFolder(QString path)
{
    QFileInfo pathinfo(path);
    if(!pathinfo.exists() || !pathinfo.isDir()) return false;
    // get a list of all files in this folder and look for
    // project file.
    QString prjExtension = "." + Project::getProjectExtension();
    QDirIterator entries(path, QDir::Files | QDir::NoSymLinks | QDir::NoDotAndDotDot);
    while(entries.hasNext())
    {
        entries.next();
        QString pathname = entries.filePath();
        QFileInfo info(pathname);
        if(info.isFile())
            if(pathname.endsWith(prjExtension))
                return true;
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief Recursively search a directory structure to see if any
//!         sub-directories contain a project file.
//!-----------------------------------------------------------------------------
bool MainWindow::subsContainProjects(QString path)
{
    QFileInfo info(path);
    if (!info.isDir()) return false;

    // avoid recursing into sub folders if this folder contains a project file.
    if (isProjectFolder(path))
        return true;

    // get a list of all sub directory folders and check if any contains a project file.
    QDirIterator directories(path, QDir::Dirs | QDir::NoSymLinks | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
    while(directories.hasNext())
    {
        directories.next();
        QString dirname = directories.filePath();
        if(isProjectFolder(dirname))
            return true;
    }
    return false;
}

//!-----------------------------------------------------------------------------
//! \brief SLOT: Called when a dynamic menu item is selected. Open associated
//! project. This is one of two ways a project can be opened. The other is with
//! openProject()
//!-----------------------------------------------------------------------------
void MainWindow::dynamicMenuItemSelected(QAction *action)
{
    // open project
    if(action != NULL)
    {
        QString path = action->data().toString();
        nav->addProject(path);
    }
}

//!----------------------------------------------------------------------------
//! \brief  Restore default geometry to main window.
//!----------------------------------------------------------------------------
void MainWindow::viewReset()
{
    setGeometry(QRect(70,60,1000,670));
    QList<int> hlist,vlist;
    hlist << 195 << 600 << 200;
    vlist << 470 << 130;
    hSplit->setSizes(hlist);
    vSplit->setSizes(vlist);
    setGeometry(QRect(70,60,1000,670));
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::saveAsFile()
{
    QString sourcePathname = nav->getSelectedFilepath();
    if(sourcePathname.isEmpty()) return;
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;

    QFileInfo info(sourcePathname);
    if(!info.isFile()) return;
    QString filename = info.fileName();

    // get new file name
    bool ok;
    QString newname = QInputDialog::getText(NULL, "Rename","New Name", QLineEdit::Normal,filename, &ok);
    if (!ok || newname.isEmpty()) return;
    QString destPathname = info.path() + "/" + newname;
    QFileInfo newInfo(destPathname);
    if(newInfo.exists())
    {
        QMessageBox::warning(this,"Error","File already exists.");
        return;
    }

    // get text from editor if editor is open
    bool found = false;
    QString fileText;
    for(int i=0;i<tabManager->count();i++)
    {
        SourceEditor *editor = tabManager->getEditor(i);
        if(editor == NULL) continue;
        QString widgetPathname = editor->getPathname();
        if(widgetPathname == sourcePathname)
        {
            fileText = editor->text();
            found = true;
            break;
        }
    }

    if(!found)
    {
        // no open editor, just copy the file.
        if(!QFile::copy(sourcePathname,destPathname))
        {
            QMessageBox::critical(NULL, "Error","Error copying file.");
            return;
        }
    }
    else
    {
        // editor is opened, use text from editor to populate the new file.
        QFile file( destPathname );
        if (!file.open(QIODevice::ReadWrite))
        {
            QMessageBox::critical(NULL, "Error","Error saving new file.");
            return;
        }
        QTextStream stream( &file );
        stream << fileText;
        stream.flush();
        file.close();
    }

    prj->update();
    nav->updateProjectTree(prj);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::setTarget(QString configName)
{
    // update program config
    ProgramConfig::set(TARGET_NAME,configName);

    int n = tabManager->count();
    QString targetConfigName = TargetConfig::getPathname();

    for(int i=0;i<n;i++)
    {
        // if the framework editor is open update it
        QString tabPathname = tabManager->getTabPathname(i);
        if(targetConfigName == tabPathname)
        {
            QWidget *widget = tabManager->widget(i);
            TargetConfig *configForm = qobject_cast<TargetConfig *>(widget);
            if(configForm == NULL) continue;
            configForm->updateForm();
            return;
        }
        // update indexing
        SourceEditor *editor = tabManager->getEditor(i);
        if(editor == NULL) continue;
        editor->updateIndexer();
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::populateTargetSelCombo()
{
    targetSelCombo->clear();
    QStringList names = Target::getTargetNames();
    if(names.isEmpty()) return;

    // get selected target from program config
    QString targetName = ProgramConfig::get(TARGET_NAME).toString();
    if(targetName.isEmpty())
        targetName = names.first();

    targetSelCombo->addItems(names);
    
    for(int i=0;i<targetSelCombo->count();i++)
    {
        QString name = targetSelCombo->itemText(i);
        QString tooltip = Target::getDescription(name);
        targetSelCombo->setItemData(i, tooltip, Qt::ToolTipRole);
    }
    
    targetSelCombo->setCurrentText(targetName);
}

//=============================================================================
//
//                          TOOLBAR SUPPORT
//
//=============================================================================


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::enableAction(QToolBar *toolbar, QString toolName, bool enabled)
{
    QList<QAction*> actionList = toolbar->actions();
    foreach(QAction *action,actionList)
    {
        if(action->text() == toolName)
        {
            action->setEnabled(enabled);
            break;
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::disableAction(QToolBar *toolbar, QString toolName)
{
    enableAction(toolbar,toolName,false);
}









//=============================================================================
//
//                              TOOLBAR ACTIONS
//
//=============================================================================

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionFormatDocument()
{
    SourceEditor *editor = tabManager->currentEditor();
    if(editor == NULL) return;
    //    editor->formatSelection();
    editor->formatDocument();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionBuild()
{
    if(actionInProgress) return;

    Project *prj = nav->getSelectedProject();
    if(prj == NULL)
    {
        console->appendLine("Build: no project selected.");
        return;
    }
    disableAction(buildToolBar,"Build project");

    for(int i=0;i<tabManager->count();i++)
    {
        SourceEditor *editor = tabManager->getEditor(i);
        if(editor == NULL) continue;
        if(prj == editor->getProject())
            tabManager->saveFile(i,false);
    }
    //    prj->runIndexer();
    // TODO set the projects current target name, before building the project should call Target load

    console->clear();
    QTime time = QTime::currentTime();
    QString timeString = time.toString();
    console->appendLine("Building " + prj->getName() + " : at " + timeString);

    connect(prj,SIGNAL(buildComplete(bool,Project*)),this,SLOT(slotBuildComplete(bool,Project*)));
    actionInProgress = true;
    QFuture<void> future = QtConcurrent::run(threadBuildProject,prj);
    //   buildWatcher->setFuture(future);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionClean()
{
    Project *prj = nav->getSelectedProject();
    if(prj == NULL)
    {
        console->appendLine("Clean: no project selected.");
        return;
    }
    console->appendLine("Cleaning " + prj->getName() + ".");
    prj->clean();
    nav->updateProjectTree(prj);
    console->appendLine("Done.");
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionOpenProjectConfig()
{
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;

    QString pathname = prj->getProjectFolder() + "/" + prj->getConfigFilename();
    if(tabManager->activateTab(pathname)) return;

    ProjectConfig *config = new ProjectConfig(prj);
    QString tabname = prj->getConfigFilename();
    int i = tabManager->addTab(config,tabname);

    tabManager->setCurrentIndex(i);
    statusBar()->showMessage(FileUtility::replacePathWithKey(prj,pathname));
    QString projectFolder = prj->getProjectFolder();
    nav->selectFile(pathname);
    updateSaveSaveAll();
    updateIndexViews();
    updateToolbarState();
    if(dataView->getClassViewProject() != prj)
        dataView->updateClassView(prj);

    /*
    ProjectConfig *configTab = new ProjectConfig;
    configTab->setProject(prj);

    QString tabname = prj->getConfigFilename();
    int i = tabManager->addTab(configTab,tabname);
    tabManager->setCurrentIndex(i);
    //    tabManager->widget(i)->setProperty("project",prj->getName());
    //    tabManager->widget(i)->setProperty("projectFolder",prj->getProjectFolder());
    //    tabManager->widget(i)->setProperty("pathname",prj->getProjectFolder()+"/"+prj->getConfigFilename());
    //    tabManager->widget(i)->setProperty("prj",qVariantFromValue((void *) prj));

    //    statusBar()->showMessage(tabManager->widget(i)->property("pathname").toString());
    //    eventTabSelChanged(i);
    QString projectFolder = prj->getProjectFolder();
    statusBar()->showMessage(pathname);
    nav->selectFile(pathname,projectFolder);
    updateSaveSaveAll();
    updateOutlineView();
    updateToolbarState();
    if(dataView->getClassViewProject() != prj)
        dataView->updateClassView(prj);
*/
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::downloadComplete()
{
    QObject *sender = QObject::sender();
    if(sender != NULL) sender->deleteLater();

    buildToolBar->setEnabled(true);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDownload()
{
    Project *prj = nav->getSelectedProject();

    if(prj == NULL)
    {
        console->appendLine("No project selected.");
        return;
    }

    QString pathname = prj->getBuildFolder()+"/"+prj->getName()+".bin";

    // make sure build file exists and is readable
    QFileInfo info(pathname);
    if(!info.exists())
    {
        console->appendLine(".bin file doesn't exist.");
        return;
    }
    if(!info.isReadable())
    {
        console->appendLine(".bin file not currently readable.");
        return;
    }

    // get target info
    Target target = prj->getTarget();
    QString cmd = FileUtility::replaceKeyWithPath(NULL,target.getFlashProgramTool());
    /*
#ifdef Q_OS_WIN
    cmd += ".exe";
    #endif
*/
    QString args = target.getFlashProgramArgs().simplified();
    QStringList argList = args.split(' ');
    for(int i=0;i<argList.size();i++)
    {
        QString s = argList.at(i);
        if(s.contains("${filename}"))
        {
            s.replace("${filename}","\""+pathname+"\"");
            argList.replace(i,s);
        }
    }

    // ConsoleProcess is a QProcess that outputs all its text to the console widget.
    ConsoleProcess *p = new ConsoleProcess(this);
    connect(p,SIGNAL(finished()),this,SLOT(downloadComplete()));

    if(!p->start(cmd,argList))
        return;
    buildToolBar->setEnabled(false);
    return;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDebug()
{
    if(actionInProgress) return;

    if(debug != NULL)
        QMessageBox::critical(this,"Error","Debug pointer is in use!");

    console->clear();

    Project *prj = nav->getSelectedProject();
    if(prj == NULL)
    {
        console->appendLine("No project selected.");
        return;
    }
    QString buildFolder = prj->getBuildFolder();
    QString prjName = prj->getName();
    QString pathname = buildFolder + "/" + prjName + ".elf";

    // make sure build file exists and is readable
    QFileInfo info(pathname);
    if(!info.exists())
    {
        QMessageBox::information(this,"Debug","The .elf file was not found, build the project.");
        return;
    }
    if(!info.isReadable())
    {
        QMessageBox::information(this,"Debug","The .elf file was not readable.");
        return;
    }

    console->appendLine("Starting " + prjName + " debug.");

    debug = new Debug(this); // actionDebugTerminate to close this out when done.
    connect(tabManager,SIGNAL(addBreakpoint(QString,int)),debug,SLOT(addBreakPoint(QString,int)));
    connect(tabManager,SIGNAL(removeBreakpoint(QString,int)),debug,SLOT(removeBreakPoint(QString,int)));
    connect(debug,SIGNAL(finished()),this,SLOT(actionDebugTerminate()));

    if(!debug->start(prj))
    {
        if(debug != NULL)
            debug->deleteLater();
        debug = NULL;
        debugToolBar->setVisible(false);
        buildToolBar->setVisible(true);
        return;
    }

    debugRunning = true;
    dataView->showDebugViews(true);
    updateDebugUi();

    // set breakpoints
    QList<S_Breakpoint> bpList = prj->getBreakpoints();
    foreach(S_Breakpoint bp,bpList)
        debug->addBreakPoint(bp.pathname,bp.lineNumber);

    debugToolBar->setVisible(true);
    buildToolBar->setVisible(false);

    enableAction(debugToolBar,"Resume");
    disableAction(debugToolBar,"Suspend");
    enableAction(debugToolBar,"Step over");
    enableAction(debugToolBar,"Step into");
    enableAction(debugToolBar,"Step return");

    connect(debug,SIGNAL(signalGdbAtPrompt()),this,SLOT(slotDebugAtPrompt()));
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionSelectProbe()
{

}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionTerminal()
{
    //    TerminalWindow *terminalWindow = new TerminalWindow(this);
    if(terminalWindow == NULL)
    {
        terminalWindow = new TerminalWindow(this);
        connect(terminalWindow,SIGNAL(TerminalClosing()),this,SLOT(slotTerminalClosing()));
        if(ProgramConfig::contains(TERMINAL_WINDOW_GEOMETRY))
            terminalWindow->setGeometry(ProgramConfig::get(TERMINAL_WINDOW_GEOMETRY).toRect());
    }
    terminalWindow->setWindowState(Qt::WindowActive);
    terminalWindow->show();
    terminalWindow->raise();
    terminalWindow->setFocus();
    terminalWindow->activateWindow();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::slotTerminalClosing()
{
    terminalWindow = NULL;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionTestVar()
{
    Project *prj = nav->getSelectedProject();
    if(prj == NULL) return;
    prj->update();
    prj->runIndexer();
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionTest()
{
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::threadBuildProject(Project *prj)
{
    prj->build();
    qDebug() << "done prj->build()";
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::slotBuildComplete(bool retval, Project *prj)
{
    qDebug() << "MainWindow::slotBuildComplete " << retval << " " << prj->getName();
    (void) retval; // unused
    nav->updateProjectTree(prj);
    disconnect(prj,SIGNAL(buildComplete(bool,Project*)),this,SLOT(slotBuildComplete(bool,Project*)));
    enableAction(buildToolBar,"Build project",true);
    actionInProgress = false;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::slotDebugComplete(Debug *debug)
{
    debug->deleteLater();
    debug = NULL;
    enableAction(buildToolBar,"Build project",true);
    enableAction(buildToolBar,"Download binary",true);
    enableAction(buildToolBar,"Start debug",true);
    actionInProgress = false;
}

//=============================================================================

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::loadMainWindowConfig()
{    
    ProgramConfig::load();

    if(ProgramConfig::contains(MAIN_WINDOW_GEOMETRY))
        setGeometry(ProgramConfig::get(MAIN_WINDOW_GEOMETRY).toRect());
    else
    {
        viewReset();
        return;
    }

    if(ProgramConfig::contains(MAIN_WINDOW_HSPLIT_STATE))
    {
        QList<QVariant> hlist;
        hlist = ProgramConfig::get(MAIN_WINDOW_HSPLIT_STATE).toList();
        QList<int> ihlist;
        foreach(QVariant v,hlist)
            ihlist.append(v.toInt());
        hSplit->setSizes(ihlist);
    }

    if(ProgramConfig::contains(MAIN_WINDOW_VSPLIT_STATE))
    {
        QList<QVariant> vlist;
        vlist = ProgramConfig::get(MAIN_WINDOW_VSPLIT_STATE).toList();
        QList<int> ivlist;
        foreach(QVariant v,vlist)
            ivlist.append(v.toInt());
        vSplit->setSizes(ivlist);
    }

    if(ProgramConfig::contains(MAIN_WINDOW_GEOMETRY))
        setGeometry(ProgramConfig::get(MAIN_WINDOW_GEOMETRY).toRect());
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::saveMainWindowConfig()
{
    QList<int> ihlist = hSplit->sizes();
    QList<QVariant> hlist;
    foreach(int r,ihlist)
        hlist.append(r);

    QList<int> ivlist = vSplit->sizes();
    QList<QVariant> vlist;
    foreach(int r,ivlist)
        vlist.append(r);

#ifdef Q_OS_WIN
    QRect rect(geometry());
    rect.setHeight(rect.height());
#else
    // didn't look into details but we need to augment the height by "other stuff" calc
    // to get the same size window on load. width seems fine.
    int dh = frameGeometry().height() - geometry().height() - statusBar()->geometry().height();
    QRect rect(geometry());
    rect.setHeight(rect.height()+dh);
#endif

    // save the currently selected target map
    //    QVariant vtarget = ProgramConfig::get(CONFIG_TARGET_DATA);

    //    ProgramConfig::clear();
    ProgramConfig::set(MAIN_WINDOW_GEOMETRY,rect);
    ProgramConfig::set(MAIN_WINDOW_VSPLIT_STATE,vlist);
    ProgramConfig::set(MAIN_WINDOW_HSPLIT_STATE,hlist);
    //    ProgramConfig::set(CONFIG_TARGET_DATA,vtarget);

    QStringList prjlist;
    nav->getOpenProjectsList(&prjlist);
    ProgramConfig::set(NAVIGATOR_OPEN_PROJECT_LIST,prjlist);

    ProgramConfig::save();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::indexingComplete()
{
    qDebug() << "Indexing complete.";
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::projectIndexingComplete(Project *prj)
{
    qDebug() << "projectIndexingComplete:" << prj->getName();
    if(prj == nav->getSelectedProject())
    {
        dataView->updateClassView(prj);
        QString pathname = nav->getSelectedFilepath();
        // Indexer *autoCompleteIndexer = NULL;
        //        SourceEditor *editor = tabManager->currentEditor();
        //        if(editor != NULL)
        //            autoCompleteIndexer = editor->getOutlineIndexer();
        //        dataView->updateOutlineView(autoCompleteIndexer,pathname);
        if(prj != NULL)
            dataView->updateOutlineView(prj->getIndexer(),pathname);
    }
}

//!----------------------------------------------------------------------------
//! \brief  SLOT: When a ClassView item is clicked, open the associated source file
//!         and scroll to the indicated line number. If the selected item
//!         is a function then toggle between the definition and implementation
//!         when clicked.
//!----------------------------------------------------------------------------
void MainWindow::classViewTreeItemClicked(QModelIndex index)
{
    Tag *tag = index.data(Qt::UserRole+1).value<Tag*>();
    if(tag == NULL) return;

    // default direction is to go to the tag pathname and line
    QString tagPathname = tag->pathname;
    int tagLine = tag->line;

    // if the tag is a function toggle between the function and prototype when clicked.
    if(tag->tagType == Tag::Function)
    {
        // check to see if we are already on either the function line or prototype line
        SourceEditor *editor = tabManager->currentEditor();
        if(editor != NULL)
        {
            QString editorPathname = editor->getPathname();
            int editorLineNum,editorColNum;
            editor->getCursorPosition(&editorLineNum,&editorColNum);
            editorLineNum++;

            // if we are in the implementation file...
            if(editorPathname == tag->pathname)
            {
                // if we are on the implementation line
                if(editorLineNum == tag->line)
                {
                    // switch to prototype
                    if(!tag->protoPathname.isEmpty())
                    {
                        tagPathname = tag->protoPathname;
                        tagLine = tag->protoline;
                    }
                    // we are on the implementation line and there is no prototype, don't do anything
                    else
                        return;
                }
                // in the file, but not on the line, go to tagPathname, tagLine.
                // tagPathname and tagLine are already pointing to where we want to go.
            }
            // see if we are in the prototype file...
            else if(editorPathname == tag->protoPathname)
            {
                if(editorLineNum == tag->protoline)
                {
                    // switch to implementation
                    if(!tag->pathname.isEmpty())
                    {
                        tagPathname = tag->pathname;
                        tagLine = tag->line;
                    }
                    else
                        return;
                }
                else
                {
                    // in the file but not on the line, go to line
                    tagPathname = tag->protoPathname;
                    tagLine = tag->protoline;
                }
            }
        }
    }

    // goto the file and line number.
    slotRequestFileOpen(tagPathname,tagLine,0);
}


//=============================================================================
//
//                          Project Signal Handlers
//
//=============================================================================
//!----------------------------------------------------------------------------
//! \brief This is a slot that gets called by the Project class requesting that
//! project level indexing be performed. We do this here because we need the
//! TabManager to access the text from dirty editors for the project.
//!----------------------------------------------------------------------------
void MainWindow::runProjectIndexer(Project *prj)
{
    if(prj==NULL || tabManager==NULL) return;
    Indexer *indexer = prj->getIndexer();
    indexer->indexProject(prj,tabManager);
}

void MainWindow::projectAdded(Project *prj)
{
    if(prj != NULL)
        connect(prj,SIGNAL(indexProject(Project*)),this,SLOT(runProjectIndexer(Project*)));
}

//=============================================================================
//
//                          TabManager Signal Handlers
//
//=============================================================================


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::editorIndexFinished(SourceEditor *editor)
{
    Q_UNUSED(editor);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::setStatusMessage(QString msg)
{
    statusBar()->showMessage(msg);
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::minimizeInfoView()
{
    // their are two items in the split, the first is the editor window
    // the second is the infoView.
    QList<int> sizes = vSplit->sizes();

    int editorSize = sizes.at(0);
    int infoSize = sizes.at(1);
    if(infoSize == 0)
    {
        if(infoViewSize == 0)
            infoViewSize = infoView->minimumSizeHint().height();
        editorSize -= infoViewSize;
        sizes.replace(0,editorSize);
        sizes.replace(1,infoViewSize);
        vSplit->setSizes(sizes);
    }
    else
    {
        editorSize += infoSize;
        infoViewSize = infoSize;
        sizes.replace(0,editorSize);
        sizes.replace(1,0);
        vSplit->setSizes(sizes);
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::restoreInfoView()
{
    // their are two items in the split, the first is the editor window
    // the second is the infoView.
    QList<int> sizes = vSplit->sizes();

    int editorSize = sizes.at(0);
    int infoSize = sizes.at(1);
    if(infoSize != 0) return;

    if(infoViewSize == 0)
        infoViewSize = infoView->minimumSizeHint().height();

    editorSize -= infoViewSize;
    sizes.replace(0,editorSize);
    sizes.replace(1,infoViewSize);
    vSplit->setSizes(sizes);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::cleanProjectFolder(QString pathname)
{
    QFileInfo info(pathname);
    if(info.fileName().startsWith('.')) return;
    if(pathname.contains("__MACOSX")) return;
    if(!info.isDir())
        return;

    if(isProjectFolder(pathname))
    {
        // this is a project folder, erase the build directory
        QString buildFolder = pathname + "/build";
        buildFolder = buildFolder.replace("\\","/");
        buildFolder = buildFolder.replace("//","/");
        QFileInfo buildInfo(buildFolder);
        if(!buildInfo.exists()) return;
        qDebug() << "cleaning:" << buildInfo.absoluteFilePath();
        FileUtility::eraseDir(buildFolder);
    }
    else
    {
        // this is a folder but not a project folder, recurse into it
        QDir dir(pathname);
        QFileInfoList fileInfoList = dir.entryInfoList();
        foreach(QFileInfo info,fileInfoList)
        {
            if(info.fileName().startsWith('.') || info.absoluteFilePath().contains("__MACOSX"))
                continue;
            if(!info.isDir()) continue;
            if(!isProjectFolder(info.absoluteFilePath())) continue;
            cleanProjectFolder(info.absoluteFilePath());
        }
    }
}

void MainWindow::cleanAllProjects()
{
    // clean all projects and examples, removing the build folder and contents
    QString pathname;

    pathname = FileUtility::getDirProjects();
    cleanProjectFolder(pathname);

    pathname = FileUtility::getDirExamples();
    cleanProjectFolder(pathname);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::zipUtility()
{
    // select a folder to zip until cancel is pressed
    while(true)
    {
        QString path = QFileDialog::getExistingDirectory(this, tr("Select folder to zip"),
                                                         FileUtility::getDocumentsPath(),
                                                         QFileDialog::ShowDirsOnly
                                                         | QFileDialog::DontResolveSymlinks);
        if(path.isEmpty()) return;
        // zip it
        Zip zip;
        ProgressDialog progress(this);
        progress.set("Zip",0,1);
        connect(&zip,SIGNAL(progress(QString,int,int)),&progress,SLOT(set(QString,int,int)));

        if(!zip.zip(path))
            QMessageBox::critical(this,"Error","Error creating zip file.");
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::archiveProject()
{
    // get currently selected project
    Project *prj = nav->getSelectedProject();
    if(prj == NULL)
    {
        QMessageBox::information(this,"Archive","No project selected.");
        return;
    }

    ProjectArchiver ar(prj,this);
    connect(&ar,SIGNAL(updateProjectTree(Project*)),nav,SLOT(updateProjectTree(Project*)));
    connect(&ar,SIGNAL(closeTabs(Project*)),tabManager,SLOT(closeTabs(Project*)));
    ar.exec();
}
