#include <QtGui>
#include <QDebug>
#include <QToolBar>
#include <QLineEdit>
#include <QAction>
#include <QFutureWatcher>

#include "mainwindow.h"
#include "programconfig.h"
#include "config/configeditor.h"
#include "infoview.h"
#include "indexer/indexer.h"
#include "utility/projectnamedialog.h"
#include "utility/fileutility.h"
#include "project/project.h"
#include "Views/console.h"
#include "gdb/debugcontrol.h"
#include "Views/dataview.h"
#include "Views/classview.h"

//============================================================================
//
//                             DEBUG SUPPORT
//
//============================================================================

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::setDebugInfoText(QString text)
{
    QList<QAction*> actionList = debugToolBar->actions();
    foreach(QAction *action,actionList)
    {
        QWidget *widget = debugToolBar->widgetForAction(action);
        if(widget->inherits("QLineEdit"))
        {
            QLineEdit *edit = (QLineEdit*) widget;
            edit->setText(text);
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString MainWindow::getDebugInfoText()
{
    QList<QAction*> actionList = debugToolBar->actions();
    foreach(QAction *action,actionList)
    {
        QWidget *widget = debugToolBar->widgetForAction(action);
        if(widget->inherits("QLineEdit"))
        {
            QLineEdit *edit = (QLineEdit*) widget;
            return edit->text();
        }
    }
    return QString("");
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::updateDebugUi()
{
    QString pathname,function;
    int line;

    if(debug->getSourceInfo(&pathname,&function,&line))
    {
        // When we compile we use pathnames that are relative to the home dir.
        // This is important because we don't want to have to require users to recompile libraries
        // after install, but we want them to still be able to step into them if they want to.
        // During debug if you try to step into a library file it will have the pathname of
        // whatever pathname it was compiled under. So if you use the full pathname during
        // compile it won't match on someone elses computer and we won't find the code.
        // So, here we want to prepend the relative pathname with our current home directory
        // so we can find the code.
        pathname = FileUtility::getDirHome() + "/" + pathname;
//        qDebug() << "debug line2:"<<line<<" file:"<<pathname;
        slotRequestFileOpen(pathname,line,0);
    }

    dataView->updateView(debug);
    setDebugInfoText("SUSPENDED");
    enableAction(debugToolBar,"Resume");
    disableAction(debugToolBar,"Suspend");
    enableAction(debugToolBar,"Step over");
    enableAction(debugToolBar,"Step into");
    enableAction(debugToolBar,"Step return");
    dataView->setEnabled(true);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDebugResume()
{
    disableDebugRunTools();
    setDebugInfoText("RUNNING");
    debug->run();

}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDebugSuspend()
{
    disableAction(debugToolBar,"Suspend");
    debug->pause();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDebugTerminate()
{
    debugRunning = false;
    dataView->showDebugViews(false);
    //    disconnect(tabManager,SIGNAL(addBreakpoint(QString,int)),debug,SLOT(addBreakPoint(QString,int)));
    //    disconnect(tabManager,SIGNAL(removeBreakpoint(QString,int)),debug,SLOT(removeBreakPoint(QString,int)));
    disconnect(debug,SIGNAL(finished()),this,SLOT(actionDebugTerminate()));
    debug->close();
    debugToolBar->setVisible(false);
    buildToolBar->setVisible(true);
    debug->deleteLater();
    debug = NULL;
    setStepModeIcon(false);
    dataView->setEnabled(true);
}

//!----------------------------------------------------------------------------
//! \brief Step over current instruction, ie not into. This sends the command
//! to gdb to step over. When the step is complete debug will emit
//! signalGdbAtPrompt();
//!----------------------------------------------------------------------------
void MainWindow::actionDebugStepOver()
{
    disableDebugRunTools();
    setDebugInfoText("STEPPING");
    debug->stepOver();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDebugStepInto()
{
    disableDebugRunTools();
    setDebugInfoText("STEPPING");
    debug->stepInto();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDebugStepReturn()
{
    disableDebugRunTools();
    setDebugInfoText("RUNNING");
    debug->stepReturn();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::actionDebugStepMode()
{
    bool stepMode = debug->getStepMode();
    stepMode = !stepMode;
    setStepModeIcon(stepMode);
    debug->setStepMode(stepMode);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::setStepModeIcon(bool mode)
{
    QList<QAction*> actionList = debugToolBar->actions();
    foreach(QAction *action,actionList)
    {
        if((action->text() == "Switch to source stepping") ||
                (action->text() == "Switch to assembly stepping"))
        {
            if(mode)
            {
                action->setIcon(QIcon(":/icons/icons/istep_asm.png"));
                action->setToolTip("Switch to source stepping");
            }
            else
            {
                action->setIcon(QIcon(":/icons/icons/istep_src.png"));
                action->setToolTip("Switch to assembly stepping");
            }
            break;
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::slotDebugAtPrompt()
{
    qDebug() << "MainWindow::slotDebugAtPrompt()";
    if(debugRunning)
        updateDebugUi();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void MainWindow::disableDebugRunTools()
{
    disableAction(debugToolBar,"Resume");
    enableAction(debugToolBar,"Suspend");
    disableAction(debugToolBar,"Step over");
    disableAction(debugToolBar,"Step into");
    disableAction(debugToolBar,"Step return");
    dataView->setEnabled(false);
}

