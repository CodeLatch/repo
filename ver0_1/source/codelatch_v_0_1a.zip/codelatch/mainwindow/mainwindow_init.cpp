//!----------------------------------------------------------------------------
//! file: mainwindow_init.cpp
//!
//! Implements the main window initialization.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include <QtGui>
#include <QDebug>
#include <QStatusBar>
#include <QShortcut>
#include <QToolBar>
#include <QMenuBar>
#include <QInputDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>
#include "mainwindow.h"
#include "programconfig.h"
#include "infoview.h"
#include "tabmanager.h"
#include "gdb/debugcontrol.h"
#include "Views/dataview.h"
#include "Views/classview.h"

#include <QPushButton>
#include <QGridLayout>
#include <QToolBar>

//!-----------------------------------------------------------------------------
//! \brief  Create the main window widgets.
//!-----------------------------------------------------------------------------
void MainWindow::createWidgets()
{
    tabManager = new TabManager;
    tabManager->setDocumentMode(true);
    tabManager->setTabsClosable(true);
    tabManager->setMovable(true);
    tabManager->setStyleSheet(
                "QTabBar {font-size: 11px;}"
                "QTabBar::tab {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #E1E1E1, stop: 0.4 #DDDDDD,stop: 0.5 #D8D8D8, stop: 1.0 #D3D3D3);}"
                "QTabBar::tab {border: 2px solid #C4C4C3;}"
                "QTabBar::tab {border-bottom-color: #C2C7CB;}"
                "QTabBar::tab {border-top-left-radius: 4px;}"
                "QTabBar::tab {border-top-right-radius: 4px;}"
                "QTabBar::tab {min-width: 5px;}"
                "QTabBar::tab {padding: 2px;}"
                "QTabBar::tab {padding-left: 2px;}"
                "QTabBar::tab {padding-right: 10px;}"
                "QTabBar::tab:selected, QTabBar::tab:hover {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #fafafa, stop: 0.4 #f4f4f4, stop: 0.5 #e7e7e7, stop: 1.0 #fafafa);}"
                "QTabBar::tab:selected {border-color: #9B9B9B; border-bottom-color: #ebebeb;}"
                "QTabBar::tab:!selected {margin-top: 1px;}"
                "QTabBar::close-button {subcontrol-position: left;}"
                );

    vSplit = new QSplitter(Qt::Vertical);
    vSplit->setHandleWidth(4);
    vSplit->addWidget(tabManager);
    infoView = new InfoView(this); // need to pass MainWindow as parent so FindReplaceWidget will get access.
    vSplit->addWidget(infoView);
    // cause tabManager to expand/contract and infoView to stay the same size on resizing.
    vSplit->setStretchFactor(0, 1);

    // add a toolbar to the vertical splitter so we can add some buttons to it.
    // placing the toolbar in the splitter will keep it visible when the
    // infoView is minimized.
    vSplit->setHandleWidth(20);
    QSplitterHandle *splitterHandle = vSplit->handle(1);
    QHBoxLayout *tbLayout = new QHBoxLayout();
    QToolBar *toolbar = new QToolBar;
    toolbar->setIconSize(QSize(16,16));
    //    toolbar->addAction(QIcon(":/icons/icons/clear_console.png"),"Clear console",infoView,SLOT(clearConsole()));
    // add space to force remaining icons to right side
    QWidget *spacer = new QWidget;
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    toolbar->addWidget(spacer);
    toolbar->addAction(QIcon(":/icons/icons/minmax.png"),"minimize/restore",this,SLOT(minimizeInfoView()));
    toolbar->setStyleSheet("QToolBar {spacing: 0px;} QToolButton { border-radius: 5px; border: none; }");
    tbLayout->addWidget(toolbar);
    tbLayout->setSpacing(0);
    tbLayout->setMargin(0);
    splitterHandle->setLayout(tbLayout);
    QList<int> sizes = vSplit->sizes();
    infoViewSize = sizes.at(1);
    infoView->initToolbar(tbLayout);

    nav = new NavTree;
    dataView = new DataView(this);
    hSplit = new QSplitter(Qt::Horizontal);
    hSplit->setHandleWidth(4);
    hSplit->addWidget(nav);
    hSplit->addWidget(vSplit);
    hSplit->addWidget(dataView);
    // cause center pane to resize, others stay fixed on resizing.
    hSplit->setStretchFactor(1, 1);

    setCentralWidget(hSplit);
}

//!-----------------------------------------------------------------------------
//! \brief  Makes one time connections.
//!-----------------------------------------------------------------------------
void MainWindow::makeConnections()
{
    // nav can signal tabManager to activate a tab or open a file (re single or double click on nav item)
    connect (nav, SIGNAL(projectIndexingComplete(Project *)), this, SLOT(projectIndexingComplete(Project*)));
    connect (nav, SIGNAL(sigNewFile()),this,SLOT(newFile()));
    connect (nav, SIGNAL(sigNewFolder()),this,SLOT(newFolder()));
    connect (nav, SIGNAL(sigDelete()),this,SLOT(actionDeleteItem()));
    connect (nav, SIGNAL(sigRename()),this,SLOT(navContextMenuRename()));
    connect (nav, SIGNAL(sigCloseProject(Project*)), this, SLOT(closeProject(Project*)));
    connect (nav, SIGNAL(sigProjectSaveAs()),this, SLOT(saveAsProject()));
    connect (nav, SIGNAL(sigFileSaveAs()),this,SLOT(saveAsFile()));
    connect (nav, SIGNAL(sigUpdateDynamicProjectMenu()),this,SLOT(updateDynamicProjectMenu()));
    connect (nav, SIGNAL(projectAdded(Project*)),this,SLOT(projectAdded(Project*)));

    // these two connections allow the navigator and tabManager to stay sync'ed to each other.
    connect (tabManager,SIGNAL(selectionChanged(QString)), nav,SLOT(selectFile(QString)));
    connect (nav, SIGNAL(singleClicked(Project*,QString)), tabManager, SLOT(selectEditor(Project*,QString)));

    // allow main window to manage updating index views
    connect (tabManager,SIGNAL(selectionChanged(QString)), this,SLOT(updateIndexViews()));
//    connect (nav, SIGNAL(singleClicked(Project*,QString)), this, SLOT(updateIndexViews()));
    connect (nav, SIGNAL(sigSelectionChanged(Project*,QString)),this, SLOT(updateIndexViews()));
    connect (tabManager,SIGNAL(documentIndexFinished(Indexer*)), this, SLOT(updateIndexViews()));

    connect (tabManager, SIGNAL(updateBreakpointView(Project*)), infoView, SLOT(updateBreakpointView(Project*)));

    // navigator signals tabManager when to open a file or if the file has been renamed.
    connect (nav, SIGNAL(doubleClicked(Project*,QString)), tabManager, SLOT(openEditor(Project*,QString)));
    connect (nav, SIGNAL(sigOpenFile(Project*,QString,int)), tabManager, SLOT(openEditor(Project*,QString,int)));
    connect (nav, SIGNAL(sigFileMoved(QString,QString,Project*)),tabManager,SLOT(filePathChanged(QString,QString,Project*)));

    connect (tabManager,SIGNAL(setStatusMessage(QString)),this,SLOT(setStatusMessage(QString)));
    connect (tabManager,SIGNAL(updateSaveSaveAll()),this,SLOT(updateSaveSaveAll()));
    connect (tabManager,SIGNAL(updateToolbarState()),this,SLOT(updateToolbarState()));

    connect (tabManager,SIGNAL(updateClassView(Project*)),dataView,SLOT(updateClassView(Project*)));
    connect (tabManager,SIGNAL(requestFileOpen(QString,int,int)),this,SLOT(slotRequestFileOpen(QString,int,int)));

    connect (dataView,SIGNAL(currentChanged(int)),this,SLOT(dataViewTabSelChanged(int)));
    connect (dataView->classView,SIGNAL(treeItemClicked(QModelIndex)),this,SLOT(classViewTreeItemClicked(QModelIndex)));
    connect (dataView->outlineView,SIGNAL(treeItemClicked(QModelIndex)),this,SLOT(classViewTreeItemClicked(QModelIndex)));
    //!    connect (dataView->classView,SIGNAL(treeItemClicked(QModelIndex)),this,SLOT(classViewTreeItemClicked(QModelIndex)));

    connect (console,SIGNAL(signalOpenEditor(QString,int)),nav,SLOT(openFile(QString,int)));

    // setup infoView interaction with other items regarding break points.
    connect (nav,SIGNAL(sigSelectionChanged(Project*,QString)),infoView,SLOT(navItemChanged(Project*,QString)));
    connect (tabManager,SIGNAL(addBreakpoint(QString,int)),infoView,SLOT(addBreakpoint(QString,int)));
    connect (tabManager,SIGNAL(removeBreakpoint(QString,int)),infoView,SLOT(removeBreakpoint(QString,int)));
    connect (infoView, SIGNAL(activateFile(QString,int)), nav, SLOT(openFile(QString,int)));

    // when a debug frame item is clicked in the dataView->variableView goto that file/line.
    connect (dataView, SIGNAL(activateFile(QString,int)), nav, SLOT(openFile(QString,int)));
}

//!-----------------------------------------------------------------------------
//! \brief  Create the main menu.
//!-----------------------------------------------------------------------------
void MainWindow::createMenu()
{
    // File Menu
    fileMenu = menuBar()->addMenu(tr("&File"));

    QMenu *fileSubMenu = fileMenu->addMenu(STR_FILE_MENU_FILE);
    fileSubMenu->addAction(STR_FILE_MENU_FILE_NEW,this,SLOT(newFile()),QKeySequence::New);
    fileSubMenu->addAction(STR_FILE_MENU_FILE_OPEN,this,SLOT(openFile()),QKeySequence::Open);
    fileSubMenu->addAction(STR_FILE_MENU_FILE_SAVE,tabManager,SLOT(saveFile()),QKeySequence::Save);
    fileSubMenu->addAction(STR_FILE_MENU_FILE_SAVE_AS,this,SLOT(saveAsFile()),QKeySequence::SaveAs);

    QMenu *projectSubMenu = fileMenu->addMenu(STR_FILE_MENU_PROJECT);
    projectSubMenu->addAction(STR_FILE_MENU_PROJECT_NEW,this,SLOT(newProject()));
    projectSubMenu->addAction(STR_FILE_MENU_PROJECT_OPEN,this,SLOT(openProject()));
    projectSubMenu->addAction(STR_FILE_MENU_PROJECT_SAVE_AS,this,SLOT(saveAsProject()));
    projectSubMenu->addAction(STR_FILE_MENU_PROJECT_CLOSE,this,SLOT(closeProject()));

    fileMenu->addSeparator();

    QMenu *projectsMenu = fileMenu->addMenu(STR_FILE_MENU_PROJECTS);
    fileMenu->addSeparator();
    QMenu *examplesMenu = fileMenu->addMenu(STR_FILE_MENU_EXAMPLES);
    QMenu *libsMenu = fileMenu->addMenu(STR_FILE_MENU_LIBRARIES);
    fileMenu->addSeparator();
    fileMenu->addAction(STR_FILE_MENU_PRINT,this,SLOT(printFile()),QKeySequence::Print);

    connect(fileMenu,SIGNAL(aboutToShow()),this,SLOT(updateFileMenuState()));
    connect(examplesMenu, SIGNAL(triggered(QAction*)), this, SLOT(dynamicMenuItemSelected(QAction*)));
    connect(projectsMenu, SIGNAL(triggered(QAction*)), this, SLOT(dynamicMenuItemSelected(QAction*)));
    connect(libsMenu, SIGNAL(triggered(QAction*)), this, SLOT(dynamicMenuItemSelected(QAction*)));
    updateDynamicProjectMenu();

    // Edit Menu
    editMenu = menuBar()->addMenu(tr("&Edit"));
    editMenu->addAction(STR_EDIT_MENU_UNDO,this,SLOT(actionUndo()),QKeySequence::Undo);
    editMenu->addAction(STR_EDIT_MENU_REDO,this,SLOT(actionRedo()),QKeySequence::Redo);
    editMenu->addSeparator();
    editMenu->addAction(STR_EDIT_MENU_CUT,this,SLOT(actionCut()),QKeySequence::Cut);
    editMenu->addAction(STR_EDIT_MENU_COPY,this,SLOT(actionCopy()),QKeySequence::Copy);
    editMenu->addAction(STR_EDIT_MENU_PASTE,this,SLOT(actionPaste()),QKeySequence::Paste);
    editMenu->addSeparator();
    editMenu->addAction(STR_EDIT_MENU_FIND_REPLACE,this,SLOT(actionFind()),QKeySequence::Find);
    editMenu->addAction(STR_EDIT_MENU_GOTO_LINE,this,SLOT(actionGoto()),QKeySequence(tr("Ctrl+G")));
    editMenu->addAction(STR_EDIT_MENU_JUMP_TO_CODE,tabManager,SLOT(jumpToCode()),QKeySequence("Ctrl+J"));
    editMenu->addSeparator();
    editMenu->addAction(STR_EDIT_MENU_FORMAT_DOCUMENT,this,SLOT(actionFormatDocument()),QKeySequence("Ctrl+I"));

    QShortcut *jumpKey = new QShortcut(QKeySequence(Qt::Key_F2), this);
    //    disableAction(editMenu,STR_EDIT_MENU_UNDO);
    //    disableAction(editMenu,STR_EDIT_MENU_REDO);
    connect(editMenu,SIGNAL(aboutToShow()),this,SLOT(updateEditMenuState()));
    connect(jumpKey, SIGNAL(activated()), tabManager, SLOT(jumpToCode()));


    // Tools Menu
    toolsMenu = menuBar()->addMenu(tr("&Tools"));
    toolsMenu->addSeparator();
    toolsMenu->addAction(STR_TOOLS_MENU_OPEN_REFERENCE,this,SLOT(openReference()));
    toolsMenu->addAction(STR_TOOLS_MENU_OPEN_HOME_FOLDER,this,SLOT(openHomeFolder()));
    toolsMenu->addAction(STR_TOOLS_MENU_SET_MAIN_FOLDER,this,SLOT(changeRootLocation()));
    toolsMenu->addSeparator();
    //    toolsMenu->addAction(STR_TOOLS_MENU_CONFIGURE_EDITOR,this,SLOT(openEditorConfig()));
    toolsMenu->addAction(STR_TOOLS_MENU_RESET_VIEW,this,SLOT(viewReset()));
    toolsMenu->addAction(STR_TOOLS_MENU_REBUILD_MENU,this,SLOT(updateDynamicProjectMenu()));
    toolsMenu->addAction(STR_TOOLS_MENU_INDEX_PROJECT,this,SLOT(indexActiveProject()));
    toolsMenu->addSeparator();
    toolsMenu->addAction(STR_TOOLS_MENU_CHECK_FOR_UPDATES,this,SLOT(showDownloadComponentsDlg()));
#ifdef QT_DEBUG
    toolsMenu->addAction("Zip Utility",this,SLOT(zipUtility()));
#endif
    toolsMenu->addAction("Clean All Projects",this,SLOT(cleanAllProjects()));
    toolsMenu->addAction(STR_TOOLS_MENU_ABOUT,this,SLOT(about()));

}

//!----------------------------------------------------------------------------
//! \brief  Create the main toolbar.
//!----------------------------------------------------------------------------
void MainWindow::createToolbar()
{
    // create file toolbar
    fileToolBar = addToolBar(tr("File"));
    fileToolBar->setIconSize(QSize(16,16));
    fileToolBar->addSeparator();
    fileToolBar->addAction(QIcon(":/icons/icons/save.png"),STR_FILE_MENU_FILE_SAVE,tabManager,SLOT(saveFile()));
    fileToolBar->addAction(QIcon(":/icons/icons/saveall.png"),STR_FILE_MENU_FILE_SAVE_ALL,tabManager,SLOT(saveAllFile()));
    fileToolBar->addAction(QIcon(":/icons/icons/compress.png"),"Archive Project",this,SLOT(archiveProject()));
    fileToolBar->addSeparator();
    fileToolBar->addAction(QIcon(":/icons/icons/newfile.png"),STR_FILE_MENU_FILE_NEW,this,SLOT(newFile()));
    fileToolBar->addAction(QIcon(":/icons/icons/newfolder.png"),"New folder",this,SLOT(newFolder()));
    fileToolBar->addSeparator();
    fileToolBar->addAction(QIcon(":/icons/icons/close.png"),STR_FILE_MENU_PROJECT_CLOSE,this,SLOT(closeProject()));
    fileToolBar->addSeparator();
    fileToolBar->addAction(QIcon(":/icons/icons/trash.png"),"Delete item",this,SLOT(actionDeleteItem()));
    fileToolBar->addSeparator();
    fileToolBar->addAction(QIcon(":/icons/icons/autoformat.png"),"Format document",this,SLOT(actionFormatDocument()));

    // create build toolbar
    buildToolBar = addToolBar(tr("Build"));
    buildToolBar->setIconSize(QSize(16,16));
    buildToolBar->addSeparator();
    buildToolBar->addAction(QIcon(":/icons/icons/build.png"),"Build project",this,SLOT(actionBuild()));
    buildToolBar->addAction(QIcon(":/icons/icons/clean.png"),"Clean project",this,SLOT(actionClean()));
    buildToolBar->addAction(QIcon(":/icons/icons/config.png"),"Edit project config",this,SLOT(actionOpenProjectConfig()));
    buildToolBar->addSeparator();
    buildToolBar->addAction(QIcon(":/icons/icons/flash.png"),"Download binary",this,SLOT(actionDownload()));
    buildToolBar->addAction(QIcon(":/icons/icons/bug.png"),"Start debug",this,SLOT(actionDebug()));
    //    buildToolBar->addAction(QIcon(":/icons/icons/usbconn.png"),"Select debug probe",this,SLOT(actionSelectProbe()));
    buildToolBar->addSeparator();
    buildToolBar->setAllowedAreas(Qt::TopToolBarArea);
    addToolBar(Qt::TopToolBarArea, buildToolBar);

    // create debug toolbar
    debugToolBar = addToolBar(tr("Debug"));
    debugToolBar->setIconSize(QSize(16,16));
    debugToolBar->addSeparator();
    debugToolBar->addAction(QIcon(":/icons/icons/resume.png"),"Resume",this,SLOT(actionDebugResume()));
    debugToolBar->addAction(QIcon(":/icons/icons/suspend.png"),"Suspend",this,SLOT(actionDebugSuspend()));
    debugToolBar->addAction(QIcon(":/icons/icons/terminate.png"),"Terminate",this,SLOT(actionDebugTerminate()));
    debugToolBar->addWidget(new QLabel(" ")); // add space between toolbars
    debugToolBar->addAction(QIcon(":/icons/icons/stepover.png"),"Step over",this,SLOT(actionDebugStepOver()));
    debugToolBar->addAction(QIcon(":/icons/icons/stepinto.png"),"Step into",this,SLOT(actionDebugStepInto()));
    debugToolBar->addAction(QIcon(":/icons/icons/stepreturn.png"),"Step return",this,SLOT(actionDebugStepReturn()));
    debugToolBar->addAction(QIcon(":/icons/icons/istep_src.png"),"Switch to assembly stepping",this,SLOT(actionDebugStepMode()));
    QLineEdit *debugRunInfo = new QLineEdit(debugToolBar);
    debugRunInfo->setMaximumWidth(100);
    debugRunInfo->setReadOnly(true);
    debugRunInfo->setAlignment(Qt::AlignCenter);
    debugRunInfo->setText("SUSPENDED");
    debugToolBar->addWidget(debugRunInfo);
    debugToolBar->setAllowedAreas(Qt::TopToolBarArea);
    debugToolBar->setVisible(false);
    addToolBar(Qt::TopToolBarArea, debugToolBar);

    // create utilty toolbar
    utilityToolBar = addToolBar(tr("Utility"));
    utilityToolBar->setIconSize(QSize(16,16));
    utilityToolBar->addAction(QIcon(":/icons/icons/back.png"),"Go Back",tabManager,SLOT(goBack()));
    utilityToolBar->addAction(QIcon(":/icons/icons/forward.png"),"Go Forward",tabManager,SLOT(goForward()));
    utilityToolBar->addSeparator();
    utilityToolBar->addAction(QIcon(":/icons/icons/terminal.png"),"Start terminal",this,SLOT(actionTerminal()));
    utilityToolBar->addSeparator();
    utilityToolBar->addAction(QIcon(":/icons/icons/edit-target.png"),"Edit Target",this,SLOT(actionEditTarget()));
    targetSelCombo = new QComboBox(this);
    targetSelCombo->setSizeAdjustPolicy(QComboBox::AdjustToContents);
    connect(targetSelCombo,SIGNAL(currentTextChanged(QString)),this,SLOT(setTarget(QString)));
    populateTargetSelCombo();
    QAction *configAction = utilityToolBar->addWidget(targetSelCombo);
    configAction->setToolTip("Select Configuration");
    utilityToolBar->addSeparator();
    utilityToolBar->addAction(QIcon(":/icons/icons/help.png"),"Open reference",this,SLOT(openReference()));

    utilityToolBar->setAllowedAreas(Qt::TopToolBarArea);
    addToolBar(Qt::TopToolBarArea, utilityToolBar);

    // disable tools until a nav item is selected
    fileToolBar->setEnabled(false);
    buildToolBar->setEnabled(false);

    // disable save tools until a tab is dirty
    disableAction(fileToolBar,STR_FILE_MENU_FILE_SAVE);
    disableAction(fileToolBar,STR_FILE_MENU_FILE_SAVE_ALL);
}
