#ifndef TABMANAGER_H
#define TABMANAGER_H

#include <QWidget>
#include <QTabWidget>
class Indexer;
class SourceEditor;
class Project;

class CursorEntry
{
public:
    QString pathname;
    int row,col;
};

class CursorHistory
{
public:
    void update(SourceEditor *editor);
    bool back(CursorEntry *location);
    bool forward(CursorEntry *location);
private:
    QList<CursorEntry> fwdStack;
    QList<CursorEntry> backStack;
    QString lastPathname;
    int lastRow;
};

class TabManager : public QTabWidget
{
    Q_OBJECT
public:
    explicit TabManager(QWidget *parent = 0);

    bool activateTab(QString pathname);
    bool openFileUsingSourceEditor(Project *prj, QString pathname);
    SourceEditor* currentEditor();
    SourceEditor* getEditor(int i);

    QString getTabPathname(int i);
    QString getTabProjectFolder(int i);
    Project* getTabProject(int i);
    void setTabPathname(int i, QString pathname);
    void setTabProject(int i, Project *project);

private:
    CursorHistory cursorHistory;

    int askToSaveDocument(QString pathname, bool allowCancel = true);

signals:
//    void tabClosed(QString); // main window will want to know this to
//    void tabSaved(QString); // main window will want to know this to update the save saveAll menu/toolbar states
//    void tabChanged(QWidget*);
 //   void documentWasModified(SourceEditor*);
//    void documentLineCountChanged(SourceEditor*,int);
    void documentIndexFinished(Indexer*);
    void setStatusMessage(QString);

    void updateBreakpointView(Project*);
    void addBreakpoint(QString,int);
    void removeBreakpoint(QString,int);

    void selectionChanged(QString);
    void updateSaveSaveAll();
    void updateToolbarState();
    void updateOutlineView();
    void updateClassView(Project*);
    void requestFileOpen(QString pathname,int linenumber,int col);

public slots:
    bool closeAllTabs(bool allowCancel = true);
    bool closeTab(int index, bool allowCancel = true);
    bool closeTabs(Project *prj);
    void saveFile();
    void saveFile(int tabIndex, bool runIndexer);
    void saveAllFile();
 //   void saveAsFile();
    void filePathChanged(QString sourcePath, QString destPath, Project *destProject);

    void slotDocumentWasModified();
    void slotDocumentLineCountChanged(int count);
    void slotDocumentIndexFinished();
    void slotTabChanged(int i);

    bool openEditor(Project *prj, QString pathname);
    bool openEditor(Project *prj, QString pathname, int line);
    void selectEditor(Project *prj, QString pathname);
    void selectEditor(QString pathname, int line);

//    void breakpointAdded(QString pathname, int line);
//    void breakpointRemoved(QString pathname, int line);

    void jumpToCode();
    void updateEditorSettings();
    void goBack();
    void goForward();

private slots:
    void editorCursorPosChanged();
};

#endif // TABMANAGER_H
