#ifndef DEVICEMONITOR_H
#define DEVICEMONITOR_H

#include <QObject>
#include <QMainWindow>

#if defined Q_OS_MAC

#include <IOKit/hid/IOHIDManager.h>
#include <IOKit/hid/IOHIDKeys.h>
#include <CoreFoundation/CoreFoundation.h>

class DeviceMonitor : public QMainWindow
{
    Q_OBJECT
public:
    explicit DeviceMonitor(QWidget *parent = 0);
    ~DeviceMonitor();
    void start(unsigned short vid = 0, unsigned short pid = 0);

private:
    IOHIDManagerRef manager;
    unsigned short vid,pid;

    static void removalCallback(void *context, IOReturn result, void *sender, IOHIDDeviceRef dev_ref);
    static void connectCallback(void *context, IOReturn result, void *sender, IOHIDDeviceRef dev_ref);

    unsigned short getVID(IOHIDDeviceRef device);
    unsigned short getPID(IOHIDDeviceRef device);
    QString getSerialNumber(IOHIDDeviceRef device);
    uint32_t getLocation(IOHIDDeviceRef device);

    int32_t getIntProperty(IOHIDDeviceRef device, CFStringRef key);
    bool getStringProperty(IOHIDDeviceRef device, CFStringRef prop, wchar_t *buf, size_t len);

signals:
    void deviceRemoved(QString);
    void deviceAttached(QString);

public slots:
    
};


#elif defined Q_OS_WIN

#include <QWidget>
#include <windows.h>
#include <setupapi.h>
#include <dbt.h>
#include <QFuture>
#include <stdint.h>
#include <QTimer>

class DeviceMonitor : public QMainWindow
{
    Q_OBJECT
public:
    explicit DeviceMonitor(QWidget *parent = 0);
    ~DeviceMonitor();
    void start(unsigned short vid = 0, unsigned short pid = 0);

private:
    HDEVNOTIFY hDevNotify;
    DEV_BROADCAST_DEVICEINTERFACE *NotificationFilter;
    QTimer *attachTimer;
    unsigned short vid,pid;
    QStringList deviceList;

private:
//    unsigned short getVID(IOHIDDeviceRef device);
//    unsigned short getPID(IOHIDDeviceRef device);
//    QString getSerialNumber(IOHIDDeviceRef device);
//    uint32_t getLocation(IOHIDDeviceRef device);
//    int32_t getIntProperty(IOHIDDeviceRef device, CFStringRef key);
//    bool getStringProperty(IOHIDDeviceRef device, CFStringRef prop, wchar_t *buf, size_t len);
    QStringList enumerate(int vendorID,int productID);

    bool nativeEvent(const QByteArray &data, void *msg, long *result);

signals:
    void deviceRemoved(QString);
    void deviceAttached(QString);

public slots:

private slots:
    void attachTimerTimeout();

};


#elif defined Q_OS_UNIX

#include <libudev.h>
#include <QTimer>
#include <QMainWindow>

class DeviceMonitor : public QMainWindow
{
    Q_OBJECT
public:
    explicit DeviceMonitor(QWidget *parent = 0);
    ~DeviceMonitor();
    void start(unsigned short vid, unsigned short pid);

private:
    unsigned short vid,pid;
    struct udev *udev;
    struct udev_monitor *mon;
    int fd;
    QTimer timer;

//    bool init(void);
    bool startMonitor();
    bool enumerate();
    void showDeviceInfo(struct udev_device *dev);

signals:
    void deviceRemoved(QString);
    void deviceAttached(QString);

private slots:
    void checkDevices();

};
#endif

#endif // DEVICEMONITOR_H
