#ifndef CEDITOR_H
#define CEDITOR_H

#include <QWidget>
#include <QPlainTextEdit>

class Highlighter;
class MarginWidget;


class CodeEditor : public QPlainTextEdit
{
    Q_OBJECT

public:
    typedef enum {
        Background,
        Normal,
        Comment,
        Number,
        String,
        Operator,
        Identifier,
        Keyword,
        BuiltIn,
        Sidebar,
        LineNumber,
        Cursor,
        Marker,
        BracketMatch,
        BracketError
    } ColorComponent;

    explicit CodeEditor(QWidget *parent = 0);

    void setColor(ColorComponent component, const QColor &color);

    QStringList getKeywords() const;
    void setKeywords(const QStringList &getKeywords);

    bool isBracketsMatchingEnabled() {return highlightBrackets;}
    bool isLineNumbersVisible() {return showLineNumbers;}

    QList<int> getBreakpoints();
    void setBreakpoints(const QList<int> &list);
    bool isBreakpointAt(int line);
    int findOpeningBracket(const QTextDocument *doc, int cursorPosition);
    int findClosingBracket(const QTextDocument *doc, int cursorPosition);
    int findOpeningParen(const QTextDocument *doc, int cursorPosition);
    int findClosingParen(const QTextDocument *doc, int cursorPosition);
    int getMarginWidgetWidth();
    int blockState();
    void marginPressEvent(int line, int x);

signals:
    void marginClicked(int line, int x);
    void updateBreakpoints();

public slots:
    void updateSidebar();
    void setBracketsMatchingEnabled(bool enable);
    void setLineNumbersVisible(bool visible);
    void updateHighlighter();

protected:
    void resizeEvent(QResizeEvent *e);

private slots:
    void updateCursor();
    void updateSidebar(const QRect &rect, int dy);
    void slotBlockCountChanged(int cnt);

private:
//    QList<int> breakpointList;
    bool highlightBrackets;
    bool showLineNumbers;
    QColor cursorColor;
    QColor bracketMatchColor;
    QColor bracketErrorColor;

    Highlighter *highlighter;
    MarginWidget *sidebar;
    QList<int> bracketMatchPositions;
    QList<int> bracketErrorPositions;
    QList<int> parenMatchPositions;
    QList<int> parenErrorPositions;
};

#endif // CEDITOR_H
