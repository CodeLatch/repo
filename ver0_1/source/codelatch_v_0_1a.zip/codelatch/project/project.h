#ifndef PROJECT_H
#define PROJECT_H

#include <QList>
#include <QString>
#include <QMap>
#include <QStringList>
#include <QObject>
#include <QLabel>
#include <Views/console.h>
#include <QFuture>
#include <QFutureWatcher>

class Indexer;
class Target;
class SourceEditor;

struct S_Breakpoint
{
    QString pathname;
    int lineNumber;
};

struct S_ReservedMem
{
    unsigned long start, stop;
};

// ----------------------------------------------------
class Project : public QObject
{
    Q_OBJECT
public:
    explicit Project(QObject *parent = 0);
    ~Project();

    void setReservedMem(QList<S_ReservedMem> &list) {reservedMemList = list;}


signals:
    void buildComplete(bool retval, Project *prj);      // build process complete success, failure
    void downloadComplete(bool retval, Project *prj);   // program process complete success, failure
    void indexProject(Project *);                       // we signal the mainwindow to start indexing because we need the tabManager
    void indexingComplete(Project *);                   // when indexing is complete we send out a signal
    void breakpointsChanged(Project *);
    void signalBreakpointAdded(QString pathname,int lineNumber);
    void signalBreakpointRemoved(QString pathname,int lineNumber);

public slots:
    void runIndexer();
    void slotIndexingComplete();

public:

    bool open(QString path);
    bool createNewProject(QString prjname);
    bool save();
    bool saveAs(QString newProjectFolder);
    void close();
    bool erase();
    bool clean();
    bool build();
    Target getTarget();

    static QString getProjectExtension();
    static QString getConfigFilename();
    QString getBuildFolder();
    QString getProjectFolder();
    QStringList getIncludeFolders();
    QStringList getHeaderFiles();
    QStringList getSourceFiles();
    QString getName();

    bool rename(QString newName);

    void update();

    void updateBreakpoints(SourceEditor *editor, QString pathname);

    QList<S_ReservedMem> getReservedMem();
    Indexer *getIndexer();

    QList<S_Breakpoint> getBreakpoints();
    bool isBreakpointAt(QString pathname, int lineNumber);
    void clearBreakpoints();
    void addBreakpoint(QString pathname, int lineNumber);
    bool removeBreakpoint(QString pathname, int lineNumber);
    void removeBreakpoints(QString pathname);
    int getBreakpointCount();

    bool isProjectFile(QString pathname);

    // project config get parameter access
    QStringList getPostBuildCommands() {return postBuildCommands;}
    QStringList getCompilerOptions() {return compilerOptions;}
    QStringList getLinkerOptions() {return linkerOptions;}
    bool getDynamicMemorySupport() {return dynamicMemorySupport;}
    bool getRemoveUnused() {return removeUnused;}
    QString getOptimization() {return optimization;}
    QString getBuildType() {return buildType;}

    QString getCompilerBaseCmd();
    QString getCompilerCmd();
//    QString getCompilerCmd() {return compilerCmd;}
//    QString getCompilerBaseCmd() {return compilerCmd.left(compilerCmd.lastIndexOf('-')+1);}

    // project config set parameter access
    void setRemoveUnused(bool enable) {removeUnused = enable;}
    void setOptimization(QString optLevel) {optimization = optLevel;}
    void setBuildType(QString buildtype) {buildType = buildtype;}
    void setPostBuildCommands(QStringList list) {postBuildCommands = list;}
    void setCompilerOptions(QStringList list) { compilerOptions = list;}
    void setLinkerOptions(QStringList list) { linkerOptions = list;}
    void setDynamicMemorySupport(bool enable) {dynamicMemorySupport = enable;}
    void setCompilerCmd(QString str) { compilerCmd = str;}

    QStringList getBuildTypes();
    QStringList getOptimizationLevels();

private:
    void scanForFiles(QString dir);
    bool compile();
    bool link();
    bool buildLibrary();
    bool parseCompilerOutput(QString str);
    bool createBinaryImage();
    bool createListFile();
    void printSize();
    void updateLPCuserCode(QByteArray &data);
    void runPostBuildCommands();

public:

private:
    // project config parameters
    QString configFileVersion;
    QStringList postBuildCommands;
    QString optimization;
    QString buildType;
    QStringList compilerOptions;
    QStringList linkerOptions;
    QString compilerCmd;
    bool dynamicMemorySupport;
    bool removeUnused;

    // project sources
    QStringList includeFolders;
    QStringList headerFiles;
    QStringList sourceFiles;

    // general
    QString projectFolder;
    QString name;
    QList<S_Breakpoint> breakpointList;
    QList<S_ReservedMem> reservedMemList;
    Indexer *indexer;
};

#endif // PROJECT_H
