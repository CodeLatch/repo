//!----------------------------------------------------------------------------
//! file: project.cpp
//!
//! This class provides project management functionality.
//! Key functions...
//!
//! open
//! close
//! save
//! saveAs
//! erase
//!
//! getProjectExtension
//!
//! getFiles
//! getFileCount
//! addExistingFile
//! addNewFile
//! deleteFile
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "project.h"
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QDir>
#include <QDirIterator>
#include <QMessageBox>
#include "utility/fileutility.h"
#include <QDebug>
#include <QProcess>
#include <QFileInfo>
#include <QByteArray>
#include "indexer/indexer.h"
#include <QtConcurrent/QtConcurrent>
#include "target.h"
#include "programconfig.h"
#include "consoleprocess.h"
#include "sourceeditor.h"
#include <stdint.h>

#define STR_CONFIG_FILE_VERSION      "0.1"
#define STR_FILE_VERSION             "fileVersion"
#define STR_BUILD_TYPE               "buildType"
#define STR_POST_BUILD               "postBuild"
#define STR_DYNAMIC_MEMORY           "dynamicMemory"
#define STR_REMOVE_UNUSED            "removeUnused"
#define STR_OPTIMIZATION             "optimization"
#define STR_COMPILER_OPTIONS         "compilerOptions"
#define STR_LINKER_OPTIONS           "linkerOptions"
#define STR_COMPILER_CMD             "compilerCmd"

// this is global because ctags is not thread safe, so we need to make
// sure calls to ctags happen sequentially.
//QFuture<void> indexingFuture;

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Project::Project(QObject *parent) :
    QObject(parent)
{

    // create indexer
    indexer = new Indexer(this);
    connect(indexer,SIGNAL(indexingComplete()),this,SLOT(slotIndexingComplete()));
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Project::~Project()
{
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QStringList Project::getOptimizationLevels()
{
    QStringList list;
    list.append("-O0 None/Debug");
    list.append("-O1 General");
    list.append("-O2 More");
    list.append("-Os More+Size");
    list.append("-O3 Most");
    return list;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QStringList Project::getBuildTypes()
{
    QStringList list;
    list.append("Binary");
    list.append("Object Files");
    list.append("Library");
    return list;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::open(QString path)
{
    if (path.isEmpty())
        return false;

    QString configpath = path + "/" + getConfigFilename();

    QFile file(configpath);
    QFileInfo fileInfo(file);
    if(!fileInfo.exists())
        return false;

    if (!file.open(QIODevice::ReadOnly))
        return false;

    projectFolder = path;
    QStringList split = path.split('/');
    name = split.last();

    // read project settings
    // everything is stored in a map, each item identified by a key string.
    QDataStream in(&file);
    in.setVersion(QDataStream::Qt_4_3);
    QMap<QString, QVariant> map;
    map.clear();
    in >> map;
    file.close();

    // extract data from map
    configFileVersion = map.value(STR_FILE_VERSION,QVariant()).toString();
    optimization = map.value(STR_OPTIMIZATION,QVariant()).toString();
    removeUnused = map.value(STR_REMOVE_UNUSED,QVariant()).toBool();
    dynamicMemorySupport = map.value(STR_DYNAMIC_MEMORY,QVariant()).toBool();
    buildType = map.value(STR_BUILD_TYPE,QVariant()).toString();
    postBuildCommands = map.value(STR_POST_BUILD,QVariant()).toStringList();
    compilerOptions = map.value(STR_COMPILER_OPTIONS,QVariant()).toStringList();
    linkerOptions = map.value(STR_LINKER_OPTIONS,QVariant()).toStringList();
    compilerCmd = map.value(STR_COMPILER_CMD,QVariant()).toString();

    // replace path keys with actual paths
    compilerCmd = FileUtility::replaceKeyWithPath(NULL,compilerCmd);
    QStringList tmpPostBuildCommands;
    foreach(QString s,postBuildCommands)
        tmpPostBuildCommands.append(FileUtility::replaceKeyWithPath(this,s));
    postBuildCommands = tmpPostBuildCommands;

    update();
    runIndexer();

    return true;
}

//!----------------------------------------------------------------------------
//! \brief  Populate sourceFiles and includeFolders lists by scanning project
//!         directory.
//!----------------------------------------------------------------------------
void Project::update()
{
    sourceFiles.clear();
    includeFolders.clear();
    headerFiles.clear();

    scanForFiles(projectFolder);
    includeFolders.removeDuplicates();
}

//!----------------------------------------------------------------------------
//! \brief  Support routine for update().
//!----------------------------------------------------------------------------
void Project::scanForFiles(QString dir)
{
    QFileInfoList filesList = QDir(dir).entryInfoList();

    foreach(QFileInfo fileInfo, filesList)
    {
        if((fileInfo.fileName() != "..") &&
                (fileInfo.fileName() != "."))
        {
            if(fileInfo.isDir() && !fileInfo.fileName().endsWith("."))
                scanForFiles(fileInfo.filePath());
            else
            {
                if(fileInfo.fileName().endsWith(".c")
                        || fileInfo.fileName().endsWith(".cpp")
                        || fileInfo.fileName().endsWith(".S"))
                    sourceFiles.append(fileInfo.filePath());

                if(fileInfo.fileName().endsWith(".h") || fileInfo.fileName().endsWith(".hpp"))
                {
                    includeFolders.append(fileInfo.absoluteDir().absolutePath());
                    headerFiles.append(fileInfo.filePath());
                }
            }
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief  Create a new empty project.
//!----------------------------------------------------------------------------
bool Project::createNewProject(QString prjname)
{
    // for debug to start with.
    // later we need to create our own dialog to select from
    // folders that don't contain projects.

    QString pathname = FileUtility::getDirProjects() + "/" + prjname;
    if(QDir(pathname).exists())
        return false;

    QDir().mkpath(pathname);
    projectFolder = pathname;
    name = prjname;
    // create project config file
    save();

    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::close()
{
    save();
}

//!----------------------------------------------------------------------------
//! \brief  Save project config.
//!----------------------------------------------------------------------------
bool Project::save()
{
    QString pathname = getProjectFolder() + "/" + getConfigFilename();

    if (pathname.isEmpty())
        return false;

    QFile file(pathname);
    QFileInfo fileInfo(file);

    if(fileInfo.exists())
        if(!fileInfo.isWritable())
            return false;


    // when we store info replace actual paths with path shortcuts
    QString tmpCompilerCmd = FileUtility::replacePathWithKey(this,compilerCmd);
    QStringList tmpPostBuildCommands;
    for(int i=0;i<postBuildCommands.size();i++)
        tmpPostBuildCommands.append(FileUtility::replacePathWithKey(this,postBuildCommands.at(i)));

    // update map
    QMap<QString, QVariant> map;
    map.insert(STR_FILE_VERSION,STR_CONFIG_FILE_VERSION);
    map.insert(STR_OPTIMIZATION,optimization);
    map.insert(STR_REMOVE_UNUSED,removeUnused);
    map.insert(STR_DYNAMIC_MEMORY,dynamicMemorySupport);
    map.insert(STR_BUILD_TYPE,buildType);
    map.insert(STR_POST_BUILD,tmpPostBuildCommands);
    map.insert(STR_COMPILER_OPTIONS,compilerOptions);
    map.insert(STR_LINKER_OPTIONS,linkerOptions);
    map.insert(STR_COMPILER_CMD,tmpCompilerCmd);

    // save data
    if (!file.open(QIODevice::WriteOnly))
        return false;

    QDataStream out(&file);
    out.setVersion(QDataStream::Qt_4_3);
    out << map;
    file.close();

    return true;
}

//!----------------------------------------------------------------------------
//! \brief  Create a new directory and copy the project files to it. Update
//!         various lists and pathname strings to point to new directory.
//!
//! \return true if success, false if fail.
//!----------------------------------------------------------------------------
bool Project::saveAs(QString newProjectFolder)
{
    QString sourceFolder = getProjectFolder();
    QString destFolder = newProjectFolder;

    // create new project directory.
    QDir dir;
    if(!dir.mkpath(destFolder))
    {
        QMessageBox::critical(NULL, "SaveAs","Error creating new project directory.");
        return false;
    }

    // copy files
    QDirIterator prjFiles(sourceFolder, QDir::Files | QDir::Dirs | QDir::NoSymLinks | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
    while(prjFiles.hasNext())
    {
        prjFiles.next();
        QString sourcePathname = prjFiles.filePath();
        QString destPathname = destFolder + "/" + sourcePathname.right(sourcePathname.length()-sourceFolder.length());
        destPathname = destPathname.replace("//","/");

        QFileInfo info(sourcePathname);
        if(info.isDir())
        {
            QDir dir;
            if(!dir.mkpath(destPathname))
            {
                QMessageBox::critical(NULL, "Error","Error creating directory.");
                return false;
            }
        }
        else
        {
            if(!QFile::copy(sourcePathname,destPathname))
            {
                QMessageBox::critical(NULL, "Error","Error copying file.");
                return false;
            }
        }
    }

    // change this project to point to new project path
    projectFolder = newProjectFolder;
    QFileInfo info(projectFolder);
    name = info.fileName();

    for(int i=0;i<breakpointList.size();i++)
    {
        S_Breakpoint bp = breakpointList.at(i);
        if(bp.pathname.startsWith(sourceFolder))
        {
            QString str = bp.pathname;
            str = str.replace(sourceFolder,destFolder);
            breakpointList.replace(i,bp);
        }
    }

    update();

    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::erase()
{
    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::rename(QString newName)
{
    // rename project directory
    QString projectDir = getProjectFolder();
    QFileInfo fileinfo(projectDir);
    QDir qdir = fileinfo.dir();
    QString parentFolder = qdir.absolutePath();
    QString newFolderName = parentFolder + "/" + newName;
    if(!qdir.rename(projectDir,newFolderName))
        return false;

    projectFolder = newFolderName;
    name = newName;
    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString Project::getProjectFolder() {return projectFolder;}
QString Project::getBuildFolder() {return getProjectFolder() + "/build";}
QStringList Project::getIncludeFolders() {return includeFolders;}
QStringList Project::getHeaderFiles() {return headerFiles;}
QStringList Project::getSourceFiles() {return sourceFiles;}
QString Project::getProjectExtension() {return QString("cprj");}
QString Project::getConfigFilename() {return QString("config.cprj");}
QString Project::getName() {return name;}
QList<S_ReservedMem> Project::getReservedMem() {return reservedMemList;}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::clean()
{
    QString folder = getBuildFolder();
    FileUtility::eraseDir(folder,false);
    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::build()
{
    // ensure Build/obj folder is present
    QString binFolder = getBuildFolder();
    QString objFolder = binFolder + "/obj";
    if(!QFileInfo(objFolder).exists())
    {
        QDir().mkpath(objFolder); // creates build folder as artifact if not present
        if(!QFileInfo(objFolder).exists())
            return false;
    }

    // update file and folder lists by scanning project directory
    update();

    bool ret = true;
    if(ret) ret = compile();
    if(!ret) qDebug() << "compile returned false.";

    if(buildType == "Binary")
    {
        if(ret) ret = link();
        if(ret) ret = createBinaryImage();
        if(ret) ret = createListFile();
        if(ret) printSize();
    }
    else if(buildType == "Library")
    {
        if(ret) ret = buildLibrary();
    }
    else if(buildType == "Object Files")
    {
        // we're done.
    }

    runPostBuildCommands();

    if(ret)
        console->appendLine("Build Complete !","green");
    else
        console->appendLine("Build stopped.","red");

    qDebug() << "emitting build complete.";

    emit buildComplete(ret,this);
    return ret;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::printSize()
{
    QString cmd = getCompilerBaseCmd() + "size";
/*#ifdef WIN32
    cmd += ".exe";
#endif
    QFileInfo cmdInfo(cmd);
    if(!cmdInfo.exists())
    {
        console->appendLine("error: " + cmd + " does not exist.");
        return;
    }
*/
    cmd += " --format=berkley ";
    cmd += "\"" + getName() + ".elf\" ";

    QProcess *process = new QProcess;
    process->setWorkingDirectory(getBuildFolder());
    process->start(cmd);
    if (!process->waitForStarted(3000))
    {
        console->appendLine("error starting cmd.");
        process->kill();
        process->deleteLater();
        return;
    }
    if (!process->waitForFinished(3000))
    {
        console->appendLine("error finishing cmd.");
        process->kill();
        process->deleteLater();
        return;
    }

    QString errorStr(process->readAllStandardError());
    QStringList errorList = errorStr.split('\n');
    foreach(QString str,errorList)
        if(!str.isEmpty())
           console->appendLine("  error: " + str);

    QString outputStr(process->readAllStandardOutput());
    QStringList outputList = outputStr.split('\n');
    foreach(QString str,outputList)
        if(!str.isEmpty())
           console->appendLine(str);

    process->deleteLater();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::createListFile()
{
    console->appendLine("creating list file.");

    QString buildDir = getBuildFolder();
    QString cmd = getCompilerBaseCmd() + "objdump";

/*#ifdef WIN32
    cmd += ".exe";
#endif
    QFileInfo cmdInfo(cmd);
    if(!cmdInfo.exists())
    {
        console->appendLine("error: " + cmd + " does not exist.");
        return false;
    }
*/
    cmd += " -h -S \"" + getName() + ".elf\"";

    QProcess *process = new QProcess;
    process->setWorkingDirectory(buildDir);
    process->start(cmd);
    if (!process->waitForStarted(3000))
    {
        console->appendLine("error starting cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }
    if (!process->waitForFinished(3000))
    {
        console->appendLine("error finishing cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }

    QString errorStr(process->readAllStandardError());
    QStringList errorList = errorStr.split('\n');
    QString outputStr(process->readAllStandardOutput());
    QStringList outputList = outputStr.split('\n');
    process->deleteLater();

    // create .lst file
    QString pathname = getBuildFolder() + "/" + getName() + ".lst";
    QFile file(pathname);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(&file);
        foreach(QString str,outputList)
            out << str << "\r\n";
        file.close();
    }

    bool ret = true;
    foreach(QString str,errorList)
    {
        if(!str.isEmpty())
        {
           console->appendLine("  error: " + str);
           ret = false;
        }
    }

    return ret;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::createBinaryImage()
{
    console->appendLine("creating binary image.");

    QString cmd = getCompilerBaseCmd() + "objcopy";
/*#ifdef WIN32
    cmd += ".exe";
#endif
    QFileInfo cmdInfo(cmd);
    if(!cmdInfo.exists())
    {
        console->appendLine("error: " + cmd + " does not exist.");
        return false;
    }
*/
    cmd += " -O binary ";
    cmd += "\"" + getName() + ".elf\" ";
    cmd += "\"" + getName() + ".bin\"";

    QProcess *process = new QProcess;
    process->setWorkingDirectory(getBuildFolder());
    process->start(cmd);
    if (!process->waitForStarted(3000))
    {
        console->appendLine("error starting cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }
    if (!process->waitForFinished(3000))
    {
        console->appendLine("error finishing cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }

    QString errorStr(process->readAllStandardError());
    QStringList errorList = errorStr.split('\n');
    process->deleteLater();

    foreach(QString str,errorList)
        if(!str.isEmpty())
           console->appendLine("  error: " + str);

    Target target = getTarget();
    if(target.getUpdateLPCUserCode())
    {
        qDebug() << "updating LPC user code";
        // update user signature if this is an lpc part
        QString pathname = getBuildFolder() + "/" + getName() + ".bin";
        QFile file(pathname);
        if(!file.open(QFile::ReadOnly)) return false;
        QByteArray prgdata = file.readAll();
        file.close();
        updateLPCuserCode(prgdata);
        if(!file.open(QFile::WriteOnly)) return false;
        file.write(prgdata);
        file.close();
    }

    return true;
}

void Project::updateLPCuserCode(QByteArray &data)
{
    uint32_t a;
    uint32_t sum = 0;
    int i;

    uint32_t *ptr = (uint32_t*) data.data();

    for(i=0;i<7;i++)
    {
        a = ptr[i];
        sum += a;
        qDebug("%d 0x%08x 0x%08x",i,a,sum);
    }
    sum = -sum;
    qDebug("0x%08x",sum);
    ptr[i] = sum;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::buildLibrary()
{
//    cmd = "arm-none-eabi-ar crvs " + libfilePathName + objList;
    QString ucmd = getCompilerCmd();
    QFileInfo toolInfo(ucmd);
    QStringList args;
    QString cmd = toolInfo.path() + "/arm-none-eabi-ar";

    args << "crvs";
    args << "\"" + getBuildFolder() + "/lib" + getName() + ".a\"";

    // append object files
//    QStringList addObjList = getObjectFiles();
    QDir objDir(getBuildFolder()+"/obj");
    QStringList addObjList = objDir.entryList();
    foreach(QString str,addObjList)
    {
        if((str != ".") && (str != ".."))
            args << "\"" + getBuildFolder() + "/obj/"+str + "\"";
    }
//    args << "\"" + getBuildFolder() + "/obj/*.o\"";

    QString param;
    foreach(QString str,args)
        param.append(str + " ");
    console->appendLine("creating library file.");
    //console->appendLine(cmd+" "+param);
    QProcess *process = new QProcess;
    process->start(cmd+" "+param);
    if (!process->waitForStarted(3000))
    {
        console->appendLine("error running cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }
    if (!process->waitForFinished(10000))
    {
        console->appendLine("error finishing cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }

    QString errorStr(process->readAllStandardError());
    process->deleteLater();
    QStringList errorList = errorStr.split('\n');
    foreach(QString str,errorList)
    {
        if(!str.isEmpty())
           console->appendLine("  error: " + str);
    }

    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::link()
{
    QString ucmd = getCompilerCmd();
    QString cmd = ucmd;
    QStringList args;
    bool ret = true;

    Target target = getTarget();

    // add linker options
    args = getLinkerOptions();

    // add linker script
    args << "-T\"" + target.getLinkerScriptFile()  + "\"";

    // define output file
    args << "-o\"" +  getBuildFolder() + "/" + getName()	+ ".elf\"";

    // append all project object files
    QString objFolder = getBuildFolder() + "/obj";
    QDirIterator objFiles(objFolder, QDir::Files | QDir::NoSymLinks | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
    while(objFiles.hasNext())
    {
        objFiles.next();
        QString pathname = objFiles.filePath();
        if(pathname.endsWith(".o"))
            args << "\""+ pathname + "\"";
    }

    // append additional object files
    QStringList addObjList = target.getObjectFiles();
    foreach(QString str,addObjList)
        args << "\"" + str + "\"";

    // append startup file
    args << "\"" + target.getStartupFile() + "\"";

    // append stubs file if required
    if(getDynamicMemorySupport())
        args << "\"" + target.getStubsFile() + "\"";

    // add libraries
    QStringList paths = target.getLibraryFiles();
    QStringList libPaths,libNames;
    foreach(QString path,paths)
    {
        path = FileUtility::replaceKeyWithPath(this,path);
        QFileInfo info(path);
        QString name = info.fileName();
        // remove leading lib and trailing .a
        name = name.left(name.length()-2);
        name = name.right(name.length()-3);
        libPaths.append(info.path());
        libNames.append(name);
    }
    // add standard libs
    libNames.append(target.getStandardLibs());

//    QStringList libPaths = target.getLibraryFolders();
    foreach(QString str,libPaths)
        args << "-L\"" + str + "\"";

    // add libraries
//    QStringList libNames = target.getLibraryFiles();
    foreach(QString str,libNames)
        args << "-l" + str;

    QString param;
    foreach(QString str,args)
        param.append(str + " ");

    console->appendLine("linking.");

    QProcess *process = new QProcess;
    //console->appendLine(cmd+" "+param);
    process->start(cmd+" "+param);
    if (!process->waitForStarted(3000))
    {
        console->appendLine("error starting link cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }
    if (!process->waitForFinished(10000))
    {
        console->appendLine("error finishing link cmd.");
        process->kill();
        process->deleteLater();
        return false;
    }

    QString errorStr(process->readAllStandardError());
    QStringList errorList = errorStr.split('\n');

    QString outputStr(process->readAllStandardOutput());
    QStringList outputList = outputStr.split('\n');

    process->deleteLater();

    foreach(QString str,errorList)
    {
        if(!str.isEmpty())
        {
           console->appendLine("  error: " + str);
           ret = false;
        }
        bool fail = parseCompilerOutput(str);
        if(fail)
        {
            console->appendLine("halting build.","red");
            return false;
        }
    }
//    if(errorList.size() > 0)
//        return false;
    return ret;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::compile()
{
    QString homeDir = FileUtility::getDirHome();
    QString cmd = getCompilerCmd();
#ifdef Q_OS_MAC
    cmd = "./" + cmd.right(cmd.length()-homeDir.length()-1);
#endif
    QStringList baseArgs;

    Target target = getTarget();

    // add compiler options
    baseArgs = getCompilerOptions();
    baseArgs.append(getOptimization().left(3));
    baseArgs.append(" ");

    // add include directories
    for(int i=0;i<includeFolders.size();i++)
    {
        QString relFolder = includeFolders.at(i);
        relFolder = relFolder.right(relFolder.length()-homeDir.length()-1);
        baseArgs << "-I\"" + relFolder  + "\" ";
    }
    QStringList externalIncludeFolders = target.getExternalIncludeFolders();
    for(int i=0;i<externalIncludeFolders.size();i++)
    {
        QString relFolder = externalIncludeFolders.at(i);
        relFolder = relFolder.right(relFolder.length()-homeDir.length()-1);
        baseArgs << "-I\"" + relFolder  + "\" ";
    }
    // compile each source file
    console->appendLine("compiling...");
    for(int i=0;i<sourceFiles.size();i++)
    {
        QStringList fileArgs;
        QString pathname = sourceFiles.at(i);
        QString relPath = pathname.right(pathname.length()-homeDir.length()-1);
        QString buildFolder = getBuildFolder();
        QString relBuildFolder = buildFolder.right(buildFolder.length()-homeDir.length()-1);

        QFileInfo info(pathname);
        console->appendLine("  " + info.fileName());

        QString objName = "-o\"" + relBuildFolder + "/obj/" + info.baseName() + ".o\" ";
        QString srcName = "\"" + relPath + "\" ";

        fileArgs << objName << srcName;

        QStringList args = baseArgs + fileArgs;

        QString param;
        foreach(QString str,args)
            param.append(str + " ");

//        console->appendLine(cmd+" "+param);

        QProcess *process = new QProcess;
        process->setWorkingDirectory(homeDir);
        process->start(cmd+" "+param);
 //       process->start(cmd,args);

        // check for an error 0=failed to start, 1=crashed, 2=timeout,
        // 3=read error, 4=write error, 5=unknown(default if no error)
        QProcess::ProcessError error = process->error();
        if(error != QProcess::UnknownError)
        {
            qDebug() << "compile startup error:" << error;
            return false;
        }
        if (!process->waitForStarted(3000))
        {
            QByteArray a = process->readAll();
            QString s(a);
            qDebug() << "process output:" << s;

            console->appendLine("error starting compile cmd.");
            process->kill();
            process->deleteLater();
            return false;
        }
        if (!process->waitForFinished(10000))
        {
            qDebug() << "killing process";
            process->kill();
            process->deleteLater();
            console->appendLine("error finishing compile cmd.");
            qDebug() << "returing false from compile";
            return false;
        }
        QString errorStr(process->readAllStandardError());
        QStringList errorList = errorStr.split('\n');

        QString outputStr(process->readAllStandardOutput());
        QStringList outputList = outputStr.split('\n');

        process->deleteLater();

        foreach(QString str,errorList)
        {
            bool fail = parseCompilerOutput(str);
            if(fail)
            {
                console->appendLine("halting build.");
                return false;
            }
        }
    }
    return true;
}

//!----------------------------------------------------------------------------
//! \brief  Parse compiler or linker output.
//!         Print file link in console window if found.
//!
//! \return true = build error detected, halt build process.
//!         false = non-error, continue build process.
//!----------------------------------------------------------------------------
bool Project::parseCompilerOutput(QString str)
{
    if(str.isEmpty()) return false;

    // check if this is a compiler tool general error
    if (str.startsWith("arm-none-eabi-"))
    {
        console->appendLine("    GENERAL ERROR:" + str); // print in red
        return true; // build error
    }

    if(str.count(':') < 2)
    {
        console->appendLine("    " + str);
        return false;
    }

    bool ret = false;
    QString filename, pathname;

    // some typical strings...
    //
    // main.cpp: In function 'int main()':
    // main.cpp:12:2: error: 'a' was not declared in this scope
    // cc1: warning: command line option "-fno-rtti" is valid for C++/ObjC++ but not for C
    // main.o: In function `main':
    // main.c:951: undefined reference to `myfunction'
    // main.cpp: In function 'int main()':
    // main.cpp:108:2: error: expected ';' before 'while'
    // main.cpp:23:2: error: expected ':' before 'int'

    // first string is usually a file path, but not always.
    // deal with windows drive letter.
    int sIndex;
    // don't need this anymore since we build using relative pathnames
/*
#ifdef Q_OS_WIN
    // get index of second colon
    sIndex = str.indexOf(':');
    sIndex = str.indexOf(':',sIndex+1);
#else
    // get index of first colon
    sIndex = str.indexOf(':');
#endif
*/
    // get index of first colon
    sIndex = str.indexOf(':');

    // determine if the first field is a pathname, if not just print the text.
    pathname = FileUtility::getDirHome() + "/" + str.left(sIndex);
    pathname.replace("\\","/");
    pathname.replace("//","/");
    QFileInfo info(pathname);
    if(!info.exists())
    {
        // in the future maybe color the text if warning: or error: is found.
        console->appendLine("    " + str);
        if(str.contains(" error: "))
            return true;
        return false;
    }

    // pathname is valid.
    filename = info.fileName();
    // remove pathname from the string for the next step in parse
    str = str.right(qMax(0,str.length()-sIndex-1));

    // create split on colon's
    QStringList field = str.split(':');
    // only process if there is something to process
    if(field.size() <= 1)
    {
        console->appendLine("    " + str);
        return false;
    }

    // next field may be a line number
    QString lineNumberStr = field.at(0);
    QString colNumberStr = field.at(1);
    bool okLine,okCol;
    lineNumberStr.toInt(&okLine);
    colNumberStr.toInt(&okCol);

    if(!okLine)
    {
        console->appendLine("    " + str);
        return false;
    }

    // remove line and column number (if present) from remaing string.
    str = str.right(str.length() - str.indexOf(':') - 1);
    if(okCol)
        str = str.right(str.length() - str.indexOf(':') - 1);
    str = str.simplified();

    // check for error
    QString tmp = str.toLower();
    if(     tmp.startsWith("error:") ||
            tmp.startsWith("fatal error:") ||
            tmp.startsWith("undefined "))
        ret = true;

    // create and print hyperlink
    // if ret == true print in red, else print in yellow
    // format required link stringlist
    QStringList list;
    list.append(filename);
    list.append(pathname);
    list.append(projectFolder);
    list.append(name);
    list.append(lineNumberStr);

    // send text and link to console
    console->appendText("    ");
    console->appendLink(list);
    console->appendText("line " + lineNumberStr + " : ");
    console->appendLine(str);

    return ret;
}

//!----------------------------------------------------------------------------
//! \brief  returns true if the pathname specifies a source or header file that
//!         is part of this project. otherwise returns false.
//!----------------------------------------------------------------------------
bool Project::isProjectFile(QString pathname)
{
    if(sourceFiles.contains(pathname))
        return true;
    if(headerFiles.contains(pathname))
        return true;
    return false;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::addBreakpoint(QString pathname, int lineNumber)
{
    if(isBreakpointAt(pathname,lineNumber)) return;
    S_Breakpoint bp;
    bp.pathname = pathname;
    bp.lineNumber = lineNumber;
    // don't add duplicates
    foreach(S_Breakpoint b,breakpointList)
        if((b.pathname == pathname) && (b.lineNumber == lineNumber)) return;
    breakpointList.append(bp);
    emit signalBreakpointAdded(pathname,lineNumber);

    return;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::removeBreakpoint(QString pathname, int lineNumber)
{
    for(int i=0;i<breakpointList.size();i++)
    {
        S_Breakpoint bp = breakpointList.at(i);
        if((bp.pathname == pathname) && (bp.lineNumber  == lineNumber))
        {
            breakpointList.removeAt(i);
            emit signalBreakpointRemoved(bp.pathname,bp.lineNumber);
            return true;
        }
    }
    return false;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::removeBreakpoints(QString pathname)
{
    for(int i=0;i<breakpointList.size();i++)
    {
        S_Breakpoint bp = breakpointList.at(i);
        if(bp.pathname == pathname)
        {
            breakpointList.removeAt(i);
            emit signalBreakpointRemoved(bp.pathname,bp.lineNumber);
            i--;
        }
    }
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::clearBreakpoints()
{
   breakpointList.clear();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QList<S_Breakpoint> Project::getBreakpoints()
{
   return breakpointList;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool Project::isBreakpointAt(QString pathname, int lineNumber)
{
    for(int i=0;i<breakpointList.size();i++)
    {
        S_Breakpoint bp = breakpointList.at(i);
        if((bp.pathname == pathname) && (bp.lineNumber  == lineNumber))
            return true;
    }
    return false;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int Project::getBreakpointCount()
{
    return breakpointList.size();
}

//!----------------------------------------------------------------------------
//! \brief A SourceEditor is telling us we need to update our breakpoints due
//! to editing.
//!----------------------------------------------------------------------------
void Project::updateBreakpoints(SourceEditor *editor, QString pathname)
{
    if(editor == NULL) return;
    if(pathname.isEmpty()) return;

    QList<int> list = editor->getBreakpoints();
    removeBreakpoints(pathname);
    foreach(int line,list)
        addBreakpoint(pathname,line);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::runIndexer()
{
    // this will launch a thread that will emit indexingComplete when done.
    qDebug() << "running project indexer:" << name;
    // emit a signal to the main window to start the project indexer
    emit indexProject(this);

//    QStringList list = sourceFiles + headerFiles;
//    indexer->processFileList(this,list);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
Indexer *Project::getIndexer()
{
    return indexer;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::slotIndexingComplete()
{
    emit indexingComplete(this);
}

//!----------------------------------------------------------------------------
//! \brief  Convenience function to get the program level target selected.
//!----------------------------------------------------------------------------
Target Project::getTarget()
{
    QString targetName = ProgramConfig::get(TARGET_NAME).toString();
    Target target(targetName);
    return target;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString Project::getCompilerBaseCmd()
{
    Target target = getTarget();
    QString s = target.getCompilerToolPrefix();
    return s;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
QString Project::getCompilerCmd()
{
    QString s = getCompilerBaseCmd() + compilerCmd;
/*#ifdef Q_OS_WIN
    s += ".exe";
#endif
*/    return s;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Project::runPostBuildCommands()
{
    foreach(QString cmd,postBuildCommands)
    {
        qDebug() << "post buld cmd:" << cmd;
        cmd = FileUtility::replaceKeyWithPath(this,cmd);
        qDebug() << "          cmd:" << cmd;
        ConsoleProcess *p = new ConsoleProcess(this);
        connect(p,SIGNAL(finished()),p,SLOT(deleteLater()));
        p->start(cmd,QStringList());
    }
}


