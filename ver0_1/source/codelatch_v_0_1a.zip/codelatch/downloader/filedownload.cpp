#include "filedownload.h"
#include <QFileInfo>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <stdio.h>
#include <QDebug>
#include <QTemporaryFile>

// TODO:
// make a queue system
// sending get adds to the queue and starts a download.
// on finish sends out a list of the remaining queue items and starts the next download.

// QNetworkReply::header(QNetworkRequest::ContentLengthHeader)

//QNetworkAccessManager * manager = new QNetworkAccessManager(this);
//connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(getHeaders(QNetworkReply*)));
//manager->head(QNetworkRequest(url));



FileDownload::FileDownload(QObject *parent)
    : QObject(parent)
{
    p_networkReply = NULL;
    downloadInProgress = false;
    connect(&networkManager, SIGNAL(finished(QNetworkReply*)), this, SLOT(getHeaders(QNetworkReply*)));
}

void FileDownload::setDestinationFolder(QString folderName)
{
    destFolder = folderName;
}

void FileDownload::get(const QUrl url, uint32_t size)
{
    if(size == 0) size = -1;
    if(downloadInProgress)
    {
        sizeQueue.append(size);
        downloadQueue.append(url);
        return;
    }
    expectedSize = size;
    startDownload(url);
}

void FileDownload::startDownload(const QUrl url)
{
    downloadInProgress = true;
    currentUrl = url;

    QString path = url.path();
    QString filename = QFileInfo(path).fileName();

    if(destFolder.isEmpty())
        destFilePath = filename;
    else
        destFilePath = destFolder + "/" + filename;

    destFilePath = destFilePath.replace("\\","/");
    destFilePath = destFilePath.replace("//","/");
    QFileInfo info(destFilePath);
    destFilePath = info.absoluteFilePath();

    emit startingDownload(destFilePath);

    if(tempFile.isOpen())
    {
        QTimer::singleShot(0, this, SIGNAL(startNextDownload(OPEN_FILE_FAILED)));
        return;
    }
    tempFile.setFileName(getTempFilepath());
    if(!tempFile.open(QIODevice::WriteOnly))
    {
        QTimer::singleShot(0, this, SIGNAL(startNextDownload(OPEN_FILE_FAILED)));
        return;
    }
    QFileInfo tempInfo(tempFile);

//    qDebug() << "URL:" << url;
//    qDebug() << "FileDownload::get temp filepath:" << tempInfo.absoluteFilePath();
//    qDebug() << "FileDownload::get dest filepath:" << destFilePath;

    // see if the remote file exists

    // get header to get file size
    totalBytes = 0;
    networkManager.head(QNetworkRequest(url));

    // get file
    QNetworkRequest request(url);
    request.setRawHeader("User-Agent", "Mozilla Firefox");
    p_networkReply = networkManager.get(request);
    qDebug() << "p_networkReply size:" << p_networkReply->size();
    qDebug() << "p_networkReply bytesAvailable:" << p_networkReply->bytesAvailable();


    if(!p_networkReply)
    {
        QTimer::singleShot(0, this, SIGNAL(startNextDownload(NETWORK_OBJ_NULL)));
        return;
    }
    connect(p_networkReply,SIGNAL(downloadProgress(qint64,qint64)),this,SLOT(slotProgress(qint64,qint64)));
    connect(p_networkReply,SIGNAL(readyRead()),this,SLOT(slotReadyRead()));
    connect(p_networkReply, SIGNAL(finished()),this,SLOT(slotFinished()));
}

void FileDownload::startNextDownload(FILEDOWNLOAD_RESULT status)
{
    this->status = status;
    if(status != SUCCESS)
        emit error(currentUrl,status);

    if(p_networkReply)
        p_networkReply->deleteLater();

    if(tempFile.isOpen())
        tempFile.close();
    if(tempFile.exists())
        tempFile.remove();

    emit fileDownloadComplete(destFilePath,status);
    if(downloadQueue.isEmpty())
    {
        downloadInProgress = false;
        emit finished();
        return;
    }

    QUrl url = downloadQueue.takeFirst();
    expectedSize = sizeQueue.takeFirst();
    startDownload(url);
}

void FileDownload::getHeaders(QNetworkReply *reply)
{
    qDebug() << "getHeaders.";
    if (reply->operation() == QNetworkAccessManager::HeadOperation)
    {
        uint content_length = reply->header(QNetworkRequest::ContentLengthHeader).toUInt();
        totalBytes = content_length;
        qDebug() << "totalBytes:" << totalBytes;
    }
}

void FileDownload::slotProgress(qint64 bytesReceived, qint64 bytesTotal)
{
    if(bytesTotal == -1)
        emit progress(destFilePath,bytesReceived,expectedSize);
    else
        emit progress(destFilePath,bytesReceived,bytesTotal);
}

void FileDownload::slotFinished()
{
    qDebug() << "FileDownload::slotFinished()";

    // if we don't have a network reply object we have a problem
    if(!p_networkReply)
    {
        startNextDownload(NETWORK_OBJ_NULL);
        return;
    }

    // if there was a network error we have a problem
    if(p_networkReply->error())
    {
        startNextDownload(NETWORK_REPLY_ERROR);
        return;
    }

    // if the tempFile is not open for writing we have a problem
    if(!tempFile.isOpen())
    {
        startNextDownload(COPY_FILE_FAILED);
        return;
    }

    // close the temp file
    tempFile.close();

    // if we can't open the temp file for reading we have a problem
    if(!tempFile.open(QIODevice::ReadOnly))
    {
        startNextDownload(COPY_FILE_FAILED);
        return;
    }

    // read in the data and then remove the temp file
    QByteArray data = tempFile.readAll();
    tempFile.close();
    tempFile.remove();

    // write the buffer to the destination file.
    QFile file(destFilePath);
    // if we can't open the destination file we have a problem
    if(!file.open(QIODevice::WriteOnly))
    {
        startNextDownload(COPY_FILE_FAILED);
        return;
    }
    file.write(data);
    file.close();

    // only in this case did we make it all the way through and copy the data ot the destination file. Yay!
    startNextDownload(SUCCESS);
}

void FileDownload::slotReadyRead()
{
    QByteArray data = p_networkReply->readAll();
    if(tempFile.isOpen())
        tempFile.write(data);
}

QString FileDownload::getErrorString()
{
    switch(status)
    {
    case SUCCESS:
        return "no error";
        break;
    case TIMEOUT:
        return "timeout error";
        break;
    case NETWORK_OBJ_NULL:
        return "network object was null";
        break;
    case NETWORK_REPLY_ERROR:
        return "network reply error";
        break;
    case NETWORK_REPLY_NOTFREE:
        return "network rely object in use";
        break;
    case OPEN_FILE_FAILED:
        return "open file failed:" + destFilePath;
        break;
    case COPY_FILE_FAILED:
        return "copy file failed";
        break;
    case DOWNLOAD_IN_PROGRESS:
        return "previous download is in progress";
    }
    return QString();
}

QString FileDownload::getTempFilepath()
{
    QTemporaryFile file;
    file.open();
    QFileInfo info(file);
    QString pathname = info.absoluteFilePath();
    file.close();
    return pathname;
}

void FileDownload::cancel()
{
    if(downloadInProgress)
    {
        downloadQueue.clear();
        p_networkReply->abort();
        p_networkReply->deleteLater();
        if(tempFile.isOpen())
        {
            tempFile.close();
            tempFile.remove();
        }
        downloadInProgress = false;
    }
}
