#ifndef READWEBPAGE_H
#define READWEBPAGE_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>

class ReadWebPage : public QObject
{
    Q_OBJECT
public:
    explicit ReadWebPage(QObject *parent = 0);
    ~ReadWebPage();

    bool sendRequest(QUrl url);
    QString sendRequestAndWait(QUrl url, uint timeout_ms = 2000);
    QByteArray getResponse() {return data;}
    void abort();

signals:
    void progress(quint64,quint64);
    void finished();

public slots:

private slots:
    void slotProgress(qint64 bytesReceived, qint64 bytesTotal);
    void slotFinished();
    void slotReadyRead();

private:
    QNetworkAccessManager *manager;
    QNetworkReply *pNetworkReply;
    QByteArray data;
};

#endif // READWEBPAGE_H
