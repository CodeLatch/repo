#include "readwebpage.h"
#include <QUrl>
#include <QEventLoop>
#include <QTimer>

ReadWebPage::ReadWebPage(QObject *parent) : QObject(parent)
{
    manager = new QNetworkAccessManager(this);
    pNetworkReply = NULL;
}

ReadWebPage::~ReadWebPage()
{
    if(pNetworkReply != NULL)
    {
        if(!pNetworkReply->isFinished() || pNetworkReply->isRunning())
            pNetworkReply->abort();
        pNetworkReply->deleteLater();
        pNetworkReply = NULL;
    }
}

void ReadWebPage::abort()
{
    if(pNetworkReply == NULL) return;
    pNetworkReply->abort();
    pNetworkReply->deleteLater();
    pNetworkReply = NULL;
}

QString ReadWebPage::sendRequestAndWait(QUrl url, uint timeout_ms)
{
    QEventLoop loop;
    QTimer timeoutTimer;

    if(pNetworkReply != NULL)
    {
        pNetworkReply->abort();
        pNetworkReply->deleteLater();
        pNetworkReply = NULL;
    }
    data.clear();

    QNetworkRequest request(url);
    request.setRawHeader("User-Agent", "Mozilla Firefox");
    pNetworkReply = manager->get(request);

    timeoutTimer.start(timeout_ms);
    connect(pNetworkReply,SIGNAL(readyRead()),this,SLOT(slotReadyRead()));
    connect(pNetworkReply, SIGNAL(finished()), &loop, SLOT(quit()));
    connect(&timeoutTimer, SIGNAL(timeout()), &loop, SLOT(quit()));
    loop.exec();

    if(!pNetworkReply->isFinished() || pNetworkReply->isRunning())
        pNetworkReply->abort();
    pNetworkReply->deleteLater();
    pNetworkReply = NULL;

    // data will typically end with char(10) which you may want to remove.
    return QString(data);
}

bool ReadWebPage::sendRequest(QUrl url)
{
    if(pNetworkReply != NULL)
    {
        if(!pNetworkReply->isFinished() || pNetworkReply->isRunning())
            return false;
        pNetworkReply->deleteLater();
        pNetworkReply = NULL;
    }
    data.clear();

    QNetworkRequest request(url);
    request.setRawHeader("User-Agent", "Mozilla Firefox");
    pNetworkReply = manager->get(request);

    connect(pNetworkReply,SIGNAL(downloadProgress(qint64,qint64)),this,SLOT(slotProgress(qint64,qint64)));
    connect(pNetworkReply,SIGNAL(readyRead()),this,SLOT(slotReadyRead()));
    connect(pNetworkReply, SIGNAL(finished()),this,SLOT(slotFinished()));
    return true;
}

void ReadWebPage::slotProgress(qint64 bytesReceived, qint64 bytesTotal)
{
    emit progress(bytesReceived,bytesTotal);
}

void ReadWebPage::slotFinished()
{
    // if there was a network error we have a problem
    if(pNetworkReply->error())
    {
        emit finished();
        return;
    }
    emit finished();
}

void ReadWebPage::slotReadyRead()
{
    data.append(pNetworkReply->readAll());
}


