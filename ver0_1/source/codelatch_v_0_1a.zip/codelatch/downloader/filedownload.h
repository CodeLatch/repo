#ifndef NET_H
#define NET_H

#include <QFile>
#include <QObject>
#include <QQueue>
#include <QUrl>
#include <QNetworkAccessManager>
#include <QDir>
#include <QNetworkReply>
#include <inttypes.h>

enum FILEDOWNLOAD_RESULT {
    SUCCESS = 0,
    TIMEOUT,
    NETWORK_OBJ_NULL,
    NETWORK_REPLY_ERROR,
    NETWORK_REPLY_NOTFREE,
    OPEN_FILE_FAILED,
    COPY_FILE_FAILED,
    DOWNLOAD_IN_PROGRESS,
};

class FileDownload: public QObject
{
    Q_OBJECT
public:
    FileDownload(QObject *parent = 0);

    void get(const QUrl url, uint32_t size = -1);
    void setDestinationFolder(QString folderName);
    QString getDestFilePath() {return destFilePath;}

    FILEDOWNLOAD_RESULT getLastError() {return status;}
    QString getErrorString();
    void cancel();

signals:
    void error(QUrl,FILEDOWNLOAD_RESULT);
    void startingDownload(QString destpath);
    void progress(QString destpath, qint64 bytesReceived, qint64 bytesTotal);
    void fileDownloadComplete(QString filepath,FILEDOWNLOAD_RESULT status);
    void finished();

private slots:
    void slotProgress(qint64 bytesReceived, qint64 bytesTotal);
    void slotFinished();
    void slotReadyRead();
    void startNextDownload(FILEDOWNLOAD_RESULT status);
    void getHeaders(QNetworkReply *reply);

private:
    void startDownload(const QUrl url);
    QString getTempFilepath();

    QNetworkAccessManager networkManager;
    QNetworkReply *p_networkReply;
    QFile tempFile;
    FILEDOWNLOAD_RESULT status;
    bool downloadInProgress;
    QString destFolder;
    QString destFilePath;
    QList<QUrl> downloadQueue;
    QList<uint32_t> sizeQueue;
    QUrl currentUrl;
    uint32_t expectedSize;
    quint64 totalBytes;
};

#endif
