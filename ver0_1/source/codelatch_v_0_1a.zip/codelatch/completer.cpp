//!----------------------------------------------------------------------------
//! file: completer.cpp
//!
//! Autocomplete popup.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include "completer.h"
#include <QScrollBar>
#include <QScrollArea>
#include <QDebug>
#include <QGridLayout>
#include <QKeyEvent>
#include <QApplication>
#include <QDesktopWidget>
#include <QWindow>
#include "indexer/indexer.h"

#define MAX_NUM_COMPLETIONS 100      // if more than this number of completions are found we won't show the popup.

ListWidget::ListWidget(QWidget *parent) :
    QListWidget(parent)
{
}

void ListWidget::keyPressEvent(QKeyEvent *event)
{
    QKeyEvent e = *event;
    emit keyPressed(e);
    QListWidget::keyPressEvent(event);
}

//!----------------------------------------------------------------------------
//! \brief  Constructor - The parent must be the editor widget, typically
//!         a QPlainTextEdit widget.
//!----------------------------------------------------------------------------
Completer::Completer(QWidget *parent) :
    QWidget(parent)
{
    setWindowFlags(Qt::Popup);
    scroll = new QScrollArea;
    popupList = new ListWidget;
    QGridLayout *layout = new QGridLayout;
    scroll->setWidget(popupList);
    layout->addWidget(scroll);
    layout->setContentsMargins(0,0,0,0);
    setLayout(layout);

    connect(popupList,SIGNAL(itemActivated(QListWidgetItem*)),this,SLOT(popupItemClicked(QListWidgetItem*)));
    // need to intercept/get key presses from the QListWidget
    connect(popupList,SIGNAL(keyPressed(QKeyEvent)),this,SIGNAL(keyPressed(QKeyEvent)));
}

//!----------------------------------------------------------------------------
//! \brief  Show autocompletion popup with suggestions. The user can either
//!         press escape to cancel or press enter or mouse double click to
//!         select a completion.
//!         If a completion is selected a signal will be sent containing the
//!         entire completion string (including the passed prefix). Note:
//!         the string in the signal may have alternate capitalization so
//!         you need to replace the whole prefix in the editor before inserting
//!         the completion.
//!
//! \param  prefix - string in need of completion
//! \param  rect - plainTextEdit->cursorRect()
//!----------------------------------------------------------------------------
void Completer::showPopup(const QList<Tag*> &list, QPoint &pos)
{
    popupList->clear(); // note: clear handles deleting allocated items as well

    if((list.size() > MAX_NUM_COMPLETIONS) || list.isEmpty())
    {
        hide();
        return;
    }

    // create items
    foreach(Tag *tag,list)
    {
        QListWidgetItem *item = new QListWidgetItem;
        QString name = tag->name;
        if(!tag->funcParameters.isEmpty())
            name += " " + tag->funcParameters;
        item->setText(name);
        QIcon icon = tag->getIcon(tag);
        item->setIcon(icon);
        popupList->addItem(item);
    }

    popupList->sortItems();

    // remove duplicates
    for(int i=1;i<popupList->count();i++)
    {
        if(popupList->item(i)->text() == popupList->item(i-1)->text())
            popupList->takeItem(i--);
    }

    // adjust width to contents or min of 100 pixels.
    int scrollWidth = scroll->verticalScrollBar()->sizeHint().width();
    int width = popupList->sizeHintForColumn(0) + scrollWidth;
    width = qMax(width,100);

    // adjust height to show 1..8 lines, after 8 user needs to scroll
    int height = popupList->sizeHintForRow(0);
    height = qMax(height,qMin(height*8,height * popupList->count()));

    // make sure the popup is on screen
    const QRect screen = QApplication::desktop()->availableGeometry();
    if((pos.x()+width) > screen.width())
        pos.setX(screen.width()-width-10);
    if((pos.x()) < 0)
        pos.setX(10);
    if((pos.y()+height) > screen.height())
        pos.setY(screen.height() - height - 10);
    if(pos.y() < 0)
        pos.setY(10);

    // setup and show popup
    setMinimumHeight(height+4);
    resize(width+2,height+4);
    move(pos);
    popupList->resize(width,height+2);
    popupList->setFocus();
    popupList->setCurrentRow(0);
    show();
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void Completer::popupItemClicked(QListWidgetItem* item)
{
    hide();
    QString str = item->text();
    emit activated(str);

}
