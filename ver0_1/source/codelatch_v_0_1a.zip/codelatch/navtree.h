#ifndef NAVTREE_H
#define NAVTREE_H

#include <QtGui>
#include <QStringList>
#include "project/project.h"
#include "navtree.h"
#include <QTreeWidget>
#include <QTreeWidgetItem>

class NavTree : public QTreeWidget
{
    Q_OBJECT

// functions
public:
    explicit NavTree(QWidget *parent = 0);
        ~NavTree();

    void initializeTree();
    Project *addProject(QString pathname);
    bool removeProject(Project *prj);
    Project *getProjectFromFolder(QString projectFolder);
    Project *getProject(QTreeWidgetItem *item);
    Project *getProjectFromFile(QString pathname);
    int findTopLevelItem(QString projectFolder);
    void getOpenProjectsList(QStringList *list);
    QString getSelectedFilepath();
    Project *getSelectedProject();
    bool copyFile(QString &sourcePath, QString &destFolderPath, bool move);
    QTreeWidgetItem *findItem(QString pathname);
    bool isFolder(QTreeWidgetItem *item);
    void closeTempProjects();

    // utility routines to get/set info about a tree item
    QTreeWidgetItem *getContextItem() {return contextItem;}
    void setPathname(QTreeWidgetItem *item, QString pathname);
    void setProjectFolder(QTreeWidgetItem *item, QString projectFolder);
    void setProjectName(QTreeWidgetItem *item, QString projectName);
    QString getPathname(QTreeWidgetItem *item);
    QString getProjectFolder(QTreeWidgetItem *item);
    QString getProjectName(QTreeWidgetItem *item);
    QString getPath(QTreeWidgetItem *item);
    bool isProjectFolder(QTreeWidgetItem *item);
    bool hasCutSelection();
    bool hasCopySelection();
    bool hasPasteSource();

private:
    // dnd overrides
    void dropEvent(QDropEvent *event);
    void dragEnterEvent(QDragEnterEvent *event);
    void dragMoveEvent(QDragMoveEvent *event);

    // dnd utlity routines for checking valid drops
    bool isSourceParentOfDest(QStringList source, QString destpath);
    bool isSourceInDest(QStringList source, QString destpath);

    void addChildren(QTreeWidgetItem* item,Project *project, QString filePath);
    void setIcon(QFileInfo fileInfo, QTreeWidgetItem *item);
    void expandChildrenInList(QTreeWidgetItem *item, QStringList *list);
    void addExpandedChildrenToList(QTreeWidgetItem *item, QStringList *list);
    QTreeWidgetItem *findItem(QTreeWidgetItem *item, QString pathname);
    void handleFileDrop(QStringList list, QTreeWidgetItem *dest);
    void handleWidgetDrop(QList<QTreeWidgetItem*> list, QTreeWidgetItem *dest);
    QString getNewFileName(QString &pathname);

protected:
    void contextMenuEvent(QContextMenuEvent *event);

public slots:
    void actionCut();
    void actionCopy();
    void actionPaste();

    void selectFile(QString pathname);
    bool openFile(QString pathname,int line);
    void updateProjectTree(Project *project);

private slots:
    void hoverTimerExpired();
    void slotCloseProject() {emit sigCloseProject(NULL);}
    void navItemDoubleClicked(QTreeWidgetItem* item,int col);
    void navItemClicked(QTreeWidgetItem* item,int col);
    void slotItemSelectionChanged();

signals:
    void projectIndexingComplete(Project*);
    void sigNewFile();
    void sigNewFolder();
    void sigProjectSaveAs();
    void sigFileSaveAs();
    void sigRename();
    void sigDelete();
    void sigCloseProject(Project*);
    void sigFileMoved(QString,QString,Project*);
    void sigUpdateDynamicProjectMenu();

    void doubleClicked(Project*,QString);
    void singleClicked(Project*,QString);
    void sigSelectionChanged(Project*,QString);

    void sigOpenFile(Project*,QString,int);
    void projectAdded(Project *prj);

// variables
public:
    QList<Project*> projectList;

    enum NavigatorConstants {
        ProjectName = Qt::UserRole+0,
        ProjectFolder = Qt::UserRole+1,
        FilePath = Qt::UserRole+2
    };

private:
    QTreeWidgetItem *contextItem;
    QTreeWidgetItem *hoverItem;
    QTime hoverTime;
    QTimer *hoverTimer;
    QList<QTreeWidgetItem *> pasteSourceList;
    bool pasteMove;

};

#endif // NAVTREE_H
