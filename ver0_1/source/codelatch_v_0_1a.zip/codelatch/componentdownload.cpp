// see if there are the directories...
//      compiler, examples, tools, targets, doc, and lib.
//   if any are missing we should download from the website.
//
//   if there's no projects directory we should create an empty one.


#include "componentdownload.h"
#include "ui_updatedialog.h"
#include <QTimer>
#include <QMessageBox>
#include <QFileInfoList>
#include <QDir>
#include "utility/fileutility.h"
#include "programconfig.h"
#include "zip.h"
#include "downloader/filedownload.h"
#include "downloader/readwebpage.h"

ComponentDownloadDialog::ComponentDownloadDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UpdateDialog)
{
    ui->setupUi(this);
    setWindowTitle(tr("Component Download"));
    ui->progressBar->setRange(0,100);
    ui->progressBar->setValue(0);
    ui->buttonStart->setFocus();

    scanLocalDirectory();

    connect(&fileDownload,SIGNAL(startingDownload(QString)),this,SLOT(slotFileDownloadStarting(QString)));
    connect(&fileDownload,SIGNAL(progress(QString,qint64,qint64)),this,SLOT(slotDownloadProgress(QString,qint64,qint64)));
    connect(&fileDownload,SIGNAL(fileDownloadComplete(QString,FILEDOWNLOAD_RESULT)),this,SLOT(slotFileDownloadComplete(QString,FILEDOWNLOAD_RESULT)));
    connect(&fileDownload,SIGNAL(finished()),this,SLOT(slotDownloadsFinished()));
}

ComponentDownloadDialog::~ComponentDownloadDialog()
{
    delete ui;
}

void ComponentDownloadDialog::scanLocalDirectory()
{
    QString dirCompiler = FileUtility::getDirCompiler();
    QString dirTools = FileUtility::getDirTools();
    QString dirTargets = FileUtility::getDirTargets();
    QString dirExamples = FileUtility::getDirExamples();
    QString dirLibrary = FileUtility::getDirLibrary();
    QString dirDoc = FileUtility::getDirDoc();

    ui->cbCompiler->setChecked(!QFileInfo::exists(dirCompiler));
    ui->cbTools->setChecked(!QFileInfo::exists(dirTools));
    ui->cbTargets->setChecked(!QFileInfo::exists(dirTargets));
    ui->cbExamples->setChecked(!QFileInfo::exists(dirExamples));
    ui->cbLibraries->setChecked(!QFileInfo::exists(dirLibrary));
    ui->cbDocs->setChecked(!QFileInfo::exists(dirDoc));
}

void ComponentDownloadDialog::on_cbAllComponents_clicked()
{
    bool checked = ui->cbAllComponents->isChecked();
    if(checked)
    {
        ui->cbCompiler->setChecked(true);
        ui->cbTools->setChecked(true);
        ui->cbTargets->setChecked(true);
        ui->cbLibraries->setChecked(true);
        ui->cbExamples->setChecked(true);
        ui->cbDocs->setChecked(true);
    }
}

void ComponentDownloadDialog::on_cbCompiler_clicked()
{
    if(!ui->cbCompiler->isChecked())
        ui->cbAllComponents->setChecked(false);
}

void ComponentDownloadDialog::on_cbLibraries_clicked()
{
    if(!ui->cbLibraries->isChecked())
        ui->cbAllComponents->setChecked(false);
}

void ComponentDownloadDialog::on_cbExamples_clicked()
{
    if(!ui->cbExamples->isChecked())
        ui->cbAllComponents->setChecked(false);
}

void ComponentDownloadDialog::on_cbTools_clicked()
{
    if(!ui->cbTools->isChecked())
        ui->cbAllComponents->setChecked(false);
}

void ComponentDownloadDialog::on_cbTargets_clicked()
{
    if(!ui->cbTargets->isChecked())
        ui->cbAllComponents->setChecked(false);
}

void ComponentDownloadDialog::on_cbDocs_clicked()
{
    if(!ui->cbDocs->isChecked())
        ui->cbAllComponents->setChecked(false);
}

void ComponentDownloadDialog::on_buttonCancel_clicked()
{
    // if we are in the middle of a download then stop it gracefully
    if(ui->buttonCancel->text() == "Cancel")
    {
        fileDownload.cancel();
        foreach(QString filepath,downloadedFileList)
        {
            QFile file(filepath);
            file.remove();
        }
        ui->plainTextEdit->appendPlainText("\nCanceled.");
        emit updateMenus();

        ui->buttonStart->setDisabled(false);
        ui->buttonCancel->setText("Close");
        return;
    }

    // otherwise just close
    this->close();
}


void ComponentDownloadDialog::slotFileDownloadStarting(QString filepath)
{
    ui->progressBar->setValue(0);
    QString msg = "Downloading " + QFileInfo(filepath).fileName() + "...";
    ui->plainTextEdit->appendPlainText(msg);
}

void ComponentDownloadDialog::slotFileDownloadComplete(QString filepath, FILEDOWNLOAD_RESULT result)
{
    QString msg;
    if(result != SUCCESS)
        msg = "   Error:" + fileDownload.getErrorString();
    ui->plainTextEdit->appendPlainText(msg);
    downloadedFileList.append(filepath);
}

void ComponentDownloadDialog::slotDownloadsFinished()
{
    // don't allow cancel at this point
    ui->buttonCancel->setDisabled(true);
    ui->progressBar->setValue(0);
    ui->plainTextEdit->appendPlainText("extracting files...");

    QTimer timeoutTimer;
    timeoutTimer.start(20000);
    QTimer::singleShot(10, this, SLOT(unzipDownloads()));
    connect(&timeoutTimer, SIGNAL(timeout()), &eventLoop, SLOT(quit()));
    eventLoop.exec();

    ui->buttonStart->setDisabled(false);
    ui->buttonCancel->setDisabled(false);
    ui->buttonCancel->setText("Close");
}

void ComponentDownloadDialog::unzipDownloads()
{
    Zip zip;
    connect(&zip,SIGNAL(progress(QString,qint64,qint64)),this,SLOT(slotDownloadProgress(QString,qint64,qint64)));
    QApplication::setOverrideCursor(Qt::WaitCursor);
    foreach(QString filepath,downloadedFileList)
    {
        QFile file(filepath);
        if(!file.exists()) continue;
        ui->plainTextEdit->appendPlainText("Extracting:" + file.fileName());
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
        if(!zip.unzip(filepath,true))
        {
            ui->plainTextEdit->appendPlainText("   Error unzipping.");
            file.open(QIODevice::ReadOnly);
            QByteArray b = file.readAll();
            file.close();
        }
        file.remove();
    }
    ui->plainTextEdit->appendPlainText("Done.");
    emit updateMenus();
    QApplication::restoreOverrideCursor();
    eventLoop.quit();
}

void ComponentDownloadDialog::slotDownloadProgress(QString filepath,qint64 value, qint64 total)
{
    Q_UNUSED(filepath);
    ui->progressBar->setRange(0,total);
    ui->progressBar->setValue(value);
}

void ComponentDownloadDialog::on_buttonStart_clicked()
{
    QString folder = ProgramConfig::get(ROOT_STORAGE_FOLDER).toString();
    QFileInfo info(folder);
    // if the root storage folder is not specified or doesn't exist put up a message and stop
    if(folder.isEmpty() || !info.exists())
    {
        QString text = "The Home Folder has not been selected. You must select this first using "
                       "the menu Tools->Select Home Folder.";
        QMessageBox::information(this, "Update", text, QMessageBox::Ok);
        return;
    }

    bool getCompiler = ui->cbCompiler->isChecked();
    bool getLibraries = ui->cbLibraries->isChecked();
    bool getExamples = ui->cbExamples->isChecked();
    bool getTools = ui->cbTools->isChecked();
    bool getTargets = ui->cbTargets->isChecked();
    bool getDocs = ui->cbDocs->isChecked();

    ui->buttonStart->setDisabled(true);
    ui->buttonCancel->setText("Cancel");
    downloadedFileList.clear();

    ReadWebPage webRead(this);
    ui->plainTextEdit->appendPlainText("Getting file locations...");
    QString resp = webRead.sendRequestAndWait(QUrl(HTTP_CODELATCH_REPO_LIST),5000);
    if(resp.isEmpty())
    {
        ui->plainTextEdit->appendPlainText(QString("Error getting server address."));
        ui->buttonCancel->setText("Close");
        ui->buttonStart->setDisabled(false);
        return;
    }
    // the repo list is a list of key;server_file pairs. each line contains one pair and
    // each pair key and server_file are seperated by a semicolon.
    QMap<QString,QString> map;
    QStringList lineList = resp.split('\n');
    foreach(QString line,lineList)
    {
        QStringList fields = line.split(';');
        if(fields.size() != 2) continue;
        map.insert(fields.at(0),fields.at(1));
    }

    fileDownload.setDestinationFolder(folder);

    // download files
    if(getCompiler)
        download(map,KEY_COMPILER_ZIP);

    if(getTools)
        download(map,KEY_TOOLS_ZIP);

    if(getTargets)
        download(map,KEY_TARGETS_ZIP);

    if(getLibraries)
        download(map,KEY_LIB_ZIP);

    if(getExamples)
        download(map,KEY_EXAMPLES_ZIP);

    if(getDocs)
        download(map,KEY_DOC_ZIP);

    ui->buttonStart->setDisabled(true);
}

void ComponentDownloadDialog::download(const QMap<QString,QString> &map, const QString &key)
{
    ReadWebPage webRead(this);

    QString zipFile = map.value(key);
    QString sizeFile = zipFile;
    sizeFile.replace(".zip",".size.txt");
    if(!zipFile.isEmpty())
    {
        QString str = webRead.sendRequestAndWait(QUrl(sizeFile),5000);
        uint32_t size = str.toUInt();
        fileDownload.get(QUrl(zipFile),size);
    }
}
