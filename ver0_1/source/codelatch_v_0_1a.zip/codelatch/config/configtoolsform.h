#ifndef CONFIGTOOLSFORM_H
#define CONFIGTOOLSFORM_H

#include "project/project.h"
#include <QWidget>
#include <QStringList>
#include <QListWidget>
#include "target.h"

namespace Ui {
class ConfigToolsForm;
}

class ConfigToolsForm : public QWidget
{
    Q_OBJECT
    
public:
    explicit ConfigToolsForm(Project *project, QWidget *parent = 0);
    ~ConfigToolsForm();
    void setProject(Project *project);

    QString getPathname();
    QString getProjectFolder();
    Project* getProject();

private slots:
    void on_comboOptimization_currentIndexChanged(const QString &arg1);
    void on_comboBuildType_currentIndexChanged(const QString &arg1);
    void on_cbDynamicMem_clicked();
    void on_cbRemoveUnused_clicked();
    void on_addCompilerOption_clicked();
    void on_removeCompilerOption_clicked();
    void on_editCompilerOption_clicked();
    void on_addLinkerOption_clicked();
    void on_removeLinkerOption_clicked();
    void on_editLinkerOption_clicked();

    void on_compilerCmd_textChanged(const QString &arg1);

private:
    QStringList removeSelectedItemsFromList(QListWidget *widget);

private:
    Ui::ConfigToolsForm *ui;
    Project *prj;
};

#endif // CONFIGTOOLSFORM_H
