#ifndef CONFIGPROJECTFORM_H
#define CONFIGPROJECTFORM_H

#include <QWidget>

class Target;

namespace Ui {
class ConfigMicroForm;
}

class ConfigMicroForm : public QWidget
{
    Q_OBJECT
    
public:
    explicit ConfigMicroForm(Target *target, QWidget *parent = 0);
    ~ConfigMicroForm();

signals:
    void targetSelectionChanged();
    void updateTargetList();

public slots:
    void updateForm();
//    void on_comboTargetName_currentIndexChanged(const QString &arg1);

private slots:
    void on_configHelp_clicked();
    void on_pbNewTarget_clicked();
    void on_btnAdd_clicked();
    void on_btnRemove_clicked();
    void on_pbSaveAs_clicked();
    void on_configDescription_textChanged();
    void on_tbCompilerPath_clicked();
    void on_tbFlashPrg_clicked();
    void on_tbGdbServer_clicked();
    void on_flashPrgArgs_textChanged(const QString &arg1);
    void on_gdbServerArgs_textChanged(const QString &arg1);
    void on_gdbCommands_textChanged();
    void on_maxHWBreakpoints_textChanged(const QString &arg1);
    void on_cbUpdateLPCUserCode_clicked(bool checked);

private:
    Ui::ConfigMicroForm *ui;
    int fontHeight;
    Target *target;
    QString getNewTargetName(QString newName = QString());

};

#endif // CONFIGPROJECTFORM_H
