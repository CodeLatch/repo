#include "configpostbuildform.h"
#include "ui_configpostbuildform.h"
#include "utility/fileutility.h"
#include <QInputDialog>
#include <QLineEdit>

ConfigPostBuildForm::ConfigPostBuildForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ConfigPostBuildForm)
{
    prj = NULL;
    ui->setupUi(this);
}

ConfigPostBuildForm::~ConfigPostBuildForm()
{
    delete ui;
}

void ConfigPostBuildForm::setProject(Project *project)
{
    prj = project;
    if(prj == NULL) return;

    QStringList cmds = prj->getPostBuildCommands();
    for(int i=0;i<cmds.size();i++)
        cmds.replace(i,FileUtility::replacePathWithKey(prj,cmds.at(i)));
    ui->listPostBuild->addItems(cmds);
}

void ConfigPostBuildForm::on_postBuildHelp_clicked()
{

}

void ConfigPostBuildForm::on_addPostBuild_clicked()
{
    if(prj == NULL) return;

    QString text;

    bool ok;
    text = QInputDialog::getText(this, "Add", "Command:", QLineEdit::Normal, text, &ok);
    if (!ok || text.isEmpty())
        return;

    text = FileUtility::replaceKeyWithPath(prj,text);
    QStringList list = prj->getPostBuildCommands();
    list.append(text);
    prj->setPostBuildCommands(list);
    prj->save();

    for(int i=0;i<list.size();i++)
        list.replace(i,FileUtility::replacePathWithKey(prj,list.at(i)));

    ui->listPostBuild->clear();
    ui->listPostBuild->addItems(list);
}

void ConfigPostBuildForm::on_removePostBuild_clicked()
{
    if(prj == NULL) return;

    QStringList list = removeSelectedItemsFromList(ui->listPostBuild);

    for(int i=0;i<list.size();i++)
        list.replace(i,FileUtility::replaceKeyWithPath(prj,list.at(i)));

    prj->setPostBuildCommands(list);
    prj->save();
}

void ConfigPostBuildForm::on_editPostBuild_clicked()
{
    if(prj == NULL) return;

    QListWidgetItem *item =  ui->listPostBuild->currentItem();
    if(item == NULL) return;
    QString text = item->text();

    bool ok;
    text = QInputDialog::getText(this, "Edit", "Command:", QLineEdit::Normal, text, &ok);
    if (ok && !text.isEmpty())
    {
        item->setText(text);
        ui->listPostBuild->setCurrentItem(item);
        // copy ui items to prj
        QStringList list;
        for(int i=0;i<ui->listPostBuild->count();i++)
            list.append(ui->listPostBuild->item(i)->text());

        for(int i=0;i<list.size();i++)
            list.replace(i,FileUtility::replaceKeyWithPath(prj,list.at(i)));
        prj->setPostBuildCommands(list);
        prj->save();
    }
}

void ConfigPostBuildForm::on_moveUpPostBuild_clicked()
{
    if(prj == NULL) return;

    QListWidgetItem *current =  ui->listPostBuild->currentItem();
    QListWidgetItem *prev = ui->listPostBuild->item(ui->listPostBuild->row(current) - 1);
    if((current == NULL) || (prev == NULL)) return;

    int currIndex =  ui->listPostBuild->row(current);
    int prevIndex = ui->listPostBuild->row(prev);

    QListWidgetItem *temp = ui->listPostBuild->takeItem(prevIndex);
    ui->listPostBuild->insertItem(prevIndex, current);
    ui->listPostBuild->insertItem(currIndex, temp);
    QStringList list;
    for(int i=0;i<ui->listPostBuild->count();i++)
        list.append(ui->listPostBuild->item(i)->text());

    for(int i=0;i<list.size();i++)
        list.replace(i,FileUtility::replaceKeyWithPath(prj,list.at(i)));
    prj->setPostBuildCommands(list);
    prj->save();
}

void ConfigPostBuildForm::on_moveDownPostBuild_clicked()
{
    if(prj == NULL) return;

    QListWidgetItem *current =  ui->listPostBuild->currentItem();
    QListWidgetItem *next = ui->listPostBuild->item(ui->listPostBuild->row(current) + 1);
    if((current == NULL) || (next == NULL)) return;

    int currIndex =  ui->listPostBuild->row(current);
    int nextIndex = ui->listPostBuild->row(next);

    QListWidgetItem *temp = ui->listPostBuild->takeItem(nextIndex);
    ui->listPostBuild->insertItem(currIndex, temp);
    ui->listPostBuild->insertItem(nextIndex, current);
    QStringList list;
    for(int i=0;i<ui->listPostBuild->count();i++)
        list.append(ui->listPostBuild->item(i)->text());

    for(int i=0;i<list.size();i++)
        list.replace(i,FileUtility::replaceKeyWithPath(prj,list.at(i)));
    prj->setPostBuildCommands(list);
    prj->save();
}

QStringList ConfigPostBuildForm::removeSelectedItemsFromList(QListWidget *widget)
{
    QStringList strlist;
    qDeleteAll(widget->selectedItems());
    for(int i=0;i<widget->count();i++)
        strlist.append(widget->item(i)->text());
    return strlist;
}
