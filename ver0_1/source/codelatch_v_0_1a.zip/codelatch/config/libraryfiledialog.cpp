/*

  libraryfiledialog.cpp

  This class implements a dialog that is used to enter or select a library file.
  Library files must start with "lib" and end with ".a". This is a utility dialog
  used by ConfigLibraryForm.

  Upon pressing Ok...

  public QString fileName   = the filename selected minus the leading "lib".
  public QString folderName = the folder the library resides in with key replacement if applicable (see FileUtilties).

*/

#include <QtGui>
#include <QFileDialog>
#include <QFileInfo>
#include <QMessageBox>
#include "libraryfiledialog.h"
#include "utility/fileutility.h"

LibraryFileDialog::LibraryFileDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LibraryFileDialog)
{
    ui->setupUi(this);

    setWindowTitle(tr("Library File Selection"));
}

void LibraryFileDialog::on_pushButton_clicked()
{
    QFileDialog dlg;

    pathName.clear();

    QString dir = FileUtility::getDirLibrary();
    dlg.setDirectory(dir);
    dlg.setNameFilter("Library Files (*.a)");
    if(!dlg.exec())
        return;
    if(dlg.selectedFiles().size() == 0)
        return;

    // we can only select one file at a time, so we don't have to deal with the list.
    pathName = dlg.selectedFiles().at(0);
    QFileInfo info(pathName);

    // GCC requires library files start with "lib"
    if(!info.fileName().startsWith("lib"))
    {
        QMessageBox msgBox;
        msgBox.setText(info.fileName() + " is an invalid name. GCC requires library files start with \"lib\". Try renaming the file.");
        msgBox.setIcon(QMessageBox::Critical);
        msgBox.exec();
        return;
    }
    // GCC requires library files end with ".a"
    if(!info.fileName().endsWith(".a"))
    {
        QMessageBox msgBox;
        msgBox.setText(info.fileName() + " is an invalid name. GCC requires library files end with \".a\". Try renaming the file.");
        msgBox.setIcon(QMessageBox::Critical);
        msgBox.exec();
        return;
    }

    ui->lineEdit->setText(pathName);
}

void LibraryFileDialog::on_buttonBox_accepted()
{
    pathName = ui->lineEdit->text();
    accept();
}

void LibraryFileDialog::on_buttonBox_rejected()
{
    reject();
}
