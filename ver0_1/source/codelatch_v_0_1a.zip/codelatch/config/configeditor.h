#ifndef CONFIGEDITOR_H
#define CONFIGEDITOR_H

#include <QWidget>

namespace Ui {
class ConfigEditor;
}

class ConfigEditor : public QWidget
{
    Q_OBJECT

public:
    explicit ConfigEditor(QWidget *parent = 0);
    ~ConfigEditor();

private slots:
    void updateExample();

signals:
    void modified();

private:
    void saveConfig();

    Ui::ConfigEditor *ui;
    QStringList styleList,styleFlags,colorSchemeList;
    QStringList varPtrAlignment,varPtrFlags;
    QStringList funcPtrAlignment,funcPtrFlags;

};

#endif // CONFIGEDITOR_H
