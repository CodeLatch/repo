#ifndef LIBRARYFILEDIALOG_H
#define LIBRARYFILEDIALOG_H

#include <QDialog>
#include "ui_libraryfiledialog.h"

namespace Ui {
    class LibraryFileDialog;
}

class LibraryFileDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LibraryFileDialog(QWidget *parent = 0);
    
    QString pathName;

signals:
    
public slots:

private slots:
    void on_pushButton_clicked();

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::LibraryFileDialog *ui;
};

#endif // LIBRARYFILEDIALOG_H
