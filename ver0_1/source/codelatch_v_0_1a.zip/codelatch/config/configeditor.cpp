#include "configeditor.h"
#include "ui_configeditor.h"
#include "programconfig.h"
#include "format.h"

ConfigEditor::ConfigEditor(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ConfigEditor)
{
    ui->setupUi(this);

    QString colorScheme = ProgramConfig::get(EDITOR_COLOR_SCHEME).toString();
    int autoCompleteTimeout = ProgramConfig::get(EDITOR_AUTOCOMPLETE_TIMEOUT).toInt();
    bool autoFormat = ProgramConfig::get(EDITOR_AUTOFORMAT_ENABLED).toBool();
    bool autoIndent = ProgramConfig::get(EDITOR_AUTOINDENT_ENABLED).toBool();
    QString formatFlags = ProgramConfig::get(EDITOR_FORMAT_FLAGS).toString();

    // initialize lists
    colorSchemeList << "Default" << "Dark" << "Simple";

    styleList << "Allman" << "Java" << "K & R" << "Stroustrup" << "Whitesmith" << "Banner";
    styleList << "GNU" << "Linux" << "Hostmann" << "One True Brace" << "Pico" << "Lisp";
    styleFlags << "A1" << "A2" << "A3" << "A4" << "A5" << "A6";
    styleFlags << "A7" << "A8" << "A9" << "A10" << "A11" << "A12";

    varPtrAlignment << "type" << "middle" << "variable";
    varPtrFlags << "k1" << "k2" << "k3";

    funcPtrAlignment << "none" << "type" << "middle" << "name";
    funcPtrFlags << "W0" << "W1" << "W2" << "W3";

    int i;
    for(i=0;i<styleFlags.size();i++)
        if(formatFlags.contains(styleFlags.at(i))) break;
    if(i == styleFlags.size()) i = 0; // default if no flag is set yet
    int styleIndex = i;

    for(i=0;i<varPtrFlags.size();i++)
        if(formatFlags.contains(varPtrFlags.at(i))) break;
    if(i == varPtrFlags.size()) i = 0; // default if no flag is set yet
    int varPtrIndex = i;

    for(i=0;i<funcPtrFlags.size();i++)
        if(formatFlags.contains(funcPtrFlags.at(i))) break;
    if(i == funcPtrFlags.size()) i = 1; // default if no flag is set yet
    int funcPtrIndex = i;

    if(colorScheme.isEmpty())
        colorScheme = colorSchemeList.first();

    if(autoCompleteTimeout <= 50)
        autoCompleteTimeout = 50;
    else if(autoCompleteTimeout >= 1000)
        autoCompleteTimeout = 1000;

    // update color scheme combo
    ui->comboBoxColorScheme->addItems(colorSchemeList);
    ui->comboBoxColorScheme->setCurrentText(colorScheme);
    // timeout
    ui->autocompleteTimeout->setText(QString::number(autoCompleteTimeout));
    // update format style combo
    ui->comboBoxStyle->addItems(styleList);
    ui->comboBoxStyle->setCurrentIndex(styleIndex);
    // update varPtrAlignment combo
    ui->comboBox_VarPtrAlign->addItems(varPtrAlignment);
    ui->comboBox_VarPtrAlign->setCurrentIndex(varPtrIndex);
    // update funcPtrAlignment combo
    ui->comboBox_FuncPtrAlign->addItems(funcPtrAlignment);
    ui->comboBox_FuncPtrAlign->setCurrentIndex(funcPtrIndex);
    // update format check boxes
    ui->autocompleteTimeout->setText(QString::number(autoCompleteTimeout));

    ui->checkBox_AutoIndent->setChecked(autoIndent);
    ui->checkBox_AutoFormat->setChecked(autoFormat);
    ui->checkBox_IndentCases->setChecked(formatFlags.contains('K'));
    ui->checkBox_IndentLabels->setChecked(formatFlags.contains('L'));
    ui->checkBox_RemoveParenSpace->setChecked(formatFlags.contains('U'));
    ui->checkBox_SpaceAfterStmts->setChecked(formatFlags.contains('H'));
    ui->checkBox_SpaceOperators->setChecked(formatFlags.contains('p'));
    ui->checkBox_SpaceParen->setChecked(formatFlags.contains('P'));

    ui->exampleCode->setWordWrapMode(QTextOption::NoWrap);
    QFontMetrics metrics(ui->exampleCode->font());
    int tabWidth = metrics.width("    ");
    ui->exampleCode->setTabStopWidth(tabWidth);

    updateExample();

    connect(ui->comboBoxColorScheme,SIGNAL(currentIndexChanged(int)),this,SLOT(updateExample()));
    connect(ui->autocompleteTimeout,SIGNAL(textChanged(QString)),this,SLOT(updateExample()));
    connect(ui->comboBoxStyle,SIGNAL(currentIndexChanged(int)),this,SLOT(updateExample()));
    connect(ui->comboBox_VarPtrAlign,SIGNAL(currentIndexChanged(int)),this,SLOT(updateExample()));
    connect(ui->comboBox_FuncPtrAlign,SIGNAL(currentIndexChanged(int)),this,SLOT(updateExample()));
    connect(ui->checkBox_AutoIndent,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
    connect(ui->checkBox_AutoFormat,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
    connect(ui->checkBox_IndentCases,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
    connect(ui->checkBox_IndentLabels,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
    connect(ui->checkBox_RemoveParenSpace,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
    connect(ui->checkBox_SpaceAfterStmts,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
    connect(ui->checkBox_SpaceOperators,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
    connect(ui->checkBox_SpaceParen,SIGNAL(clicked(bool)),this,SLOT(updateExample()));
}

ConfigEditor::~ConfigEditor()
{
    delete ui;
}

void ConfigEditor::saveConfig()
{
 //   QString formatFlags = ProgramConfig::get(EDITOR_FORMAT_FLAGS).toString();

    ProgramConfig::set(EDITOR_COLOR_SCHEME,ui->comboBoxColorScheme->currentText());
    ProgramConfig::set(EDITOR_AUTOFORMAT_ENABLED,ui->checkBox_AutoFormat->checkState());
    ProgramConfig::set(EDITOR_AUTOINDENT_ENABLED,ui->checkBox_AutoIndent->checkState());
    ProgramConfig::set(EDITOR_AUTOCOMPLETE_TIMEOUT,ui->autocompleteTimeout->text().toInt());

    QString flags;
    QString style = ui->comboBoxStyle->currentText();
    int i = styleList.indexOf(style);
    if(i != -1)
        flags = styleFlags.at(i);

//    QString flags = varPtrFlags.at(i);

 //   QString flags = styleFlags.at(ui->comboBoxStyle->currentIndex());
    i = ui->comboBox_VarPtrAlign->currentIndex();
    if(i != -1)
        flags += varPtrFlags.at(i);

    flags += funcPtrFlags.at(ui->comboBox_FuncPtrAlign->currentIndex());

    if(ui->checkBox_IndentCases->isChecked()) flags += "K";
    if(ui->checkBox_IndentLabels->isChecked()) flags += "L";
    if(ui->checkBox_RemoveParenSpace->isChecked()) flags += "U";
    if(ui->checkBox_SpaceAfterStmts->isChecked()) flags += "H";
    if(ui->checkBox_SpaceOperators->isChecked()) flags += "p";
    if(ui->checkBox_SpaceParen->isChecked()) flags += "P";

    ProgramConfig::set(EDITOR_FORMAT_FLAGS,flags);

    ProgramConfig::save();
    emit modified();
}

void ConfigEditor::updateExample()
{
    saveConfig();

    QString code;
    code = "#include \"header.h\"\n\nclass Foo\n{\npublic:\nFoo();\nvirtual ~Foo();\n};\n\n";
    code += "unsigned int * myFunction(char *str, int a, bool b){\n";
    code += "switch (foo) {case 1: a += 1; break; case 2:{a += 2;break;}}\n";
    code += "\n";
    code += "for(int i=0;i<10;i++) {a++;b++;c++;}\n";
    code += "\n";
    code += "if(a > b) a++;else {b++;c++;}\n";
    code += "}\n";

    bool ok;
    Format fmt;
    QString output = fmt.run(code,ok,"test.cpp");
    ui->exampleCode->clear();
    ui->exampleCode->insertPlainText(output);
}

