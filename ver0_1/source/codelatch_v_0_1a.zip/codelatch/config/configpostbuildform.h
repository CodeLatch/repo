#ifndef CONFIGPOSTBUILDFORM_H
#define CONFIGPOSTBUILDFORM_H

#include "project/project.h"
#include <QWidget>
#include <QListWidget>

namespace Ui {
class ConfigPostBuildForm;
}

class ConfigPostBuildForm : public QWidget
{
    Q_OBJECT
    
public:
    explicit ConfigPostBuildForm(QWidget *parent = 0);
    ~ConfigPostBuildForm();
    void setProject(Project *project);

private slots:
    void on_postBuildHelp_clicked();
    void on_addPostBuild_clicked();
    void on_removePostBuild_clicked();
    void on_editPostBuild_clicked();
    void on_moveUpPostBuild_clicked();
    void on_moveDownPostBuild_clicked();

private:
    QStringList removeSelectedItemsFromList(QListWidget *widget);

private:
    Ui::ConfigPostBuildForm *ui;
    Project *prj;
};

#endif // CONFIGPOSTBUILDFORM_H
