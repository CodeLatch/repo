/*
*   $Id: main.h 443 2006-05-30 04:37:13Z darren $
*
*   Copyright (c) 1998-2002, Darren Hiebert
*
*   This source code is released for free distribution under the terms of the
*   GNU General Public License.
*
*   External interface to main.c
*/
#ifndef _CTAGS_CMD_H
#define _CTAGS_CMD_H
#ifdef __cplusplus
extern "C" {
#endif
/*
*   INCLUDE FILES
*/
#include "general.h"  /* must always come first */

#include <stdio.h>

#include "vstring.h"

/*
*   FUNCTION PROTOTYPES
*/
extern void addTotals (const unsigned int files, const long unsigned int lines, const long unsigned int bytes);
extern boolean isDestinationStdout (void);
int ctags_cmd(char *exepathname, char *cmdline);

#ifdef __cplusplus
}
#endif

#endif  /* _MAIN_H */

/* vi:set tabstop=4 shiftwidth=4: */
