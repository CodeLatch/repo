#ifndef CTAGS_GLOBAL_H
#define CTAGS_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(CTAGS_LIBRARY)
#  define CTAGSSHARED_EXPORT Q_DECL_EXPORT
#else
#  define CTAGSSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // CTAGS_GLOBAL_H
