//!----------------------------------------------------------------------------
//! file: main.cpp
//! project: gdbserver
//!
//! Command line arguments...
//! -s<probe serial number>
//! -d<device mfg number>
//! -help
//!
//!
//! version	: 1.0
//! date	: 11. Oct. 2011
//! author	: jem
//!
//!----------------------------------------------------------------------------

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include "types.h"
#include "probe.h"
#include "hid_api.h"
#include "tcp.h"
#include "util.h"

#define TCP_RX_BUF_SIZE				(64+8192)		// tcp receive buffer size
#define HALT_MONITOR_PERIOD			100				// 100ms between probe queries for halt condition
#define MEM32DATASIZE				1024			// data buffer size for reading from memory
#define MAXFLASHSIZE				(2000*1024) 	// data buffer size for writing to memory 2MB for now
#define RESP_BUF_SIZE               8192
#define MAX_TABLE_ENTRIES           64

int startServer(int port);
bool startHid(char *serno);
int closeServer();
void delay_ms(int ms);
void heartbeat();

void processGDBcmd(char *buf, int n);

int cmdInit(U32 *idcode);
int cmdVersion(U32 *ver);
int cmdHello();
int reportHalt();

int unescapeData(U8 *data, int n);
void parseMonitorCmd(char *cmdbuf, char *dest, int destlen);
void monitorCommand(char *cmd, int maxlen);

int cmdReadGeneralRegisters(char *buf, int n);
int cmdWriteGeneralRegisters(char *buf, int n);
int cmdReadMemory(char *buf, int n);
int cmdWriteMemory(char *buf, int n);
int cmdWriteMemoryBinary(char *buf, int n);
int cmdContinue(char *buf, int n);
int cmdInsertBreakpoint(char *buf, int n);
int cmdRemoveBreakpoint(char *buf, int n);
int cmdReadCoreRegister(char *buf, int n);
int cmdWriteCoreRegister(char *buf, int n);
int cmdSingleStep(char *buf, int n);
int cmdReportWhyHalted(char *buf, int n);
int cmdQuery(char *buf, int n);
int cmdFeature(char *buf, int n);
int cmdKill(char *buf, int n);
void debugTest(void);
void showHelp(void);

void adjustAccessForRead(U32 *start, U32 *byteCount);
void adjustAccessForWrite(U32 *start, U32 *byteCount);

char resp[RESP_BUF_SIZE]; 				// our response buffer
U8 noACKmode = 0; 				// QStartNoAckMode+
U8 hasRun = 0;
U8 monitorForHalt = 0;
U64 haltMonitorTimer;
U32 mem32Data[MEM32DATASIZE];
char tcpRxBuf[TCP_RX_BUF_SIZE];
FILE *disk = NULL;
char fname[] = "gdblog.txt";
char coutStr[128];

// STM32f103R8
// rom 0x08000000 - 0x0801ffff
// ram 0x20000000 - 0x20004fff

// rom_table and ram_table are address space tables that can be
// written using monitor commands from gdb.
// example for stm32f103x:
//    monitor clear rom
//    monitor clear ram
//    monitor rom 0x08000000 0x0801ffff
//    monitor ram 0x20000000 0x20004fff

// rom_table - table that contains the address "spaces" that
//   are read only. each "space" has a start and end address.
//   the tables first entry is the number of entries in the table.
//   each following entry is a start address followed by an end address.
//   we arbitrarily support 32 rom spaces.
U32 rom_table_entries = 0;
U32 rom_table[MAX_TABLE_ENTRIES];

// ram_table - table that contains the address "spaces" that
//   are read/write. each "space" has a start and end address.
//   the tables first entry is the number of entries in the table.
//   each following entry is a start address followed by an end address.
//   we arbitrarily support 32 ram spaces.
U32 ram_table_entries = 0;
U32 ram_table[MAX_TABLE_ENTRIES];


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
/*void sig_handler(int signo)
{
	closeServer();
    exit(2);
	if (signo == SIGINT)
	{
//		printf("received SIGINT");
//		printf("halting ");
        printf("received SIGINT\nhalting\n");

		probeHaltCore();
		strcpy(resp, "$S05#b8");
		tcp_send(resp);
	}
}
*/
//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int main(int argc, char* argv[])
{
	int n;
	int run = 1;
	char *serno = NULL;
	char *device = NULL;
	int port = 2525;
    
	U32 idcode;
	U32 param[3];
    
//    printf("Hello from gdbserver\n");

//	disk = fopen(fname, "w");
//	fprintf(disk, "Start of log\n");
    
	// install signal handler
//	if (signal(SIGINT, sig_handler) == SIG_ERR)
//        printf("ERROR: can't install SIGINT handler.\n");
        //printf("ERROR: can't install SIGINT handler.");

	// parse command line arguments
	if (argc > 1)
	{
		for (int i = 1; i < argc; i++)
		{
			if (argv[i][0] == '-')
			{
				if (strcmp_s(&argv[i][1], "help") == 0)
				{
					showHelp();
					return 1;
				}
				char *str = &argv[i][1];
				if (str[0] == ' ')
					str = &argv[i][2];
				if (str[0] == 's')
					serno = &str[1];
				if (str[0] == 'd')
					device = &str[1];
				if (str[0] == 'p')
					port = atoi(&str[1]);
			}
		}
	}

    memset(rom_table, 0, sizeof(rom_table));
    memset(ram_table, 0, sizeof(ram_table));


	if (disk != NULL)
		fprintf(disk, "device: %s\r\n", device);

	//***** DEBUG *******
	//    HID_open(NULL);
	//	cmdInit(&idcode);
    //	printf("target idcode: " << hex << idcode);
	//    debugTest();
	//    return 0;
	//*******************
    
//    printf("starting server: port:%d serno:%s\n",port,serno);
    if (!startHid(serno))
    {
        printf("error connecting to hid: exiting\n");
        if (disk)
            fclose(disk);
        return 4;
    }
    // open tcp connection and allocate memory wait for connection
    if (!startServer(port))
	{
        printf("error starting server: exiting\n");
		if (disk)
			fclose(disk);
        return 5;
	}
    printf("startup success.\n");

	// put target in debug mode
	cmdInit(&idcode);
	// in the future maybe validate the id code vs expected target
    printf("target idcode: %x\n",idcode);
    
    
	// loop until the tcp connection closes or the hid connection fails
	while (run)
	{
		// check for incoming tcp data from the debug client
		if (tcp_checkForClientMessage())
		{
			if ((n = tcp_waitForClientMessage(tcpRxBuf, TCP_RX_BUF_SIZE)) > 0)
				processGDBcmd(tcpRxBuf, n);
			else
			{
                printf("connection terminated.\n");
				break; // this breaks the while loop if the connection has an error (closes)
			}
		}
		else
		{
			// if the target should be running periodically check if a halt has occurred
			if (monitorForHalt && timer_isExpired(haltMonitorTimer))
			{
				haltMonitorTimer = timer_start(HALT_MONITOR_PERIOD);
				if (probeIsCoreHalted(param))
				{
					if (param[0] != 0) // param[0] == 0 if core is running
					{
						reportHalt();
						monitorForHalt = 0;
					}
				}
				else
				{
                    printf("Error: halt query failed.\n"); // this is likely because the user reset the probe or target.
					break;
				}
			}
		}
        
		heartbeat();
	}
    
    printf("closing server.\n");
	// shutdown and clean up
	closeServer();
    printf("goodbye.\n");
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void showHelp(void)
{
    printf("gdbserver ver 1.0\n");
    printf("copyright John Maloney 2012\n");
    
    printf("-help     show help.\n");
    printf("-s        specify probe serial number eg: -s12345678\n");
    printf("-p        specify port number eg: -p2525\n");
    printf("\n");
    printf("END HELP\n");
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool startHid(char *serno)
{
    wchar_t wserno[32];
    wchar_t *ptr = NULL;

    if (serno != NULL)
    {
        mbstowcs(wserno, serno, 32);
        ptr = wserno;
    }
//    printf("serno processed\n");

    if (!HID_open(ptr))
        //		if (!HID_open(serialNumberToWide(serno)))
    {
        printf("debug probe not found.\n");
        if (disk) fprintf(disk, "debug probe not found.\n");
//		tcp_closeServer();
        return false;
    }
    printf("hid open\n");
    return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int startServer(int port)
{
	// start tcp server
	if (!tcp_startServer(port))
	{
        printf("Error: Couldn't start server.\n");
		return 0;
	}
    printf("server is running. waiting for client.\n");
    
	if (!tcp_waitForClientToConnect())
	{
        printf("Error: Invalid socket.\n");
		tcp_closeServer();
		return 0;
	}
    printf("client connected!\n");

	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int closeServer()
{
	probeRelease();
	probeHWReset();
	HID_close();
	hid_exit();
	tcp_closeServer();
    printf("connection closed.\n");
	if (disk)
		fclose(disk);
    
//	delete [] flashData;
    
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void processGDBcmd(char *buf, int n)
{
	char resp[12];
	if (buf[1] != 'X')
	{
        //printf("client: " << buf);
        printf("client:%s\n",buf);
	}
    
	// pause, stop, or terminate command
	if (n == 1)
	{
        sprintf(coutStr, "Received 1 Byte : %d\n", buf[0]);
        printf("%s\n",coutStr);
		if (buf[0] == 3)
		{
            printf("halting\n");
			probeHaltCore();
			strcpy(resp, "$S05#b8");
			tcp_send(resp);
			return;
		}
	}
    
	// deal with ACK and NAK
	if (buf[0] == '+')
	{
		buf++;
		n--;
		if (n == 0)
			return;
	}
	else if (buf[0] == '-')
	{
		tcp_send(resp); // send the last response string we sent again.
		buf++;
		n--;
		if (n == 0)
			return;
	}
    
	// check $, #, crc, if ok send + else send -
	if (!validateGDBcmd(buf, n))
	{
		if (!noACKmode)
			tcp_send("-");
		return;
	}
	if (!noACKmode)
		tcp_send("+");
/*
	// if we were receiving flash programming data and have received the last of the data
	// then another command will show up, we'll take that as a signal to program flash.
	if ((flashWriteFlag == 1) && (buf[1] != 'X'))
	{
		flashWriteFlag = 0;
	}
*/
	switch (buf[1])
	{
		case 'g': // read general registers
			cmdReadGeneralRegisters(buf, n);
			break;
		case 'G': // write general registers
			cmdWriteGeneralRegisters(buf, n);
			break;
		case 'm': // read memory
			cmdReadMemory(buf, n);
			break;
		case 'M': // write memory
			cmdWriteMemory(buf, n);
			break;
		case 'X': // write memory in binary format
			cmdWriteMemoryBinary(buf, n);
			break;
		case 'c': // continue
			cmdContinue(buf, n);
			break;
		case 'C': // continue
			cmdContinue(buf, n);
			break;
		case 'Z': // insert breakpoint
			cmdInsertBreakpoint(buf, n);
			break;
		case 'z': // remove breakpoint
			cmdRemoveBreakpoint(buf, n);
			break;
		case 'p': // read core register
			cmdReadCoreRegister(buf, n);
			break;
		case 'P': // write core register
			cmdWriteCoreRegister(buf, n);
			break;
		case 's': // single step
			cmdSingleStep(buf, n);
			break;
		case '?': // report why halted
			cmdReportWhyHalted(buf, n);
			break;
		case 'q': // general query
			cmdQuery(buf, n);
			break;
		case 'Q': // feature control
			cmdFeature(buf, n);
			break;
		case 'k': // kill
			cmdKill(buf, n);
			break;
            
		default: // unsupported command
			strcpy(resp, "$#00");
			tcp_send(resp);
			break;
	}
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdReadGeneralRegisters(char *buf, int n) // $g#67
{
    (void)buf;
    (void)n;

	U32 data[8];
	U32 i;
    
	resp[0] = '$';
	if (!probeReadGenRegs(data))
	{
		strcpy(resp, "-");
		tcp_send(resp);
		return 0;
	}
    
	for (i = 0; i < 8; i++)
		U32toGDBHexStr(data[i], &resp[1 + (i << 3)]);
    
	resp[1 + (i << 3)] = '#';
	resp[2 + (i << 3)] = 0;
	appendGDBcrc(resp);
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdWriteGeneralRegisters(char *buf, int n)
{
    (void)buf;
    (void)n;

    strcpy(resp, "$#00");
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void debugTest(void)
{
	U32 address, data, i, startaddr;
	int ret;
    
	// STM32
	//   startaddr = 0x08000184;
	// LPC
	startaddr = 0x00000154;
    
    printf("Offset word read ...\n");
	address = startaddr;
    
	probeReadMem(address, &data);
	sprintf(coutStr, "a: 0x%08x  d: 0x%08x", address, data);
    printf("%s\n",coutStr);
	address++;
    
	probeReadMem(address, &data);
	sprintf(coutStr, "a: 0x%08x  d: 0x%08x", address, data);
    printf("%s\n",coutStr);
	address++;
    
	probeReadMem(address, &data);
	sprintf(coutStr, "a: 0x%08x  d: 0x%08x", address, data);
    printf("%s\n",coutStr);
	address++;
    
	probeReadMem(address, &data);
	sprintf(coutStr, "a: 0x%08x  d: 0x%08x", address, data);
    printf("%s\n",coutStr);
	address++;
    
    printf("Word read test...\n");
	address = startaddr;
	for (i = 0; i < 10; i++)
	{
		ret = probeReadMem(address, &data);
		sprintf(coutStr, "a: 0x%08x  d: 0x%08x", address, data);
        printf("%s\n",coutStr);
		address += 4;
	}
    
    printf("Array read test...\n");
	address = startaddr;
	probeReadMemBuf(address, &mem32Data[0], 4 * 10);
	for (i = 0; i < 10; i++)
	{
		sprintf(coutStr, "a: 0x%08x  d: 0x%08x", address, mem32Data[i]);
        printf("%s\n",coutStr);
		address += 4;
	}
    
}
//!----------------------------------------------------------------------------
//! \brief
//!* @brief    Read a number of bytes from memory.
//!*
//!*       Examples:
//!* 		$m<address>,<numbytes>#XX   both address and numbytes are hex numbers
//!* 		$md3a808,4#65 	read 4 bytes starting at 0xd3a808
//!* 		$m312,2,#61	read 2 bytes starting at 0x312
//!*
//!*  Memory should be accessed on 4 byte word boundaries. If not,
//!*  the data is read in an unusual way.
//!*  example:
//!*   if the data starting at memory address 0 is 01 02 03 04 05 06 07 08,
//!*   that is address 0 contains 04030201 and address 4 contains 08070605
//!*
//!*    read address 0: 01 02 03 04  or 04030201
//!*    read address 1: 05 02 03 04  or 04030205
//!*    read address 2: 05 06 03 04  or 04030605
//!*    read address 3: 05 06 07 04  or 04070605
//!*    read address 4: 05 06 07 08  or 08070605
//!*
//!* We compenstate for this in this routine so you always get the correct
//!* memory byte aligned data.
//!*
//!* @param[in]	.
//!* @return 		.
//!----------------------------------------------------------------------------
int cmdReadMemory(char *buf, int n)
{
	(void) n; // unused
    
	U32 baseAddress, address, numbytes, offset;
	U32 i, j, wordIndex;
	U32 numWords, wordCnt;
	U8 *ptr = (U8*)mem32Data;
    
	// get starting address and number of bytes to read
	i = U32fromHexStr(&buf[2], 10, &address, ',') + 2;
	U32fromHexStr(&buf[i], 10, &numbytes, '#');
	//    qDebug("mem read from 0x%08x %d bytes",address,numbytes);
    
	// determine 4 byte boundry starting address
	baseAddress = address & 0xfffffffc;
	// determine byte offset from desired start address
	offset = address - baseAddress;
	// determine word count, read extra word to account for any alignment offset
	numWords = (numbytes >> 2) + 1;
    
	// i = word count
	i = 0;
	while (numWords > 0)
	{
		// read in chucks of 256 bytes...
		// 64 4byte words = 256 bytes = 512 ascii characters which
		// is the max size of the probes tx data buffer.
		if (numWords > 64)
			wordCnt = 64;
		else
			wordCnt = numWords;
        
        
		// adjust our start and byte count to ensure the area we are reading is in a valid read area
		U32 start = baseAddress + (i << 2);
		U32 preAdjustStart = start;
		U32 bcnt = wordCnt << 2;
		memset(&mem32Data[i], 0, bcnt);
		adjustAccessForRead(&start, &bcnt);
		U32 startOffset = start - preAdjustStart;
		if (bcnt > 0)
		{
			if (!probeReadMemBuf(start, &mem32Data[i + startOffset], bcnt))
			{
				strcpy(resp, "-");
				tcp_send(resp);
				return 0;
			}
		}
		i += wordCnt;
		numWords -= wordCnt;
	}
    
	numWords = (numbytes >> 2) + 2;
    
	// send desired data
	resp[0] = '$';
	wordIndex = 0;
	j = offset;
	for (i = 0; i < numbytes; i++)
	{
		U8 bdata = ptr[j++];
		resp[1 + (i << 1)] = hexchartable[(bdata >> 4) & 0x0f];
		resp[2 + (i << 1)] = hexchartable[(bdata >> 0) & 0x0f];
	}
	resp[1 + (i << 1)] = '#';
	resp[2 + (i << 1)] = 0;
	appendGDBcrc(resp);
	tcp_send(resp);
	return 1;
    
    
    
	/*
     (void) n; // unused
     
     printf("# Server:cmdReadMemory: " << n << " bytes");
     
     U32 baseAddress, address, numbytes, offset;
     U32 i, j, wordIndex;
     U32 numWords,wordCnt;
     U8 bdata;
     U8 *ptr = (U8*)mem32Data;
     
     // get starting address and number of bytes to read
     i = U32fromHexStr(&buf[2], 10, &address, ',') + 2;
     U32fromHexStr(&buf[i], 10, &numbytes, '#');
     //    qDebug("mem read from 0x%08x %d bytes",address,numbytes);
     
     // determine 4 byte boundry starting address
     baseAddress = address & 0xfffffffc;
     // determine offset from desired start address
     offset = address - baseAddress;
     // determine word count, read extra word to account for any alignment offset
     numWords = (numbytes >> 2) + 1;
     
     i = 0;
     while(numWords > 0)
     {
     // 64 4byte words = 256 bytes = 512 ascii characters which
     // is the max size of the probes tx data buffer.
     if(numWords > 64)
     wordCnt = 64;
     else
     wordCnt = numWords;
     
     U32 raddr = baseAddress + (i<<2);
     U32 bcnt = wordCnt<<2;
     
     // zero out memory
     memset(&mem32Data[i],0,bcnt);
     
     // make sure address range to be read is in a non-reserved area
     U32 start,end,woffset;
     start = raddr;
     end = start + bcnt - 1;
     
     // make sure address range is in a valid read area
     // if start or end are in a defined section then adjust
     // start and end to force both to be in that section.
     bool ok = false;
     // if we don't have any table entries then read/write any address
     if((rom_table_entries == 0) && (ram_table_entries == 0))
     ok = true;
     // check tables
     for(j=0;j<rom_table_entries;j++)
     {
     U32 rom_start = rom_table[j<<2];
     U32 rom_end = rom_table[(j<<2)+1];
     if(((start >= rom_start) && (start <= rom_end)) ||
     ((end >= rom_start) && (end <= rom_end)))
     {
     if(start < rom_start)
     start = rom_start;
     if(end > rom_end)
     end = rom_end & 0xfffffffc;
     ok = true;
     bcnt = end - start;
     }
     }
     if(!ok)
     {
     for(j=0;j<ram_table_entries;j++)
     {
     U32 ram_start = ram_table[j<<2];
     U32 ram_end = ram_table[(j<<2)+1];
     if(((start >= ram_start) && (start <= ram_end)) ||
     ((end >= ram_start) && (end <= ram_end)))
     {
     if(start < ram_start)
     start = ram_start;
     if(end > ram_end)
     end = ram_end & 0xfffffffc;
     ok = true;
     bcnt = end - start;
     }
     }
     }
     if(!ok)
     bcnt = 0;
     
     woffset = (start - raddr) >> 2;
     
     // send command to probe to read memory
     // if (!probe->probeReadMemBuf(raddr,&mem32Data[i],bcnt))
     if(bcnt > 0) {
     // read up to 512 bytes at a time
     //            qDebug("debug2: start: 0x%08x bcnt: %d",start,bcnt);
     printf("# Server:cmdReadMemory start: " << start << " bcnt: " << bcnt);
     
     if (!probeReadMemBuf(start,&mem32Data[i+woffset],bcnt))
     {
     strcpy(resp, "-");
     tcp_send(resp);
     return 0;
     }
     }
     i += wordCnt;
     numWords -= wordCnt;
     }
     
     numWords = (numbytes >> 2) + 2;
     
     // send desired data
     resp[0] = '$';
     wordIndex = 0;
     j = offset;
     for (i = 0; i < numbytes; i++)
     {
     bdata = ptr[j++];
     resp[1 + (i << 1)] = hexchartable[(bdata >> 4) & 0x0f];
     resp[2 + (i << 1)] = hexchartable[(bdata >> 0) & 0x0f];
     }
     resp[1 + (i << 1)] = '#';
     resp[2 + (i << 1)] = 0;
     appendGDBcrc(resp);
     cout <<" tcpsend():" << resp;
     tcp_send(resp);
     return 1;
	 */
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void adjustAccessForRead(U32 *start, U32 *byteCount)
{
	U32 j;
	U32 end = *start + *byteCount - 1;
    
    
	// if we don't have any table entries then read any address
	if ((ram_table_entries == 0) && (rom_table_entries == 0))
		return;
    
	for (j = 0; j < ram_table_entries; j++)
	{
		U32 ram_start = ram_table[j << 2];
		U32 ram_end = ram_table[(j << 2) + 1];
        
		if ((*start < ram_start) && (end >= ram_start) && (end <= ram_end))
		{
			*start = ram_start;
			*byteCount = end - *start + 1;
			return;
		}
		else if ((*start >= ram_start) && (end <= ram_end))
			return;
		else if ((*start >= ram_start) && (*start <= ram_end) && (end > ram_end))
		{
			*byteCount = ram_end - *start + 1;
			return;
		}
	}
    
	for (j = 0; j < rom_table_entries; j++)
	{
		U32 rom_start = rom_table[j << 2];
		U32 rom_end = rom_table[(j << 2) + 1];
        
		if ((*start < rom_start) && (end >= rom_start) && (end <= rom_end))
		{
			*start = rom_start;
			*byteCount = end - *start + 1;
			return;
		}
		else if ((*start >= rom_start) && (end <= rom_end))
			return;
		else if ((*start >= rom_start) && (*start <= rom_end) && (end > rom_end))
		{
			*byteCount = rom_end - *start + 1;
			return;
		}
	}
    
	*byteCount = 0;
	return;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void adjustAccessForWrite(U32 *start, U32 *byteCount)
{
	U32 j;
	U32 end = *start + *byteCount - 1;
    
    
	// if we don't have any table entries then write any address
	if (ram_table_entries == 0)
		return;
    
	for (j = 0; j < ram_table_entries; j++)
	{
		U32 ram_start = ram_table[j << 2];
		U32 ram_end = ram_table[(j << 2) + 1];
        
		if ((*start < ram_start) && (end >= ram_start) && (end <= ram_end))
		{
			*start = ram_start;
			*byteCount = end - *start + 1;
			return;
		}
		else if ((*start >= ram_start) && (end <= ram_end))
			return;
		else if ((*start >= ram_start) && (*start <= ram_end) && (end > ram_end))
		{
			*byteCount = ram_end - *start + 1;
			return;
		}
	}
	*byteCount = 0;
	return;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdWriteMemory(char *buf, int n)
{
    (void)n;

	U32 address = 0;
	U32 numbytes = 0;
	U32 i = 0;
    
	i = U32fromHexStr(&buf[2], 10, &address, ',') + 2;
	i += U32fromHexStr(&buf[i], 10, &numbytes, ':');
    
    printf("MEM WRITE: 0x%08x : %d\n",address,numbytes);
    
	strcpy(resp, "$#00");
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool isAddressReadable(U32 address)
{
	U32 j;
    
	// if we don't have any table entries then read/write any address
	if ((rom_table_entries == 0) && (ram_table_entries == 0))
		return true;
    
	// if address is in ram or rom space it's safe to read from.
	for (j = 0; j < ram_table_entries; j++)
	{
		U32 ram_start = ram_table[j << 2];
		U32 ram_end = ram_table[(j << 2) + 1];
		if ((address >= ram_start) && (address <= ram_end))
			return true;
	}
	for (j = 0; j < rom_table_entries; j++)
	{
		U32 rom_start = rom_table[j << 2];
		U32 rom_end = rom_table[(j << 2) + 1];
		if ((address >= rom_start) && (address <= rom_end))
			return true;
	}
	return false;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
bool isAddressWritedReserved(U32 address)
{
	U32 j;
    
	// if we don't have any table entries then read/write any address
	if ((rom_table_entries == 0) && (ram_table_entries == 0))
		return false;
    
	// if address is in ram space it's safe to write to, return false.
	for (j = 0; j < ram_table_entries; j++)
	{
		U32 ram_start = ram_table[j << 2];
		U32 ram_end = ram_table[(j << 2) + 1];
		if ((address >= ram_start) && (address <= ram_end))
			return false;
	}
	return true;
}

//!----------------------------------------------------------------------------
//! \brief
//!* @brief		Support for gdb command 'X'. write binary data to address.
//!*
//!* example $X10000467,1:M#ce    - write 1 byte value 77 (ascii M) to address 10000467
//!* example $X10000467,1:M#ce    - write 4 bytes value 4d4b4c4A (ascii M) to address 10000467
//!* example $X10000468,4:JKLM#b3 - write 4 byte value 4a4b4c4d (ascii JKLM) to address 100000468
//!----------------------------------------------------------------------------
int cmdWriteMemoryBinary(char *buf, int n)
{
	U32 address, numbytes, addr;
	int i;
	U8 *data;
	U32 rddata;
	U32 offset;
	U32 byteIndex;
    
	// get starting address and number of bytes
	i = U32fromHexStr(&buf[2], 10, &address, ',') + 2;
	i += U32fromHexStr(&buf[i], 10, &numbytes, ':');
	// set data pointer to start of binary data
	data = (U8*) &buf[i];
    
	// note: gdb will send us a binary write request with 0 as the number of bytes
	// as a way of testing if we support this command.
	if (numbytes > 0)
	{
		// undo escape sequences, total current length = n - 3(#<CRC> at end) - i(HEADER LENGTH)
		n = unescapeData(data, n - 3 - i);
		if (n != (int)numbytes)
		{
			//			printf("Error in binary write count.\r\n");
			strcpy(resp, "-");
			tcp_send(resp);
			return 0;
		}
        
		// write to memory
		i = 0;
		while (n > 0)
		{
			addr = address & 0xfffffffc; // 4 byte boundry
            
			// only allow writing to non-flash
			if (!isAddressWritedReserved(addr))
			{
				probeReadMem(addr, &rddata);
				byteIndex = address & 0x03;
				if (byteIndex == 0)
					offset = 0;
				else if (byteIndex == 1)
					offset = 8;
				else if (byteIndex == 2)
					offset = 16;
				else
					offset = 24;
                
				rddata &= ~(0xff << offset);
				rddata |= (data[i] << offset);
				probeWriteMem(addr, rddata);
			}
			i++;
			n--;
			address++;
		}
		// send response to client
		strcpy(resp, "$OK#9a");
		tcp_send(resp);
		return 1;
	}
	else
	{
		strcpy(resp, "$OK#9a");
		tcp_send(resp);
		return 1;
	}
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdContinue(char *buf, int n)
{
    (void)buf;
    (void)n;

	if (!probeRunCore())
	{
		strcpy(resp, "-");
		tcp_send(resp);
		return 0;
	}
	monitorForHalt = 1;
	hasRun = 1;
	haltMonitorTimer = timer_start(HALT_MONITOR_PERIOD);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdInsertBreakpoint(char *buf, int n)
{
    (void)n;

	U32 r;
	U32 address;
	int i;
    
	i = U32fromHexStr(&buf[2], 10, &r, ',') + 2;
	U32fromHexStr(&buf[i], 10, &address, ',');
    
	if (r != 0)
	{
		strcpy(resp, "$#00");
		tcp_send(resp);
		return 0;
	}
    
	if (probeSetBreakpoint(address))
		strcpy(resp, "$OK#9a");
	else
		strcpy(resp, "-");
    
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdRemoveBreakpoint(char *buf, int n)
{
    (void)n;

	U32 r;
	U32 address;
	int i;
    
	i = U32fromHexStr(&buf[2], 10, &r, ',') + 2;
	U32fromHexStr(&buf[i], 10, &address, ',');
    
	if (r != 0)
	{
		strcpy(resp, "$#00");
		tcp_send(resp);
		return 0;
	}
    
	if (probeClrBreakpoint(address))
		strcpy(resp, "$OK#9a");
	else
		strcpy(resp, "-");
    
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdReadCoreRegister(char *buf, int n)
{
    (void)n;

	U32 data;
	U32 reg;
    
	U32fromHexStr(&buf[2], 10, &reg, '#');
    
	resp[0] = '$';
	if (!probeReadReg(reg, &data))
	{
		strcpy(resp, "-");
		tcp_send(resp);
		return 0;
	}
	U32toGDBHexStr(data, &resp[1]);
	resp[9] = '#';
	resp[10] = 0;
	appendGDBcrc(resp);
	tcp_send(resp);
    
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdWriteCoreRegister(char *buf, int n)
{
    (void)n;

	U32 reg, data;
	int i;
    
	i = U32fromHexStr(&buf[2], 10, &reg, '=') + 2;
	U32fromHexStr(&buf[i], 10, &data, '#');
	data = ByteSwapU32(data);
    
	if (probeWriteReg(reg, data))
		strcpy(resp, "$OK#9a");
	else
		strcpy(resp, "-");
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdSingleStep(char *buf, int n)
{
    (void)buf;
    (void)n;

	U32 param[3]; // param 0 = 5 or 6, param 1 = f (re pc reg), param 2 = program counter
    
	if (!probeSingleStep(param))
	{
		strcpy(resp, "-");
		tcp_send(resp);
		return 0;
	}
    
	strcpy(resp, "$T050f:");
	U32toGDBHexStr(param[2], &resp[7]);
	resp[15] = ';';
	resp[16] = '#';
	resp[17] = 0;
	appendGDBcrc(resp);
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdReportWhyHalted(char *buf, int n)
{
    (void)buf;
    (void)n;
	//	U32 data;
    
	if (hasRun == 0)
	{
		strcpy(resp, "$S05#b8");
		tcp_send(resp);
		return 1;
	}
	else
	{
		strcpy(resp, "$T05#b9");
		tcp_send(resp);
		return 1;
	}
	/*
	 if (!probeReadReg(15, &data))
	 {
	 strcpy(resp, "-");
	 tcp_send(resp);
	 return 0;
	 }
     
	 strcpy(resp, "$T060f:");
	 U32toGDBHexStr(data, &resp[7]);
	 resp[15] = ';';
	 resp[16] = '#';
	 resp[17] = 0;
	 appendGDBcrc(resp);
	 tcp_send(resp);
	 return 1;
	 */
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdQuery(char *buf, int n)
{
    (void)n;

	if (strcmp_s(buf, "$qSupported") == 0)
	{
		//		strcpy(resp, "$PacketSize=1024;QStartNoAckMode+#");
		strcpy(resp, "$PacketSize=1024#");
		appendGDBcrc(resp);
		tcp_send(resp);
	}
	else if (strcmp_s(buf, "$qfThreadInfo") == 0)
	{
		//strcpy(resp, "$m0#");
		strcpy(resp, "$l#");
		appendGDBcrc(resp);
		tcp_send(resp);
	}
	else if (strcmp_s(buf, "$qsThreadInfo") == 0)
	{
		strcpy(resp, "$l#");
		appendGDBcrc(resp);
		tcp_send(resp);
	}
	else if (strcmp_s(buf, "$qRcmd") == 0)
	{
		// gdb set a monitor message
		// $qRcmd,68656c6c6f206a6f686e2066726f6d206764622e#0d
		// decode
		char cbuf[128];
		parseMonitorCmd(buf, cbuf, sizeof(cbuf));
		monitorCommand(cbuf, sizeof(cbuf));
		strcpy(resp, "$OK#9a");
		tcp_send(resp);
	}
	else
		tcp_send("$#00");
    
	return 1;
}

//!------------------------------------------------------------------
//! \brief
//!    clear rom_table
//!    clear ram_table
//!    rom_table 0x08000000 0x0801ffff
//!    ram_table 0x20000000 0x20004fff
//!------------------------------------------------------------------
void monitorCommand(char *cmd, int maxlen)
{
	// process monitor command.
	if (strcmp_s(cmd, "clear rom") == 0)
	{
		rom_table_entries = 0;
		memset(rom_table, 0, sizeof(rom_table));
	}
	else if (strcmp_s(cmd, "clear ram") == 0)
	{
		ram_table_entries = 0;
		memset(ram_table, 0, sizeof(ram_table));
	}
	else if (strcmp_s(cmd, "rom ") == 0)
	{
		char field[3][MAXFIELDLEN];
		int i = splitString(cmd, maxlen, field, 3, ' ');
		if (i != 3)
		{
            printf("error # param: %d\n",i);
			return;
		}
		if (rom_table_entries >= 32)
		{
            printf("error rom_table full.\n");
			return;
		}
		U32 start = HexStrToVal(field[1], strlen_s(field[1], 10));
		U32 end = HexStrToVal(field[2], strlen_s(field[2], 10));
		if (end < start)
		{
            printf("error end < start: %d %d\n",start,end);
			return;
		}
		U32 next_entry_offset = (rom_table_entries << 2);
		rom_table[next_entry_offset] = start;
		rom_table[next_entry_offset + 1] = end;
		rom_table_entries++;
        printf("added rom_table entry: %d %d\n",start,end);
	}
	else if (strcmp_s(cmd, "ram ") == 0)
	{
		char field[3][MAXFIELDLEN];
		int i = splitString(cmd, maxlen, field, 3, ' ');
		if (i != 3)
		{
            printf("error # param: %d\n",i);
			return;
		}
		if (ram_table_entries >= 32)
		{
            printf("error ram_table full.\n");
			return;
		}
		U32 start = HexStrToVal(field[1], strlen_s(field[1], 10));
		U32 end = HexStrToVal(field[2], strlen_s(field[2], 10));
		if (end < start)
		{
            printf("error end < start: %d %d\n",start,end);
			return;
		}
		U32 next_entry_offset = (ram_table_entries << 2);
		ram_table[next_entry_offset] = start;
		ram_table[next_entry_offset + 1] = end;
		ram_table_entries++;
        printf("added ram_table entry: %d %d\n",start,end);
	}
}

//!------------------------------------------------------------------
//! \brief
//!------------------------------------------------------------------
void parseMonitorCmd(char *cmdbuf, char *dest, int destlen)
{
	// gdb set a monitor message
	// $qRcmd,68656c6c6f206a6f686e2066726f6d206764622e#0d
	// point to start of data
	char *ptr = &cmdbuf[7];
	// get length minus #crc
	int n = strlen(ptr) - 3;
	// two characters per byte
	n = n / 2;
	if (n > (destlen - 1))
		n = destlen - 1;
	memset(dest, 0, destlen);
	for (int i = 0; i < n; i++)
	{
		dest[i] = HexStrToVal(ptr, 2);
		ptr += 2;
	}
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdFeature(char *buf, int n)
{
    (void)n;

	if (strcmp_s(buf, "$QStartNoAckMode#") == 0)
	{
		strcpy(resp, "$OK#9a");
		noACKmode = 1;
		tcp_send(resp);
	}
	else
		tcp_send("$#00");
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdKill(char *buf, int n) // $k#6b
{
    (void)buf;
    (void)n;

	if (!noACKmode)
		tcp_send("+");
	probeHWReset();
	probeRelease();
	HID_close();
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdHello()
{
	U32 resp[2];
    
	if (SendProbeCommand(PROBE_HELLO, NULL, 0, resp, 2) == 0)
		return 0;
	if ((resp[0] != RESP_ACK) || (resp[1] != 0x12345678))
		return 0;
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdInit(U32 *idcode)
{
	return probeInit(idcode);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int cmdVersion(U32 *ver)
{
	U32 buf[16];
    
	if (!handle)
		return 0;
    
	int ret = probeSendCmd(PROBE_GET_VER, NULL, 0);
	if (ret < 0)
		return 0;
    
	ret = getProbeResponse(buf, 64, 1000);
	if ((ret != 64) || (buf[0] != RESP_ACK))
		return 0;
	*ver = buf[1];
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int reportHalt()
{
	U32 data;
    
	if (!probeReadReg(15, &data))
		return 0;
    
	strcpy(resp, "$T050f:");
	U32toGDBHexStr(data, &resp[7]);
	resp[15] = ';';
	resp[16] = '#';
	resp[17] = 0;
	appendGDBcrc(resp);
	tcp_send(resp);
	return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!* @brief Undo escape sequences in binary data
//!*
//!*  '#', '$' and '}' are escaped by preceding them by '}' and xor-ing with 0x20.
//!*
//!*  This function reverses that, modifying the data in place.
//!*
//!* @param[in] data  The array of bytes to convert.
//!* @param[in]  n     The number of bytes currently in data.
//!*
//!* @return  The number of bytes after conversion
//!----------------------------------------------------------------------------
int unescapeData(U8 *data, int n)
{
	int i = 0;		// source index
	int j = 0;		// destination index
    
	while (i < n)
	{
		if (data[i] == '}')
		{
			i++;
			data[j] = data[i] ^ 0x20;
		}
		else
		{
			data[j] = data[i];
		}
        
		i++;
		j++;
	}
    
	return j;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void delay_ms(int ms)
{
	U64 timer;
	timer = timer_start(ms);
	while (!timer_isExpired(timer));
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void heartbeat()
{
	static U64 timer = 0;
	if (timer_isExpired(timer))
	{
		timer = timer_start(2000);
	}
}
