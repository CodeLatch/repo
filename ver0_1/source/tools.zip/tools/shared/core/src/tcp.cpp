/*
 * tcp.cpp
 *
 *  Created on: Oct 18, 2011
 *      Author: admin
 */

/*
#if defined __APPLE__ || defined __linux__

#elif defined _WIN32 || defined _WIN64
#else
#error "unknown platform"
#endif
*/

//project->properties->c/c++ build->settings->mingw c linker->libraries
//
//add library
//ws2_32
//

//#include <iostream>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include <tcp.h>

#ifdef __APPLE__
  #include <CoreServices/CoreServices.h>
  #import <CoreFoundation/CFSocket.h>
#endif

#include <sys/time.h>
#include <sys/types.h>

#if defined __APPLE__ || defined __linux__
 #include <sys/socket.h>
 #include <sys/select.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>
#elif defined _WIN32 || defined _WIN64
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
//#include <winsock.h>
#else
#error "unknown platform"
#endif

#include <unistd.h>
//#include <netinet/in.h>
//#include <netdb.h>

using namespace std;


extern FILE *disk;

#if defined __APPLE__ || defined __linux__
struct sockaddr_in sinAddr;
int sClient = -1;
int sServer = -1;
#elif defined _WIN32 || defined _WIN64
// globals for tcp socket
SOCKET sServer;
SOCKADDR_IN sinServer;
SOCKET sClient;
#else
#error "unknown platform"
#endif

// default for unspecified server protocol is tcp
int tcp_startServer(int port) {
	return tcp_startServer(port,IPPROTO_TCP);
}

#if defined _WIN32 || defined _WIN64 
int tcp_startServer(int port,int protocol)
{
	WSADATA t_wsa; // WSADATA structure
	WORD wVers; // version number
	int iError; // error number

	wVers = MAKEWORD(2, 2); // Set the version number to 2.2
	iError = WSAStartup(wVers, &t_wsa); // Start the WSADATA
	if (iError != NO_ERROR || iError == 1)
	{
//		MessageBox(NULL, (LPCTSTR) "Error at WSAStartup()", (LPCTSTR) "Server::Error", MB_OK | MB_ICONERROR);
		WSACleanup();
		return 0;
	}
	if (LOBYTE(t_wsa.wVersion) != 2 || HIBYTE(t_wsa.wVersion) != 2)
	{
//		MessageBox(NULL, (LPCTSTR) "Error at WSAStartup()", (LPCTSTR) "Server::Error", MB_OK | MB_ICONERROR);
		WSACleanup();
		return 0;
	}

	// create a socket
	sServer = socket(AF_INET, SOCK_STREAM, protocol);
	if (sServer == INVALID_SOCKET || iError == 1)
	{
//		MessageBox(NULL, (LPCTSTR) "Invalid Socket!", (LPCTSTR) "Server::Error", MB_OK | MB_ICONERROR);
		WSACleanup();
		return 0;
	}
	memset(&sinServer, 0, sizeof(sinServer));

	sinServer.sin_family = AF_INET;
	//sinServer.sin_addr.s_addr = INADDR_ANY; // Where to start server?
	sinServer.sin_addr.s_addr = inet_addr("127.0.0.1");
	sinServer.sin_port = htons(port); // Port

	if (bind(sServer, (LPSOCKADDR) &sinServer, sizeof(sinServer)) == SOCKET_ERROR)
	{
		/* failed at starting server */
//		MessageBox(NULL, (LPCTSTR) "Could not bind the server!", (LPCTSTR) "Server::Error", MB_OK | MB_ICONERROR);
		WSACleanup();
		return 0;
	}

	// start listening for connections, allow only 1 connection
	int attempts = 10;
	while (listen(sServer, 1) == SOCKET_ERROR)
	{
		Sleep(10);
		attempts--;
		if (attempts == 0)
		{
			// bail out
			WSACleanup();
			return 0;
		}
	}

	Sleep(100);
//	MessageBox(NULL, (LPCTSTR) "Waiting for a Client!", (LPCTSTR) "Server::Success", MB_OK);
	return 1;
}
#endif

#if defined __APPLE__ || defined __linux__
int tcp_startServer(int port,int protocol)
{
	// create a socket
	sServer = socket(AF_INET, SOCK_STREAM, protocol);
	if (sServer == -1)
	{
		return 0;
	}

	memset(&sinAddr, 0, sizeof(sinAddr));
    
	sinAddr.sin_family = AF_INET;
	sinAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	sinAddr.sin_port = htons(port); // Port

//	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
//	setsockopt(sock, SOL_SOCKET, SO_REUSEPORT, &yes, sizeof(yes));
    int sz = sizeof(sinAddr);
    
	if (bind(sServer, (struct sockaddr *)&sinAddr, sz) == -1)
	{
		return 0;
	}

	// start listening for connections, allow only 1 connection
    listen(sServer,1);
    

	return 1;
}
int tcp_startClient(int port)
{
	// create a socket
	sServer = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sServer == -1)
	{
		return 0;
	}
    
	memset(&sinAddr, 0, sizeof(sinAddr));
    
	sinAddr.sin_family = AF_INET;
	sinAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	sinAddr.sin_port = htons(port); // Port
    
    //	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    //	setsockopt(sock, SOL_SOCKET, SO_REUSEPORT, &yes, sizeof(yes));
    //int sz = sizeof(sinAddr);
    
//	if (bind(sServer, (struct sockaddr *)&sinAddr, sz) == -1)
//	{
//		return 0;
//	}
    
	// start listening for connections, allow only 1 connection
//    listen(sServer,1);
    
    if(connect(sServer, (struct sockaddr *)&sinAddr, sizeof(sinAddr)) < 0)
    {
        printf("error connecting to server\n");
        return 0;
    }
    
	return 1;
}
#endif

int tcp_waitForClientToConnect()
{
	socklen_t szlength;

#if defined __APPLE__ || defined __linux__
	szlength = sizeof(sinAddr);
	// ******** accept is a blocking call *********
	sClient = accept(sServer, (struct sockaddr *)&sinAddr, &szlength);
	if (sClient == -1)
	{
			close(sServer);
			return 0;
	}
	
#elif defined _WIN32 || defined _WIN64
szlength = sizeof(sinServer);
sClient = accept(sServer,(LPSOCKADDR)&sinServer, &szlength);
if(sClient == INVALID_SOCKET)
{
	closesocket(sServer);
	WSACleanup();
	return 0;
	}
#else
#error "unknown platform"
#endif

	return 1;
}

int tcp_waitForClientMessage(void *buf, int maxNumBytes)
{
	int ret;

	char *ptr = (char*) buf;

	memset(ptr, 0, maxNumBytes);

	// NOTE: recv is a blocking call.
	// it will return when data is received, there is an error, or the connection is closed.
	// if there is an error or the connection is closed the return value will be <= 0.
	// if we received data the return value will be the number of bytes we received.
	ret = recv(sClient, ptr, maxNumBytes, 0);

	if((disk != NULL) && (ret > 3))
		fprintf(disk,"client: %d,%s %s\r\n",ret,ptr,&ptr[ret-3]);

	return ret;
}

int tcp_checkForClientMessage()
{
	//  select function parameters
	//  int nfds,						// ignored
	//  fd_set* readfds, 				// optional set of sockets to check for readability
	//  fd_set* writefds, 				// optional set of sockets to check for writeability
	//  fd_set* exceptfds, 				// optional set of sockets to check for errors
	//  const struct timeval* timeout 	// timeout period

// #ifdef __MACOSX__
#ifdef __APPLE__
  struct fd_set rdset;
#elif defined __linux__
  fd_set rdset;
#elif defined _WIN32 || defined _WIN64
  fd_set rdset;
#else
#error "unknown platform"
#endif

	//	struct fd_set rdset;
//	fd_set rdset;
	struct timeval timeout;
    FD_ZERO(&rdset); // initialize rdset
    FD_SET((unsigned int)sClient,&rdset); // add sClient to rdset
//	rdset.fd_count = 1;
//	rdset.fd_array[0] = sClient;
    
    
	// set timeout to 50us
	timeout.tv_sec = 0;
	timeout.tv_usec = 50;
//	timeout.tv_usec = 500;

    select(1+sClient,&rdset,NULL,NULL,&timeout); 
    //	ret = select(0,&rdset,NULL,NULL,&timeout);
	// ret should be 0, 1, or SOCKET_ERROR
    if(FD_ISSET(sClient,&rdset))
        return 1;
    else
        return 0;
}

int tcp_checkForClientError()
{
	int ret;

	//  select function parameters
	//  int nfds,						// ignored
	//  fd_set* readfds, 				// optional set of sockets to check for readability
	//  fd_set* writefds, 				// optional set of sockets to check for writeability
	//  fd_set* exceptfds, 				// optional set of sockets to check for errors
	//  const struct timeval* timeout 	// timeout period

	fd_set erset;
	struct timeval timeout;

    FD_ZERO(&erset);
    FD_SET((unsigned int)sClient,&erset);
//	erset.fd_count = 1;
//	erset.fd_array[0] = sClient;

	// set timeout to 50ms
	timeout.tv_sec = 0;
	timeout.tv_usec = 50000;

	ret = select(1,NULL,NULL,&erset,&timeout);
	// ret should be 0, 1, or SOCKET_ERROR

	return ret;
}

void tcp_closeServer()
{
	// Cleanup
#if defined __APPLE__ || defined __linux__
	close(sClient);
	close(sServer);
#elif defined _WIN32 || defined _WIN64
	closesocket(sClient);
	closesocket(sServer);
	WSACleanup();
#else
#error "unknown platform"
#endif

}

int tcp_send(const char *buf)
{
	int ret;
	if(disk != NULL)
		fprintf(disk,"server: %s\r\n",buf);    
	ret = send(sClient, buf, strlen(buf), 0);
	return ret;
}

int tcp_send(const char *buf, int numbytes)
{
	int ret;
	if(disk != NULL)
		fprintf(disk,"server: %s\r\n",buf);
	ret = send(sClient, buf, numbytes, 0);
	return ret;
}


