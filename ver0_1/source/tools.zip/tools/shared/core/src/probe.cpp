#include <iostream>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
//#include <CoreServices/CoreServices.h>
#include "types.h"
#include "probe.h"
#include "hid_api.h"
#include "util.h"

using namespace std;

extern hid_device *handle;


/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
// probe write/read process.
//
// the server initiates all communication with the probe.
// the server sends the probe a packet and the probe responds.
//
// *** server to probe packet ***
// key = 0x55aa79ab (4 bytes)
// command code
// 0-3 (or more) parameters
//
// *** probe to server packet ***
// key = 0x55aa (2 bytes)
// command code that caused this response
// response code RESP_ACK or RESP_NAK
// 0-3 (or more) parameters
//
int SendProbeCommand(U32 cmd, U32 param[], int numParam, U32 resp[], int numResp)
{
	int i, ret;
	U32 buf[16];

	if (!handle)
		return 0;

	ret = probeSendCmd(cmd, param, numParam);
	if (ret < 0)
		return 0;

	ret = getProbeResponse(buf, 64, 1000);
	if (ret != 64)
		return 0;

	if (buf[0] != cmd) // probe should have sent our originating command back for confirmation
		return 0;

	for (i = 0; i < numResp; i++)
		resp[i] = buf[i + 1];

	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
// wait up to timeout_ms for n bytes of data.
// begin filling buf after a 0x55 is received in the first data byte location.
int getProbeResponse(void *buf, int numbytes, int timeout_ms)
{
	int res;
	U8 hidbuf[65];
	int m;
	int len = 0;
	U8 *ptr = (U8*) buf;
    U64 timer;
    
	// a response always comes at the start of a packet,
	// so we can just look at the beginning for the response.

//	DWORD endtime = GetTickCount() + timeout_ms;
    timer = timer_start(timeout_ms);
	// pass 0 to enable blocking, 1 to disable blocking
	hid_set_nonblocking(handle, 0);
//	while ((GetTickCount() < endtime) && (numbytes > 0))
    while((!timer_isExpired(timer)) && (numbytes > 0))
	{
		// have to read 65 data bytes from hid to get 64 byte packet
		res = HID_read(hidbuf, 65);
		if (res < 0)
			return 0;
		if(len != 0)
		{
			m = min(numbytes,64);
			memcpy(&ptr[len], &hidbuf[0], m);
			numbytes -= m;
			len += m;
		}
		else if ((hidbuf[0] == 0x55) && (hidbuf[1] == 0xaa))
		{
			m = min(numbytes,62);
			memcpy(&ptr[len], &hidbuf[2], m);
			numbytes -= m;
			len += m;
		}
	}
	return len;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeInit(U32 *idcode)
{
	U32 resp[2];

	if (SendProbeCommand(PROBE_INIT_SWD, NULL, 0, resp, 2) == 0)
		return 0;

	if (resp[0] != RESP_ACK)
		return 0;

	*idcode = resp[1];
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeReadMem(U32 address, U32 *data)
{
	U32 resp[2];

	if (SendProbeCommand(PROBE_MEM_READ, &address, 1, resp, 2) == 0)
		return 0;

	if (resp[0] != RESP_ACK)
		return 0;

	*data = resp[1];
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeReadMemBuf(U32 address, void *data, U32 numbytes)
{
/*
int SendProbeCommand(U32 cmd, U32 param[], int numParam, U32 resp[], int numResp)
{
	int i, ret;
	U32 buf[16];

	if (!handle)
		return 0;

	ret = probeSendCmd(cmd, param, numParam);
	if (ret < 0)
		return 0;

	ret = getProbeResponse(buf, 64, 1000);
	if (ret != 64)
		return 0;

	if (buf[0] != cmd) // probe should have sent our originating command back for confirmation
		return 0;

	for (i = 0; i < numResp; i++)
		resp[i] = buf[i + 1];

	return 1;
}
*/
    // allow read of up to 128*4 = 512 bytes
	U32 buf[128+1];
	U32 param[2];
	int ret;

	param[0] = address;
	param[1] = numbytes;

	if (!handle)
		return 0;

	ret = probeSendCmd(PROBE_MEMBUF_READ, param, 2);
	if (ret == 0)
		return 0;

	ret = getProbeResponse(buf, numbytes+4, 1000);
    if ((U32)ret != (numbytes+4))
		return 0;

	if (buf[0] != PROBE_MEMBUF_READ) // probe should have sent our originating command back for confirmation
		return 0;

	memcpy(data,&buf[1],numbytes);

	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeWriteMem(U32 address, U32 data)
{
	U32 resp[1];
	U32 param[2];

	param[0] = address;
	param[1] = data;

	if (SendProbeCommand(PROBE_MEM_WRITE, param, 2, resp, 1) == 0)
		return 0;

	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

int probeWriteMemBuf(U32 address, void *data, int n)
{
    int numbytes;
	int offset;
	U8 hidbuf[65];
	U32 resp[16];
	int m, i, ret;
	int strIndex = 0;
	unsigned short crc;
	int maxpayloadsize = 32 + 4096;
    unsigned char *data_ptr = (unsigned char*) data;
    
	if (handle == NULL)
		return 0;
    
	unsigned char *str = new unsigned char[maxpayloadsize];
	unsigned char *block = new unsigned char[4096];
    
	// pass 0 to enable blocking, 1 to disable blocking
	hid_set_nonblocking(handle, 0);
    
//    cout << "probeWriteMemBuf:" << address << " " << n << endl;
	// send data in blocks, loop until all data is sent programmed
	offset = 0;
	do
	{
		// determine block size
		if (n >= 4096)
			numbytes = 4096;
		else if (n >= 1024)
			numbytes = 1024;
		else if (n >= 512)
			numbytes = 512;
		else
			numbytes = 256;
        
		// copy data into block
		if (n < numbytes)
		{
			memcpy(block, &data_ptr[offset], n);
			memset(&block[n], 0, numbytes - n);
		} else
			memcpy(block, &data_ptr[offset], numbytes);
        
		// calculate crc for this block
		crc = crc16(block, numbytes);
        
		// format header
//		cout << "  sending " << numbytes << " bytes to " << address << endl;
		U32 *ptr = (U32*) str;
		ptr[0] = 0x55aa79ab;
		ptr[1] = PROBE_MEMBUF_WRITE;
		ptr[2] = address;
		ptr[3] = numbytes;
		ptr[4] = crc;
		strIndex = 20; // 5*4
		// append data block
		memcpy(&str[strIndex], block, numbytes);
        
		strIndex += numbytes;
		offset += numbytes;
        
		// send to the probe in 64 byte chunks and then wait for a response
		i = strIndex; // i = number of bytes to send
		strIndex = 0;
		while (i > 0)
		{
			if (i > 64)
				m = 64;
			else
				m = i;
			memset(hidbuf, 0, 65); // writing to report 0
			memcpy(hidbuf + 1, &str[strIndex], m);
			ret = HID_write(hidbuf, 65);
			if (ret < 0)
			{
				cout << "error: membuf write failed." << endl;
				delete[] str;
				delete[] block;
				return 0;
			}
			i -= m;
			strIndex += m;
		}
        
		ret = getProbeResponse(resp, 64, 1000);
		if ((ret != 64) || (resp[0] != PROBE_MEMBUF_WRITE) || (resp[1] != RESP_ACK))
		{
			cout << "error: membuf write." << endl;
			delete[] str;
			delete[] block;
			return 0;
		}
        
		n -= numbytes;
		address += numbytes;
	} while (n > 0);
    
	delete[] str;
	delete[] block;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
*********************************************************************/
int probeWriteMem16(U32 address, U32 data)
{
	U32 resp[1];
	U32 param[2];
    
	param[0] = address;
	param[1] = data;
    
	if (SendProbeCommand(PROBE_MEM_WRITE_16, param, 2, resp, 1) == 0)
		return 0;
    
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeReadReg(U32 reg, U32 *data)
{
	U32 resp[2];

	if (SendProbeCommand(PROBE_REG_READ, &reg, 1, resp, 2) == 0)
		return 0;

	if (resp[0] != RESP_ACK)
		return 0;

	*data = resp[1];
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeReadGenRegs(U32 *data)
{
	int i;
	U32 resp[9];

	if (SendProbeCommand(PROBE_GENREGS_READ, NULL, 0, resp, 9) == 0)
		return 0;

	if (resp[0] != RESP_ACK)
		return 0;

	for(i=0;i<8;i++)
		data[i] = resp[i+1];
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeWriteReg(U32 reg, U32 data)
{
	U32 resp[1];
	U32 param[2];

	param[0] = reg;
	param[1] = data;

	if (SendProbeCommand(PROBE_REG_WRITE, param, 2, resp, 1) == 0)
		return 0;
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeSetBreakpoint(U32 address)
{
	U32 resp[1];

	if (SendProbeCommand(PROBE_ADD_BREAKPOINT, &address, 1, resp, 1) == 0)
		return 0;
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeClrBreakpoint(U32 address)
{
	U32 resp[1];

	if (SendProbeCommand(PROBE_CLR_BREAKPOINT, &address, 1, resp, 1) == 0)
		return 0;
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeEraseFlash(U32 startSector, U32 endSector)
{
	U32 resp[1];
	U32 param[2];

	param[0] = startSector;
	param[1] = endSector;

	if (SendProbeCommand(PROBE_FLASH_ERASE, param, 2, resp, 1) == 0)
		return 0;
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeEraseSTM32Flash()
{
	U32 resp[1];

	if (SendProbeCommand(PROBE_STM_ERASE, NULL, 0, resp, 1) == 0)
		return 0;
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}



/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeRelease()
{
	U32 resp[1];

	if (SendProbeCommand(PROBE_RELEASE_SWD, NULL, 0, resp, 1) == 0)
		return 0;
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeRunCore()
{
	U32 resp[1];
//cout << "*** 1 PROBE_PRG_CONTINUE" << endl;
	if (SendProbeCommand(PROBE_PRG_CONTINUE, NULL, 0, resp, 1) == 0)
	{
		return 0;
//cout << "*** 2 PROBE_PRG_CONTINUE retured 0"<< endl;
	}

	if (resp[0] != RESP_ACK)
	{
//cout << "*** 3 PROBE_PRG_CONTINUE return != RESP_ACK" << endl;
		return 0;
	}
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeHaltCore()
{
	U32 resp[1];

	if (SendProbeCommand(PROBE_PRG_HALT, NULL, 0, resp, 1) == 0)
		return 0;
	if (resp[0] != RESP_ACK)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeIsCoreHalted(U32 param[])
{
	U32 resp[4];

	if (SendProbeCommand(PROBE_PRG_HALTREPORT, NULL, 0, resp, 4) == 0)
		return 0;

	if ((resp[0] != RESP_CORE_HALTED) && (resp[0] != RESP_CORE_NOT_HALTED))
		return 0;

	param[0] = resp[1]; // halt signal (0=running, 5=halt on break, or 6=halt on abort)
	param[1] = resp[2]; // pc reg number 0x0f
	param[2] = resp[3]; // pc contents
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeSingleStep(U32 param[])
{
	U32 resp[4];

	if (SendProbeCommand(PROBE_PRG_SINGLESTEP, NULL, 0, resp, 4) == 0)
		return 0;

	if ((resp[0] != RESP_CORE_HALTED) && (resp[0] != RESP_CORE_NOT_HALTED))
		return 0;

	param[0] = resp[1];
	param[1] = resp[2];
	param[2] = resp[3];
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
// blocksize must be 256,512,1024,or 4096
// address must be on a 256 byte boundary (ie least significant byte = 0)
int probeProgramFlash(U32 address, unsigned char *data, int n)
{
	int numbytes;
//	int address = 0; // for test purposes, but could pass this parameter in to program targeted sections
	int offset;
	U8 hidbuf[65];
	U32 resp[16];
	int m, i, ret;
	int strIndex = 0;
	unsigned short crc;
	int maxpayloadsize = 32 + 4096;

	if (handle == NULL)
		return 0;

	unsigned char *str = new unsigned char[maxpayloadsize];
	unsigned char *block = new unsigned char[4096];

	// pass 0 to enable blocking, 1 to disable blocking
	hid_set_nonblocking(handle, 0);

	// send data in blocks, loop until all data is sent programmed
	offset = 0;
	do
	{
		// determine block size
		if (n >= 4096)
			numbytes = 4096;
		else if (n >= 1024)
			numbytes = 1024;
		else if (n >= 512)
			numbytes = 512;
		else
			numbytes = 256;

		// copy data into block
		if (n < numbytes)
		{
			memcpy(block, &data[offset], n);
			memset(&block[n], 0, numbytes - n);
		} else
			memcpy(block, &data[offset], numbytes);

		// calculate crc for this block
		crc = crc16(block, numbytes);

		// format header
//		cout << "sending " << dec << numbytes << " bytes" << endl;
		U32 *ptr = (U32*) str;
		ptr[0] = 0x55aa79ab;
		ptr[1] = PROBE_FLASH_PROGRAM;
		ptr[2] = address;
		ptr[3] = numbytes;
		ptr[4] = crc;
		strIndex = 20; // 5*4
		// append data block
		memcpy(&str[strIndex], block, numbytes);

		strIndex += numbytes;
		offset += numbytes;

		// send to the probe in 64 byte chunks and then wait for a response
		i = strIndex; // i = number of bytes to send
		strIndex = 0;
		while (i > 0)
		{
			if (i > 64)
				m = 64;
			else
				m = i;
			memset(hidbuf, 0, 65); // writing to report 0
			memcpy(hidbuf + 1, &str[strIndex], m);
			ret = HID_write(hidbuf, 65);
			if (ret < 0)
			{
				cout << "error: flash write failed." << endl;
				delete[] str;
				delete[] block;
				return 0;
			}
			i -= m;
			strIndex += m;
		}

		ret = getProbeResponse(resp, 64, 1000);
		if ((ret != 64) || (resp[0] != PROBE_FLASH_PROGRAM) || (resp[1] != RESP_ACK))
		{
			cout << "error: flash write." << endl;
			delete[] str;
			delete[] block;
			return 0;
		}

		n -= numbytes;
		address += numbytes;
	} while (n > 0);

	delete[] str;
	delete[] block;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
// blocksize must be 256,512,1024,or 4096
// address must be on a 256 byte boundary (ie least significant byte = 0)
int probeProgramSTM32Flash(U32 address, unsigned char *data, int n)
{
	int numbytes;
//	int address = 0x08000000; // for test purposes, but could pass this parameter in to program targeted sections
	int offset;
	U8 hidbuf[65];
	U32 resp[16];
	int m, i, ret;
	int strIndex = 0;
	unsigned short crc;
	int maxpayloadsize = 32 + 4096;

	if (handle == NULL)
		return 0;

	unsigned char *str = new unsigned char[maxpayloadsize];
	unsigned char *block = new unsigned char[4096];

	// pass 0 to enable blocking, 1 to disable blocking
	hid_set_nonblocking(handle, 0);

	// send data in blocks, loop until all data is sent programmed
	offset = 0;
	do
	{
		// determine block size
//        if (n >= 4096)
//			numbytes = 4096;
        //		else if (n >= 1024)
        if (n >= 1024)
			numbytes = 1024;
		else if (n >= 512)
			numbytes = 512;
		else
			numbytes = 256;
        
		// copy data into block
		if (n < numbytes)
		{
			memcpy(block, &data[offset], n);
			memset(&block[n], 0, numbytes - n);
		} else
			memcpy(block, &data[offset], numbytes);

		// calculate crc for this block
		crc = crc16(block, numbytes);

		// format header
//		cout << "sending " << dec << numbytes << " bytes to address " << hex << address << endl;
		U32 *ptr = (U32*) str;
		ptr[0] = 0x55aa79ab;
		ptr[1] = PROBE_STM_PRGBUF;
		ptr[2] = address;
		ptr[3] = numbytes;
		ptr[4] = crc;
		strIndex = 20; // 5*4
		// append data block
		memcpy(&str[strIndex], block, numbytes);

		strIndex += numbytes;
		offset += numbytes;

		// send to the probe in 64 byte chunks and then wait for a response
		i = strIndex; // i = number of bytes to send
		strIndex = 0;
		while (i > 0)
		{
			if (i > 64)
				m = 64;
			else
				m = i;
			memset(hidbuf, 0, 65); // writing to report 0
			memcpy(hidbuf + 1, &str[strIndex], m);
			ret = HID_write(hidbuf, 65);
			if (ret < 0)
			{
				cout << "error: flash write failed." << endl;
				delete[] str;
				delete[] block;
				return 0;
			}
			i -= m;
			strIndex += m;
		}

		ret = getProbeResponse(resp, 64, 1000);
		if ((ret != 64) || (resp[0] != PROBE_STM_PRGBUF) || (resp[1] != RESP_ACK))
		{
			cout << "error: flash write." << endl;
			delete[] str;
			delete[] block;
			return 0;
		}

		n -= numbytes;
		address += numbytes;
	} while (n > 0);

	delete[] str;
	delete[] block;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeHWReset()
{
	U32 buf[16];
	int ret;

	if (!handle)
		return 0;

	ret = probeSendCmd(PROBE_HWRESET, NULL, 0);
	if (ret < 0)
		return 0;

	ret = getProbeResponse(buf, 64, 1000);
	if ((ret != 64) || (buf[0] != RESP_ACK))
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int probeSendCmd(U32 cmd, U32 param[], int n)
{
	int i, j, ret;
	U8 buf[65];
	U32 *ptr = (U32*) &buf[1];

	// zero out buffer, it's imperative that buf[0] = 0, this indicates what hid report this is
	memset(buf, 0, 65);

	j = 0;
	ptr[j++] = 0x55aa79ab;	// key word
	ptr[j++] = cmd;			// command

	// optional parameters
	for (i = 0; i < n; i++)
		ptr[j++] = param[i];

	ret = HID_write(buf, 65);
	if (ret < 0)
		return 0;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
void updateUserCodeSignature(unsigned char *data)
{
	int i;
	long sum = 0;
	unsigned long codeSignature;
	U32 *ptr;

	// calc signature
	for (i = 0; i < 7; i++)
	{
		ptr = (U32*) &data[i << 2];
		sum += *ptr;
	}
	codeSignature = (unsigned long) (-sum);
	// update data with user code signature
	ptr = (U32*) &data[0x1c];
	*ptr = codeSignature;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
unsigned short crc16(void *data, unsigned long numbytes)
{
	unsigned long i;
	unsigned short crc;
	unsigned char *ptr = (unsigned char *) data;

	crc = 0;

	for (i = 0; i < numbytes; i++)
	{
		crc = (unsigned char) (crc >> 8) | (crc << 8);
		crc ^= ptr[i];
		crc ^= (unsigned char) (crc & 0xff) >> 4;
		crc ^= (crc << 8) << 4;
		crc ^= ((crc & 0xff) << 4) << 1;
	}
	return crc;
}
