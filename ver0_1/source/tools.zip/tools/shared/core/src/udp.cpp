/*
 * udp.cpp
 *
 *  Created on: Oct 18, 2011
 *      Author: jem
 */

/*
 #if defined __APPLE__ || defined __linux__
 #elif defined _WIN32 || defined _WIN64
 #else
 #error "unknown platform"
 #endif
 */

//project->properties->c/c++ build->settings->mingw c linker->libraries
//
//add library
//ws2_32
//

#include <iostream>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include <udp.h>

#ifdef __APPLE__
#include <CoreServices/CoreServices.h>
#import <CoreFoundation/CFSocket.h>
#endif

#include <sys/time.h>
#include <sys/types.h>

#if defined __APPLE__ || defined __linux__
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#elif defined _WIN32 || defined _WIN64
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
//#include <winsock.h>
#else
#error "unknown platform"
#endif

#include <unistd.h>
//#include <netinet/in.h>
//#include <netdb.h>

using namespace std;

// **** APPLE ****
#if defined __APPLE__ || defined __linux__
struct sockaddr_in rxAddr;
struct sockaddr_in txAddr;
int udpRx = -1;
int udpTx = -1;
socklen_t txAddrLen;

// **** WINDOWS OS ****
#elif defined _WIN32 || defined _WIN64
SOCKET udpRx,udpTx;
SOCKADDR_IN rxAddr,txAddr;
int txAddrLen;

#else
#error "unknown platform"
#endif

extern FILE *disk;

#if defined _WIN32 || defined _WIN64
int udp_startServer(int port) {
	WSADATA wsaData;
	WSAStartup(0x0202, &wsaData); /*windows socket startup */

	memset((char*) &rxAddr, 0, sizeof(udpsinServer));
	udpsinServer.sin_family = AF_INET;
	udpsinServer.sin_addr.s_addr = inet_addr("127.0.0.1");
	udpsinServer.sin_port = htons(port); // Port

	udpServer = socket(PF_INET, SOCK_DGRAM, 0);/*create a socket*/
	if (udpServer < 0) {
		printf("socket creation failed\n");
		WSACleanup();
		return 0;
	}

	if (bind(udpServer, (LPSOCKADDR) &udpsinServer, sizeof(udpsinServer)) < 0) {/*bind a server address and port*/
		printf("bind failed\n");
		WSACleanup();
		return 0;
	}

	clientAddrLen = sizeof(clientAddr);

	Sleep(100);
	return 1;
}
#endif

#if defined __APPLE__ || defined __linux__
int udp_start(int port)
{
	// create a socket
	udpServer = socket(AF_INET, SOCK_DGRAM, 0);
	if (udpServer == -1)
	{
		printf("socket creation failed\n");
		return 0;
	}

	memset(&udpsinAddr, 0, sizeof(udpsinAddr));

	udpsinAddr.sin_family = AF_INET;
	udpsinAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	udpsinAddr.sin_port = htons(port); // Port

//	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
//	setsockopt(sock, SOL_SOCKET, SO_REUSEPORT, &yes, sizeof(yes));
	int sz = sizeof(udpsinAddr);

	if (bind(udpServer, (struct sockaddr *)&udpsinAddr, sz) == -1)
	{
		printf("bind failed\n");
		return 0;
	}

	clientAddrLen = sizeof(clientAddr);

	return 1;
}

int udp_startClient(int port)
{
	// create a socket
	udpClient = socket(AF_INET, SOCK_DGRAM, 0);
	if (udpClient == -1)
	{
		printf("socket creation failed\n");
		return 0;
	}
    
	memset(&udpsinAddr, 0, sizeof(udpsinAddr));
    
	udpsinAddr.sin_family = AF_INET;
	udpsinAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	udpsinAddr.sin_port = htons(port); // Port
        
	return 1;
}
#endif

int udp_waitForClientMessage(void *buf, int maxNumBytes) {
	int ret;

	char *ptr = (char*) buf;

	memset(ptr, 0, maxNumBytes);

	// NOTE: this is a blocking call.
	// it will return when data is received, there is an error, or the connection is closed.
	// if there is an error or the connection is closed the return value will be <= 0.
	// if we received data the return value will be the number of bytes we received.
#if defined __APPLE__ || defined __linux__
	ret = recvfrom(udpServer,ptr,maxNumBytes,0,(sockaddr*)&clientAddr,&clientAddrLen);
#elif defined _WIN32 || defined _WIN64
	ret = recvfrom(udpServer,ptr,maxNumBytes,0,(LPSOCKADDR)&clientAddr,&clientAddrLen);
#endif

	if ((disk != NULL) && (ret > 3))
		fprintf(disk, "client: %d,%s %s\r\n", ret, ptr, &ptr[ret - 3]);

	return ret;
}

int udp_checkForClientMessage()
{
	//  select function parameters
	//  int nfds,						// ignored
	//  fd_set* readfds, 				// optional set of sockets to check for readability
	//  fd_set* writefds, 				// optional set of sockets to check for writeability
	//  fd_set* exceptfds, 				// optional set of sockets to check for errors
	//  const struct timeval* timeout 	// timeout period

// #ifdef __MACOSX__
#ifdef __APPLE__
  struct fd_set rdset;
#elif defined __linux__
  fd_set rdset;
#elif defined _WIN32 || defined _WIN64
  fd_set rdset;
#else
#error "unknown platform"
#endif

	//	struct fd_set rdset;
//	fd_set rdset;
	struct timeval timeout;
    FD_ZERO(&rdset); // initialize rdset
    FD_SET((unsigned int)udpServer,&rdset); // add udpServer to rdset
//	rdset.fd_count = 1;
//	rdset.fd_array[0] = sClient;
    
    
	// set timeout to 1 seconds
	timeout.tv_sec = 1;
	timeout.tv_usec = 0;
//	timeout.tv_usec = 500;

    select(1+udpServer,&rdset,NULL,NULL,&timeout); 
    //	ret = select(0,&rdset,NULL,NULL,&timeout);
	// ret should be 0, 1, or SOCKET_ERROR/Users/johnmaloney/Desktop/dev/tools_dev/shared/core/src/udp.cpp
    if(FD_ISSET(udpServer,&rdset))
        return 1;
    else
        return 0;
}

void udp_closeServer() {
	// Cleanup
#if defined __APPLE__ || defined __linux__
	close(udpServer);
#elif defined _WIN32 || defined _WIN64
	closesocket(udpServer);
	WSACleanup();
#else
#error "unknown platform"
#endif

}

int udp_send(const char *buf) {
	int ret;
	if (disk != NULL)
		fprintf(disk, "server: %s\r\n", buf);
#if defined __APPLE__ || defined __linux__
	ret = sendto(udpServer,buf,strlen(buf),0,(sockaddr*)&clientAddr,clientAddrLen);
#elif defined _WIN32 || defined _WIN64
	ret = sendto(udpServer,buf,strlen(buf),0,(LPSOCKADDR)&clientAddr,clientAddrLen);
#endif
	return ret;
}

int udp_send(const char *buf, int numbytes) {
	int ret;
	if (disk != NULL)
		fprintf(disk, "server: %s\r\n", buf);
#if defined __APPLE__ || defined __linux__
	ret = sendto(udpServer,buf,numbytes,0,(sockaddr*)&clientAddr,clientAddrLen);
#elif defined _WIN32 || defined _WIN64
	ret = sendto(udpServer,buf,numbytes,0,(LPSOCKADDR)&clientAddr,clientAddrLen);
#endif
	return ret;
}

