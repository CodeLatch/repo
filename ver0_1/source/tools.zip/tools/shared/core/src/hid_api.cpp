
//#include <iostream>
#include <stdio.h>
#include <wchar.h>
#include <string>
#include <stdlib.h>
#include "types.h"
#include "probe.h"
#include "hid_api.h"
#include "util.h"

using namespace std;


#define USB_VENDOR_ID 0x0925 	// Vendor ID
#define USB_PROD_ID   0x7001	// Product ID
#define USB_DEVICE    0x0100	// Device ID

extern void delay_ms(int ms);

hid_device *handle;


/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int HID_open(wchar_t *serial_number)
{
	// if the hid handle is open, close it first
	handle = hid_open(USB_VENDOR_ID, USB_PROD_ID, serial_number);
	if (!handle)
        // open failed
		return 0;
	else
        // open success
		return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int HID_open(wchar_t *serial_number, unsigned short vid, unsigned short pid)
{
	// if the hid handle is open, close it first
	handle = hid_open(vid, pid, serial_number);
	if (!handle)
        // open failed
		return 0;
	else
        // open success
		return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
void HID_close()
{
	if (handle != NULL) {
		hid_close(handle);
    }
    
	handle = NULL;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int HID_write(unsigned char *buf, int len)
{
	if (handle == NULL)
		return 0;
	return hid_write(handle, buf, len);
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int HID_read(unsigned char *buf, int len)
{
	if (handle == NULL)
		return 0;
	return hid_read(handle, buf, len);
}


/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int HID_getManufacturerString(char str[256])
{
	int res;
	wchar_t wstr[256];

	// Read the Manufacturer String
	wstr[0] = 0x0000;
	res = hid_get_manufacturer_string(handle, wstr, 256);
	if (res < 0)
		return 0;
	wcstombs( str, wstr, wcslen(wstr) );
//	cout << "Manufacturer String: " << str << endl;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int HID_getProductString(char str[256])
{
	int res;
	wchar_t wstr[256];

	// Read the Manufacturer String
	wstr[0] = 0x0000;
	res = hid_get_product_string(handle, wstr, 256);
	if (res < 0)
		return 0;
	wcstombs( str, wstr, wcslen(wstr) );
//	cout << "Product Number String: " << str << endl;
	return 1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int HID_getSerialNumberString(char str[256])
{
	int res;
	wchar_t wstr[256];

	// Read the Manufacturer String
	wstr[0] = 0x0000;
	res = hid_get_serial_number_string(handle, wstr, 256);
	if (res < 0)
		return 0;
	wcstombs( str, wstr, wcslen(wstr) );
//	cout << "Serial Number String: " << str << endl;
	return 1;
}

/********************************************************************//**
* @
* @param[in]	.
* @return 		.
*********************************************************************/
uint32_t HID_getLocation()
{
	// Read the location
	uint32_t location = hid_get_location(handle);
	return location;
}

