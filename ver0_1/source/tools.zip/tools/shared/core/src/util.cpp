//#include <iostream>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include "types.h"
#include "probe.h"
#include "hid_api.h"
#include "util.h"

using namespace std;

char hexchartable[] = "0123456789abcdef";

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
// converts a hex string to a number
unsigned long HexStrToVal(char *str, int n)
{
	unsigned long ret = 0;
	int i;

	for (i = 0; i < n; i++)
	{
        if((str[i] == 0) || (str[i] == ' '))
            return ret;
		ret <<= 4;
		ret += CharToVal(str[i]);
	}
	return ret;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
U8 validateGDBcmd(char *str, int maxlen)
{
	int i;
	U8 crc = 0;

	if (str[0] != '$')
		return 0;
	// look for end of cmd
	for (i = 1; i < maxlen; i++)
	{
		if (str[i] == '#')
			break;
		crc += str[i];
	}
	if (i == maxlen)
		return 0;
//	printf("crc calc: %c%c\r\n",hexchartable[crc >> 4],hexchartable[crc & 0xf]);
	if ((hexchartable[crc >> 4] == str[i + 1]) && (hexchartable[crc & 0xf] == str[i + 2]))
		return 1;
	return 0;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
U8 calcGDBcrc(char *str, int startIndex, int length)
{
	int i;
	U8 crc = 0;

	for (i = startIndex; i < (length + startIndex); i++)
		crc += str[i];

	return crc;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
void appendGDBcrc(char *str)
{
	int i, n;
	U8 crc = 0;

	n = strlen(str) - 1;
	for (i = 1; i < n; i++)
		crc += str[i];
	str[i + 1] = hexchartable[crc >> 4];
	str[i + 2] = hexchartable[crc & 0x0f];
	str[i + 3] = 0;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
// returns the index of the character after the delimiter
U32 U32fromHexStr(char *str, int maxlen, U32 *data, char delimiter)
{
	int i;
	U32 val = 0;

    if(data != NULL)
        *data = 0;
	for (i = 0; i < maxlen; i++)
	{
		if ((str[i] == delimiter) || (str[i] == 0))
		{
            if(data != NULL)
                *data = val;
			return i + 1;
		}
		val <<= 4;
		val |= CharToVal(str[i]);
	}
	return 0;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
U32 ByteSwapU32(U32 v)
{
	U32 ret = 0;
	ret = (v >> 24) | ((v >> 8)&0xff00) |
		  ((v << 8)&0xff0000) | (v<<24);
	return ret;
}
/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
// converts a 32bit number to a hex string in GDB format
// example: number = 1234ABCD, string = "CDAB3412"
void U32toGDBHexStr(U32 data, char *str)
{
	str[0] = hexchartable[(data >> 4) & 0x0f];
	str[1] = hexchartable[(data >> 0) & 0x0f];
	str[2] = hexchartable[(data >> 12) & 0x0f];
	str[3] = hexchartable[(data >> 8) & 0x0f];
	str[4] = hexchartable[(data >> 20) & 0x0f];
	str[5] = hexchartable[(data >> 16) & 0x0f];
	str[6] = hexchartable[(data >> 28) & 0x0f];
	str[7] = hexchartable[(data >> 24) & 0x0f];
	str[8] = 0;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
unsigned long atoU32_s(char *s, int maxstrlen)
{
	unsigned long r = 0;
	int i = 0;

	// get past any whitespace
	while (((s[i] == ' ') || (s[i] == '\t')) && (i < maxstrlen))
		i++;
	if (i >= maxstrlen)
		return 0;

	// read number
	while (((s[i] >= '0') && (s[i] <= '9')) && (i < maxstrlen))
	{
		r = r * 10;
		r = r + (s[i] - '0');
		i++;
	}
	if (i > maxstrlen)
		return 0;

	return r;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
unsigned int CharToVal(char c)
{
	unsigned int ret;

	if ((c > 47) && (c < 58)) // '0' to '9'
		ret = c - 48;
	else if ((c > 64) && (c < 71)) // 'A' to 'F'
		ret = c - 65 + 10;
	else if ((c > 96) && (c < 103)) // 'a' to 'f'
		ret = c - 97 + 10;
	else
		ret = 0;

	return ret;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int strlen_s(char *str, int maxlen)
{
	int i = 0;
	while ((str[i] != 0) && (i < maxlen))
		i++;
	return i;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int splitString(char *str, int maxlen, char field[][MAXFIELDLEN], int numfields, char delimiter)
{
	int i, j, k, n;
	char c;

	n = strlen_s(str, maxlen);

	// zero out fields
	for (i = 0; i < numfields; i++)
		memset(field[i], 0, MAXFIELDLEN);

	j = 0; // field index
	k = 0; // character index within field

	// process each character
	for (i = 0; i < n; i++)
	{
		c = str[i];
		if (c == delimiter)
		{
			j++;
			k = 0;
			if (j >= numfields)
				return j;
		} else
		{
			field[j][k] += str[i];
			k++;
			if (k >= MAXFIELDLEN)
				return 0;
		}
	}
	return j+1;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
U64 timer_start(U64 dt_ms)
{
	timeval tm;
	gettimeofday(&tm, NULL);
	U64 endtime = tm.tv_sec * 1000000 + tm.tv_usec + dt_ms * 1000;
	return endtime;
}

/********************************************************************//**
 * @brief		.
 * @param[in]	.
 * @return 		.
 *********************************************************************/
int timer_isExpired(U64 timer)
{
    timeval tm;
	gettimeofday(&tm, NULL);
	U64 curtime = tm.tv_sec * 1000000 + tm.tv_usec;
	if (curtime >= timer)
		return 1;
	else
		return 0;
}

int strcmp_s(char *str1, const char *str2)
{
	int n = strlen(str2);
	int i;
	for (i = 0; i < n; i++)
		if (str1[i] != str2[i])
			return 1;
	return 0;
}


