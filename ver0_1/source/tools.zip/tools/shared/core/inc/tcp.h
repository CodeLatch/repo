#ifndef TCPAPI_H__
#define TCPAPI_H__


int tcp_startServer(int port);
int tcp_startClient(int port);
// protocol = IPPROTO_TCP or IPPROTO_UDP
int tcp_startServer(int port,int protocol);
int tcp_waitForClientToConnect();
int tcp_waitForClientMessage(void *buf, int maxNumBytes);
void tcp_closeServer();
int tcp_send(const char *buf);
int tcp_send(const char *buf, int numbytes);
int tcp_checkForClientError();
int tcp_checkForClientMessage();

#endif
