#ifndef _HID_API_H_
#define _HID_API_H_

#include "types.h"
#include "hidapi.h"

extern hid_device *handle;

int HID_open(wchar_t *serial_number);
int HID_open(wchar_t *serial_number, unsigned short vid, unsigned short pid);
void HID_close();
int HID_write(unsigned char *buf, int len);
int HID_read(unsigned char *buf, int len);

int HID_getManufacturerString(char str[256]);
int HID_getProductString(char str[256]);
int HID_getSerialNumberString(char str[256]);
uint32_t HID_getLocation();

#endif
