#ifndef UDPAPI_H__
#define UDPAPI_H__


int udp_startServer(int port);
int udp_waitForClientMessage(void *buf, int maxNumBytes);
void udp_closeServer();
int udp_send(const char *buf);
int udp_send(const char *buf, int numbytes);
int udp_checkForClientError();
int udp_checkForClientMessage();

#endif
