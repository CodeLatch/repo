#ifndef _PROBE_H_
#define _PROBE_H_

#include "types.h"

//******** commands we receive from the server **********


// probe info commands
#define PROBE_HELLO				0x01
#define PROBE_GET_VER			0x02
// general control commands
#define PROBE_INIT_SWD			0x04
#define PROBE_RELEASE_SWD		0x05
#define PROBE_HWRESET			0x06
// low level swd read/write
#define PROBE_SWD_WRITE			0x07
#define PROBE_SWD_READ			0x08
// flash programming commands
#define PROBE_FLASH_ERASE		0x09
#define PROBE_FLASH_PROGRAM		0x0a
// breakpoint commands
#define PROBE_ADD_BREAKPOINT	0x0b
#define PROBE_CLR_BREAKPOINT	0x0c
#define PROBE_CLRALL_BREAKPTS	0x0d
// memory and register read/write
#define PROBE_MEM_WRITE			0x0e
#define PROBE_MEM_READ			0x0f
#define PROBE_REG_WRITE			0x10
#define PROBE_REG_READ			0x11
// program execution control and status
#define PROBE_PRG_CONTINUE		0x12
#define PROBE_PRG_SINGLESTEP	0x13
#define PROBE_PRG_HALT			0x14
#define PROBE_PRG_HALTREPORT	0x15
#define PROBE_PRG_ENABLEINTS	0x16
#define PROBE_PRG_DISABLEINTS	0x17

#define PROBE_MEMBUF_WRITE		0x18
#define PROBE_MEMBUF_READ		0x19
#define PROBE_GENREGS_READ		0x1a

// stm32f1x support
#define PROBE_STM_ERASE			0x1b
#define PROBE_STM_PRGBUF		0x1c

#define PROBE_MEM_WRITE_16		0x1d


//******** info we get back from the probe **********

#define RESP_NAK				0x01
#define RESP_ACK				0x02
#define RESP_CORE_HALTED		0x03
#define RESP_CORE_NOT_HALTED	0x04
//#define RESP_READ_MEM			0x04
//#define RESP_READ_REG			0x05
//#define RESP_IDCODE				0x06
//#define RESP_OK					0x07
//#define RESP_VER				0x08
//#define RESP_HELLO				0x09


int SendProbeCommand(U32 cmd, U32 param[], int numParam, U32 resp[], int numResp);
int probeSendCmd(U32 cmd, U32 param[], int n);
int getProbeResponse(void *buf, int numbytes, int timeout_ms);
void updateUserCodeSignature(unsigned char *data);
unsigned short crc16(void *data, unsigned long numbytes);

int probeInit(U32 *idcode);
int probeEraseFlash(U32 startSector, U32 endSector);
int probeEraseSTM32Flash();
int probeProgramFlash(U32 address, unsigned char *data, int n);
int probeProgramSTM32Flash(U32 address, unsigned char *data, int n);
int probeReadMem(U32 address, U32 *data);
int probeReadMemBuf(U32 address, void *data, U32 numbytes);
int probeWriteMem(U32 address, U32 data);
int probeWriteMemBuf(U32 address, void *data, int numbytes);
int probeWriteMem16(U32 address, U32 data);
int probeReadReg(U32 reg, U32 *data);
int probeWriteReg(U32 reg, U32 data);
int probeReadGenRegs(U32 *data);
int probeRelease();
int probeHWReset();
int probeIsCoreHalted(U32 param[]);
int probeSingleStep(U32 param[]);
int probeRunCore();
int probeSetBreakpoint(U32 address);
int probeClrBreakpoint(U32 address);
int probeHaltCore();

#endif
