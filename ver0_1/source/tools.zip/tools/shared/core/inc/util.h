#ifndef _GDB_UTIL_H_
#define _GDB_UTIL_H_

#include "types.h"

#define NUMFIELDS		5		// max number of fields in a command string
#define MAXFIELDLEN		20		// max number of character in a field

extern char hexchartable[];

U8 validateGDBcmd(char *str, int maxlen);
U8 calcGDBcrc(char *str, int startIndex, int length);
void appendGDBcrc(char *str);
void U32toGDBHexStr(U32 data, char *str);
U32 U32fromHexStr(char *str, int maxlen, U32 *data, char delimiter);
U32 ByteSwapU32(U32 v);
unsigned long HexStrToVal(char *str, int n);
unsigned long atoU32_s(char *s, int maxstrlen);
unsigned int CharToVal(char c);
U64 timer_start(U64 dt_ms);
int timer_isExpired(U64 timer);

int splitString(char *str, int maxlen, char field[][MAXFIELDLEN], int numfields, char delimiter);
int strlen_s(char *str, int maxlen);
int strcmp_s(char *str1, const char *str2);

#endif
