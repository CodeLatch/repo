//!----------------------------------------------------------------------------
//! file: main.cpp
//! project: hidserver
//!
//! Hid i/o tcp server. This program operates as a tcp server interface between
//! an external program and a microcontroller hid device. The microcontroller
//! can be read from and write to the hid device via a tcp pipe.
//!
//! usage: hidserver <port> <vid> <pid> <serial number>
//! example: hidserver 3535 0x0725 0x7002 000000010000
//!
//! All parameters are optional. Defaults are specified in the main() routine.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include "types.h"
#include "probe.h"
#include "hid_api.h"
#include "tcp.h"
#include "util.h"

#ifdef __APPLE__
#include <CoreServices/CoreServices.h>
#import <CoreFoundation/CFSocket.h>
#endif

#include <sys/time.h>
#include <sys/types.h>

#if defined __APPLE__ || defined __linux__
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#elif defined _WIN32 || defined _WIN64
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
//#include <winsock.h>
#else
#error "unknown platform"
#endif

//using namespace std;

//!----------------------------------------------------------------------------
//! defines
//!----------------------------------------------------------------------------
#if defined __APPLE__ || defined __linux__
#define TCP_RX_BUF_SIZE				64				// tcp receive buffer size
#elif defined _WIN32 || defined _WIN64
#define TCP_RX_BUF_SIZE				65				// tcp receive buffer size
#endif
#define RESP_BUF_SIZE               65

//!----------------------------------------------------------------------------
//! prototypes
//!----------------------------------------------------------------------------
int openHidConnection(int vid, int pid, char *serno);
int closeServer();
bool startServer(int port);
void runEnumeration(int pid, int vid);

//!----------------------------------------------------------------------------
//! globals
//!----------------------------------------------------------------------------
struct sockaddr_in servaddr;
char resp[RESP_BUF_SIZE];                   // our response buffer
char tcpRxBuf[TCP_RX_BUF_SIZE];
bool run = true;
FILE *disk = NULL;


//!----------------------------------------------------------------------------
//! \brief Program entry point.
//!
//! Important: The first text written to the console needs to indicate that
//! ther server either didn't start or did start. This is because the code
//! that launches this process is going to wait for an indication (the first
//! text written to the console) that the server is running or not. The text
//! itself is not important, only that the first line of text is output upon
//! the failure or success of the server starting.
//!----------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    int n, port, vid, pid;
    char *serno;
    unsigned char hidbuf[65];

    // defaults if no command line arguments
    port = 3535;
    vid = 0x0925;
    pid = 0x7002;
    serno = NULL; // null will cause us to use the first device found.

    // if 1st param is present it's the port number
    if (argc >= 2)
        port = atoi(argv[1]);

    // if 2nd param is present it's the device vid
    if (argc >= 3)
        vid = atoi(argv[2]);

    // if 3rd param is present it's the device pid
    if (argc >= 4)
        pid = atoi(argv[3]);

    // if 4th param is present it's the device serial number
    if (argc >= 5)
        serno = argv[4];

    // start tcp server and wait for client to connect, this is the first
    // action that will output text.
    if(!startServer(port)) return 0;

    runEnumeration(vid, pid);

    // attempt to open connection with the device
    openHidConnection(vid, pid, serno);
    if (handle == NULL)
    {
//		cout << "no hid detected." << endl;
        return 0;
    }

    // 0=blocking, 1=non-blocking
    hid_set_nonblocking(handle, 0);

    while (run)
    {
        int res = HID_read(hidbuf, 65);
        if (res <= 0) break;

        // only send non-null packets to pc
        //            if(hidbuf[0] != 0)
        tcp_send((char*)hidbuf, 64);

        int msgWaiting = tcp_checkForClientMessage();
        if (msgWaiting)
        {
            if ((n = tcp_waitForClientMessage(tcpRxBuf, TCP_RX_BUF_SIZE)) > 0)
                HID_write((unsigned char*)tcpRxBuf, n);
            else
                break;
        }
    }

//	cout << "closing server." << endl;
    //	closeServer();
    return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void runEnumeration(int vid, int pid)
{
    struct hid_device_info *devs, *cur_dev;

    devs = hid_enumerate(vid, pid);
    cur_dev = devs;
    /*	printf("Loop %d\n",cnt++);
     while (cur_dev) {
     printf("Device Found\n  type: %04hx %04hx\n  path: %s\n  serial_number: %ls", cur_dev->vendor_id, cur_dev->product_id, cur_dev->path, cur_dev->serial_number);
     printf("\n");
     printf("  Manufacturer: %ls\n", cur_dev->manufacturer_string);
     printf("  Product:      %ls\n", cur_dev->product_string);
     printf("  Release:      %hx\n", cur_dev->release_number);
     printf("  Interface:    %d\n",  cur_dev->interface_number);
     printf("\n");
     cur_dev = cur_dev->next;
     }
     */
    hid_free_enumeration(devs);
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int openHidConnection(int vid, int pid, char *serno)
{
    wchar_t wserno[32];
    wchar_t *ptr = NULL;

    if (serno != NULL)
    {
        mbstowcs(wserno, serno, 32);
        ptr = wserno;
    }
    if (!HID_open(ptr, vid, pid))
    {
        return 0;
    }

//    uint32_t location = HID_getLocation();
//    cout << "location:" << location << endl;

    return 1;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int closeServer()
{
    HID_close();
    hid_exit();
    tcp_closeServer();

    return 1;
}

//!----------------------------------------------------------------------------
//! \brief  Starts the tcp server on the local host on the specified port.
//!
//! Important: The first text written to the console needs to indicate that
//! ther server either didn't start or did start. This is because the code
//! that launches this process is going to wait for an indication (the first
//! text written to the console) that the server is running or not. The text
//! itself is not important, only that the first line of text is output upon
//! the failure or success of the server starting.
//!----------------------------------------------------------------------------
bool startServer(int port)
{
    // start tcp server
    if (!tcp_startServer(port))
    {
        // first text indicating server didn't start.
//		cout << "Error: Couldn't start server." << endl;
        return false;
    }
    // first text indicating server did start.
//	cout << "waiting for client." << endl;

    if (!tcp_waitForClientToConnect())
    {
//		cout << "Error: Invalid socket." << endl;
        tcp_closeServer();
        return false;
    }
//	cout << "client connected." << endl;

    return true;
}

/************************************** END OF FILE **********************************/
