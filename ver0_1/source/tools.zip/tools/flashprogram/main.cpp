//!----------------------------------------------------------------------------
//! file: main.cpp
//! project: flashprogram
//!
//! Command line flash programming tool.
//!
//! Written by: J.Maloney
//! Copyright (C) 2013
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <http://www.gnu.org/licenses/>.
//!----------------------------------------------------------------------------

#include <iostream>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include "types.h"
#include "probe.h"
#include "hid_api.h"
#include "util.h"


#define STM32_FLASH_ACR			0x40022000		// flash control access register
#define STM32_FLASH_KEYR		0x40022004		// FPEC flash protection control register
#define STM32_FLASH_OPKEYR		0x40022008		// option byte key register
#define STM32_FLASH_SR			0x4002200c		// status register
#define STM32_FLASH_CR			0x40022010		// control register
#define STM32_FLASH_AR			0x40022014		// address register
#define STM32_FLASH_OBR			0x4002201c		// option byte register
#define STM32_FLASH_WRPR		0x40022020		// write protection register

#define STM32_FLASH_KEY1		0x45670123
#define STM32_FLASH_KEY2		0xcdef89ab
#define STM32_FLASH_RDPRT		0x00a5

#define STM32_FLASH_CR_PG		0x01
#define STM32_FLASH_CR_PER		0x02
#define STM32_FLASH_CR_MER		0x04
#define STM32_FLASH_CR_OPTPG	0x10
#define STM32_FLASH_CR_OPTER	0x20
#define STM32_FLASH_CR_STRT		0x40
#define STM32_FLASH_CR_LOCK		0x80
#define STM32_FLASH_CR_OPTWRE	0x200
#define STM32_FLASH_CR_ERRIE	0x400
#define STM32_FLASH_CR_EOPIE	0x1000

#define STM32_FLASH_SR_BSY		0x01
#define STM32_FLASH_SR_PGERR	0x04
#define STM32_FLASH_SR_WRPRTERR	0x10
#define STM32_FLASH_SR_EOP		0x20

enum PARTTYPES
{
    UNSPECIFIED = 0,
    STM32F10X = 1,
    LPC1X = 2,
};

using namespace std;

FILE *disk = NULL;
char cbuf[200];

int LPC1X_programFlash(U32 start, char *filename);
int SM32F10X_loadRam(U32 start, char *filename);
int SM32F10X_programFlash(U32 start,char *filename, bool verify);
void showHelp();

// stm32f10x_flashprg.bin
// this is a program that is loaded into ram at 0x20000000 to aid in flash programming.
// this code unlocks flash if necessary, sets the pg bit, and copies a block of ram
// to flash a half word at a time.
// The flash destination starting address should be set in ram address 0x20000900
// The ram source starting address should be set in ram address 0x20000904
// The number of 32bit words to copy should be set in ram address 0x20000908
unsigned char stm32f10x_flashprg[] =
   {0x2d,0xe9,0xf8,0x43,0x24,0x4b,0x25,0x4d,0x53,0xf8,0x04,0x6c,0x1f,0x68,0x53,0xf8,
    0x08,0x4c,0x6b,0x68,0x1a,0x68,0x12,0xf0,0x80,0x0f,0x09,0xd0,0xaa,0x68,0x20,0x49,
    0x11,0x60,0x20,0x49,0x11,0x60,0x1b,0x68,0x13,0xf0,0x80,0x0f,0x00,0xd0,0x02,0xbe,
    0x6b,0x68,0x1a,0x68,0x42,0xf0,0x01,0x02,0x1a,0x60,0x00,0xf0,0x35,0xf8,0x20,0xe0,
    0x22,0x88,0x4f,0xf6,0xff,0x73,0x92,0xb2,0x9a,0x42,0x00,0xd0,0x03,0xbe,0xb1,0x46,
    0x39,0xf8,0x02,0x3b,0xa0,0x46,0x9b,0xb2,0x28,0xf8,0x02,0x3b,0x00,0xf0,0x24,0xf8,
    0x62,0x88,0x4f,0xf6,0xff,0x73,0x92,0xb2,0x9a,0x42,0x00,0xd0,0x04,0xbe,0xb9,0xf8,
    0x00,0x30,0x04,0x34,0x9b,0xb2,0xa8,0xf8,0x00,0x30,0x00,0xf0,0x15,0xf8,0x04,0x36,
    0x01,0x3f,0x00,0x2f,0xdc,0xd1,0x6b,0x68,0x1a,0x68,0x22,0xf0,0x01,0x02,0x1a,0x60,
    0x05,0xbe,0x01,0x20,0xbd,0xe8,0xf8,0x83,0x08,0x09,0x00,0x20,0xcc,0x00,0x00,0x20,
    0x23,0x01,0x67,0x45,0xab,0x89,0xef,0xcd,0x07,0x4b,0x1a,0x68,0x4c,0xf2,0x50,0x33,
    0x05,0xe0,0x11,0x68,0x11,0xf0,0x01,0x0f,0x01,0xd1,0x1b,0xb1,0x70,0x47,0x01,0x3b,
    0xf7,0xd2,0x70,0x47,0x01,0xbe,0x70,0x47,0xcc,0x00,0x00,0x20,0x0c,0x20,0x02,0x40,
    0x10,0x20,0x02,0x40,0x04,0x20,0x02,0x40,0x00,0x20,0x02,0x40,0x14,0x20,0x02,0x40};

//!----------------------------------------------------------------------------
//! \brief Program flash main routine.
//!
//! arguments...
//!   -p<part-type>
//!   -a<start address>
//!   -l<probe location>
//!   -f<file name>
//!
//!----------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    U32 startAddress = 0;
    char *filename = NULL;
    char *hidLocation = NULL;
    int partType = UNSPECIFIED;
    int n;
    bool verify = false;

    if (argc > 1)
    {
        if (strcmp(argv[1], "help") == 0)
        {
            showHelp();
            return 1;
        }
    }
    for (int i = 1; i < argc; i++)
    {
        if (argv[i][0] != '-')
        {
            cout << "Invalid argument:" << argv[i] << endl;
            return 0;
        }
        if ((argv[i][1] == ' ') || (argv[i][1] == 0))
        {
            cout << "Invalid argument:" << argv[i] << endl;
            return 0;
        }
        char key = argv[i][1];

        // deal with a possible space after the key which splits the arg
        char *str;
        if (argv[i][2] == 0)
        {
            i++;
            if(i == argc)
            {
                cout << "Invalid argument:" << argv[i-1] << endl;
                return 0;
            }
            str = &argv[i][0];
        }
        else
            str = &argv[i][2];

        // process arg
        switch (key)
        {
            case 'a': // starting address in hex
                startAddress = HexStrToVal(str, strlen(str));
                break;
            case 'f': // .bin filename
                filename = str;
                // remove leading and trailing double quote if present
                if(filename[0] == '"')
                    filename++;
                n = strlen(filename);
                if(n > 1)
                {
                    if(filename[n-1] == '"')
                        filename[n-1] = 0;
                }
                break;
            case 'l': // hid probe location
                hidLocation = str;
                break;
            case 'p': // part type
                if (strcmp(str, "stm32f10x") == 0)  partType = STM32F10X;
                else if (strcmp(str, "lpc1x") == 0) partType = LPC1X;
                else
                {
                    cout << "unsupported micro type:" << str << endl;
                    showHelp();
                    return 0;
                }
                break;
            case 'v': // verify
                if(strcmp(str,"verify") == 0) verify = true;
                break;
            default:
                cout << "Invalid argument:" << argv[i] << endl;
                return 0;
        }
    }

    if (partType == UNSPECIFIED)
    {
        cout << "A valid part must be specified." << endl;
        showHelp();
        return 0;
    }
    if (!HID_open(NULL))
    {
        cout << "Probe not found. Check usb connection." << endl;
        return 0;
    }

    switch (partType)
    {
        case STM32F10X:
            if(startAddress >= 0x20000000)
                SM32F10X_loadRam(startAddress,filename);
            else
                SM32F10X_programFlash(startAddress,filename,verify);
            break;
        case LPC1X:
            LPC1X_programFlash(startAddress,filename);
            break;
    }

    probeHWReset();
    probeRelease();
    HID_close();
    hid_exit();

    cout << "done." << endl;

    return 2;
}

//!----------------------------------------------------------------------------
//! \brief Show usage.
//!----------------------------------------------------------------------------
void showHelp()
{
    cout << endl << "usage:   flashprogram -p <partType> -a <startAddress> -l <probeLocation> -f <filename> -verify" << endl;
    cout << endl << "example: flashprogram -p stm32f10x -a 0x08000000 -f \"my program.bin\"" << endl << endl;
    cout << endl << "a space between the flag and the parameter is optional (re -p lpc1x or -plpc1x" << endl;
    cout << "probeLocation is optional." << endl;
    cout << "-verify is an optional flag that invokes data verification after programming." << endl;
    cout << "filename is the .bin file filename and should usually be surrounded by double quotes." << endl;
    cout << "startAddress is a hex number which specifies the starting address to program." << endl;
    cout << "partType specifies the part type, supported types are:" << endl;
    cout << "     stm32f10x" << endl;
    cout << "     lpc1x" << endl;
}

//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
void delay_ms(int ms)
{
    U64 timer;
    timer = timer_start(ms);
    while(!timer_isExpired(timer));
}

//!----------------------------------------------------------------------------
//! \brief  Wait for the core to stop running, hopefully due to hitting a
//! software break point. Waits up to 440ms.
//!----------------------------------------------------------------------------
U32 waitForCoreStop(U32 *endingPc)
{
    // wait for core to stop
    U32 param[4];
    U32 loopcnt = 0;
    bool running = true;
    delay_ms(40);
    while(running)
    {
        if(probeIsCoreHalted(param) == 0)
        {
            cout << "** error checking for core halt." << endl;
            return 0;
        }
        if(param[0] != 0) // 0 == core is running
            running = false;
        else
            delay_ms(20);

        //        sprintf(cbuf,"  state: %d pc:0x%08x",param[0],param[2]);
        //        cout << cbuf << endl;

        loopcnt++;
        if(loopcnt > 20)
        {
            cout << "** core halt timeout." << endl;
            return 0;
        }
    }
    *endingPc = param[2];
    return param[0];
}

//!----------------------------------------------------------------------------
//! \brief Read section of flash and verify it's all 0xff.
//!----------------------------------------------------------------------------
int verifyFlashErase(U32 start_address, U32 nbytes)
{
    probeHaltCore();

    U32 n = nbytes;
    unsigned char *vdata = new unsigned char[nbytes];
    unsigned char *vptr;
    vptr = vdata;
    memset(vdata,0,nbytes);
    U32 saddr = start_address;
    while(n > 0)
    {
        int nread = n;
        if(nread > 256)
            nread = 256;
        probeReadMemBuf(saddr,vptr,nread);
        saddr += nread;
        vptr += nread;
        n -= nread;
    }

    for(U32 i=0;i<nbytes;i++)
    {
        if(vdata[i] != 0xff)
        {
            sprintf(cbuf,"*** Error flash not erased: 0x%08x %d",0x08000000+i,vdata[i]);
            cout << cbuf << endl;

            delete [] vdata;
            return 0;
        }
    }

    delete [] vdata;
    return 1;
}

//!----------------------------------------------------------------------------
//! \brief Read section of memory and verify it matches data.
//!----------------------------------------------------------------------------
int verifyMemory(U32 start_address, unsigned char *data, U32 nbytes)
{
    probeHaltCore();

    U32 n = nbytes;
    unsigned char *vdata = new unsigned char[nbytes];
    unsigned char *vptr;
    vptr = vdata;
    memset(vdata,0,nbytes);
    U32 saddr = start_address;
    while(n > 0)
    {
        int nread = n;
        if(nread > 256)
            nread = 256;
        probeReadMemBuf(saddr,vptr,nread);
        saddr += nread;
        vptr += nread;
        n -= nread;
    }

    for(U32 i=0;i<nbytes;i++)
    {
        if(vdata[i] != data[i])
        {
            sprintf(cbuf, "data mismatch: index: %d expected 0x%02x read 0x%02x",i,data[i],vdata[i]);
            cout << cbuf << endl;
            delete [] vdata;
            return 0;
        }
    }

    delete [] vdata;
    return 1;
}



//!----------------------------------------------------------------------------
//! \brief Program the flash of a LPC1X part (re LPC1343, LPC1754, ...)
//!----------------------------------------------------------------------------
int LPC1X_programFlash(U32 start, char *filename)
{
    FILE *disk = NULL;
    long n;
    int startSector,endSector;
    U32 idcode;

    cout << "Programming LPC1X..." << endl;

    // make sure hid channel is open
    if (handle == NULL)
    {
        cout << "HID is not open." << endl;
        return 0;
    }

    // open file
    disk = fopen(filename, "rb");
    if (disk == NULL)
    {
        cout << "Couldn't open " << filename << endl;
        return 0;
    }

    // get the filesize
    fseek(disk, 0L, SEEK_END);
    n = ftell(disk);
    fseek(disk, 0L, SEEK_SET);

    cout << "File size: " << n << endl;

    // sanity check the number of bytes
    if (n > 0x80000)
    {
        cout << "Filesize > 512K, exiting." << endl;
        return 0;
    }
    if (n < 32)
    {
        cout << "Filesize < 32bytes, exiting." << endl;
        return 0;
    }

    // create a buffer
    unsigned char *data = new unsigned char[n];
    if (data == NULL)
    {
        fclose(disk);
        return 0;
    }

    // read in the data and close the file
    fread(data, 1, n, disk);
    fclose(disk);
    // calculate user code signature and update binary data
    updateUserCodeSignature(data);

    // send init command to probe
    if (!probeInit(&idcode))
    {
        cout << "failed to init target" << endl;
        delete[] data;
        return 0;
    }
    cout << "Target Init Success" << endl;

    // determine starting and ending sectors
    if (start <= 0xffff)
        startSector = (start / 4096);
    else
        startSector = 16 + ((start - 0xffff) / 32768);

    if ((start + n) <= 0xffff)
        endSector = ((start + n) / 4096);
    else
        endSector = 16 + (((start + n) - 0xffff) / 32768);

    // send erase command to probe
    if (probeEraseFlash(startSector, endSector) == 0)
    {
        cout << "Failed to erase target" << endl;
        delete[] data;
        return 0;
    }
    cout << "Target Erase Success" << endl;

    // program flash
    if (probeProgramFlash(start, data, n) == 0)
        cout << "Flash programming failed." << endl;
    else
        cout << "Flash programming succeeded." << endl;

    // free buffer
    delete[] data;

    probeRelease();
    probeHWReset();

    return 1;
}


//!----------------------------------------------------------------------------
//! \brief
//!----------------------------------------------------------------------------
int SM32F10X_waitNotBusy()
{
    U32 val;
    int i;
    for (i = 0; i < 500; i++)
    {
        probeReadMem(STM32_FLASH_SR, &val);
        if ((val & 0x01) == 0) break;
    }
    return i;
}

//!----------------------------------------------------------------------------
//! \brief Load a binary file into ram.
//!----------------------------------------------------------------------------
int SM32F10X_loadRam(U32 start,char *filename)
{
    FILE *disk = NULL;
    long n;
    //	int endSector;
    U32 idcode;
    //	int i;

    cout << "Loading ram..." << endl;

    // make sure hid channel is open
    if (handle == NULL)
    {
        cout << "HID is not open." << endl;
        return 0;
    }

    // open file
    disk = fopen(filename, "rb");
    if (disk == NULL)
    {
        cout << "Couldn't open " << filename << endl;
        return 0;
    }

    // get the filesize
    fseek(disk, 0L, SEEK_END);
    n = ftell(disk);
    fseek(disk, 0L, SEEK_SET);

    cout << "File size: " << n << endl;

    // sanity check the number of bytes
    if (n > 0x80000)
    {
        cout << "Filesize > 512K, exiting." << endl;
        return 0;
    }
    if (n < 32)
    {
        cout << "Filesize < 32bytes, exiting." << endl;
        return 0;
    }

    // create a buffer
    unsigned char *data = new unsigned char[n];
    if (data == NULL)
    {
        fclose(disk);
        return 0;
    }

    // read in the data and close the file
    fread(data, 1, n, disk);
    fclose(disk);

    // send init command to probe
    if (!probeInit(&idcode))
    {
        cout << "failed to init target" << endl;
        delete[] data;
        return 0;
    }

    // program ram
    U8 *ptr = data;
    while(n > 0)
    {
        U32 numbytes = n;
        if(numbytes > 2048) numbytes = 2048;
        if (probeWriteMemBuf(start, ptr, numbytes) == 0)
        {
            cout << "ram programming failed." << endl;
            delete [] data;
            return 0;
        }
        start += numbytes;
        ptr += numbytes;
        n -= numbytes;
    }
    // free buffer
    delete[] data;
    cout << "finished ram load" << endl;
    return 1;
}

//!----------------------------------------------------------------------------
//! \brief  Erase STM32F10X flash page by page for a given number of bytes.
//! Each pages is 1024 bytes.
//!----------------------------------------------------------------------------
int STM32F10X_flashErasePages(U32 start_address, U32 nbytes)
{
    // determine the number of pages to erase
    U32 npages = nbytes / 1024;
    if(nbytes % 1024) npages++;

    U32 data;
    U32 address = start_address;

    // Unlock the flash if needed
    probeReadMem(0x40022010,&data);
    if (data & 0x00000080)
    {
        probeWriteMem(0x40022004,0x45670123);
        probeWriteMem(0x40022004,0xCDEF89AB);
        probeReadMem(0x40022010,&data);
        if (data & 0x00000080)
            return 0;
    }
    SM32F10X_waitNotBusy();

    for(U32 i=0;i<npages;i++)
    {
        // Program the FLASH_AR register to select a page to erase
        probeWriteMem(0x40022014,address);
        // Set the PER bit in the FLASH_CR register
        probeReadMem(0x40022010,&data);
        data |= 0x00000002;
        probeWriteMem(0x40022010,data);
        // Set the STRT bit in the FLASH_CR register
        probeReadMem(0x40022010,&data);
        data |= 0x00000040;
        probeWriteMem(0x40022010,data);
        // Wait for BSY bit to be reset
        SM32F10X_waitNotBusy();
        // move address to next page
        address += 1024;
    }
    // clear FLASH_CR
    probeReadMem(0x40022010,&data);
    data = 0;
    probeWriteMem(0x40022010,data);

    return 1;
}

//!----------------------------------------------------------------------------
//! \brief Program STM32F10X flash with binary image.
//!----------------------------------------------------------------------------
int SM32F10X_programFlash(U32 dest_address,char *filename, bool verify)
{
    FILE *disk = NULL;
    U32 n,idcode;
    int ret;
    U32 dest_start = dest_address;

    cout << "Programming STM32 Flash..." << endl;

    // send init command to probe
    if (!probeInit(&idcode))
    {
        cout << "failed to init target" << endl;
        return 0;
    }

    // load flash burner into ram
//    if(cmdProgramRam(0x20000000,"/users/johnmaloney/desktop/dev/projects/flashwrt/build/flashwrt.bin") != 1)
//        return 0;
    ret = probeWriteMemBuf(0x20000000, stm32f10x_flashprg, sizeof(stm32f10x_flashprg));

    // make sure hid channel is open
    if (handle == NULL)
    {
        cout << "HID is not open." << endl;
        return 0;
    }

    // open file
    cout << "opening " << filename << endl;

    disk = fopen(filename, "rb");
    if (disk == NULL)
    {
        cout << "Couldn't open " << filename << endl;
        return 0;
    }

    // get the filesize
    fseek(disk, 0L, SEEK_END);
    n = ftell(disk);
    fseek(disk, 0L, SEEK_SET);

    cout << "File size: " << n << endl;

    // sanity check the number of bytes
    if (n > 0x80000)
    {
        cout << "Filesize > 512K, exiting." << endl;
        return 0;
    }
    if (n < 32)
    {
        cout << "Filesize < 32bytes, exiting." << endl;
        return 0;
    }

    // create a buffer
    unsigned char *data = new unsigned char[n];
    if (data == NULL)
    {
        fclose(disk);
        return 0;
    }

    // read in the data and close the file
    fread(data, 1, n, disk);
    fclose(disk);


    // ******** ERASE FLASH *********
    cout << "Erasing Flash." << endl;
    if(STM32F10X_flashErasePages(dest_address,n) == 0)
    {
        cout << "Failed to erase target" << endl;
        delete[] data;
        return 0;
    }

    // ******** PROGRAM FLASH *********
    cout << "Programming Flash." << endl;
    unsigned char *ptr = data;
    U32 cnt = n;
    while(cnt > 0)
    {
        U32 endingPc;
        U32 numbytes = cnt;
        if(numbytes > 1024) numbytes = 1024;
        U32 numwords = numbytes >> 2;
        if(numwords == 0) numwords = 1;

        //        printf("writing %d words to 0x%08x\n",numwords,dest_address);
        sprintf(cbuf,"writing %d bytes to 0x%08x",numbytes,dest_address);
        cout << cbuf << endl;

        // copy data to target ram
        ret = probeWriteMemBuf(0x20001000, ptr, numbytes);
        // load source, dest, and numwords into target ram
        ret = probeWriteMem(0x20000900,dest_address); // flash destination starting address   -> 0x20000900
        ret = probeWriteMem(0x20000904,0x20001000);   // ram source starting address          -> 0x20000904
        ret = probeWriteMem(0x20000908,numwords);     // number of words to copy              -> 0x20000908
        ret = probeWriteReg(15,0x20000000);           // set program counter
        ret = probeWriteReg(13,0x20000800);           // set stack pointer (1k above pc)

        // run
        ret = probeRunCore();
        ret = waitForCoreStop(&endingPc);
        if(ret == 0)
        {
            delete [] data;
            probeWriteMem(0x40022010,0);
            return 0;
        }
        // update data pointer, destination address, and remaining byte count
        ptr += numbytes;
        dest_address += numbytes;
        cnt-=numbytes;
    }

    // read data to verify
    if(verify)
    {
        cout << "Verifying flash." << endl;
        if(verifyMemory(dest_start,data,n) == 0)
            cout << "Error: verify failed!" << endl;
    }

    probeRelease();
    probeHWReset();
    delete[] data;

    return 1;
}
