//
// Demonstrates using pin interrupts on the OLIMEXINO-STM32 board.
//
// Connect a jumper wire between the digital pin 0 and digital pin 3.
//
// The program sets up a rising edge interrupt on pin 0 and periodically toggles
// the led on pin 3. When the amber led is toggled from low to high an interrupt will be
// generated on pin 0 (as long as the wire is jumped from pin 3 to pin 0). At that point
// the interrupt service routine will toggle the green led.
//
// If you remove the jumper the green led should stop changing states.
//

#include <codelatch.h>

#define LED_GREEN               13      // on board green led
#define LED_AMBER               3       // on board amber led, also digital pin 3
#define MY_INTERRUPT_PIN        0       // digital pin 0 will be an input that will generate an interrupt

//---------------------------------------------------------
// this is our external pin interrupt call-back function.
// in this example we just toggle the state of the green
// led pin.
//---------------------------------------------------------
void pinInterruptCallback(void)
{
	// check if INT_IN pin caused and interrupt, if so handle it.
	if (Pin.getInterruptStatus(MY_INTERRUPT_PIN))
	{
		// if you don't clear the interrupt for this pin then
		// this function will get called repeatedly until it is cleared.
		Pin.clearInterruptStatus(MY_INTERRUPT_PIN);
		// toggle the green led indicating we handled the interrupt.
		Pin.toggle(LED_GREEN);
	}
}

int main(void)
{
	// setup pins
	Pin.mode(LED_GREEN, OUTPUT);    // output pin to drive led
	Pin.mode(LED_AMBER, OUTPUT);    // output pin to drive led
	Pin.mode(MY_INTERRUPT_PIN, INPUT | PULLUP);  // input pin with a pull-up

	// setup interrupt on INT_IN pin, can be RISING, FALLING, or BOTH.
	Pin.configureInterrupt(MY_INTERRUPT_PIN, EDGE, RISING);
	
	// set call-back function so we get notified of external interrupts.
	Pin.setInterruptCallback(&pinInterruptCallback);
	// enable the interrupt
	Pin.enableInterrupt(MY_INTERRUPT_PIN);

	while (true)
	{
        // send pin 3 low, turning off the amber led. if you configured the interrupt for 
        // FALLING or BOTH and the amber led was on this will cause the green led to change state.
		Pin.clr(LED_AMBER);
		delay(500);

        // send pin 3 high, turning on the amber led. if you configured the interrupt for 
        // RISING or BOTH and the amber led was off this will cause the green led to change state.
		Pin.set(LED_AMBER);
		delay(500);
	}
}