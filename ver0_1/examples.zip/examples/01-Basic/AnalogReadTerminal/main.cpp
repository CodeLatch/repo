//
// Read an ADC input and write the result to the Terminal.
//
#include <codelatch.h>

#define APIN             A0     				// name the pin we are using

int main(void)
{
	Pin.mode(APIN, ADC);						// make pin A0 an analog input pin
	Terminal.start();						// start the terminal

	while (true)
	{
		u32 adcVal = Pin.readAnalog(APIN);		// read the analog pin
		Terminal.printf("adc: %d\n",adcVal);		// write the value to the terminal with a line feed
		delay(200);								// delay 200 milliseconds
	}
}
