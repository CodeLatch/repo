//
// Demonstrates using PWM functionality to set brightness of LED.
//
#include <codelatch.h>

#define LED             3               // define what pin the led is connected to

int main(void)
{
	Pin.mode(LED, PWM);                 // initialize the LED pin as a PWM output

	u16 val = 0;
	s8 step = 10;
	
	while (true)
	{
		Pin.pwm(LED, val);

		val += step;
		if (val == 660)
			step = -step;
		if (val == 0)
			step = -step;

		delay(20);                     // delay 20 milliseconds
	}
}
