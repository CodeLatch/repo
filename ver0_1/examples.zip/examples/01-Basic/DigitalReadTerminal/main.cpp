//
// Read a digital pin and write the state to the Terminal.
//
#include <codelatch.h>

#define DPIN             2       	// define the pin we are using

int main(void)
{
	Pin.mode(DPIN, INPUT | PULLUP);	// make our pin an input pin with a pull-up
	Terminal.start();				// initialize the terminal

	while (true)
	{
		bool state = Pin.read(DPIN);	// read the pin state
		Terminal.println(state);		// print it to the terminal with a line feed
		delay(500);					// delay 500 milliseconds
	}
}
