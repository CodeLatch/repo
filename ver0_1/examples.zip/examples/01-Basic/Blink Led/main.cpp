//
// Blinks an LED.
//
#include <codelatch.h>

#define LED             LED1	// define what pin the led is connected to

int main(void)
{
	Pin.mode(LED, OUTPUT);		// make the pin an output to drive the led

	while (true)                    // loop forever
	{
		// one way is to use set and clr...
		Pin.set(LED);			// set the led pin high
		delay(200);				// delay 200 milliseconds
		Pin.clr(LED);			// set the led pin low
		delay(200);				// delay 200 milliseconds

		// another way is to use toggle...
		Pin.toggle(LED);            // change the state of the pin
		delay(200);				// delay 200 milliseconds
	}
}
