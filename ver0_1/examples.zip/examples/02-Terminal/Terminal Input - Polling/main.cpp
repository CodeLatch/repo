//
// Demonstrates Terminal input using polling. Receive data is kept in a fifo, so you won't
// miss incomming data unless the fifo fills up before you read it, then further data is
// ignored and lost. When you perform a Terminal read  you begin to free teh fifo.
//
// After downloading this program open the Terminal window,
// enter one of the following commands in the text entry box and press Send.
//     led on
//     led off
//     led toggle
//
#include <codelatch.h>

#define LED         3			// define the pin our led is on

int main(void)
{
	Pin.mode(LED, OUTPUT);		// setup output pin to drive led
	Terminal.start();			// start the Terminal
	delay(500);					// give usb time to enumerate

	while (true)
	{
		char rxBuffer[16];
		// read string from hid receiver if available
		Terminal.gets(rxBuffer, sizeof(rxBuffer));
		if (strcmp(rxBuffer, "led on") == 0)
			Pin.set(LED);
		else if (strcmp(rxBuffer, "led off") == 0)
			Pin.clr(LED);
		else if (strcmp(rxBuffer, "led toggle") == 0)
			Pin.toggle(LED);
	}
}
