//
// Demonstrates terminal output.
//
#include <codelatch.h>

int main(void)
{
	Terminal.start();

	// if you want to make sure the computer catches the first text output then
	// you need to delay a bit to give the computer enough time to enumerate
 	// the usb device (our microcontroller) before we start sending data.
	delay(500);
	
	// a variable to use
	u32 n = 0;

	while (true)
	{
		// to print with a line feed use Terminal.println()
		Terminal.printf("Hello, this is a line of text.\n");
		
		// to print without a line feed use Terminal.print()
		Terminal.printf("One, ");
		Terminal.printf("Two, ");
		Terminal.printf("Three and a line feed.\n");
		
		// you can print text and numbers
		Terminal.printf("n = %d\n",n);
	
		// you can specify the format of a number
		Terminal.printf("n in binary: %d\n",n);
		Terminal.printf("n in octal: %d\n",n);
		Terminal.printf("n in decimal: %d\n",n);
		Terminal.printf("n in hex: %x\n",n);
		
		// print the systick counter which updates every millisecond
		Terminal.printf("System timer count: %d\n",systicks);
		
		n++;		
		delay(1000);
	}
}
