//
// Demonstrates Terminal input using a receive interrupt callback routine.
//
// After downloading this program open the Terminal window,
// enter one of the following commands in the text entry box and press Send.
//     led on
//     led off
//     led toggle
//
#include <codelatch.h>

#define LED         3      // define the pin our led is on

// this is our hid rx callback function. it gets called
// whenever the host computer sends us a packet of data.
void hidRxCallback(void)
{
	// the Terminal Receive buffer is 64 bytes, but we don't need to copy all the bytes here.
	char rxBuffer[16];

	// get string from hid receiver if available
	Terminal.gets(rxBuffer, sizeof(rxBuffer));

	// check for commands
	if (strcmp(rxBuffer, "led on") == 0)
		Pin.set(LED);
	else if (strcmp(rxBuffer, "led off") == 0)
		Pin.clr(LED);
	else if (strcmp(rxBuffer, "led toggle") == 0)
		Pin.toggle(LED);
}

int main(void)
{
	Pin.mode(LED, OUTPUT);		// setup output pin to drive led

	// set receive callback function and start Terminal
	Terminal.setRxCallback(hidRxCallback);
	Terminal.start();
	delay(500);    				// give usb time to enumerate

	Terminal.println("send one of the following...");
	Terminal.println("   led on");
	Terminal.println("   led off");
	Terminal.println("   led toggle");
	
	while (true)
	{
		// if the pc sends us data we will generate an interrupt and call hidRxCallback,
		// otherwise, do nothing.
		delay(100);
	}
}
