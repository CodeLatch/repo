//
// Read ADC1 channel 10 on PC0 and print the value to the Terminal.
//
// PC0 is A0 on the OLIMEXINO STM32 board.
//

#include <codelatch.h>

//------------------------------------------------------------------------------
// Initialize the ADC
// notes: 
// 1) ADC clk must be <= 14MHz.
// 2) ADC clk is pclk2 /2, /4, /6, or /8.
// 3) SampleTime can be one of eight selections.
// 4) Total conversion time = SampleTime + 12.5 cycles. 
//    Minimum conversion time = 1.5 + 12.5 = 14 cycles.
// 5) For minimum error the external input impedance for the ADC must be less than
//    a specified value (see page 104 of the specification). Basic notion is a longer
//    sample time allows tolerating a larger input impedance.
//
// Example: pclk2 = 72MHz, prescaler must be /6 or /8 to get ADC clk <= 14MHz
//          at /6 ADC clk = 12MHz. With a /6 prescaler the min/max conversions are...
//			Minimum conversion time = 1.5+12.5=14 cycles = 1.167us (~857KHz)
//			Maximum conversion time = 239.5+12.5=252 cycles = 21us (~47KHz)
//------------------------------------------------------------------------------
void init_ADC()
{
	
	// enable on GPIOC
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	// set adc clock to pclk2 / 6. Can be Div2,Div4,Div6,Div8
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);
	// enable ADC1
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

	// make GPIOC bit 0 an ADC input
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_0;
	s.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &s);

	// initialize ADC1
	ADC1->CR1 &= 0xFFF0FEFF;
	ADC1->CR1 |= ADC_Mode_Independent;
	ADC1->CR2 &= 0xFFF1F7FD;
	ADC1->CR2 |= (ADC_DataAlign_Right | ADC_ExternalTrigConv_None);
	ADC1->SQR1 &= 0xFF0FFFFF;
	ADC1->SQR1 = 0;
	ADC1->CR2 |= 0x00000001;

	// Enable ADC1 reset calibration
	ADC1->CR2 |= 0x00000008;
	// wait for the end of ADC1 reset calibration
	while (ADC1->CR2 & 0x00000008);

	// Start ADC1 calibration
	ADC1->CR2 |= 0x00000004;
	// wait for the end of ADC1 calibration
	while (ADC1->CR2 & 0x00000004);

	// sample time ranges from 1.5 to 239.5 cycles in 8 different settings.
	// (adc, channel, rank, sample_time) PC0 is channel 10
	ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_28Cycles5);
}

//------------------------------------------------------------------------------
// Program entry point and main loop.
//------------------------------------------------------------------------------
int main(void)
{
	Terminal.start();
	init_ADC();

	while (true)
	{
		// start a conversion
		ADC_SoftwareStartConvCmd(ADC1, ENABLE);
		// wait for the conversion to finish
		while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
		// get the value
		u16 val = ADC_GetConversionValue(ADC1);

		Terminal.printf("adc: %d\n",val);
		
		delay(250); // delay 250 milliseconds between readings
	}
}
