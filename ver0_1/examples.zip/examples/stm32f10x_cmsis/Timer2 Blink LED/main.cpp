//
// Demonstrates using Timer2 to blink an LED.
//
// Hardware: STM32F103X, LED on PA1.
//
//

#include <codelatch.h>

// cnt is the global variable we'll use to count the number of timer interrupts that have occurred.
volatile u8 cnt = 0;

//------------------------------------------------------------------------------
// Initialize the LED on PA1.
//------------------------------------------------------------------------------
void init_LED()
{
	// enable GPIOA interface
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	// make LED pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &s);
}

//------------------------------------------------------------------------------
// Initialize Timer2 to generate an interrupt every 20ms.
//------------------------------------------------------------------------------
void init_Timer2()
{
	// enable timer2 peripheral
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	// configure timer
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1;				// set prescaler for 1MHz clock = 72MHz/72
	TIM_TimeBaseStructure.TIM_Period = 20000 - 1;				// set max count for 20ms rep rate = 20000/1MHz
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 		// can be DIV1, DIV2, or DIV4
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;	// Up or Down
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

	// set interrupt source to "timer update"
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

	// configure interrupt
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;				// timer 2 interrupt
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;	// pre-emption priority level (0..15)
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;			// subpriority level (0..15)
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	// enable timer
	TIM_Cmd(TIM2, ENABLE);
}

//------------------------------------------------------------------------------
// Timer2 interrupt handler. Toggle the LED every 200ms.
//------------------------------------------------------------------------------
void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

		// Toggle the led every 200ms. We get this interrupt every 20ms so when cnt=10 200ms has passed.
		cnt++;
		if (cnt == 10)
		{
			GPIOA->ODR ^= GPIO_Pin_1;	// toggle led
			cnt = 0;
		}
	}
}

//------------------------------------------------------------------------------
// Program entry point and main loop.
//------------------------------------------------------------------------------
int main(void)
{
	init_LED();
	init_Timer2();

	while (true)
	{
		// perform whatever normal program loop activites you have.
	}
}
