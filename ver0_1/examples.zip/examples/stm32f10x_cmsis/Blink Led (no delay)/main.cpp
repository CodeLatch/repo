//
// Blinks an LED on PA1 (D3 on Olimexino)
//
// This version of blink does not use delay statements. This has the advantage of not "wasting" processor
// time sitting idle. Instead we load a variable with the system timer plus some amount of time we want
// to pass before we want to take some action. We then periodically compare that variable to the current time.
// If the desired time has passed we reset our variable to a new time in the future, perform whatever task
// we want, and then continue polling.
//
// There are two macros defined to help simplify the code...
//
//   timerStart(variable,delta) - this will load a variable with the current millisecond count + delta.
//   timerExpired(value) - this will return true if the millisecond count is greater than the value passed.
//


#include <codelatch.h>

void init_LED()
{
	// enable GPIOA interface
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	// make LED pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&s);
}

int main(void)
{
	init_LED();
	
	uint32_t timer;
	timerStart(timer,200);
	
	while (true)
	{
		if(timerExpired(timer))
		{
			timerStart(timer,200);
			GPIOA->ODR ^= GPIO_Pin_1;	// toggle LED bit
		}
		
		// We can now take advantage of the processor to perform other tasks here. As long as
		// we keep looping through the above code periodically the led will blink. 

	}
}
