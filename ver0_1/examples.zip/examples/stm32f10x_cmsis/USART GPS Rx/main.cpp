//
// Demonstrate receiving and parsing uart data from a gps receiver. We process the GGA
// message to get position, time, and fix quality information.
//
// Hardware: STM32F103X, GPS receiver.
//
// Required Connections:
//
// connect GPS Serial Output to PA10      (PA10 is USART1_RX)
// 										  On the OLIMEXINO-STM32 board PA10 is D8.
//
// Notes:
//
// Common GPS Messages
//  $GPGGA - essential fix data - time, position, altitude, HDOP, fix quality, number of sats.
//  $GPRMC - recommended minimum data - date, position, ground speed, track angle, magnetic variation.
//  $GPVTG - velocity made good - ground speed, track angle, magnetic variation.
//  $GPGSA - DOP and active satellite PRN's.
//  $GPGSV - Satellite PRN's in view (not necessarily active).
//
//  gpsFixQuality: 0 = invalid
//                 1 = GPS fix (SPS)
//                 2 = DGPS fix
//                 3 = PPS fix
//			       4 = Real Time Kinematic
//			       5 = Float RTK
//                 6 = estimated (dead reckoning) (2.3 feature)
//			       7 = Manual input mode
//			       8 = Simulation mode
//


#include <codelatch.h>

#ifndef LED1
#define LED1 15		// LED on PA1
#endif

// variables for receiving and managing gps data
char uartrx[128];
char gpsmsg[128];	// double buffer so we don't miss data.
unsigned char uartRxIndex = 0;
volatile bool gpsMessageWaiting = false;

// gps data that we will populate
int gpsHour;
int gpsMinute;
int gpsSecond;
int gpsNumSats;
int gpsFixQuality;
double gpsLatitude;
double gpsLongitude;
double gpsHDOP;
double gpsAltitude;

//------------------------------------------------------------------------------
// Utility to aid in parsing comma seperated text into fields.
//
// *str: pointer to comma seperated text string to process.
// index: current index into the string, should be 0 to start.
// maxindex: max allowable index, typically should be the str length.
// *field: pointer to string that will hold the extracted text field.
// maxsize: the maximum size allowed for the field string.
//
// Returns: the starting index for the next field.
//------------------------------------------------------------------------------
u8 getNextField(const char *str, u8 index, u8 maxindex, char *field, u8 maxsize)
{
	u8 j = 0;
	memset(field, 0, maxsize);
	while ((index < maxindex) && (str[index] != ',') && (j < (maxsize - 1)))
		field[j++] = str[index++];
	index++; // skip seperator (comma) for next pass

	return index;
}

//------------------------------------------------------------------------------
// Convert a GPS GGA string into numeric values stored in global variables.
// note: we convert altitude to feet.
//
// Returns false if there was a problem with the conversion or a crc mismatch.
//------------------------------------------------------------------------------
bool parse_GPGGA(const char *str, u8 maxlen)
{
	bool ret = true;
	u8 i = 0;
	char field[16];

	// field 1, gps message type
	i = getNextField(str, i, maxlen, field, sizeof(field));
	// make sure this is a GPGGA message
	if (memcmp(field, "$GPGGA", 6) != 0) return false;

	// field 2, time
	i = getNextField(str, i, maxlen, field, sizeof(field));
	// minimum 6 characters HHMMSS followed by optional decimal point and fractional seconds
	gpsHour = gpsMinute = gpsSecond = 0;
	if (strlen_s(field, sizeof(field)) >= 6)
	{
		gpsHour   = (field[0] - '0') * 10 + (field[1] - '0');
		gpsMinute = (field[2] - '0') * 10 + (field[3] - '0');
		gpsSecond = (field[4] - '0') * 10 + (field[5] - '0');
	}
	else
		ret = false;

	// field 3, latitude
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 4)
	{
		u8 intPart = (field[0] - '0') * 10 + (field[1] - '0');
		double remPart = atof_s(&field[2], sizeof(field) - 2);
		gpsLatitude = (double)intPart + (remPart / 60.0);
	}
	else
		ret = false;

	// field 4, latitude reference (N,S)
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) == 1)
	{
		if (field[0] == 'S')
			gpsLatitude = -gpsLatitude;
	}
	else
		ret = false;

	// field 5, longitude
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 5)
	{
		u8 intPart = (field[0] - '0') * 100 + (field[1] - '0') * 10 + (field[2] - '0');
		double remPart = atof_s(&field[3], sizeof(field) - 3);
		gpsLongitude = (double)intPart + (remPart / 60.0);
	}
	else
		ret = false;

	// field 6, longitude reference (E,W)
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) == 1)
	{
		if (field[0] == 'W')
			gpsLongitude = -gpsLongitude;
	}
	else
		ret = false;

	// field 7, fix quality
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) == 1)
		gpsFixQuality = field[0] - '0';
	else
		ret = false;

	// field 8, number of satellites
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 1)
		gpsNumSats = atoi_s(field, sizeof(field));
	else
		ret = false;

	// field 9, horizontal dilution of position (HDOP)
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 1)
		gpsHDOP = atof_s(field, sizeof(field));
	else
		ret = false;

	// field 10, altitude
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 1)
		gpsAltitude = atof_s(field, sizeof(field));
	else
		ret = false;

	// field 11, altitude units
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) == 1)
	{
		if (field[0] == 'M')
			gpsAltitude *= 3.28084; // convert to feet
	}
	else
		ret = false;

	// field 12, mean sea level
	i = getNextField(str, i, maxlen, field, sizeof(field));

	// field 13, mean sea level units
	i = getNextField(str, i, maxlen, field, sizeof(field));

	// field 14, empty field
	i = getNextField(str, i, maxlen, field, sizeof(field));

	// field 15, checksum
	i = getNextField(str, i, maxlen, field, sizeof(field));
	u8 fieldLen = strlen_s(field, sizeof(field));
	if (fieldLen >= 3)
	{
		u8 msb = field[fieldLen - 2];

		if (msb >= 'A')
			msb = (msb - 'A') + 10;
		else
			msb = msb - '0';

		u8 lsb = field[fieldLen - 1];
		if (lsb >= 'A')
			lsb = (lsb - 'A') + 10;
		else
			lsb = lsb - '0';

		u8 crc = (msb * 16) + lsb;

		int n = strlen_s(str, maxlen);
		u8 checksum = str[1];
		for (int j = 2; j < n; j++)
		{
			if (str[j] == '*') break;
			checksum ^= str[j];
		}
		if (crc != checksum)
			ret = false;
	}
	else
		ret = false;

	return ret;
}

//------------------------------------------------------------------------------
// Serial interrupt callback routine. Processes available Serial receive characters.
// We wait for a '$' before accepting characters, then wait for a '\n'
// to store the message and set the gpsMessageWaiting flag.
//------------------------------------------------------------------------------
void serialRxCallback(void)
{
	char c;
	Serial.gets(&c, 1);

	// wait for a $ character before we start filling the message buffer.
	// all gps strings start with '$'.
	if ((uartRxIndex == 0) && (c != '$'))
		return;

	// only place printable characters in our buffer, re don't store CR or LF.
	if ((c >= ' ') && (c <= '~'))
		uartrx[uartRxIndex++] = c;

	// check for buffer overrun
	if (uartRxIndex >= sizeof(uartrx))
	{
		memset(uartrx, 0, sizeof(uartrx));
		uartRxIndex = 0;
	}
	// check for end of message, gps messages end with LF
	else if (c == '\n')
	{
		// if there is not a gps message awaiting processing then copy the message and set the flag.
		// if there is a message waiting, ie we're taking a really long time to process or ignoring
		// the last message alert, the we will drop this new message.
		if (!gpsMessageWaiting)
		{
			memcpy(gpsmsg, uartrx, sizeof(gpsmsg));
			gpsMessageWaiting = true;
			memset(uartrx, 0, sizeof(uartrx));
			uartRxIndex = 0;
		}
		else
		{
			memset(uartrx, 0, sizeof(uartrx));
			uartRxIndex = 0;
			// you could add a counter here to keep track of the number of dropped messages
			// as a performance indicator.
		}
	}
}

//------------------------------------------------------------------------------
// Program entry point and main loop.
//------------------------------------------------------------------------------
int main(void)
{
	memset(gpsmsg, 0, sizeof(gpsmsg));
	pinMode(LED1, OUTPUT);

	pinMode(D0, OUTPUT);
	pinMode(D1, OUTPUT);

	Terminal.start();
	Serial.setRxCallback(serialRxCallback);
	// start uart service running at 38.4kbps
	Serial.start(38400);

	while (1)
	{
		// check if gps message has been received
		if (gpsMessageWaiting)
		{
			Pin.toggle(LED1);
			// if the message starts with $GPGGA then parse the message into data and print it.
			if (strcmp_s(gpsmsg, "$GPGGA,") == 0)
			{
				bool ret = parse_GPGGA(gpsmsg, sizeof(gpsmsg));
				Terminal.printf("Ret:%d Time:%02d:%02d:%02d Lat:%f Long:%f Sats:%d DOP:%f Alt:%f\n",
				                ret, gpsHour, gpsMinute, gpsSecond , gpsLatitude, gpsLongitude,
				                gpsNumSats, gpsHDOP, gpsAltitude);
			}
//			else
//				Terminal.println(gpsmsg);
			gpsMessageWaiting = false;
		}
	}
}
