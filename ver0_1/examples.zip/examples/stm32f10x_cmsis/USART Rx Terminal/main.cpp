//
// Demonstrate using the USART Serial routines to transmit a message and use interrupt
// callback to process receive characters.
//
// Hardware: STM32F103X
//
// Required Connections
//
// connect PA9 to PA10   (USART1_TX to USART1_RX)
//
// On the OLIMEXINO-STM32 board PA9 is D7, PA10 is D8.
//

#include <codelatch.h>

#ifndef LED1
#define LED1 15
#endif

char gpsmsg[128];
volatile bool gpsMessageWaiting = false;
unsigned char gpsIndex = 0;

double m_GPS_Latitude;
double m_GPS_Longitude;
int m_GPS_NumSats;
double m_GPS_DOP;
double m_GPS_Altitude;
double m_GPS_rTime;

int gpsHour;
int gpsMinute;
int gpsSecond;
double gpsLatitude;
double gpsLongitude;
int gpsNumSats;
double gpsHDOP;
double gpsAltitude;
int gpsFixQuality;

//-----------------------------------------------------------------------------
// parse GPS $GPGGA string
//$GPGGA,201535,3258.2993,N,11713.2662,W,0,00,,00056.0,M,-032.7,M,,*6F			--- Etek not acquired
//$GPGGA,201536,3258.2882,N,11713.2713,W,1,04,07.0,00056.0,M,-032.7,M,,*76		--- ETek
//$GPGGA,163101.000,3258.3123,N,11713.2660,W,1,05,3.3,52.2,M,-35.4,M,,0000*5D	--- USGlobalSat
//$GPGGA,000435.004,8960.000000,N,00000.000000,E,0,0,,137.000,M,13.000,M,,*45    --- Etek not acquired

// Assumptions: we are always in North America, so we aren't going to adjust Latitude for N S + -
// Assumptions: we are always in North America, so we aren't going to adjust Longitude for E W + -
// Assumptions: we are not going East of Texas so the Longitude will always have 5 digits to the left of the decimal
//-----------------------------------------------------------------------------
u8 getNextField(const char *str, u8 index, u8 maxindex, char *field, u8 maxsize)
{
	u8 j = 0;
	memset(field, 0, maxsize);
	while ((index < maxindex) && (str[index] != ',') && (j < (maxsize - 1)))
		field[j++] = str[index++];
	index++; // skip seperator (comma) for next pass
	
	return index;
}

bool parse_GPGGA(const char *str, u8 maxlen)
{
	bool ret = true;
	u8 i = 0;
	char field[16];

	// field 1, gps message type
	i = getNextField(str, i, maxlen, field, sizeof(field));
	// make sure this is a GPGGA message
	if (memcmp(field, "$GPGGA", 6) != 0) return false;

	// field 2, time
	i = getNextField(str, i, maxlen, field, sizeof(field));
	// minimum 6 characters HHMMSS followed by options decimal point and fractional seconds
	gpsHour = gpsMinute = gpsSecond = 0;
	if (strlen_s(field, sizeof(field)) >= 6)
	{
		gpsHour   = (field[0] - '0') * 10 + (field[1] - '0');
		gpsMinute = (field[2] - '0') * 10 + (field[3] - '0');
		gpsSecond = (field[4] - '0') * 10 + (field[5] - '0');
	}
	else
		ret = false;

	// field 3, latitude
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 4)
	{
		u8 intPart = (field[0] - '0') * 10 + (field[1] - '0');
		double remPart = atof_s(&field[2], sizeof(field) - 2);
		gpsLatitude = (double)intPart + (remPart / 60.0);
	}
	else
		ret = false;

	// field 4, latitude reference (N,S)
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if(strlen_s(field,sizeof(field)) == 1)
	{
		if(field[0] == 'S')
			gpsLatitude = -gpsLatitude;
	}
	else
		ret = false;

	// field 5, longitude
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 5)
	{
		u8 intPart = (field[0] - '0') * 100 + (field[1] - '0') * 10 + (field[2] - '0');
		double remPart = atof_s(&field[3], sizeof(field) - 3);
		gpsLongitude = (double)intPart + (remPart / 60.0);
	}
	else
		ret = false;

	// field 6, longitude reference (E,W)
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if(strlen_s(field,sizeof(field)) == 1)
	{
		if(field[0] == 'W')
			gpsLongitude = -gpsLongitude;
	}
	else
		ret = false;

	// field 7, fix quality
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) == 1)
		gpsFixQuality = field[0] - '0';
	else
		ret = false;

	// field 8, number of satellites
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 1)
		gpsNumSats = atoi_s(field, sizeof(field));
	else
		ret = false;

	// field 9, horizontal dilution of position (HDOP)
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 1)
		gpsHDOP = atof_s(field, sizeof(field));
	else
		ret = false;

	// field 10, altitude
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if (strlen_s(field, sizeof(field)) >= 1)
		gpsAltitude = atof_s(field, sizeof(field));
	else
		ret = false;

	// field 11, altitude units
	i = getNextField(str, i, maxlen, field, sizeof(field));
	if(strlen_s(field,sizeof(field)) == 1)
	{
		if(field[0] == 'M')
			gpsAltitude *= 3.28084; // convert to feet
	}
	else
		ret = false;
		
	// field 12, mean sea level
	i = getNextField(str, i, maxlen, field, sizeof(field));

	// field 13, mean sea level units
	i = getNextField(str, i, maxlen, field, sizeof(field));

	// field 14, empty field
	i = getNextField(str, i, maxlen, field, sizeof(field));

	// field 15, checksum
	i = getNextField(str, i, maxlen, field, sizeof(field));
	u8 fieldLen = strlen_s(field, sizeof(field));
	if (fieldLen >= 3)
	{
		u8 msb = field[fieldLen - 2];
		
		if (msb >= 'A')
			msb = (msb - 'A') + 10;
		else
			msb = msb - '0';
			
		u8 lsb = field[fieldLen - 1];
		if (lsb >= 'A')
			lsb = (lsb - 'A') + 10;
		else
			lsb = lsb - '0';
		
		u8 crc = (msb * 16) + lsb;

		int n = strlen_s(str,maxlen);
		u8 checksum = str[1];
		for (int j = 2; j < n; j++)
		{
			if(str[j] == '*') break;
			checksum ^= str[j];
		}
		if(crc != checksum)
			ret = false;
	}
	else
		ret = false;

//return true;
	return ret;
}
/*
bool parseGPGGA_old()
{
	// we want 10 fields of info to fill in the 6 numbers we want
	char chksum;
	char chkstr[4];
	char str_time[11];
	char str_lat[15];
	char str_long[15];
	char str_tmp[15];
	char c_latDir;
	char c_longDir;
	char str_numSats[3];
	char str_dilution[6];
	char str_alt[15];
	unsigned char i, n;
	const char *str = (const char*) gpsmsg;

	// get string length
	n = strlen_s(str, sizeof(gpsmsg));
	if (n >= sizeof(gpsmsg))
		return false;

	//validate checksum
	chksum = str[1];
	for (i = 2; i < (n - 5); i++)
		chksum ^= str[i];
	sprintf(chkstr, 4, "%02X", chksum);
	// see if the checksums match
	if ((chkstr[0] != str[n - 2]) && (chkstr[1] != str[n - 1]))
		return false;

	// init fields
	memset(str_time, 0, 11);
	memset(str_lat, 0, 15);
	memset(str_long, 0, 15);
	memset(str_numSats, 0, 3);
	memset(str_dilution, 0, 6);
	memset(str_alt, 0, 15);

	// read in the fields
	i = 7;
	// time
	n = 0;
	while ((str[i] != ',') && (i < sizeof(gpsmsg)))
		str_time[n++] = str[i++];
	if (i >= sizeof(gpsmsg)) return false;

	i++;
	// latitude
	n = 0;
	while ((str[i] != ',') && (i < sizeof(gpsmsg)))
		str_lat[n++] = str[i++];
	if (i >= sizeof(gpsmsg)) return false;

	i++;
	c_latDir = str[i++];

	i++;
	// longitude
	n = 0;
	while ((str[i] != ',') && (i < sizeof(gpsmsg)))
		str_long[n++] = str[i++];
	if (i >= sizeof(gpsmsg)) return false;

	i++;
	c_longDir = str[i++];

	// skip fix quality
	i += 3;
	// number of satellites
	n = 0;
	while ((str[i] != ',') && (i < sizeof(gpsmsg)))
		str_numSats[n++] = str[i++];
	if (i >= sizeof(gpsmsg)) return false;

	i++;
	// DOP
	n = 0;
	while ((str[i] != ',') && (i < sizeof(gpsmsg)))
		str_dilution[n++] = str[i++];
	if (i >= sizeof(gpsmsg)) return false;

	i++;
	// altitude
	n = 0;
	while ((str[i] != ',') && (i < sizeof(gpsmsg)))
		str_alt[n++] = str[i++];
	if (i >= sizeof(gpsmsg)) return false;

	// convert strings to numbers
	str_tmp[0] = str_lat[0];
	str_tmp[1] = str_lat[1];
	str_tmp[2] = 0;
	m_GPS_Latitude = atof_s(str_tmp, 15);
	strcpy_s(str_tmp, 15, str_lat + 2);
	m_GPS_Latitude = m_GPS_Latitude + (atof_s(str_tmp, 15) / 60.0);

	str_tmp[0] = str_long[0];
	str_tmp[1] = str_long[1];
	str_tmp[2] = str_long[2];
	str_tmp[3] = 0;
	m_GPS_Longitude = -atof_s(str_tmp, 15);
	strcpy_s(str_tmp, 15, str_long + 3);
	m_GPS_Longitude = m_GPS_Longitude + (-atof_s(str_tmp, 15) / 60.0);

	m_GPS_NumSats = atoi_s(str_numSats, 3);
	m_GPS_DOP = atof_s(str_dilution, 6);
	m_GPS_Altitude = atof_s(str_alt, 15) * 3.2808399; // convert to feet
	m_GPS_rTime = (int)atof_s(str_time, 11);

	return true;
}
*/
//------------------------------------------------------------------------------
// Interrupt callback routine. Process available Serial receive characters.
//------------------------------------------------------------------------------
void serialRxCallback(void)
{
	char c;
	Serial.gets(&c, 1);

	if (gpsMessageWaiting)
		return;

	if ((c >= ' ') && (c <= '~'))
		gpsmsg[gpsIndex++] = c;

	if (gpsIndex >= sizeof(gpsmsg))
	{
		// overrun
		memset(gpsmsg, 0, sizeof(gpsmsg));
		gpsIndex = 0;
	}
	else if (c == '\n')
	{
		if (memcmp(gpsmsg, "$GPGGA,", 7) == 0)
			gpsMessageWaiting = true;
		else
		{
			memset(gpsmsg, 0, sizeof(gpsmsg));
			gpsIndex = 0;
		}
	}
}




// gps strings terminate with 13, 10
//------------------------------------------------------------------------------
// Program entry point and main loop.
//------------------------------------------------------------------------------
int main(void)
{
	memset(gpsmsg, 0, sizeof(gpsmsg));
	pinMode(LED1, OUTPUT);

	Terminal.start();
	//	delay(3000);
	Serial.setRxCallback(serialRxCallback);
	Serial.start(38400);

	while (1)
	{
		if (gpsMessageWaiting)
		{
			Pin.toggle(LED1);
			Terminal.println(gpsmsg);
			if (parse_GPGGA(gpsmsg, sizeof(gpsmsg)))
			{
				Terminal.printf("Time:%d:%d:%d Lat:%f Long:%f Sats:%d DOP:%f Alt:%f\n",
				                gpsHour, gpsMinute, gpsSecond , gpsLatitude, gpsLongitude,
				                gpsNumSats, gpsHDOP, gpsAltitude);
			}
			else
				Terminal.printf("ERROR: Time:%d:%d:%d Lat:%f Long:%f Sats:%d DOP:%f Alt:%f\n",
				                gpsHour, gpsMinute, gpsSecond , gpsLatitude, gpsLongitude,
				                gpsNumSats, gpsHDOP, gpsAltitude);
			memset(gpsmsg, 0, sizeof(gpsmsg));
			gpsIndex = 0;
			gpsMessageWaiting = false;
		}
	}
}
