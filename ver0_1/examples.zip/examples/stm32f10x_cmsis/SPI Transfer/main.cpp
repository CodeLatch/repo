//
// SPI (Serial Peripheral Bus) example. Transfers data between SPI1 and SPI2 every 100ms. 
// Uses SPI1 as the master and SPI2 as the slave. Toggles a LED on PA1 everytime
// a successfull transfer occurs.
//
// Hardware: STM32F103x
// 
// Required Connections:
// 		Connect jumper wires between the following pins...
// 		PA5 -> PB13		(D13 to D32 on Olimexino)
// 		PA6 -> PB14		(D12 to D33 on Olimexino)
// 		PA7 -> PB15		(D11 to D34 on Olimexino)
//
// Reference:
// 		Signal      SPI1		SPI2
// 		----------------------------
// 		SCK			PA5		PB13
// 		MISO			PA6		PB14
// 		MOSI			PA7		PB15
//


#include <codelatch.h>

uint8_t SPI1_Buffer_Tx[] = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06,
                             0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12,
                             0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E,
                             0x1F, 0x20
                           };
uint8_t SPI2_Buffer_Tx[] = { 0x51, 0x52, 0x53, 0x54, 0x55, 0x56,
                             0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F, 0x60, 0x61, 0x62,
                             0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E,
                             0x6F, 0x70
                           };
                           
#define NUM_BYTES sizeof(SPI1_Buffer_Tx)

uint8_t SPI1_Buffer_Rx[NUM_BYTES];
uint8_t SPI2_Buffer_Rx[NUM_BYTES];


//------------------------------------------------------------------------------
// Initialize SPI1 as master and SPI2 as slave.
//------------------------------------------------------------------------------
void init_SPI(void)
{
	// enable interfaces
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_SPI1, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);

	// configure SPI1 pins SCK (PA5), MISO (PA6), MOSI (PA7)
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// configure SPI2 pins SCK (PB13), MISO (PB14), MOSI (PB15)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// general SPI configuration
	SPI_InitTypeDef SPI_InitStructure;
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;	// full duplex
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;					// 8 bit data size
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;							// CPOL = 0
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;							// CPHA = 1
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;							// software controlled chip select
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4; 	// 72MHz/4 = 18Mbps
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_LSB;					// send lsb first
	SPI_InitStructure.SPI_CRCPolynomial = 7;

	// SPI1 as the master
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_Init(SPI1, &SPI_InitStructure);

	// SPI2 as the slave
	SPI_InitStructure.SPI_Mode = SPI_Mode_Slave;
	SPI_Init(SPI2, &SPI_InitStructure);

	// Enable SPI1 and SPI2
	SPI_Cmd(SPI1, ENABLE);
	SPI_Cmd(SPI2, ENABLE);
}

//------------------------------------------------------------------------------
// Initialize the LED on PA1.
//------------------------------------------------------------------------------
void init_LED()
{
	// enable GPIOA interface for LED
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	// make LED pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &s);
}

//------------------------------------------------------------------------------
// Run the spi test.
//------------------------------------------------------------------------------
void runTest()
{
	uint8_t i = 0;
	uint32_t timeout;

	// transfer data one byte at a time until done
	while (i < NUM_BYTES)
	{
		// Wait for SPI1 Tx buffer empty
		while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);

		// Load SPI2 with data. SPI2 is configured as the slave so data is
		// loaded but not actually sent until the master (SPI1) clocks the data out.
		SPI_I2S_SendData(SPI2, SPI2_Buffer_Tx[i]);

		// Send SPI1 data. Load and clock out SPI1 data and consequentially SPI2 data.
		SPI_I2S_SendData(SPI1, SPI1_Buffer_Tx[i]);

		// Wait for SPI2 data reception
		timeout = 0xfff;
		while ((SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET) && (timeout != 0))
			timeout--;

		// Read SPI2 received data
		SPI2_Buffer_Rx[i] = SPI_I2S_ReceiveData(SPI2);

		// Wait for SPI1 data reception
		timeout = 0xfff;
		while ((SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET) && (timeout != 0))
			timeout--;

		// Read SPI1 received data
		SPI1_Buffer_Rx[i] = SPI_I2S_ReceiveData(SPI1);
		
		i++;
	}

	// compare the received data with the transmitted data
	int cmp1 = memcmp(SPI2_Buffer_Rx, SPI1_Buffer_Tx, NUM_BYTES);
	int cmp2 = memcmp(SPI1_Buffer_Rx, SPI2_Buffer_Tx, NUM_BYTES);

	// if the data matches toggle the LED on PA1.
	if ((cmp1 == 0) && (cmp2 == 0))
		GPIOA->ODR ^= GPIO_Pin_1;
}

//------------------------------------------------------------------------------
// Program entry point and main loop.
//------------------------------------------------------------------------------
int main(void)
{
	init_SPI();
	init_LED();

	while (1)
	{
		runTest();
		delay(100);
	}
}
