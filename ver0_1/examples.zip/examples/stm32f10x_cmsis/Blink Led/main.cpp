//
// Blinks an LED on PA1 (D3 on Olimexino)
//
#include <codelatch.h>

void init_LED()
{
	// enable GPIOA interface
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	// make LED pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&s);
}

int main(void)
{
	init_LED();
	
	while (true)
	{
		GPIOA->BSRR = GPIO_Pin_1;	// set bit, turn led on
		delay(200);					// delay 200 milliseconds
		GPIOA->BRR = GPIO_Pin_1;		// clear bit, turn led off
		delay(200);					// delay 200 milliseconds
		
		// an alternate way to blink and led...
		// GPIOA->ODR ^= GPIO_Pin_1;	// toggle bit (change state on/off)
		// delay(200);					// delay 200 milliseconds
	}
}
