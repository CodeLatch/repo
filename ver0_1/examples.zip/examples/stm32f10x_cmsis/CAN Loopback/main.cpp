//
// Loopback test of CAN (Controller Area Network) interface.
//
// Configures the CAN1 interface to operate in loopback mode. Sends a message every 100ms.
// If the message is received and matches what was sent an LED on GPIOA pin 1 is toggled.
// Utilizes CAN1_RX1_IRQHandler receive interrupt handler.
//
// Hardware: STM32F103X with LED on PA1.

#include <codelatch.h>

//------------------------------------------------------------------------------
// Initialize CAN1 in loopback mode using FIFO1/RX1 with receive interrupt
// enabled.
//------------------------------------------------------------------------------
void init_CAN1_FIFO1()
{
	CAN_InitTypeDef CAN_InitStructure;
	CAN_FilterInitTypeDef CAN_FilterInitStructure;

	// enable GPIOB, GPIOC, and AFIO and CAN1
    	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

	// CAN register init
	CAN_DeInit(CAN1);
	CAN_StructInit(&CAN_InitStructure);    

    CAN_InitStructure.CAN_TTCM = DISABLE;			// time triggered communication
    CAN_InitStructure.CAN_ABOM = DISABLE;			// automatic bus off management
    CAN_InitStructure.CAN_AWUM = DISABLE;			// automatic wake up
  	CAN_InitStructure.CAN_NART = ENABLE;				// no automatic retransmission
    CAN_InitStructure.CAN_RFLM = DISABLE;			// receive fifo locked mode
    CAN_InitStructure.CAN_TXFP = ENABLE;				// transmit fifo priority
    CAN_InitStructure.CAN_Mode = CAN_Mode_LoopBack;	// *** operating mode is LOOPBACK ***
	CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;			// max bit time quanta change for re-sync
	CAN_InitStructure.CAN_BS1 = CAN_BS1_3tq;			// time quanta in bit segment 1
	CAN_InitStructure.CAN_BS2 = CAN_BS2_2tq;			// time quanta in bit segment 2
	CAN_InitStructure.CAN_Prescaler = 6;				// length of time quanta (1..1024)
    CAN_Init(CAN1, &CAN_InitStructure);

	// CAN filter init
    CAN_FilterInitStructure.CAN_FilterNumber=1;
    CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;
    CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;
    CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;
    CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
    CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;
    CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
    CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_FIFO1;
    CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;
    CAN_FilterInit(&CAN_FilterInitStructure);

	// CAN FIFO1 message pending interrupt enable
	CAN_ITConfig(CAN1, CAN_IT_FMP1, ENABLE);

	// enable CAN1 RX1 interrupt
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

//------------------------------------------------------------------------------
// Initialize the LED on PA1.
//------------------------------------------------------------------------------
void initLED()
{
	// enable GPIOA interface for LED
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	// make LED pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &s);
}

//------------------------------------------------------------------------------
// Send a message.
//------------------------------------------------------------------------------
void sendCAN1Message()
{
	CanTxMsg TxMessage;
	
	// create a message
	TxMessage.StdId = 0x0;			// standard identifier 0..0x7ff
	TxMessage.ExtId = 0x1234;		// extended identifier 0..0x1fffffff
	TxMessage.IDE = CAN_ID_EXT;		// message identifier type CAN_ID_STD or CAN_ID_EXT
	TxMessage.RTR = CAN_RTR_DATA;	// message frame type CAN_RTR_DATA or CAN_RTR_REMOTE
	TxMessage.DLC = 2;				// number of data bytes (0..8)
	// up to 8 bytes of data [0..7] as specified by DLC register.
	TxMessage.Data[0] = 0xAB;
	TxMessage.Data[1] = 0xCD;

	// send the message
	CAN_Transmit(CAN1, &TxMessage);
}

//------------------------------------------------------------------------------
// Validate the receive message.
//------------------------------------------------------------------------------
void validateRxMessage(CanRxMsg *msg)
{
	if ((msg->ExtId == 0x1234) &&
	        (msg->IDE == CAN_ID_EXT) &&
	        (msg->DLC == 2) &&
	        (msg->Data[0] == 0xAB) &&
	        (msg->Data[1] == 0xCD))
	{
		// if the message is what we expected toggle the LED on PA1.
		GPIOA->ODR ^= GPIO_Pin_1;
	}
}

//------------------------------------------------------------------------------
// CAN1 RX1 interrupt handler. 
//------------------------------------------------------------------------------
void CAN1_RX1_IRQHandler(void)
{
	// clear msg structure, we are only sending 2 bytes of data, so only clear those.
	// you can send up to 8 bytes of data.
	CanRxMsg msg;
	msg.StdId = 0x00;
	msg.ExtId = 0x00;
	msg.IDE = 0;
	msg.DLC = 0;
	msg.FMI = 0;
	msg.Data[0] = 0x00;
	msg.Data[1] = 0x00;

	// get the receive message
	CAN_Receive(CAN1, CAN_FIFO1, &msg);
	// validate the message
	validateRxMessage(&msg);
}

//------------------------------------------------------------------------------
// Program entry point and main loop.
//------------------------------------------------------------------------------
int main(void)
{
	initLED();
	init_CAN1_FIFO1();

	// transmit a message every 100 milliseconds.
	while (1)
	{
		sendCAN1Message();
		delay(100);
	}

}
