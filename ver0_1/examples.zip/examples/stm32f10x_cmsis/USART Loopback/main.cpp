//
// Loopback test of USART1 interface.
//
// Configures the USART1 to transmit and receive. Processes receive characters via
// USART1 receive interrupt routine. The main loop sends a string every 200ms. If the
// Interrupt routine receives the expected string it toggles the LED.
//
// Hardware: STM32F103X, LED on PA1.
//
// Required Connections
//
// connect PA9 to PA10   (USART1_TX to USART1_RX)
// 
// On the OLIMEXINO-STM32 board PA9 is D7, PA10 is D8.
//

#include <codelatch.h>

const char txMsg[] = "Hello World!";
const char expectedMsg[] = "Hello World!";
char rxBuf[16] = {'\0'};
unsigned int rxBufIndex = 0;

//------------------------------------------------------------------------------
// Initialize the USART1 and use PA9 for Tx, PA10 for RX.
//------------------------------------------------------------------------------
void init_USART1(void)
{
	// enable USART1 and GPIOA clocks
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);

	// configure USART1
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1, &USART_InitStructure);

	// enable USART1
	USART_Cmd(USART1, ENABLE);

	// enable USART1 receive interrupt
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

	// configure gpio pins for usart operation
	GPIO_InitTypeDef GPIO_InitStructure;
	// USART1 Tx on PA9
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	// USART1 Rx on PA10
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

//------------------------------------------------------------------------------
// Initialize the LED on PA1.
//------------------------------------------------------------------------------
void init_LED()
{
	// enable GPIOA interface
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	// make LED pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &s);
}

//------------------------------------------------------------------------------
// Send a character string.
//------------------------------------------------------------------------------
void UARTSend(const char *data, int cnt)
{
	for (int i = 0; i < cnt; i++)
	{
		USART_SendData(USART1, (uint16_t) *data++);
		// loop while tx is busy
		while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET)
		{
		}
	}
}

//------------------------------------------------------------------------------
// Process received message to see if it matches what we expect to get. If it
// does then toggle the LED.
//------------------------------------------------------------------------------
void processRxMsg()
{
	unsigned int n = sizeof(expectedMsg);
	for (unsigned int i = 0; i < n; i++)
	{
		if (rxBuf[i] != expectedMsg[i])
			return;
	}
	// message matched, toggle led
	GPIOA->ODR ^= GPIO_Pin_1;
}

//------------------------------------------------------------------------------
// USART1 interrupt handler. Called when we receive a character on USART1.
//------------------------------------------------------------------------------
void USART1_IRQHandler(void)
{
	// if we received a character process it
	if ((USART1->SR & USART_FLAG_RXNE) != (u16)RESET)
	{
		// get the character
		char c = (char) USART_ReceiveData(USART1);
		// if it's a terminating null character process the message.
		if (c == '\0')
		{
			processRxMsg();
			memset(rxBuf, 0, sizeof(rxBuf));
			rxBufIndex = 0;
		}
		// othwise, append it to the buffer.
		else
		{
			// if the buffer is full then clear it out and reset the index.
			if (rxBufIndex >= sizeof(rxBuf))
			{
				memset(rxBuf, 0, sizeof(rxBuf));
				rxBufIndex = 0;
			}
			rxBuf[rxBufIndex++] = c;
		}
	}
}

//------------------------------------------------------------------------------
// Program entry point and main loop.
//------------------------------------------------------------------------------
int main(void)
{
	init_LED();
	init_USART1();

	while (1)
	{
		// note: Because we are using sizeof on a const char string we will include
		// the null termination character in our count. We expect the null character
		// be sent to determine the end of the string in our USART1_IRQHandler routine.
		// If you are dealing with variable length strings stored in a buffer you
		// use want to use strlen(txMsg)+1 instead of sizeof(txMsg).
		UARTSend(txMsg, sizeof(txMsg));
		delay(200);
	}
}


