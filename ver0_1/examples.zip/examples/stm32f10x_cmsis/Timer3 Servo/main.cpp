//
// Demonstrates using Timer3 to control three servos syncronously, ie servo pulses all start
// at the same time.
//
// D6 PA8  TIM1_CH1
// D7 PA9  TIM1_CH2
// D8 PA10 TIM1_CH3
// 1ms to 2ms high time, 20ms repetition rate.

#include <codelatch.h>

volatile u16 servo[3] = { 0, 0, 0}; // 0..1000us

void TIM1_UP_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);

		// 1000us + 0..2000us 10us per degree
		TIM1->CCR1 = 1000 + servo[0];
		TIM1->CCR2 = 1000 + servo[1];
		TIM1->CCR3 = 1000 + servo[2];
	}
}

void init_GPIO(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void init_Timer1(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

	// default configure TIM1
	TIM_DeInit(TIM1);
	
	// configure timer
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1;				// 72 MHz / 72 = 1 MHz
	TIM_TimeBaseStructure.TIM_Period = 20000 - 1;				// 1 MHz / 20000 = 50 Hz (20 ms)
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

	// configure pwm outputs
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_Pulse = 1500;						// 1500 us - mid scale

	TIM_OC1Init(TIM1, &TIM_OCInitStructure);    // Channel 1 configuration = PC.06 TIM3_CH1
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);    // Channel 2 configuration = PC.07 TIM3_CH2
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);    // Channel 3 configuration = PC.08 TIM3_CH3

	// configure interrupt
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;			// timer 1 "update" interrupt
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;	// pre-emption priority level (0..15)
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;			// subpriority level (0..15)
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	// turn on PWM outputs
	TIM_CtrlPWMOutputs(TIM1, ENABLE);
	// enable TIM1 update interrupt
	TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
	// enable TIM1
	TIM_Cmd(TIM1, ENABLE);
}

int main(void)
{	
	init_GPIO();
	init_Timer1();

	int i = 2;
	while (1)
	{
		// sweep servo[0]
		servo[0] += i;	
		if(servo[0] > 2000) i = -i;
		if(servo[0] < 0) i = -i;
		
		delay(5);
	}
}