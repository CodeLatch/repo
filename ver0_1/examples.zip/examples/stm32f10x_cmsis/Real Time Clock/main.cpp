//
// Demonstrates using the Real Time Clock (RTC). The clock stays operational as long as
// Vdd or Vbat are present. Prints out the time to the Terminal and blinks an led
// once per second.
//
// If power is totally disconnected and then Vdd is applied the clock needs to
// be initialized with the current time. This is done in the initializeTime() routine
// which in this example sets an arbitrary time of 00:00:00.
//
// Hardware: STM32F103X, LED on PA1, 32.768KHz xtal on OSC32 pins.


#include <codelatch.h>

// defining this will cause RTCCLK/64 (512Hz) to be output on PC13
#define RTCClockOutput_Enable
// flag to tell the main loop to print the time.
volatile bool updateFlag = false;

//------------------------------------------------------------------------------
// RTC interrupt handler, set up to interrupt once per second.
//------------------------------------------------------------------------------
void RTC_IRQHandler(void)
{
	if (RTC_GetITStatus(RTC_IT_SEC) != RESET)
	{
		RTC_ClearITPendingBit(RTC_IT_SEC);	// clear pending interrupt bit
		GPIOA->ODR ^= GPIO_Pin_1;			// toggle led
		updateFlag = true;					// set flag for main loop
		RTC_WaitForLastTask();				// wait for RTC write operations to finish
	}
}

//------------------------------------------------------------------------------
// Sets the time when the RTC has not yet been set. This is where you
// may want to add some smarts/user interface to have the user set the
// initial time, or get the time from the internet or something.
//------------------------------------------------------------------------------
void initializeTime(void)
{
	uint32_t hour, minute, second, time;

	// for this example an arbitrary start up time of 0.
	hour = 0;
	minute = 0;
	second = 0;

	time = hour * 3600 + minute * 60 + second;

	RTC_WaitForLastTask();
	RTC_SetCounter(time);
	RTC_WaitForLastTask();
}

//------------------------------------------------------------------------------
// Initialize RTC. Setup up RTC and interrupt.
//------------------------------------------------------------------------------
void init_RTC(void)
{
	// configure RTC interrupt
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	// check if we have already initialized everything by using the backup register BKP_DR1.
	// note: There are 42 16-bit backup registers you can use. They stay alive as long as power
	// (Vbat or Vdd) is applied.
	if (BKP_ReadBackupRegister(BKP_DR1) != 0xA5A5)
	{
		// cold start, need to initialize everything.
		Terminal.printf("Configuring RTC.\n");
		// enable RTC and backup peripherals
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
		PWR_BackupAccessCmd(ENABLE);
		BKP_DeInit();
		RCC_LSEConfig(RCC_LSE_ON);
		while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)	{}
		// setup RTC and enable one second interrupt
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
		RCC_RTCCLKCmd(ENABLE);
		RTC_WaitForSynchro();
		RTC_WaitForLastTask();
		RTC_ITConfig(RTC_IT_SEC, ENABLE);
		RTC_WaitForLastTask();
		RTC_SetPrescaler(32767); // set interrupt period = RTCCLK/RTC_PR = (32.768 KHz)/(32767+1)
		RTC_WaitForLastTask();
		// dead start power up so we need to set the current time.
		initializeTime();
		// write to backup register 1 our key indicating RTC has been configured,
		// this value will stay as long as power is not removed.
		BKP_WriteBackupRegister(BKP_DR1, 0xA5A5);
	}
	else
	{
		// warm start, don't need to initialize.

		// check for Power On Reset
		if (RCC_GetFlagStatus(RCC_FLAG_PORRST) != RESET)
			Terminal.printf("Power On Reset occurred.\n");

		// check for Pin Reset
		else if (RCC_GetFlagStatus(RCC_FLAG_PINRST) != RESET)
			Terminal.printf("External Reset occurred.\n");

		Terminal.printf("RTC already configured.\n");
		RTC_WaitForSynchro();				// wait for synchonization
		RTC_ITConfig(RTC_IT_SEC, ENABLE);	// enable RTC interrupt
		RTC_WaitForLastTask();				// wait for tasks to complete
	}

#ifdef RTCClockOutput_Enable
	// Enable PWR and BKP clocks
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
	// Allow access to BKP Domain
	PWR_BackupAccessCmd(ENABLE);
	// To output RTCCLK/64 on Tamper pin the tamper functionality must be disabled
	BKP_TamperPinCmd(DISABLE);
	// Enable RTC Clock Output on Tamper Pin
	BKP_RTCOutputConfig(BKP_RTCOutputSource_CalibClock);
#endif

	RCC_ClearFlag();
}

//------------------------------------------------------------------------------
// Initialize the LED. We'll toggle it once per second in via the RTC_IRQHandler.
//------------------------------------------------------------------------------
void init_LED(void)
{
	// enable GPIOA interface
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	// make LED pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &s);
}

//------------------------------------------------------------------------------
// Print the time to the terminal, deal with time roll-over.
//------------------------------------------------------------------------------
void printTime(uint32_t TimeVar)
{
	uint32_t hour, minute, second;

	// Reset RTC Counter when Time is 23:59:59
	if (RTC_GetCounter() == 0x0001517F)
	{
		RTC_SetCounter(0);
		RTC_WaitForLastTask();
	}

	hour = TimeVar / 3600;
	minute = (TimeVar % 3600) / 60;
	second = (TimeVar % 3600) % 60;

	Terminal.printf("Time: %d:%02d:%02d\n", hour, minute, second);
}

//------------------------------------------------------------------------------
// Program entry point and main program loop.
//------------------------------------------------------------------------------
int main(void)
{
	Terminal.start();
	delay(3000);			// give usb time to enumerate so we don't miss any printf's

	init_LED();
	init_RTC();

	while (1)
	{
		if (updateFlag) // gets set once per second by RTC_IRQHandler
		{
			printTime(RTC_GetCounter());
			updateFlag = false;
		}
	}
}
