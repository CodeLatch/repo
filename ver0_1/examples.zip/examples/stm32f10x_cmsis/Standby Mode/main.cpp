//
// Demonstrates entering and exiting a low power state (standby).
//
// Wait for PA3 to be pulled low by the user, then enter standby mode
// for 5 seconds or until WKUP (PA0) is pulled high by the user. Store
// and restore a variable to demonstrate using the backup registers.
//
// Hardware: STM32F103x with 32.768KHz real time clock crystal.
//
// Signal	Olimexino Location		Usage
// --------------------------------------------------------------
// PA3 		D0						Enter standby when pulled low
// PA0		D2						Exit standby when pulled high
// PA1		LED1
// PA5		LED2
//

#include <codelatch.h>

// we will use cnt to demonstrate store/restore of variables
uint8_t cnt = 0;

//------------------------------------------------------------------------------
// Save important variables to the backup registers.
//------------------------------------------------------------------------------
void saveState()
{
	// When we enter standby mode data in ram will be lost.
	// So if there is data we want to save we need to store it in the backup registers before
	// we enter standby mode. We can then restore the values when we come out of standby.
	// There are 42 16-bit backup data registers we can use (BKP_DR1..BKP_DR42). The backup
	// registers stay valid as long as power is applied to the microcontroller.

	// save the variable cnt
	BKP_WriteBackupRegister(BKP_DR1, cnt);
}

//------------------------------------------------------------------------------
// Restore important variables from the backup registers.
//------------------------------------------------------------------------------
void restoreState()
{
	// restore the variable cnt
	cnt = BKP_ReadBackupRegister(BKP_DR1);
}

//------------------------------------------------------------------------------
// Initialize the Real Time Clock. We will use this to generate an alarm that
// will wake us up from standby after five seconds has passed.
//------------------------------------------------------------------------------
void init_RTC(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
	PWR_BackupAccessCmd(ENABLE);

	// check standby flag
	if (PWR_GetFlagStatus(PWR_FLAG_SB) != RESET)
	{
		// we resumed from standby mode, RTC configuration is maintained.
		PWR_ClearFlag(PWR_FLAG_SB);
		RTC_WaitForSynchro();
		// however, ram was lost so restore data that we saved.
		restoreState();
	}
	else
	{
		// cold start, need to perform RTC configuration.
		BKP_DeInit();
		RCC_LSEConfig(RCC_LSE_ON);
		while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET) {}
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);		// Select the RTC Clock Source
		RCC_RTCCLKCmd(ENABLE);						// Enable the RTC Clock
		RTC_WaitForSynchro();						// Wait for RTC APB registers synchronisation
		RTC_SetPrescaler(32767);						// Set the RTC time base to 1s
		RTC_WaitForLastTask();						// Wait for write operations to finish
	}
}

//------------------------------------------------------------------------------
// Initialize the LED gpio's.
//------------------------------------------------------------------------------
void init_LED()
{
	// enable GPIOA interface
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	// make LED1 pin an output
	GPIO_InitTypeDef s;
	s.GPIO_Pin = GPIO_Pin_1;
	s.GPIO_Mode = GPIO_Mode_Out_PP;
	s.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &s);

	// make LED2 pin an output
	s.GPIO_Pin = GPIO_Pin_5;
	GPIO_Init(GPIOA, &s);
}

//------------------------------------------------------------------------------
// Run the standby test.
//------------------------------------------------------------------------------
void standbyTest(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
	PWR_BackupAccessCmd(ENABLE);

	// setup input pin on PA3 to signal us to enter standby when pulled low
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// enable WKUP pin functionality (PA0) (D2 on Olimexino)
	PWR_WakeUpPinCmd(ENABLE);

	uint32_t timer;
	timerStart(timer, 200);
	
	while (1)
	{
		// periodically blink the led
		if (timerExpired(timer))
		{
			timerStart(timer, 200);
			GPIOA->ODR ^= GPIO_Pin_1; // toggle LED1
			GPIOA->ODR ^= GPIO_Pin_5; // toggle LED2
		}

		// look to see if PA3 has been pulled low, if so enter standby
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == Bit_RESET)
		{
			// wait for RTC second update
			RTC_ClearFlag(RTC_FLAG_SEC);
			while (RTC_GetFlagStatus(RTC_FLAG_SEC) == RESET);

			// set the RTC Alarm to wake us up in 5 seconds
			RTC_SetAlarm(RTC_GetCounter() + 5);
			RTC_WaitForLastTask(); // wait for last RTC write operation to complete

			// save important variable values
			cnt++;
			saveState();

			// enter standby mode
			PWR_EnterSTANDBYMode();

			// we will never get here, when we wake up from standby we will start in main()
			// as if we experienced a reset, however we can check a flag to see why we
			// are starting in main(). We check the flag in the init_RTC routine.
		}
	}
}

//------------------------------------------------------------------------------
// Program entry point and main program loop.
//------------------------------------------------------------------------------
int main(void)
{
	init_LED();
	init_RTC();

	// To demonstrate how we can save and restore important data using the backup registers during
	// standby mode, we toggle LED2 an extra time every other time through the main routine.
	// This will cause LED1 and LED2 to blink together or alternate depending on how many
	// times we have run through the main loop due to returning from standby. In this example
	// we are saving and restoring the variable "cnt", which is incremented and stored each time before
	// we enter standby.
	if(cnt & 0x01)
		GPIOA->ODR ^= GPIO_Pin_5; // toggle LED2

	standbyTest();
}
