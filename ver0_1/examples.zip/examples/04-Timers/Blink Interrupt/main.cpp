//
// Demonstrates using timer 2 interrupt to blink an LED on the OLIMEXINO board.
//

#include <codelatch.h>

#define LED 		LED1		// define our LED pin as LED1 on the OLIMEXINO board

// Timer 2 interrupt handler
void TIM2_IRQHandler(void)
{
	// if this interrupt was generated because of a timer rollover...
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		// clear the pending interrupt
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
		// toggle the led
		Pin.toggle(LED);
	}
}

int main(void)
{
	// set Timer 2 clock = 2000Hz, max cnt = 1000, so the rep rate is 1/2Hz
	timerInit(TIM2, 2000, 1000);
	// enable Timer 2 interrupt, with priority 1 and sub-priority 1
	timerEnableInterrupt(TIM2, 1, 1);
	
	Pin.mode(LED, OUTPUT);
	
	while (true)
	{
		// loop forever
	}
}
