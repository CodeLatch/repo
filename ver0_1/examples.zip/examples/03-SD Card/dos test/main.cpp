//
// Demonstrates terminal output.
//
#include <codelatch.h>

#define LED 3
u8 buf[512];

int main(void)
{	
	CSWSPI::SPIINTERFACE sd;
	CDos dos;
	
	sd.CSn = SD_CS;
	sd.MISO = SD_MISO;
	sd.MOSI = SD_MOSI;
	sd.SCK = SD_SCK;

	Pin.mode(LED,OUTPUT);

	Terminal.start();

	// if you want to make sure the computer catches the first text output then
	// you need to delay a bit to give the computer enough time to enumerate
	// the usb device (our microcontroller) before we start sending data.
	delay(500);

	u32 sector;
	CMMC mmc;
	
	u8 ret = mmc.init(0, &sd);
	if (ret != 0)
		Terminal.print("mmc init failed\n");

	mmc.sectorOffset = 0;

/*
Partition table records are at 0x1be, 0x1ce, 0x1de, 0x1ee
Look at 0x1c6, 0x1d6, 0x1e6, 0x1f6 for a 4byte word detailing the boot sector

Offset	Description												Size
0x00	 	0x80 if active (bootable), 0 otherwise	 				1
0x01	 	start of the partition in CHS-addressing	 				3
0x04	 	type of the partition, see below	 						1
0x05	 	end of the partition in CHS-addressing	 				3
0x08	 	relative offset to the partition in sectors (LBA)	 	4
0x0C	 	size of the partition in sectors	 						4
*/

	mmc.readsector(0,buf);

	Terminal.print("--------------------------\n");
	int cnt = 0;
	Terminal.print("00   ");
	for(int i=0; i<512;)
	{	
		Terminal.printf("%02x ",buf[i++]);
		cnt++;
		if(cnt == 16)
		{
			Terminal.print("\n");
			Terminal.printf("%02x   ",i);
			cnt = 0;
		}
	}
	Terminal.print("--------------------------\n");
	Terminal.print("00   ");
	for(int i=0; i<512;)
	{	
		u8 c = buf[i++];
		if((c > 31) && (c<127))
		Terminal.printf("%c",c);
		else Terminal.printf(".");
		cnt++;
		if(cnt == 16)
		{
			Terminal.print("\n");
			Terminal.printf("%02x   ",i);
			cnt = 0;
		}
	}
	Terminal.print("--------------------------\n");

	for(u32 offset=0x1be; offset <= 0x1ee; offset+=0x10)
	{
		u8* active = (u8*) &buf[offset];
		u8* type = (u8*) &buf[offset+4];
		u32* relOffset = (u32*) &buf[offset+8];
		u32* size = (u32*)& buf[offset+12];
		
		Terminal.print("--------------------------\n");
		Terminal.printf("active:0x%x\n",*active);
		Terminal.printf("type:0x%x\n",*type);
		Terminal.printf("relOffset:%u\n",*relOffset);
		Terminal.printf("size:%u\n",*size);
	}

	
	// search for the boot sector
	sector = 0;
	while (sector < 1024)
	{
		mmc.readsector(sector, buf);
		if (((memcmp(buf + 0x36, "FAT16", 5) == 0)
		        || (memcmp(buf + 0x52, "FAT32", 5) == 0))
		        && (buf[0x1fe] == 0x55) && (buf[0x1ff] == 0xaa))
		{
			// found boot sector
			Terminal.printf("found boot sector at %u\n",sector);
//			mmc.sectorOffset = sector;
		}
		sector++;
	}
	
	Terminal.print("Done.\n");
		
	while (true)
	{
		delay(200);
		Pin.toggle(LED);
	}
}
