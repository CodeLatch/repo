//
// Demonstrates terminal output.
//
#include <codelatch.h>

#define LED 3

int main(void)
{
	CSWSPI::SPIINTERFACE sd;
	MMCFILE file;
	CDos dos;
	
	sd.CSn = SD_CS;
	sd.MISO = SD_MISO;
	sd.MOSI = SD_MOSI;
	sd.SCK = SD_SCK;

	Pin.mode(LED,OUTPUT);

	Terminal.start();

	// if you want to make sure the computer catches the first text output then
	// you need to delay a bit to give the computer enough time to enumerate
	// the usb device (our microcontroller) before we start sending data.
	delay(500);

	int n = 32;
	double p = 23.432;
	Terminal.printf("Hello, the number is %d\n",n);
	Terminal.printf("int: %d hex: 0x%08x float: %f\n",n,n,p);
	
	dos.initialize(0,&sd);
		
	dos.open(&file,"log.txt",'a');
	//	dos.putStr("Hello\r\n",&file);
	// lets write a bunch of info
//	dos.putStr("Line in the file, this is just a bunch of text\n",&file);
	dos.fprintf(&file,"Line in the file, this is just a bunch of text\n");
/*
	MMCFILE dir;
	DIRENTRY entry;
	
	dos.InitDirectorySearch(&dir,1);
	while(dos.GetNextDirEntry(&dir,&entry,0xff) == DOS_SUCCESS)
	{
		Terminal.printf("----------------\n");
		Terminal.printf("attribute: %u\n",entry.attribute);
		Terminal.printf("cluster: %u\n",entry.cluster);
		Terminal.printf("date: 0x%x\n",entry.date);
		Terminal.printf("name: %s\n",entry.name);
		Terminal.printf("size: %u\n",entry.size);
		Terminal.printf("time: 0x%x\n",entry.time);
	}
*/	
	while (true)
	{
		delay(200);
		Pin.toggle(LED);
	}
}
